# TUTUP KAS · LION GROUP V4.1

Patch backend V4 untuk tujuan Google Sheets yang melebar horizontal: indeks struktur temporer, pembacaan target eksplisit, dan scan formula/struktur global dengan memori terbatas. Tujuan tidak lagi ditolak karena `rowCount × columnCount`. Aturan keuangan, koordinat absolut, Notes, proteksi tulis, laporan, source reader V4, UI, API, skema DB dan worker tetap dipertahankan.

198 tes backend lulus pada Python 3.10/3.12 dan 5 tes browser lulus. Probe tujuan 1.000 × 1.500 dengan seluruh blank terformat memakai peak proses 172,79 MiB pada RLIMIT_AS 1536 MiB. Ini benchmark offline dengan harness, bukan bukti produksi. Global scan tetap memerlukan banyak request; live Google/VPS masih pending. Lihat [TEST_REPORT.md](docs/TEST_REPORT.md), [PERFORMANCE_V41.md](docs/PERFORMANCE_V41.md) dan [SCOPE_V41.md](docs/SCOPE_V41.md).

**Untuk aplikasi V4 yang sudah terpasang:** ikuti [UPGRADE_V41.md](docs/UPGRADE_V41.md). ZIP berisi backend, frontend siap pakai, migrasi, pengujian, skrip backup/upgrade/rollback dan panduan. Node.js tidak diperlukan pada VPS saat memakai ZIP rilis.

## Perilaku finansial dan alur V3 yang dipertahankan

DOC DEPO dibaca langsung dari J/K/L untuk total deposit/WD/saldo, H biaya dan I kiriman; DOC QRIS memakai I/J/K, G biaya dan H fee/kiriman. Header sumber tidak menentukan posisi kolom. Deskripsi tetap D. Pemetaan tujuan tetap dinamis, tanpa konfigurasi huruf kolom tujuan. Hari yang terbukti kosong menghasilkan DEPO/WD nol serta carry-forward saldo, sementara missing date, nilai rusak dan error Google tetap gagal secara akurat.

Tanggal massal hanya mengendalikan Pratinjau Semua/Mulai Semua. Setiap baris WEB memiliki tanggal tersendiri dan status yang sesuai. Detail dan riwayat menyediakan Batalkan Antrean atau Stop Penarikan. Pembatalan menunggu batas aman dan verifikasi tulisan yang telah dikirim; hasil berhasil tetap tersimpan, job Dibatalkan tidak auto-resume, dan retry hanya mengulang item belum selesai. Unexpected error difinalkan sehingga tidak terjebak dalam restart loop.

## Alur harian

Konfigurasikan sumber dan satu URL salinan kerja tujuan per bulan → Validasi → Aktifkan sheet → Pilih tanggal massal atau individual → Pratinjau opsional → Mulai satu WEB atau Semua WEB → Tulis dan verifikasi → Baca laporan per WEB → Periksa konsolidasi → Selesai & Clear.

Penulisan berhasil berarti **Berhasil Ditulis**, belum otomatis KLOP. `Laporan deposit harian` hanya dibaca. BALANCE harus berupa angka tepat nol, tanpa toleransi pembulatan. Clear memerlukan seluruh WEB aktif selesai pada revisi sumber/tujuan saat ini, tulisan terverifikasi, tanpa kesalahan yang relevan, semua saldo WEB dan konsolidasi nol.

Simpan dan Validasi tidak menjalankan penarikan. URL baru mereset validasi, sumber baru mereset aktivasi sheet, dan hasil lama tetap menjadi riwayat. Gunakan **Crawl Ulang ke URL Baru** untuk tanggal/rentang yang dipilih eksplisit. Tidak ada pemilih TEST/produksi permanen. Data konfigurasi lama tetap dipertahankan; jika satu bulan mempunyai beberapa URL lama, admin memilih satu salinan kerja secara eksplisit.

## Upgrade VPS yang sudah berjalan

Unggah ZIP dan checksum melalui SFTP, ekstrak ke staging terpisah, baca migrasi/panduan, lalu dari folder hasil ekstrak:

```bash
sudo bash deploy/upgrade.sh
```

Skrip membackup DB/aplikasi/frontend, memeriksa skema yang sama, memfinalkan antrean lama sebagai Dibatalkan secara diaudit, memasang backend V4.1 dan memulai API saja. Worker tetap berhenti serta dinonaktifkan saat boot sampai penerimaan manual. Run #7, hasil sukses dan write intents tidak dihapus atau otomatis dijalankan ulang. MemoryMax, Nginx, HTTPS, akun, app.env serta key dipertahankan. [Panduan upgrade](docs/UPGRADE_V41.md) memuat PREVIEW VELBETT 18 Oktober, pemeriksaan intent, manual-start dan rollback. Footer frontend tetap v3.0 karena tidak ada perubahan UI.

## Pengembangan cloud/lokal

Python 3.10+ dan Node.js 22+. Gunakan checkout yang ada. Setiap tugas cloud sudah terisolasi; tidak perlu Git worktree tambahan.

```bash
bash scripts/dev-install.sh
cd backend
../.venv/bin/python -m app.cli create-admin namaadmin
TK_COOKIE_SECURE=false TK_APP_ORIGIN=http://127.0.0.1:5173 ../.venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Terminal lain: dari `backend`, jalankan `../.venv/bin/python -m app.worker`; dari `frontend`, jalankan `npm run dev`. SQLite lokal default di `backend/data/`. Key Google ditunjuk melalui `TK_CREDENTIAL_FILE`, tanpa menyalin isinya ke source. Tidak ada akun/password bawaan atau registrasi publik. Cookie non-Secure hanya untuk lokal; VPS memakai HTTPS.

## Verifikasi dan pembuatan paket

```bash
.venv/bin/pytest backend/tests -q
(cd backend && ../.venv/bin/alembic check)
npm --prefix frontend run build
PLAYWRIGHT_CHROMIUM_EXECUTABLE=/usr/bin/chromium bash scripts/e2e.sh
bash scripts/package.sh
```

E2E memerlukan port 8000/5173 kosong; ia memakai DB temporer dan admin acak. ZIP dibuat di `../tutupkas-lion-group-v4.1.zip` beserta `.sha256`, berisi source dan `public/`. Database, key nyata, password admin, `.env`, virtualenv, node_modules dan cache tidak disertakan. Sumber Sheets palsu hanya ada di kode test.

## Lokasi implementasi

| Area | Berkas |
|---|---|
| API dan konfigurasi | `backend/app/api.py`, `operations.py`, `workflow.py` |
| Batch dan pemulihan | `batches.py`, `worker.py`, `job_control.py` |
| Laporan hanya baca | `engine/report.py`, `reconciliation.py` |
| Ekstraksi/tulis aman | `engine/parser.py`, `resolver.py`, `runner.py`, `writer.py`, `sheets.py`, `source_reader.py`, `destination_reader.py` |
| History dan migrasi | `models.py`, `backend/migrations/` |
| UI dan panduan | `frontend/src/Dashboard.tsx`, `Settings.tsx`, `App.tsx`, `Help.tsx`, `help.ts` |
| Upgrade | `deploy/upgrade.sh`, `rollback.sh`, `docs/UPGRADE_V41.md` |

Rute lama `/tasks/1`, run dan Pusat Kesalahan tetap berfungsi; task_number tetap 1. Rute baru: `/tasks/1/batches/:id`, `/panduan`, `/panduan/:slug`. Task 02/03 tetap belum mempunyai executor. Lihat [ENGINE.md](docs/ENGINE.md), [IMPLEMENTATION.md](docs/IMPLEMENTATION.md), dan [TEST_REPORT.md](docs/TEST_REPORT.md).

Pengujian otomatis lokal tidak membuktikan integrasi workbook asli atau deployment VPS. Pengembang belum mengakses key Google/SSH VPS; pemeriksaan sebenarnya harus dijalankan pada konfigurasi Anda sesuai panduan upgrade.

Daftar perubahan V4.1: [RELEASE_NOTES_V41.md](docs/RELEASE_NOTES_V41.md). Laporan V4 dan V3 diarsipkan di [TEST_REPORT_V4.md](docs/TEST_REPORT_V4.md) dan [TEST_REPORT_V3.md](docs/TEST_REPORT_V3.md).
