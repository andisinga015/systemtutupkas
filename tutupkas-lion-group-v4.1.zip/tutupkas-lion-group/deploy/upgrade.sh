#!/usr/bin/env bash
# Upgrade v4 -> v4.1. Does not edit Nginx, certificates, app.env, or credentials.
set -euo pipefail
umask 027
[[ $EUID -eq 0 ]] || { echo 'Jalankan sudo bash deploy/upgrade.sh' >&2; exit 1; }
release_source=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
credential_path=/home/aksesfinancebot/spreadsheet-robot/credentials/robot-key.json
[[ -s "$release_source/public/index.html" && -d "$release_source/backend/migrations" ]] || { echo 'Gunakan ZIP rilis lengkap dengan public/index.html.' >&2; exit 1; }
[[ -d /opt/tutupkas/current/backend && -f /etc/tutupkas/app.env ]] || { echo 'Instalasi lama atau app.env tidak ditemukan. Ikuti docs/UPGRADE_V41.md.' >&2; exit 1; }
[[ -r "$credential_path" ]] || { echo 'Kredensial lama tidak ditemukan; isi key tidak akan diubah.' >&2; exit 1; }
for executable in python3 rsync tar curl runuser systemctl nginx; do command -v "$executable" >/dev/null; done
[[ $(systemctl show -p User --value tutupkas-api) == tutupkas && $(systemctl show -p User --value tutupkas-worker) == tutupkas ]] || { echo 'User layanan berbeda dari tutupkas. Sesuaikan panduan manual sebelum upgrade.' >&2; exit 1; }
for service in tutupkas-api tutupkas-worker; do
  [[ $(systemctl show -p WorkingDirectory --value "$service") == /opt/tutupkas/current/backend ]] || { echo "WorkingDirectory $service berbeda; periksa unit tanpa menggantinya." >&2; exit 1; }
  [[ $(systemctl show -p EnvironmentFiles --value "$service") == /etc/tutupkas/app.env\ * ]] || { echo "EnvironmentFile $service berbeda." >&2; exit 1; }
done
nginx -t
runuser -u tutupkas -- test -r "$credential_path"
release_name="v4.1-$(date -u +%Y%m%dT%H%M%S)-$$"
release_path="/opt/tutupkas/releases/$release_name"
backup_path="/var/lib/tutupkas/backups/upgrade-$release_name"
install -d -m 0755 /opt/tutupkas/releases "$release_path"
rsync -a --exclude='.git' --exclude='.venv' --exclude='.env*' --exclude='node_modules' --exclude='data' --exclude='__pycache__' --exclude='test-results' --exclude='playwright-report' "$release_source/" "$release_path/"
python3 -m venv "$release_path/.venv"
"$release_path/.venv/bin/python" -m pip install --require-hashes -r "$release_path/backend/requirements.txt"
chown -R root:tutupkas "$release_path"
chmod -R u=rwX,g=rX,o=rX "$release_path"
app_run() {
  runuser -u tutupkas -- bash -c 'set -a; source /etc/tutupkas/app.env; set +a; cd "$1/backend"; shift; exec "$@"' bash "$release_path" "$@"
}
app_run "$release_path/.venv/bin/python" -c 'import app.models, app.operations; print("Modul pembaruan dapat dimuat.")'
database_path=$(app_run "$release_path/.venv/bin/python" -c 'from app.config import settings; from pathlib import Path; u=settings().database_url; assert u.startswith("sqlite:////var/lib/tutupkas/"); print(Path(u[10:]).resolve())')
[[ "$database_path" == /var/lib/tutupkas/* && -f "$database_path" ]] || { echo 'Database lama tidak ditemukan di /var/lib/tutupkas. Dibatalkan.' >&2; exit 1; }
install -d -m 0700 -o tutupkas -g tutupkas "$backup_path"
printf '%s\n' "$database_path" > "$backup_path/database-path"
previous_release=$(readlink -f /opt/tutupkas/current)
printf '%s\n' "$previous_release" > "$backup_path/previous-release"
echo "Backup: $backup_path"
# Stop API first to prevent new requests, then let the worker finish its item.
systemctl stop tutupkas-api
systemctl stop tutupkas-worker
# Keep a reboot from silently activating held financial work during acceptance.
systemctl disable tutupkas-worker
trap 'echo "Upgrade terhenti. Backup: $backup_path. Lihat docs/UPGRADE_V41.md atau jalankan sudo bash $release_source/deploy/rollback.sh $backup_path" >&2' ERR
app_run "$release_path/.venv/bin/python" -m app.cli backup "$backup_path/database.sqlite3"
tar -C /opt/tutupkas/current -czf "$backup_path/application.tar.gz" .
tar -C /var/www/html -czf "$backup_path/frontend.tar.gz" .
cp -p /etc/tutupkas/app.env "$backup_path/app.env.backup"
chmod 0600 "$backup_path/app.env.backup"
app_run "$release_path/.venv/bin/alembic" current
app_run "$release_path/.venv/bin/alembic" upgrade head
app_run "$release_path/.venv/bin/alembic" check
# Never resume an unfinished V4 job (including Run #7) during the destination patch.
app_run "$release_path/.venv/bin/python" -m app.cli prepare-v41-upgrade --services-stopped
if [[ ! -L /opt/tutupkas/current ]]; then
  previous_release="/opt/tutupkas/releases/legacy-$release_name"
  mv /opt/tutupkas/current "$previous_release"
  printf '%s\n' "$previous_release" > "$backup_path/previous-release"
fi
ln -s "$release_path" /opt/tutupkas/current.next
mv -Tf /opt/tutupkas/current.next /opt/tutupkas/current
# Keep old hashed assets for cached pages and rollback. Publish HTML last.
rsync -a --exclude='index.html' "$release_path/public/" /var/www/html/
install -m 0644 "$release_path/public/index.html" "/var/www/html/index.html.$release_name"
mv -f "/var/www/html/index.html.$release_name" /var/www/html/index.html
nginx -t
systemctl start tutupkas-api
healthy=false
for attempt in {1..15}; do
  if curl --fail --silent http://127.0.0.1:8000/api/health >/dev/null; then healthy=true; break; fi
  sleep 2
done
[[ "$healthy" == true ]] || { echo 'API belum sehat; ikuti rollback sebelum menjalankan transaksi.' >&2; exit 1; }
trap - ERR
printf 'Upgrade selesai. Backup: %s\n' "$backup_path"
echo 'Worker tetap STOPPED dan dinonaktifkan saat boot. Tinjau antrean/intent, lalu ikuti PREVIEW dan manual-start pada docs/UPGRADE_V41.md. MemoryMax, Nginx, HTTPS, kredensial, akun, dan app.env dipertahankan.'
