import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, event
from sqlalchemy.orm import Session

from app.auth import hasher
from app.config import settings
from app.db import Base, get_db
from app.main import app
from app.models import User


@pytest.fixture
def db(tmp_path):
    engine = create_engine('sqlite:///' + str(tmp_path / 'test.sqlite'), connect_args={'check_same_thread': False})
    @event.listens_for(engine, 'connect')
    def fk(conn, _):
        conn.execute('PRAGMA foreign_keys=ON')
    Base.metadata.create_all(engine)
    with Session(engine, expire_on_commit=False) as session:
        session.add(User(username='finance', password_hash=hasher.hash('test-only-password-123')))
        session.commit()
        yield session
    engine.dispose()


@pytest.fixture
def client(db, monkeypatch):
    monkeypatch.setattr(settings(), 'cookie_secure', False)
    monkeypatch.setattr(settings(), 'app_origin', 'http://testserver')
    def override():
        try:
            yield db
        except Exception:
            db.rollback()
            raise
    app.dependency_overrides[get_db] = override
    with TestClient(app, raise_server_exceptions=False) as c:
        yield c
    app.dependency_overrides.clear()


@pytest.fixture
def logged(client):
    token = client.get('/api/auth/csrf').json()['csrf_token']
    response = client.post('/api/auth/login', json={'username': 'finance', 'password': 'test-only-password-123'},
                            headers={'x-csrf-token': token})
    assert response.status_code == 200, response.text
    client.headers['x-csrf-token'] = response.json()['csrf_token']
    return client


@pytest.fixture(autouse=True)
def fast_report_checks(monkeypatch):
    monkeypatch.setattr(settings(), 'reconciliation_delay', 0)
