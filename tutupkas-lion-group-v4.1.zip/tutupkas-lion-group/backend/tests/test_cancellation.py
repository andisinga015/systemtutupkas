from uuid import uuid4

import pytest
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.batches import process_batch
from app.db import utcnow
from app.engine.runner import process_run
from app.job_control import request_run_cancel, request_batch_cancel
from app.models import BatchEntry,CrawlBatch,Run,RunItem,TaskError,WriteLedger
from app.worker import recover_jobs
from app.workflow import lock_date
from helpers import DAY
from test_engine import configured,start
from test_reconciliation import add_second


def cancel_other(db,id,batch=False):
    with Session(db.get_bind()) as other:
        obj=other.get(CrawlBatch if batch else Run,id)
        lock_date(other,obj.selected_date)
        (request_batch_cancel if batch else request_run_cancel)(other,obj,1)
        other.commit()


def test_cancel_queued_authenticated_idempotent_and_never_resumes(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);r=start(logged,w)
    assert logged.post(f"/api/runs/{r['id']}/cancel",headers={'x-csrf-token':'wrong'}).status_code==403
    response=logged.post(f"/api/runs/{r['id']}/cancel")
    assert response.status_code==200 and response.json()['status']=='CANCELED'
    assert logged.post(f"/api/runs/{r['id']}/cancel").json()['status']=='CANCELED'
    recover_jobs(db);process_run(db,db.get(Run,r['id']),fake)
    assert not fake.reads and not fake.writes
    assert all(i.status=='CANCELED' for i in db.scalars(select(RunItem).where(RunItem.run_id==r['id'])))
    assert logged.post(f"/api/runs/{r['id']}/clear").status_code==409
    new=start(logged,w);assert new['id']!=r['id']


@pytest.mark.parametrize('preview',[False,True])
def test_stop_during_read_starts_no_further_items(logged,db,monkeypatch,tmp_path,preview):
    w,fake=configured(logged,db,monkeypatch,tmp_path);r=start(logged,w,preview=preview)
    original=fake.grid;once=[False]
    def grid(*args):
        result=original(*args)
        if not once[0]:once[0]=True;cancel_other(db,r['id'])
        return result
    fake.grid=grid
    process_run(db,db.get(Run,r['id']),fake)
    assert db.get(Run,r['id']).status=='CANCELED'
    assert len(fake.reads)==1 and not fake.writes and not list(db.scalars(select(WriteLedger)))


def test_stop_during_submitted_write_verifies_then_preserves_partial_results(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);r=start(logged,w)
    original=fake.write;once=[False]
    def write(*args):
        original(*args)
        if not once[0]:
            once[0]=True;cancel_other(db,r['id'])
            request={'website_id':w['id'],'selected_date':str(DAY),'idempotency_key':str(uuid4())}
            assert logged.post('/api/runs',json=request).status_code==409
    fake.write=write
    process_run(db,db.get(Run,r['id']),fake)
    detail=logged.get(f"/api/runs/{r['id']}").json()
    assert detail['status']=='CANCELED' and not detail['date_status']['eligible']
    successful=[i['id'] for i in detail['items'] if i['status']=='SUCCESS']
    assert successful and all(l.verification_status=='VERIFIED' for l in db.scalars(select(WriteLedger)))
    first_write=fake.writes[0]
    fake.write=original
    assert logged.post(f"/api/runs/{r['id']}/retry",json={}).status_code==202
    before=len(fake.writes);process_run(db,db.get(Run,r['id']),fake)
    assert db.get(Run,r['id']).status=='SUCCESS'
    assert not any(w.tab==first_write.tab and w.address==first_write.address for w in fake.writes[before:])
    assert db.get(RunItem,successful[0]).status=='SUCCESS'


def test_uncertain_write_keeps_prepared_intent_and_can_be_retried(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);r=start(logged,w)
    original=fake.write
    def write(*args):
        original(*args);cancel_other(db,r['id']);raise ConnectionError('uncertain transport')
    fake.write=write
    process_run(db,db.get(Run,r['id']),fake)
    assert db.get(Run,r['id']).status=='CANCELED'
    assert db.scalar(select(WriteLedger)).verification_status=='PREPARED'
    assert db.scalar(select(TaskError)).error_code=='WRITE_FAILURE'
    fake.write=original
    assert logged.post(f"/api/runs/{r['id']}/retry",json={}).status_code==202
    process_run(db,db.get(Run,r['id']),fake)
    assert db.get(Run,r['id']).status=='SUCCESS'
    assert all(l.verification_status=='VERIFIED' for l in db.scalars(select(WriteLedger)))


def batch_start(logged):
    response=logged.post('/api/batches',json={'selected_date':str(DAY),'idempotency_key':str(uuid4())})
    assert response.status_code==202,response.text
    return response.json()


def test_queued_batch_cancel_preserves_children_and_preview_is_read_only(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);add_second(logged,fake)
    b=batch_start(logged)
    assert logged.post(f"/api/batches/{b['id']}/cancel").json()['status']=='CANCELED'
    recover_jobs(db);process_batch(db,db.get(CrawlBatch,b['id']),fake)
    assert not fake.writes and not fake.reads
    assert all(r.status=='CANCELED' for r in db.scalars(select(Run)))


def test_running_batch_stop_and_selective_retry_do_not_replay_success(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);second=add_second(logged,fake)
    b=batch_start(logged);original=fake.write;once=[False]
    def write(*args):
        original(*args)
        if not once[0]:once[0]=True;cancel_other(db,b['id'],True)
    fake.write=write
    process_batch(db,db.get(CrawlBatch,b['id']),fake)
    result=logged.get(f"/api/batches/{b['id']}").json()
    assert result['status']=='CANCELED' and result['canceled']==2
    assert all(e['reconciliation_status']!='BALANCED' for e in result['entries'])
    fake.write=original
    assert logged.post(f"/api/batches/{b['id']}/retry",json={'website_id':w['id']}).status_code==202
    process_batch(db,db.get(CrawlBatch,b['id']),fake)
    assert db.get(CrawlBatch,b['id']).status=='PARTIAL'
    assert logged.post(f"/api/batches/{b['id']}/retry",json={'website_id':second['id']}).status_code==202
    process_batch(db,db.get(CrawlBatch,b['id']),fake)
    result=logged.get(f"/api/batches/{b['id']}").json()
    assert result['status']=='SUCCESS' and result['date_status']['eligible']


def test_cancel_requested_survives_worker_restart(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);r=start(logged,w)
    run=db.get(Run,r['id']);run.status='RUNNING';db.commit();cancel_other(db,run.id)
    recover_jobs(db);db.refresh(run)
    assert run.status=='CANCELED'
    process_run(db,run,fake)
    assert not fake.reads and not fake.writes


def test_reconciliation_exception_finalizes_and_retry_does_not_write_again(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);r=start(logged,w)
    from app import reconciliation
    original=reconciliation.reconcile_website
    monkeypatch.setattr(reconciliation,'reconcile_website',lambda *args,**kwargs:(_ for _ in ()).throw(RuntimeError('unexpected')))
    process_run(db,db.get(Run,r['id']),fake)
    assert db.get(Run,r['id']).status=='PARTIAL'
    assert not list(db.scalars(select(RunItem).where(RunItem.run_id==r['id'],RunItem.status=='PENDING')))
    writes=len(fake.writes)
    monkeypatch.setattr(reconciliation,'reconcile_website',original)
    assert logged.post(f"/api/runs/{r['id']}/retry",json={}).status_code==202
    process_run(db,db.get(Run,r['id']),fake)
    assert db.get(Run,r['id']).status=='SUCCESS' and len(fake.writes)==writes


def test_cancel_recheck_does_not_cancel_verified_financial_run(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);r=start(logged,w)
    process_run(db,db.get(Run,r['id']),fake);writes=len(fake.writes)
    response=logged.post(f"/api/runs/{r['id']}/reconcile",json={}).json()
    b=db.get(CrawlBatch,response['id'])
    assert logged.post(f'/api/batches/{b.id}/cancel').status_code==200
    process_batch(db,b,fake)
    assert db.get(Run,r['id']).status=='SUCCESS' and len(fake.writes)==writes
    state=logged.get('/api/reconciliations/date',params={'selected_date':str(DAY)}).json()
    assert not state['eligible']


def test_stop_recheck_during_consolidation_never_reuses_old_green(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);r=start(logged,w)
    process_run(db,db.get(Run,r['id']),fake);writes=len(fake.writes)
    response=logged.post(f"/api/runs/{r['id']}/reconcile",json={}).json();b=db.get(CrawlBatch,response['id'])
    original=fake.grid;report_reads=[0]
    def grid(*args):
        result=original(*args)
        if args[1]=='Laporan deposit harian':
            report_reads[0]+=1
            if report_reads[0]==3:cancel_other(db,b.id,True)
        return result
    fake.grid=grid
    process_batch(db,b,fake);recover_jobs(db)
    assert db.get(CrawlBatch,b.id).status=='CANCELED' and db.get(Run,r['id']).status=='SUCCESS'
    assert len(fake.writes)==writes
    state=logged.get('/api/reconciliations/date',params={'selected_date':str(DAY)}).json()
    assert not state['eligible'] and state['consolidated']['status']=='CANCELED'
    assert logged.post(f"/api/runs/{r['id']}/clear").status_code==409


def test_unexpected_batch_exception_finalizes_queue_and_does_not_loop(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);b=batch_start(logged)
    monkeypatch.setattr('app.batches.process_run',lambda *args:(_ for _ in ()).throw(RuntimeError('unexpected worker failure')))
    process_batch(db,db.get(CrawlBatch,b['id']),fake)
    assert db.get(CrawlBatch,b['id']).status=='FAILED'
    assert all(r.status=='FAILED' for r in db.scalars(select(Run)))
    recover_jobs(db)
    assert not list(db.scalars(select(Run).where(Run.status.in_(['RUNNING','QUEUED']))))
