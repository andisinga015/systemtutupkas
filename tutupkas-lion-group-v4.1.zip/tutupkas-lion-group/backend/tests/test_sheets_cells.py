import pytest

from app.engine.types import Cell, Issue, Write
from app.sheets import google_cell, spreadsheet_id


def test_empty_string_roundtrip_is_equivalent_but_formula_stays_protected():
    assert google_cell({}).snapshot == Write('fee',1,1,'').proposed
    cell=google_cell({'userEnteredValue':{'formulaValue':'=""'},'effectiveValue':{'stringValue':''}})
    assert not cell.empty
    assert cell.formula=='=""'


def test_real_cell_metadata_keeps_zero_note_date_and_resolved_color():
    cell=google_cell({'effectiveValue':{'numberValue':0},'note':'manual',
                     'effectiveFormat':{'numberFormat':{'type':'DATE'},'backgroundColorStyle':{'rgbColor':{'red':1,'green':.6}}}})
    assert cell.value==0 and not cell.empty
    assert cell.color==(1.,.6,0.) and cell.date_format and cell.note=='manual'


@pytest.mark.parametrize('url',[
    'http://docs.google.com/spreadsheets/d/abc123456789012345/edit',
    'https://docs.google.com.evil.example/spreadsheets/d/abc123456789012345/edit',
    'https://user:password@docs.google.com/spreadsheets/d/abc123456789012345/edit',
    'https://docs.google.com/not-a-sheet',
])
def test_url_cannot_redirect_credentialed_requests(url):
    with pytest.raises(Issue):
        spreadsheet_id(url)



def test_report_write_rejected_before_http():
    import pytest
    from app.sheets import SheetsClient
    from app.engine.types import Grid, Write, Issue
    client=object.__new__(SheetsClient)
    calls=[]
    client.request=lambda *args,**kwargs:calls.append(args)
    with pytest.raises(Issue) as error:
        client.write('destination',Grid('Laporan deposit harian',1,[]),[Write('Laporan deposit harian',2,3,0)])
    assert error.value.code=='READ_ONLY_REPORT' and calls==[]


@pytest.mark.parametrize('method',['GET','POST'])
def test_get_retry_can_stop_but_submitted_write_retry_stays_bounded(method,monkeypatch):
    from app.config import settings
    from app.job_control import JobCanceled
    from app.sheets import SheetsClient
    monkeypatch.setattr(settings(),'google_min_interval',0)
    monkeypatch.setattr('app.sheets.time.sleep',lambda _:None)
    client=object.__new__(SheetsClient);client.last_request=0
    calls=[]
    def cancel():
        if calls: raise JobCanceled()
    client.cancel_check=cancel
    class Reply:
        def __init__(self,code):self.ok=code==200;self.status_code=code
        def iter_content(self,**kwargs):yield b'{"ok":true}'
        def close(self):pass
    class Session:
        def request(self,*args,**kwargs):
            calls.append(args);return Reply(503 if len(calls)==1 else 200)
    client.session=Session()
    if method=='GET':
        with pytest.raises(JobCanceled):client.request(method,'id')
        assert len(calls)==1
    else:
        assert client.request(method,'id')['ok'] and len(calls)==2
