from copy import deepcopy
from datetime import date

from app.engine.types import Cell, Grid, Issue

DAY = date(2026, 10, 15)
BROWN = (1.0, 0.6, 0.0)
BLUE = (0.0, 1.0, 1.0)
PALETTE = {'approved_brown': [list(BROWN)], 'excluded_blue': [list(BLUE)]}
DEPO_NAME = 'WD BCA 1 TOKEN / IVAN RAKHMANDA ( PP )'


def blank(title, rows, columns, sheet_id=1):
    return Grid(title, sheet_id, [[Cell() for _ in range(columns)] for _ in range(rows)])


def put(grid, row, col, value, **kwargs):
    grid.rows[row][col] = Cell(value, **kwargs)


def marker(grid, row, day):
    put(grid, row, 0, day.strftime('%A, %d %B %Y'), color=(0., 0., 0.))
    grid.merges.append({'startRowIndex': row, 'endRowIndex': row+1, 'startColumnIndex': 0, 'endColumnIndex': 9})


def depo():
    g = blank(DEPO_NAME, 308, 13)
    for c, h in enumerate(['', 'Jam', 'User', DEPO_NAME, 'DEPO', 'WD', 'CEK SALDO', 'DLL', 'Kiriman', 'Total', 'Total WD', 'SALDO', 'BALANCE']):
        put(g, 1, c, h)
    marker(g, 290, DAY.replace(day=15))
    put(g, 291, 3, 'PENGIRIMAN DARI KAS BESAR BCA', color=BROWN)
    put(g, 291, 8, 10000000)
    put(g, 292, 3, 'KIRIM KE NL KAS BCA', color=BROWN)
    put(g, 292, 8, -1741000)
    put(g, 293, 3, 'DARI BCA', color=BLUE)
    put(g, 293, 8, 500000)
    put(g, 305, 3, 'WINDA S')
    put(g, 305, 7, -6500)
    put(g, 304, 7, 1000)
    for c, v in [(9, 0), (10, 9399000), (11, 2355000)]:
        put(g, 305, c, v)
    marker(g, 306, DAY.replace(day=16))
    marker(g, 307, DAY.replace(day=17))
    return g


def qris(name='QRIS E-POWER'):
    g = blank(name, 90, 11)
    for c, h in enumerate(['', 'Jam', 'User', name, 'DEPO', 'WD', 'DLL', 'Kiriman', 'Total Depo', 'Total WD', 'SALDO']):
        put(g, 1, c, h)
    marker(g, 83, DAY)
    put(g, 84, 3, name)
    put(g, 84, 4, 75342988)
    if name == 'QRIS E-POWER':
        put(g, 85, 3, 'KIRIM KE KAS BESAR BRI', color=BROWN)
        put(g, 85, 7, -1000000)
        put(g, 86, 3, 'FEE WD AUTO')
        put(g, 86, 7, -732340)
        put(g, 87, 6, -492000)
    else:
        put(g, 85, 3, 'FEE QRIS PERIODE 14 - 15 october 2026')
        put(g, 85, 7, -621134)
        put(g, 87, 6, -5000)
    put(g, 87, 3, 'BIAYA')
    for c, v in [(8, 75342988), (9, 59804000), (10, 449057834)]:
        put(g, 87, c, v)
    marker(g, 88, DAY.replace(day=16))
    marker(g, 89, DAY.replace(day=17))
    return g


def regular_destination(title, labels):
    g = blank(title, 4, len(labels)+4, 100)
    put(g, 0, 0, 'VELBETT')
    put(g, 0, len(labels)+2, 'FANTASI')
    put(g, 2, 0, '15-Oct-2026')
    put(g, 2, len(labels)+2, '15-Oct-2026')
    put(g, 2, len(labels)+3, 777)
    for c, label in enumerate(labels, 1):
        put(g, 1, c, label)
    put(g, 1, len(labels)+1, 'TOTAL')
    put(g, 2, len(labels)+1, 0, formula='=SUM(B3:C3)')
    return g


def destinations():
    out = {title: regular_destination(title, ['IVAN RAKHMANDA', 'QRIS E-POWER', 'QRIS QRIZZ'])
           for title in ['TOTAL DEPO', 'TOTAL WD', 'SALDO BANK']}
    out['BIAYA'] = regular_destination('BIAYA', ['BIAYA', 'BIAYA TARIK QRIS', 'BIAYA AUTO WD'])
    for kind in ['DEPO', 'WD']:
        name = 'Pengeluaran FEE QRIS ' + kind
        out[name] = regular_destination(name, ['KETERANGAN', 'FEE QRIS ' + kind])
    g = blank('KET PENGIRIMAN', 8, 8, 200)
    put(g, 0, 0, '15-Oct-2026')
    g.merges.append({'startRowIndex': 0, 'endRowIndex': 1, 'startColumnIndex': 0, 'endColumnIndex': 8})
    put(g, 1, 0, 'VELBETT')
    for c, bank in enumerate(['BCA', 'MANDIRI', 'BRI', 'BNI']):
        put(g, 2, c*2, bank)
        g.merges.append({'startRowIndex': 2, 'endRowIndex': 3, 'startColumnIndex': c*2, 'endColumnIndex': c*2+2})
        put(g, 6, c*2, 'TOTAL')
        put(g, 6, c*2+1, 0, formula='=SUM(B4:B6)')
    out[g.title] = g
    out['Laporan deposit harian'] = report()
    return out


class FakeSheets:
    def __init__(self):
        self.documents = {'depo-document-12345': {DEPO_NAME: depo()},
                          'qris-document-12345': {n: qris(n) for n in ['QRIS E-POWER', 'QRIS QRIZZ']},
                          'destination-copy-12345': destinations()}
        self.reads, self.writes = [], []
        self.fail_tabs = set()
        self.corrupt_readback = False

    def metadata(self, id):
        if id not in self.documents:
            raise Issue('SPREADSHEET_MISSING', 'Spreadsheet tidak ditemukan.')
        return {'properties': {'title': id}, 'sheets': [{'properties': {'sheetId': i, 'title': name}}
                for i, name in enumerate(self.documents[id])]}

    def grid(self, id, title):
        self.reads.append((id, title))
        if title in self.fail_tabs:
            raise Issue('GOOGLE_TIMEOUT', 'Google tidak merespons.')
        try:
            return deepcopy(self.documents[id][title])
        except KeyError:
            raise Issue('TAB_MISSING', 'Sheet tidak ditemukan.')

    def destination_grid(self,id,title,registered=()):
        return self.grid(id,title)

    def source_day(self, id, title, selected, kind):
        from app.engine.parser import Day
        return Day.resolve(self.grid(id,title),selected,kind)

    def write(self, id, grid, writes):
        self.writes.extend(deepcopy(writes))
        target = self.documents[id][grid.title]
        for w in writes:
            put(target, w.row, w.col, w.value, note=w.note or '', color=target.cell(w.row, w.col).color)
        if self.corrupt_readback:
            target.rows[writes[0].row][writes[0].col].value = 'changed'



def report(websites=('VELBETT', 'FANTASI', 'BBTOTO'), balances=None, consolidated=0):
    headers = ['Tanggal','DEPOSIT','WITHDRAW','HASIL','ADMIN BCA','ADMIN MANDIRI','ADMIN BRI','ADMIN BNI','TOTAL SALDO BANK','BALANCE']
    g = blank('Laporan deposit harian', 8, (len(websites)+1)*13)
    for index, name in enumerate([None, *websites]):
        offset = index*13
        if name:
            put(g, 0, offset, name)
        for c, label in enumerate(headers+([] if name else ['STATUS','KETERANGAN'])):
            put(g, 1, offset+c+1, label)
        if name is None:
            put(g,2,offset+11,'STATUS MANUAL',color=(0.2,0.4,0.6))
            put(g,2,offset+12,'KETERANGAN MANUAL',note='Tetap',color=(0.8,0.3,0.2))
        put(g, 2, offset+1, '15-Oct-2026')
        put(g, 2, offset+10, (balances or {}).get(name,0) if name else consolidated,
            formula='=SUM(A1:A2)', note='Laporan manual: jangan diubah')
    return g
