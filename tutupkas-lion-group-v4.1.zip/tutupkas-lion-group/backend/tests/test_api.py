from datetime import timedelta

from sqlalchemy import select

from app.db import utcnow
from app.models import AuthSession, Website
from helpers import FakeSheets


def test_unauthorized_and_csrf(client):
    assert client.get('/api/websites').status_code == 401
    assert client.post('/api/auth/login', json={'username':'finance','password':'bad'}).status_code == 403


def test_invalid_password_login_and_logout(client, logged):
    assert logged.get('/api/auth/me').json()['username'] == 'finance'
    assert logged.post('/api/auth/logout').status_code == 200
    assert logged.get('/api/websites').status_code == 401
    token = client.get('/api/auth/csrf').json()['csrf_token']
    result=client.post('/api/auth/login', json={'username':'finance','password':'bad'}, headers={'x-csrf-token':token})
    assert result.status_code == 401


def test_expiration(logged, db):
    session = db.scalar(select(AuthSession))
    session.expires_at = utcnow()-timedelta(seconds=1)
    db.commit()
    assert logged.get('/api/websites').status_code == 401


def test_login_rate_limit(client):
    csrf = client.get('/api/auth/csrf').json()['csrf_token']
    for _ in range(8):
        assert client.post('/api/auth/login',json={'username':'finance','password':'bad'},headers={'x-csrf-token':csrf}).status_code==401
    assert client.post('/api/auth/login',json={'username':'finance','password':'bad'},headers={'x-csrf-token':csrf}).status_code==429


def test_csrf_and_origin(logged):
    assert logged.post('/api/websites',json={'display_name':'VELBETT','slug':'velbett'},headers={'x-csrf-token':'bad'}).status_code==403
    assert logged.post('/api/websites',json={'display_name':'VELBETT','slug':'velbett'},headers={'origin':'https://evil.example'}).status_code==403


def test_website_lifecycle(logged):
    result=logged.post('/api/websites',json={'display_name':'VELBETT','slug':'velbett'})
    assert result.status_code==201,result.text
    id=result.json()['id']
    assert logged.get('/api/websites/velbett').json()['id']==id
    assert logged.patch(f'/api/websites/{id}',json={'display_name':'VELBETT BARU','is_active':False}).status_code==200
    assert logged.get('/api/websites/velbett').json()['display_name']=='VELBETT BARU'
    assert logged.post('/api/websites',json={'display_name':'Duplicate','slug':'velbett'}).status_code==409
    assert logged.patch(f'/api/websites/{id}',json={'is_archived':True}).status_code==200
    assert logged.get('/api/websites').json()==[]
    assert len(logged.get('/api/websites?status=archived').json())==1


def setup_docs(logged, monkeypatch):
    fake=FakeSheets()
    monkeypatch.setattr('app.api.SheetsClient',lambda:fake)
    site=logged.post('/api/websites',json={'display_name':'VELBETT','slug':'velbett'}).json()
    doc=logged.put(f"/api/websites/{site['id']}/sources",json={'year':2026,'month':10,'document_type':'DEPO',
        'spreadsheet_url':'https://docs.google.com/spreadsheets/d/depo-document-12345/edit'}).json()
    return fake,site,doc


def test_months_revisions_validation_tabs(logged,monkeypatch):
    fake,site,doc=setup_docs(logged,monkeypatch)
    id=doc['id']
    assert logged.post(f'/api/sources/{id}/validate').json()['document']['validation_status']=='VALID'
    tabs=logged.get(f'/api/sources/{id}/tabs').json()
    assert len(tabs)==1 and not tabs[0]['is_active']
    assert logged.post(f'/api/sources/{id}/tabs',json={'ids':[tabs[0]['id']],'is_active':True}).status_code==200
    grid=fake.documents['depo-document-12345'].pop(tabs[0]['tab_name'])
    fake.documents['depo-document-12345']['RENAMED TAB']=grid
    refreshed=logged.post(f'/api/sources/{id}/tabs/refresh').json()
    assert not next(t for t in refreshed if t['tab_name']=='RENAMED TAB')['is_active']
    assert not next(t for t in refreshed if t['tab_name']==tabs[0]['tab_name'])['is_available']
    november=logged.put(f"/api/websites/{site['id']}/sources",json={'year':2026,'month':11,'document_type':'DEPO',
        'spreadsheet_url':'https://docs.google.com/spreadsheets/d/depo-document-12345/edit'}).json()
    assert november['id']!=id
    assert logged.get(f"/api/websites/{site['id']}/sources?year=2026&month=10").json()[0]['validation_status']=='VALID'
    replacement=logged.put(f"/api/websites/{site['id']}/sources",json={'year':2026,'month':10,'document_type':'DEPO',
        'spreadsheet_url':'https://docs.google.com/spreadsheets/d/replacement-doc-12345/edit'}).json()
    assert replacement['validation_status']=='UNVALIDATED'
    assert len(logged.get(f'/api/sources/{id}/history').json())==2
    assert logged.get(f'/api/sources/{id}/tabs').json()==[]


def test_single_destination_ignores_legacy_environment(logged):
    body={'year':2026,'month':10,'environment':'TEST','spreadsheet_url':'https://docs.google.com/spreadsheets/d/destination-copy-12345/edit'}
    first=logged.put('/api/destinations',json=body)
    assert first.status_code==200
    second=logged.put('/api/destinations',json={**body,'environment':'PRODUCTION'})
    assert second.status_code==200 and second.json()['id']==first.json()['id']
    assert len(logged.get('/api/destinations').json())==1
    assert logged.put('/api/destinations',json={**body,'spreadsheet_url':'https://evil.example/spreadsheets/d/destination-copy-12345/edit'}).status_code==422

