from datetime import date
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys

import pytest
from sqlalchemy import select

from app.config import settings
from app.engine.parser import Day, transfer_rows
from app.engine.types import Cell, Issue
from app.engine.runner import process_run
from app.job_control import JobCanceled
from app.models import Run, RunItem, WriteLedger
from app.sheets import SheetsClient
from app.worker import recover_jobs
from helpers import DAY, PALETTE, depo, qris, marker, put
from range_api import RangeAPI
from test_engine import configured, start
from test_v3_source import empty_october18


def outcomes(day,kind):
    return {'metrics':[day.metric(x) for x in ['Total','Total WD','SALDO']],
            'signed':day.signed_sum(7 if kind=='DEPO' else 6),
            'depo_fee':day.fees('FEE QRIS PERIODE'),'wd_fee':day.fees('FEE WD AUTO'),
            'transfers':transfer_rows(day,kind,PALETTE),
            'bounds':[day.start,day.end,day.transaction_rows]}


@pytest.mark.parametrize('factory,kind,selected',[(depo,'DEPO',DAY),(qris,'QRIS',DAY),
    (lambda:qris('QRIS QRIZZ'),'QRIS',DAY),(empty_october18,'DEPO',date(2026,10,18))])
def test_bounded_reads_match_v3_financial_parser(factory,kind,selected):
    grid=factory();api=RangeAPI(grid)
    old=Day.resolve(deepcopy(grid),selected,kind)
    new=api.source_day('source',grid.title,selected,kind)
    assert outcomes(new,kind)==outcomes(old,kind)
    assert api.largest<100_000
    for path,p in api.calls:
        if 'ranges' not in p:continue
        for a1 in p['ranges']:
            first,last,left,right=api.decode(a1)
            assert last-first+1<=settings().source_chunk_rows
            if p.get('includeGridData')=='true':
                assert first==last and left==right
                assert 'note' not in p['fields'] and 'userEnteredValue' not in p['fields']


@pytest.mark.parametrize('fault',['missing','duplicate','wrong_order','numeric_date','other_numeric_date','invalid_saldo','formula_error','blue','multi_fee'])
def test_dates_errors_colors_and_fees_preserve_v3(fault):
    g=qris('QRIS QRIZZ') if fault=='multi_fee' else depo()
    if fault=='missing':put(g,306,0,None)
    if fault=='duplicate':marker(g,200,DAY)
    if fault=='wrong_order':marker(g,295,date(2026,10,20))
    if fault=='numeric_date':
        for r,d in [(290,DAY),(306,date(2026,10,16))]:
            put(g,r,0,(d-date(1899,12,30)).days,date_format=True,color=(0,0,0))
    if fault=='other_numeric_date':put(g,295,0,0,date_format=True,color=(0,0,0))
    if fault=='invalid_saldo':put(g,305,11,'not money')
    if fault=='formula_error':put(g,305,9,'#REF!')
    if fault=='blue':put(g,291,3,'DARI KAS BCA',color=(0,1,1))
    if fault=='multi_fee':put(g,86,3,'FEE QRIS PERIODE 15 october 2026');put(g,86,7,-100)
    kind='QRIS' if fault=='multi_fee' else 'DEPO'
    api=RangeAPI(g)
    try:old=outcomes(Day.resolve(g,DAY,kind),kind)
    except Issue as error:
        with pytest.raises(Issue) as caught:outcomes(api.source_day('source',g.title,DAY,kind),kind)
        assert caught.value.code==error.code
    else:assert outcomes(api.source_day('source',g.title,DAY,kind),kind)==old


def test_boundary_is_revalidated_and_source_cancel_checked():
    g=depo();api=RangeAPI(g)
    from app.source_reader import SourceReader
    original=SourceReader.formatted
    # Last request for two anchors happens after scoped source data/format reads.
    anchor_reads=[0]
    def mutated(self,positions,fields,with_merges=False):
        if positions==[(290,0),(306,0)]:
            anchor_reads[0]+=1
            if anchor_reads[0]==2:put(g,306,0,'17-Oct-2026',color=(0,0,0))
        yield from original(self,positions,fields,with_merges)
    from unittest.mock import patch
    with patch.object(SourceReader,'formatted',mutated),pytest.raises(Issue) as caught:
        api.source_day('source',g.title,DAY,'DEPO')
    assert caught.value.code=='SOURCE_CHANGED'
    api.cancel_check=lambda:(_ for _ in ()).throw(JobCanceled())
    with pytest.raises(JobCanceled):api.source_day('source',g.title,DAY,'DEPO')


def test_source_and_destination_limits_fail_before_large_allocation(monkeypatch):
    api=RangeAPI(history=200000)
    with pytest.raises(Issue) as caught:api.source_day('source',api.fixture.title,DAY,'DEPO')
    assert caught.value.code=='SOURCE_RESOURCE_LIMIT' and api.count==1
    api=RangeAPI();monkeypatch.setattr(settings(),'max_source_day_cells',10)
    with pytest.raises(Issue) as caught:api.source_day('source',api.fixture.title,DAY,'DEPO')
    assert caught.value.code=='SOURCE_RESOURCE_LIMIT'
    monkeypatch.setattr(settings(),'max_destination_cells',10)
    api=RangeAPI()
    view=api.grid('destination',api.fixture.title)
    assert view.width==api.fixture.width  # Allocated-product guard is obsolete.
    view.close()


def test_destination_bands_keep_every_mapping_formula_note_color_and_merge(monkeypatch):
    from helpers import destinations
    monkeypatch.setattr(settings(),'grid_chunk_cells',12)
    monkeypatch.setattr(settings(),'source_chunk_rows',3)
    for g in destinations().values():
        api=RangeAPI(g);actual=api.grid('dest',g.title)
        assert actual.merges==g.merges
        assert [ [actual.cell(r,c).snapshot for c in range(g.width)] for r in range(len(g.rows)) ]==[
            [cell.snapshot for cell in row] for row in g.rows]
        for _,p in api.calls:
            for a1 in p.get('ranges',[]):
                first,last,left,right=api.decode(a1)
                assert (last-first+1)*(right-left+1)<=12


def test_large_http_body_is_stopped_while_streaming_and_closed(monkeypatch):
    monkeypatch.setattr(settings(),'max_api_response_bytes',100)
    monkeypatch.setattr(settings(),'google_min_interval',0)
    class Reply:
        ok=True;closed=False
        def iter_content(self,**kwargs):
            yield b' '*80;yield b' '*80
            pytest.fail('Body must not be consumed after size cap')
        def close(self):self.closed=True
    reply=Reply()
    class Session:
        def request(self,*args,**kwargs):
            assert kwargs['stream'] is True and kwargs['timeout']==settings().request_timeout
            return reply
    api=object.__new__(SheetsClient);api.session=Session();api.last_request=0;api.cancel_check=lambda:None
    with pytest.raises(Issue) as caught:api.request('GET','doc')
    assert caught.value.code=='RESPONSE_TOO_LARGE' and reply.closed


def test_stream_disconnect_retries_with_bound_and_releases_old_response(monkeypatch):
    import requests
    monkeypatch.setattr(settings(),'google_min_interval',0)
    monkeypatch.setattr('app.sheets.time.sleep',lambda _:None)
    class Reply:
        ok=True;closed=False
        def __init__(self,fail):self.fail=fail
        def iter_content(self,**kwargs):
            if self.fail:raise requests.ConnectionError('test disconnected body')
            yield b'{"ok":true}'
        def close(self):self.closed=True
    replies=[Reply(True),Reply(False)]
    class Session:
        def request(self,*args,**kwargs):
            assert kwargs['headers']['Accept-Encoding']=='identity'
            return replies.pop(0)
    api=object.__new__(SheetsClient);api.session=Session();api.last_request=0;api.cancel_check=lambda:None
    first=replies[0]
    assert api.request('GET','doc')=={'ok':True} and first.closed and not replies


def test_complete_run_uses_scoped_source_reads_and_matches_v3_write_plan(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    first=start(logged,w);process_run(db,db.get(Run,first['id']),fake)
    baseline=[(x.tab,x.address,x.value,x.note,x.bank,x.transaction) for x in fake.writes]
    golden=json.loads((Path(__file__).with_name('fixtures')/'v3_financial_outputs.json').read_text())
    assert [list(x) for x in baseline]==golden['writes']
    fake.writes.clear();contexts={}
    def source(id,title,selected,kind):
        api=RangeAPI(fake.documents[id][title]);contexts[id,title]=api
        return api.source_day(id,title,selected,kind)
    fake.source_day=source
    second=start(logged,w);process_run(db,db.get(Run,second['id']),fake)
    assert db.get(Run,second['id']).status=='SUCCESS'
    assert [(x.tab,x.address,x.value,x.note,x.bank,x.transaction) for x in fake.writes]==baseline
    assert len(contexts)==3
    assert all(l.verification_status=='VERIFIED' for l in db.scalars(select(WriteLedger)))
    # Selective retry does not re-read successful source items.
    item=db.scalar(select(RunItem).where(RunItem.run_id==second['id'],RunItem.metric_type=='deposit'))
    item.status='FAILED';db.get(Run,second['id']).status='PARTIAL';db.commit()
    contexts.clear();fake.writes.clear()
    assert logged.post(f"/api/runs/{second['id']}/retry",json={'item_ids':[item.id]}).status_code==202
    process_run(db,db.get(Run,second['id']),fake)
    assert len(contexts)==1


def test_worker_restart_never_replays_interrupted_run_or_verified_writes(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);r=start(logged,w)
    run=db.get(Run,r['id']);run.status='RUNNING';db.commit()
    recover_jobs(db);recover_jobs(db)
    assert run.status=='FAILED'
    process_run(db,run,fake)
    assert not fake.reads and not fake.writes


def test_crash_after_post_preserves_intent_and_requires_explicit_reconciled_retry(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);r=start(logged,w)
    original=fake.write
    class AbruptExit(BaseException):
        pass
    def crash(*args):
        original(*args)
        raise AbruptExit()
    fake.write=crash
    with pytest.raises(AbruptExit):process_run(db,db.get(Run,r['id']),fake)
    assert db.scalar(select(WriteLedger)).verification_status=='PREPARED'
    calls=len(fake.reads);writes=len(fake.writes)
    recover_jobs(db);recover_jobs(db)
    process_run(db,db.get(Run,r['id']),fake)
    assert len(fake.reads)==calls and len(fake.writes)==writes
    assert db.scalar(select(WriteLedger)).verification_status=='PREPARED'
    fake.write=original
    assert logged.post(f"/api/runs/{r['id']}/retry",json={}).status_code==202
    process_run(db,db.get(Run,r['id']),fake)
    assert db.get(Run,r['id']).status=='SUCCESS'
    assert all(l.verification_status=='VERIFIED' for l in db.scalars(select(WriteLedger)))


def test_scoped_preview_does_not_write_or_create_ownership(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    def source(id,title,selected,kind):
        api=RangeAPI(fake.documents[id][title])
        return api.source_day(id,title,selected,kind)
    fake.source_day=source
    r=start(logged,w,preview=True);process_run(db,db.get(Run,r['id']),fake)
    assert db.get(Run,r['id']).status=='PREVIEWED'
    assert not fake.writes and not list(db.scalars(select(WriteLedger)))


def test_memory_stays_bounded_as_historical_cell_count_grows(tmp_path):
    script=Path(__file__).with_name('performance')/'measure_source.py'
    results=[]
    for history in (4000,40000):
        result=subprocess.run([sys.executable,str(script),'--history',str(history),'--limit-mib','1536'],
            capture_output=True,text=True,timeout=90,check=True)
        measured=json.loads(result.stdout);results.append(measured)
        assert measured['metrics']==[0,0,2355000] and measured['peak_rss_mb']<256
        assert measured['largest_response_bytes']<100000 and measured['retained_rows']<25
        assert measured['oom'] is False
    assert results[1]['peak_rss_mb']<results[0]['peak_rss_mb']+32


def test_vps_diagnostics_are_private_and_rotated(tmp_path):
    import logging
    import stat
    from app.diagnostics import configure_worker_log
    log=logging.getLogger('tutupkas.worker')
    before=list(log.handlers)
    configure_worker_log(tmp_path/'worker.lock')
    handler=log.handlers[-1]
    try:
        assert handler.maxBytes==5*1024*1024 and handler.backupCount==3
        assert stat.S_IMODE((tmp_path/'worker-performance.log').stat().st_mode)==0o600
        handler.maxBytes=64
        for _ in range(8):
            handler.emit(logging.LogRecord('tutupkas.worker',20,'',0,'{"event":"source_read","rss_mb":44}',(),None))
        assert len(list(tmp_path.glob('worker-performance.log*')))==4
    finally:
        log.removeHandler(handler);handler.close()
    assert log.handlers==before


def test_complete_website_memory_with_three_large_tabs():
    script=Path(__file__).with_name('performance')/'measure_website.py'
    result=subprocess.run([sys.executable,str(script),'--history','40000'],capture_output=True,text=True,timeout=90,check=True)
    measured=json.loads(result.stdout)
    assert measured['status']=='SUCCESS' and measured['source_tabs']==3
    assert measured['golden_values_coordinates_notes_banks_match'] and measured['cell_writes']==22
    assert measured['peak_rss_mb']<384 and measured['largest_response_bytes']<100000
