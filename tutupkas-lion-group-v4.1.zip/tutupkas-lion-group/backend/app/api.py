import json
import re
from datetime import date
from pathlib import Path
from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import func, select, or_
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .auth import admin
from .config import settings
from .db import get_db, utcnow
from .engine.types import Issue, fingerprint
from .models import (Website, SourceDocument, SourceRevision, SourceSheet, Destination, DestinationRevision,
                     ValidationEvent, Run, RunItem, TaskError, Clearance, AccountAlias, AuditLog, WriteLedger)
from .sheets import SheetsClient, spreadsheet_id

router = APIRouter(dependencies=[Depends(admin)])


def serialize(obj):
    return {c.key: getattr(obj, c.key) for c in obj.__mapper__.column_attrs}


def require(db, model, id):
    obj = db.get(model, id)
    if obj is None:
        raise HTTPException(404, "Data tidak ditemukan.")
    return obj


def audit(db, actor, action, obj, details=None):
    db.add(AuditLog(actor_id=actor.id, action=action, entity_type=obj.__tablename__,
                    entity_id=str(obj.id), details=details or {}))


def save(db):
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Data atau pekerjaan yang sama sudah tersedia. Muat ulang halaman.")


class WebsiteCreate(BaseModel):
    display_name: str = Field(min_length=2, max_length=100)
    slug: str = Field(min_length=2, max_length=100, pattern=r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


class WebsiteEdit(BaseModel):
    display_name: Optional[str] = Field(default=None, min_length=2, max_length=100)
    is_active: Optional[bool] = None
    is_archived: Optional[bool] = None


class Period(BaseModel):
    year: int = Field(ge=2020, le=2100)
    month: int = Field(ge=1, le=12)


class SourceSave(Period):
    document_type: Literal['DEPO', 'QRIS']
    spreadsheet_url: str = Field(max_length=2000)


class DestinationSave(Period):
    environment: Optional[Literal['TEST', 'PRODUCTION', 'WORKING']] = None
    spreadsheet_url: str = Field(max_length=2000)


class TabsAction(BaseModel):
    ids: list[int] = Field(max_length=1000)
    is_active: bool


class RunStart(BaseModel):
    website_id: int
    selected_date: date
    environment: Optional[Literal['TEST', 'PRODUCTION', 'WORKING']] = None
    preview: bool = False
    idempotency_key: str = Field(min_length=16, max_length=100)


class AliasSave(BaseModel):
    source_name: str = Field(min_length=1, max_length=300)
    destination_header: str = Field(min_length=1, max_length=300)


class Authorize(BaseModel):
    test_run_id: int
    reviewed_formulas_notes_and_retry: bool


class Retry(BaseModel):
    source_document_id: Optional[int] = None
    item_ids: Optional[list[int]] = Field(default=None, max_length=1000)
    metric_types: Optional[list[str]] = Field(default=None, max_length=50)


class Reopen(BaseModel):
    reason: str = Field(min_length=10, max_length=1000)


@router.get('/dashboard')
def dashboard(db: Session = Depends(get_db)):
    count = lambda m, *conditions: db.scalar(select(func.count()).select_from(m).where(*conditions))
    return {"websites": count(Website, Website.is_archived == False),
            "active_websites": count(Website, Website.is_active == True, Website.is_archived == False),
            "inactive_websites": count(Website, Website.is_active == False, Website.is_archived == False),
            "active_tabs": count(SourceSheet, SourceSheet.is_active == True, SourceSheet.is_available == True,
                                  SourceSheet.source_revision_id == SourceDocument.active_revision_id,
                                  SourceSheet.source_document_id == SourceDocument.id),
            "inactive_tabs": count(SourceSheet, SourceSheet.is_active == False, SourceSheet.is_available == True,
                                    SourceSheet.source_revision_id == SourceDocument.active_revision_id,
                                    SourceSheet.source_document_id == SourceDocument.id),
            "validated_urls": count(SourceDocument, SourceDocument.validation_status == 'VALID') + count(Destination, Destination.validation_status == 'VALID'),
            "failed_urls": count(SourceDocument, SourceDocument.validation_status == 'FAILED') + count(Destination, Destination.validation_status == 'FAILED'),
            "success_runs": count(Run, Run.status == 'SUCCESS', Run.preview == False),
            "partial_runs": count(Run, Run.status == 'PARTIAL'), "failed_runs": count(Run, Run.status == 'FAILED'),
            "errors": count(TaskError, TaskError.is_resolved == False),
            "credentials_configured": Path(settings().credential_file).is_file(),
            "palette_configured": Path(settings().transfer_palette_file).is_file()}


@router.get('/websites')
def websites(q: str = '', status: str = 'all', db: Session = Depends(get_db)):
    query = select(Website).where(Website.display_name.ilike(f'%{q}%'))
    if status == 'archived':
        query = query.where(Website.is_archived == True)
    else:
        query = query.where(Website.is_archived == False)
    if status in ('active', 'inactive'):
        query = query.where(Website.is_active == (status == 'active'))
    return [serialize(w) for w in db.scalars(query.order_by(Website.created_at))]


@router.post('/websites', status_code=201)
def create_website(body: WebsiteCreate, db: Session = Depends(get_db), user=Depends(admin)):
    if db.scalar(select(Website.id).where(Website.slug == body.slug)):
        raise HTTPException(409, 'Slug WEB sudah digunakan.')
    if any(w.display_name.strip().casefold() == body.display_name.strip().casefold() for w in db.scalars(select(Website))):
        raise HTTPException(409, 'Nama WEB sudah digunakan; identitas tujuan harus unik.')
    obj = Website(**body.model_dump())
    db.add(obj)
    db.flush()
    audit(db, user, 'create', obj)
    save(db)
    return serialize(obj)


@router.get('/websites/{slug}')
def website(slug: str, db: Session = Depends(get_db)):
    obj = db.scalar(select(Website).where(Website.slug == slug))
    if not obj:
        raise HTTPException(404, 'WEB tidak ditemukan.')
    return serialize(obj)


@router.patch('/websites/{id}')
def edit_website(id: int, body: WebsiteEdit, db: Session = Depends(get_db), user=Depends(admin)):
    obj = require(db, Website, id)
    if db.scalar(select(Run.id).where(Run.website_id == id, Run.status.in_(['RUNNING', 'QUEUED']))):
        raise HTTPException(409, 'Tunggu proses WEB ini selesai sebelum mengubah pengaturan.')
    for k, v in body.model_dump(exclude_none=True).items():
        setattr(obj, k, v)
    if obj.is_archived:
        obj.is_active = False
    audit(db, user, 'edit', obj, body.model_dump(exclude_none=True))
    save(db)
    return serialize(obj)


@router.get('/websites/{id}/sources')
def sources(id: int, year: Optional[int] = None, month: Optional[int] = None, db: Session = Depends(get_db)):
    query = select(SourceDocument).where(SourceDocument.website_id == id)
    if year is not None:
        query = query.where(SourceDocument.year == year)
    if month is not None:
        query = query.where(SourceDocument.month == month)
    return [serialize(s) for s in db.scalars(query.order_by(SourceDocument.year.desc(), SourceDocument.month.desc()))]


@router.put('/websites/{id}/sources')
def save_source(id: int, body: SourceSave, db: Session = Depends(get_db), user=Depends(admin)):
    require(db, Website, id)
    sid = spreadsheet_id(body.spreadsheet_url)
    obj = db.scalar(select(SourceDocument).where(SourceDocument.website_id == id, SourceDocument.document_type == body.document_type,
                                                SourceDocument.year == body.year, SourceDocument.month == body.month))
    if obj and obj.spreadsheet_url == body.spreadsheet_url:
        return serialize(obj)
    if not obj:
        obj = SourceDocument(website_id=id, **body.model_dump(), spreadsheet_id=sid)
        db.add(obj)
        db.flush()
    rev = (db.scalar(select(func.max(SourceRevision.revision_number)).where(SourceRevision.source_document_id == obj.id)) or 0) + 1
    revision = SourceRevision(source_document_id=obj.id, revision_number=rev, spreadsheet_url=body.spreadsheet_url,
                              spreadsheet_id=sid, changed_by=user.id)
    db.add(revision)
    db.flush()
    obj.spreadsheet_url, obj.spreadsheet_id = body.spreadsheet_url, sid
    obj.active_revision_id = revision.id
    obj.validation_status, obj.validated_at, obj.spreadsheet_title = 'UNVALIDATED', None, None
    audit(db, user, 'save_source_revision', obj, {"revision": rev})
    save(db)
    return serialize(obj)


@router.get('/sources/{id}/history')
def source_history(id: int, db: Session = Depends(get_db)):
    require(db, SourceDocument, id)
    return [serialize(o) for o in db.scalars(select(SourceRevision).where(SourceRevision.source_document_id == id).order_by(SourceRevision.revision_number.desc()))]


def refresh_tabs(db, obj, metadata):
    current = list(db.scalars(select(SourceSheet).where(SourceSheet.source_revision_id == obj.active_revision_id)))
    names = {s['properties']['title'] for s in metadata.get('sheets', [])}
    for tab in current:
        tab.is_available = tab.tab_name in names
        if tab.is_available:
            tab.last_seen_at = utcnow()
        else:
            tab.is_active = False
    existing = {s.tab_name for s in current}
    for name in names - existing:
        db.add(SourceSheet(source_document_id=obj.id, source_revision_id=obj.active_revision_id, tab_name=name, is_active=False))


def validate_document(db, obj, kind, user):
    try:
        metadata = SheetsClient().metadata(obj.spreadsheet_id)
        obj.spreadsheet_title = metadata['properties']['title']
        obj.validation_status = 'VALID'
        obj.validated_at = utcnow()
        if kind == 'SOURCE':
            refresh_tabs(db, obj, metadata)
        code, message = None, 'Akses baca dan metadata berhasil diverifikasi. Akses tulis belum diuji.'
    except Issue as e:
        obj.validation_status, obj.validated_at = 'FAILED', utcnow()
        code, message = e.code, e.message
    db.add(ValidationEvent(document_id=obj.id, document_type=kind, result=obj.validation_status,
                            error_code=code, human_message=message))
    audit(db, user, 'validate', obj, {"status": obj.validation_status})
    save(db)
    return {"document": serialize(obj), "message": message, "error_code": code}


@router.post('/sources/{id}/validate')
def validate_source(id: int, db: Session = Depends(get_db), user=Depends(admin)):
    return validate_document(db, require(db, SourceDocument, id), 'SOURCE', user)


@router.get('/sources/{id}/tabs')
def tabs(id: int, db: Session = Depends(get_db)):
    obj = require(db, SourceDocument, id)
    return [serialize(t) for t in db.scalars(select(SourceSheet).where(SourceSheet.source_revision_id == obj.active_revision_id).order_by(SourceSheet.tab_name))]


@router.post('/sources/{id}/tabs/refresh')
def refresh(id: int, db: Session = Depends(get_db), user=Depends(admin)):
    obj = require(db, SourceDocument, id)
    metadata = SheetsClient().metadata(obj.spreadsheet_id)
    refresh_tabs(db, obj, metadata)
    obj.spreadsheet_title, obj.validation_status, obj.validated_at = metadata['properties']['title'], 'VALID', utcnow()
    audit(db, user, 'refresh_tabs', obj)
    save(db)
    return tabs(id, db)


@router.post('/sources/{id}/tabs')
def toggle_tabs(id: int, body: TabsAction, db: Session = Depends(get_db), user=Depends(admin)):
    obj = require(db, SourceDocument, id)
    targets = list(db.scalars(select(SourceSheet).where(SourceSheet.id.in_(body.ids),
                   SourceSheet.source_revision_id == obj.active_revision_id, SourceSheet.is_available == True)))
    if len(targets) != len(set(body.ids)):
        raise HTTPException(409, 'Pilihan sheet sudah berubah. Refresh daftar terlebih dahulu.')
    for tab in targets:
        tab.is_active = body.is_active
    audit(db, user, 'toggle_tabs', obj, body.model_dump())
    save(db)
    return tabs(id, db)


@router.get('/websites/{id}/aliases')
def aliases(id: int, db: Session = Depends(get_db)):
    return [serialize(o) for o in db.scalars(select(AccountAlias).where(AccountAlias.website_id == id))]


@router.put('/websites/{id}/aliases')
def save_alias(id: int, body: AliasSave, db: Session = Depends(get_db), user=Depends(admin)):
    require(db, Website, id)
    obj = db.scalar(select(AccountAlias).where(AccountAlias.website_id == id, AccountAlias.source_name == body.source_name))
    if not obj:
        obj = AccountAlias(website_id=id, **body.model_dump())
        db.add(obj)
        db.flush()
    obj.destination_header = body.destination_header
    audit(db, user, 'save_alias', obj)
    save(db)
    return serialize(obj)

