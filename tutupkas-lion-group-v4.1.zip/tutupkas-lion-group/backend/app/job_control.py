"""Pembatalan persisten, diperiksa di antara operasi aman, tanpa membunuh HTTP tulis."""
import json
import logging
import time

from fastapi import HTTPException
from sqlalchemy import select, update
from sqlalchemy.orm import Session

from .diagnostics import memory
from .db import utcnow
from .models import BatchEntry, CrawlBatch, Reconciliation, Run, RunItem, TaskError

ACTIVE = ('QUEUED', 'RUNNING', 'CANCEL_REQUESTED')
logger = logging.getLogger('tutupkas.worker')


class JobCanceled(Exception):
    pass


def cancellation_requested(db, run=None, batch=None):
    # Separate short read transaction sees requests from the API, bypassing the
    # worker's identity map and any old SQLite read snapshot.
    with Session(db.get_bind()) as observer:
        if run:
            state = observer.execute(select(Run.status, Run.cancel_requested_at).where(Run.id == run.id)).one()
            if state[0] in ('CANCEL_REQUESTED', 'CANCELED') or state[1]:
                return True
            if run.batch_id:
                batch = observer.get(CrawlBatch, run.batch_id)
        if batch:
            state = observer.execute(select(CrawlBatch.status, CrawlBatch.cancel_requested_at).where(CrawlBatch.id == batch.id)).one()
            return state[0] in ('CANCEL_REQUESTED', 'CANCELED') or state[1] is not None
    return False


def check_cancel(db, run=None, batch=None):
    if cancellation_requested(db, run, batch):
        raise JobCanceled()


def phase(db, job, value):
    db.execute(update(type(job)).where(type(job).id == job.id).values(current_phase=value))
    db.commit()
    job.current_phase = value


def log_phase(run, item, value, started=None, code=None):
    logger.info(json.dumps({'event':'item_phase','run_id':run.id,'website':run.config_snapshot.get('website'),
        'source_tab':item.source_tab_name,'selected_date':str(run.selected_date),'module':item.metric_type,
        'phase':value,'error_code':code,**memory(),'elapsed_ms':round((time.monotonic()-started)*1000) if started else 0}))


def finalize_cancel(db, run):
    db.refresh(run)
    for item in db.scalars(select(RunItem).where(RunItem.run_id == run.id, RunItem.status == 'PENDING')):
        item.status, item.processed_at = 'CANCELED', utcnow()
    run.cancel_requested_at=run.cancel_requested_at or utcnow()
    run.status, run.current_phase, run.finished_at = 'CANCELED', 'CANCELED', utcnow()
    db.commit()


def claim(db, job):
    from .workflow import lock_date
    lock_date(db, job.selected_date)
    db.refresh(job)
    if job.status=='CANCELED':
        db.rollback();return False
    if cancellation_requested(db, run=job if isinstance(job,Run) else None, batch=job if isinstance(job,CrawlBatch) else None):
        if isinstance(job,Run):
            finalize_cancel(db,job)
        else:
            finalize_batch_cancel(db,job)
        return False
    if job.status not in ('QUEUED','RUNNING'):
        db.rollback()
        return False
    job.status, job.current_phase = 'RUNNING', 'PREPARING'
    db.commit()
    return True


def request_run_cancel(db, run, user_id):
    db.refresh(run)
    if run.status == 'CANCELED':
        return
    if run.status not in ACTIVE:
        raise HTTPException(409,'Proses sudah selesai; hanya antrean atau proses berjalan yang dapat dibatalkan.')
    run.cancel_requested_at = run.cancel_requested_at or utcnow()
    run.cancel_requested_by = user_id
    if run.status == 'QUEUED':
        for item in db.scalars(select(RunItem).where(RunItem.run_id == run.id, RunItem.status == 'PENDING')):
            item.status, item.processed_at = 'CANCELED', utcnow()
        run.status, run.current_phase, run.finished_at = 'CANCELED', 'CANCELED', utcnow()
        if run.batch_id:
            for entry in db.scalars(select(BatchEntry).where(BatchEntry.run_id == run.id, BatchEntry.reused == False)):
                entry.status = 'CANCELED'
    else:
        run.status = 'CANCEL_REQUESTED'


def cancel_recheck_entry(db, batch, entry):
    from .workflow import website_context
    run = db.get(Run,entry.run_id)
    db.add(Reconciliation(selected_date=run.selected_date,website_id=run.website_id,run_id=run.id,batch_id=batch.id,
        destination_document_id=batch.destination_snapshot['id'],destination_revision=batch.destination_snapshot['revision'],
        context_signature=website_context(db,run),kind='WEBSITE',status='CANCELED',
        human_message='Pemeriksaan ulang dibatalkan; jalankan pemeriksaan baru untuk memastikan saldo.',details={}))


def cancel_consolidated_check(db,batch):
    if not batch.recheck_only:
        return
    from .workflow import monthly_destination,context_signature
    try:dest=monthly_destination(db,batch.selected_date)
    except HTTPException:return
    if (dest.id,dest.revision)!=(batch.destination_snapshot['id'],batch.destination_snapshot['revision']):
        return
    db.add(Reconciliation(selected_date=batch.selected_date,batch_id=batch.id,
        destination_document_id=dest.id,destination_revision=dest.revision,
        context_signature=context_signature(db,batch.selected_date,dest),kind='CONSOLIDATED',status='CANCELED',
        human_message='Pemeriksaan konsolidasi dibatalkan. Jalankan pemeriksaan ulang sebelum Clear.',details={}))


def request_batch_cancel(db, batch, user_id):
    db.refresh(batch)
    if batch.status == 'CANCELED':
        return
    if batch.status not in ACTIVE:
        raise HTTPException(409,'Kelompok proses sudah selesai.')
    was_queued = batch.status == 'QUEUED'
    cancel_consolidated_check(db,batch)
    batch.cancel_requested_at = batch.cancel_requested_at or utcnow()
    batch.cancel_requested_by = user_id
    batch.status = 'CANCELED' if was_queued else 'CANCEL_REQUESTED'
    if was_queued:
        batch.current_phase, batch.finished_at = 'CANCELED', utcnow()
    for entry in db.scalars(select(BatchEntry).where(BatchEntry.batch_id == batch.id, BatchEntry.status.in_(['WAITING','RUNNING']))):
        if batch.recheck_only:
            if was_queued or entry.status == 'WAITING':
                cancel_recheck_entry(db,batch,entry)
        else:
            child = db.get(Run,entry.run_id)
            if child.status in ACTIVE:
                request_run_cancel(db,child,user_id)
        if was_queued or entry.status == 'WAITING':
            entry.status = 'CANCELED'


def finalize_batch_cancel(db, batch):
    db.refresh(batch)
    for entry in db.scalars(select(BatchEntry).where(BatchEntry.batch_id == batch.id, BatchEntry.status.in_(['WAITING','RUNNING']))):
        if batch.recheck_only:
            cancel_recheck_entry(db,batch,entry)
        else:
            child=db.get(Run,entry.run_id)
            if child.status in ACTIVE:
                finalize_cancel(db,child)
        entry.status='CANCELED'
    cancel_consolidated_check(db,batch)
    batch.cancel_requested_at=batch.cancel_requested_at or utcnow()
    batch.status, batch.current_phase, batch.finished_at = 'CANCELED', 'CANCELED', utcnow()
    db.commit()


def fail_run(db,run,code='WORKER_ERROR'):
    """Finalize unexpected failures, preserving VERIFIED and PREPARED ledgers."""
    from .engine.runner import error
    from .engine.types import Issue
    db.rollback();db.refresh(run)
    if cancellation_requested(db,run=run):
        finalize_cancel(db,run);return
    pending=list(db.scalars(select(RunItem).where(RunItem.run_id==run.id,RunItem.status=='PENDING')))
    if not pending:
        item=db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type=='reconciliation'))
        if not item:
            item=RunItem(run_id=run.id,source_tab_name='Pemeriksaan hasil',metric_type='reconciliation',source_date=run.selected_date)
            db.add(item);db.flush()
        pending=[item]
    for item in pending:
        error(db,run,item,Issue(code,'Pemrosesan terhenti karena kesalahan layanan; hasil terverifikasi tetap disimpan.',
            'Periksa Pusat Kesalahan, lalu ulangi hanya item yang belum selesai.',run_id=run.id,phase=run.current_phase))
    completed=db.scalar(select(RunItem.id).where(RunItem.run_id==run.id,RunItem.status.in_(['SUCCESS','PREVIEWED'])))
    run.status,run.current_phase,run.finished_at = ('PARTIAL' if completed else 'FAILED'),'FAILED',utcnow()
    db.commit()
