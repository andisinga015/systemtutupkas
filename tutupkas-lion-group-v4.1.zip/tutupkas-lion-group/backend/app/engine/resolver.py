import re
from datetime import date

from .parser import parse_date
from .types import Grid, Issue, Write, norm

BANKS = ("BCA", "MANDIRI", "BRI", "BNI")


def unique(values, code: str, message: str):
    found = list(dict.fromkeys(values))
    if len(found) != 1:
        raise Issue(code, message, matches=len(found))
    return found[0]


def website_block(grid: Grid, website: str, registered: list[str]):
    names = {norm(v) for v in registered}
    positions = [(r, c, norm(cell.value)) for r,c,cell in grid.iter_cells(bottom=12)
                 if norm(cell.value) in names]
    r, left, _ = unique([p for p in positions if p[2] == norm(website)], "WEBSITE_BLOCK_MISSING",
                        f"Blok {website} pada {grid.title} tidak ditemukan secara unik.")
    # An unregistered website still bounds the current block when its own date
    # column proves that it is a distinct structural section. Never cross it.
    structural_boundaries = [c for rr,c,cell in grid.iter_cells(bottom=1)
                             if cell.value not in (None, '') and c > left
                             and any(parse_date(v) for dr,cc,v in grid.iter_cells(top=2,left=c,right=c+1))]
    right = min([c for _, c, n in positions if c > left and n != norm(website)] + structural_boundaries or [grid.width])
    return r, left, right


def date_row(grid: Grid, left: int, right: int, selected: date):
    # Each block owns its date column, anchored on its website label.
    return unique([r for r,c,cell in grid.iter_cells(top=2,left=left,right=left+1) if parse_date(cell) == selected],
                  "DESTINATION_DATE_MISSING", f"Tanggal {selected} tidak ditemukan secara unik dalam blok website.")


def account_names(source: str) -> set[str]:
    v = norm(source)
    out = {v}
    if "/" in v:
        out.add(re.sub(r"\s*\(\s*PP\s*\)\s*$", "", v.split("/", 1)[1]).strip())
    if v.startswith("QRIS "):
        out.add(v[5:].strip())
    return out


def regular(grid: Grid, website: str, registered: list[str], selected: date,
            source: str, value, alias: str = "") -> Write:
    _, left, right = website_block(grid, website, registered)
    row = date_row(grid, left, right, selected)
    names = {norm(alias)} if alias else account_names(source)
    exact = []
    for c in range(left + 1, right):
        top, sub = norm(grid.inherited(0, c).value), norm(grid.inherited(1, c).value)
        if names.intersection({top, sub, f"{top} {sub}".strip()}):
            exact.append(c)
    col = unique(exact, "ACCOUNT_MISSING", f"Rekening {source} tidak ditemukan secara unik di blok {website}.")
    return Write(grid.title, row, col, value)


def labeled(grid: Grid, website: str, registered: list[str], selected: date, label: str, value) -> Write:
    _, left, right = website_block(grid, website, registered)
    row = date_row(grid, left, right, selected)
    col = unique([c for c in range(left + 1, right)
                  if norm(label) in {norm(grid.inherited(r, c).value) for r in (0, 1)}],
                 "HEADER_MISSING", f"Kolom {label} tidak ditemukan secara unik di blok {website}.")
    return Write(grid.title, row, col, value)


def fees(grid: Grid, website: str, registered: list[str], selected: date, label: str, desc: str, value: int):
    return [labeled(grid, website, registered, selected, "KETERANGAN", desc),
            labeled(grid, website, registered, selected, label, value)]


def transfer_slots(grid: Grid, website: str, registered: list[str], selected: date):
    # Both supported layouts require positive structural boundaries. Calendar
    # dates are preferred. Monthly side-total headers use the configured period
    # and a unique day number; they must also prove the previous-day boundary.
    dates = [(r, c, parse_date(cell)) for r,c,cell in grid.iter_cells()
             if parse_date(cell) is not None]
    anchors = [(r, c) for r, c, d in dates if d == selected]
    side_column = None
    if anchors:
        anchor_r, left = unique(anchors, "DESTINATION_DATE_MISSING",
                               "Bagian tanggal KET PENGIRIMAN tidak dapat diidentifikasi secara unik.")
        merged = next((m for m in grid.merges if m['startRowIndex'] == anchor_r
                       and m['startColumnIndex'] == left), None)
        if not merged or merged['endColumnIndex'] - left < 4:
            raise Issue("TRANSFER_LAYOUT_AMBIGUOUS", "Batas merged bagian tanggal kiriman belum jelas.")
        right = merged['endColumnIndex']
        top = anchor_r + 1
        bottom = min([r for r, c, d in dates if r > anchor_r and left <= c < right] or [grid.height])
    else:
        def header_day(cell):
            value = cell.value
            if isinstance(value, (int, float)) and not isinstance(value, bool) and 1 <= value <= 31 and value == int(value):
                return int(value)
            if isinstance(value, str) and re.fullmatch(r'(?:[1-9]|[12][0-9]|3[01])', value.strip()):
                return int(value)
            return None
        days = [(r, c, header_day(cell)) for r,c,cell in grid.iter_cells(bottom=4) if header_day(cell) is not None
                and cell.color is not None and max(cell.color) < .15 and not cell.date_format]
        anchor_r, side_column, _ = unique([p for p in days if p[2] == selected.day],
            'DESTINATION_DATE_MISSING', 'Nomor hari kiriman tidak ditemukan secara unik pada header bulanan.')
        same_row = sorted((c, d) for r, c, d in days if r == anchor_r)
        if len(same_row) < 2 or any(b[1] <= a[1] for a, b in zip(same_row, same_row[1:])):
            raise Issue('TRANSFER_LAYOUT_AMBIGUOUS', 'Urutan nomor hari pada header kiriman tidak konsisten.')
        if selected.day == 1:
            if same_row[0] != (side_column, 1):
                raise Issue('TRANSFER_LAYOUT_AMBIGUOUS', 'Batas awal hari pertama tidak dapat dibuktikan.')
            left = 0
        else:
            previous = unique([c for c, d in same_row if d == selected.day - 1 and c < side_column],
                              'TRANSFER_LAYOUT_AMBIGUOUS', 'Kolom TOTAL hari sebelumnya tidak ditemukan untuk membatasi bagian kiriman.')
            span = next((m for m in grid.merges if m['startRowIndex'] == anchor_r and m['startColumnIndex'] == previous), None)
            left = span['endColumnIndex'] if span else previous + 1
        right, top, bottom = side_column, anchor_r, grid.height
    labels = [(r, c, norm(cell.value)) for r,c,cell in grid.iter_cells(top,bottom,left,right) if left <= c < right
              and norm(cell.value) in {norm(n) for n in registered}]
    wr, wc, _ = unique([p for p in labels if p[2] == norm(website)], "WEBSITE_BLOCK_MISSING",
                        "Blok website pada bagian tanggal kiriman tidak ditemukan secara unik.")
    end = min([r for r, _, _ in labels if r > wr] or [bottom])
    if side_column is not None:
        section = next((m for m in grid.merges if m['startRowIndex'] == wr and m['startColumnIndex'] == wc), None)
        if not section or section['endColumnIndex'] > right or section['endColumnIndex'] - wc < 8:
            raise Issue('TRANSFER_LAYOUT_AMBIGUOUS', 'Batas merged header website tidak membuktikan bagian empat bank.')
        if not any(norm(cell.value) == 'TOTAL' for r,c,cell in grid.iter_cells(wr+1,end,side_column,side_column+1)):
            raise Issue('TRANSFER_LAYOUT_AMBIGUOUS', 'Nomor hari belum terhubung ke kolom TOTAL pada blok website ini.')
        left, right = wc, section['endColumnIndex']
    bank_positions = [(r, c, norm(cell.value)) for r,c,cell in grid.iter_cells(wr+1,end,left,right) if left <= c < right and norm(cell.value) in BANKS]
    slots = {b: [] for b in BANKS}
    for bank in BANKS:
        br, bc, _ = unique([p for p in bank_positions if p[2] == bank], "BANK_AMBIGUOUS",
                            f"Blok bank {bank} tidak ditemukan secara unik.")
        span = next((m for m in grid.merges if m['startRowIndex'] == br and m['startColumnIndex'] == bc), None)
        if not span or span['endColumnIndex'] - bc != 2:
            raise Issue("TRANSFER_LAYOUT_AMBIGUOUS", "Blok bank kiriman harus berisi pasangan keterangan dan nominal.")
        limit = unique([r for r,c,cell in grid.iter_cells(br+1,end,bc,bc+1) if norm(cell.value) == "TOTAL"],
                       "HEADER_MISSING", "Batas TOTAL bank tidak ditemukan secara unik.")
        slots[bank] = [(r, bc, bc + 1) for r in range(br + 1, limit)]
    return slots

