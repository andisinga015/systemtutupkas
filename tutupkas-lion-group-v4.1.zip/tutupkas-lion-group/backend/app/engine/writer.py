from sqlalchemy import select

from ..destination_reader import close_view, formula_signature
from ..db import utcnow
from ..models import WriteLedger, TransferOwnership
from .parser import parse_date
from .types import Grid, Issue, Write, fingerprint, norm


def structural(grid: Grid):
    if hasattr(grid,'structural_signature'):
        return grid.structural_signature
    labels = []
    for r, row in enumerate(grid.rows):
        for c, cell in enumerate(row):
            if r < 2 or parse_date(cell) or norm(cell.value) in ('BCA', 'MANDIRI', 'BRI', 'BNI', 'TOTAL'):
                labels.append((r, c, cell.value, cell.formula))
    return fingerprint([labels, grid.merges])


def formula_map(grid: Grid):
    if hasattr(grid,'formula_signature'):
        return grid.formula_signature
    return formula_signature(grid.iter_cells())


def owner_key(run, item):
    # Stable across retries and later explicit runs for the same date/source revision.
    doc = next((d for d in run.config_snapshot['sources'] if d['id'] == item.source_document_id), {})
    return fingerprint([run.website_id, str(run.selected_date), item.source_document_id,
                        doc.get('revision'), item.source_tab_name, item.metric_type])


def get_ledger(db, run, write):
    dest = run.config_snapshot['destination']
    return db.scalar(select(WriteLedger).where(WriteLedger.destination_document_id == dest['id'],
        WriteLedger.destination_revision == dest['revision'], WriteLedger.destination_tab == write.tab,
        WriteLedger.target_range == write.address))


def check_write(db, run, item, grid, write):
    cell = grid.cell(write.row, write.col)
    merged = (grid.merges.at(write.row,write.col) is not None) if hasattr(grid.merges,'at') else any(
        m['startRowIndex'] <= write.row < m['endRowIndex'] and
        m['startColumnIndex'] <= write.col < m['endColumnIndex'] for m in grid.merges)
    if merged:
        raise Issue('MERGED_CELL_CONFLICT', f'Sel {write.tab}!{write.address} termasuk area gabungan yang dilindungi.')
    if cell.formula is not None:
        raise Issue('FORMULA_CONFLICT', f'Sel {write.tab}!{write.address} berisi formula dan dilindungi.')
    ledger = get_ledger(db, run, write)
    if ledger:
        if ledger.owner_key != owner_key(run, item):
            from ..models import Run, RunItem
            previous_item = db.get(RunItem, ledger.run_item_id)
            previous_run = db.get(Run, previous_item.run_id) if previous_item else None
            authorized = (run.config_snapshot.get('authorized_previous_run_id') == (previous_run.id if previous_run else None)
                and previous_run is not None and previous_run.website_id == run.website_id
                and previous_run.selected_date == run.selected_date
                and previous_item.source_document_id == item.source_document_id
                and previous_item.source_tab_name == item.source_tab_name and previous_item.metric_type == item.metric_type)
            if not authorized:
                raise Issue('DUPLICATE_DESTINATION', f'Sel {write.tab}!{write.address} sudah dimiliki item sumber lain.')
        allowed = [ledger.written_value]
        if ledger.verification_status == 'PREPARED':
            allowed.append(ledger.previous_managed_value)
        if cell.snapshot not in allowed:
            raise Issue('EXISTING_VALUE_CONFLICT', f'Sel {write.tab}!{write.address} telah diubah di luar robot.',
                        'Tinjau perubahan manual. Robot tidak akan menimpanya secara otomatis.')
        # First reconcile an uncertain old write before changing its desired output.
        if ledger.verification_status == 'PREPARED' and write.proposed != ledger.written_value:
            raise Issue('UNCERTAIN_WRITE', 'Nilai sumber berubah saat hasil tulis sebelumnya belum pasti.',
                        'Pulihkan hasil sumber awal dan Crawl Ulang untuk rekonsiliasi sebelum melakukan koreksi baru.')
    elif not cell.empty:
        raise Issue('EXISTING_VALUE_CONFLICT', f'Sel {write.tab}!{write.address} berisi data atau Note yang bukan milik robot.',
                    'Gunakan salinan kerja dan pastikan sel output tersedia; formula dan entri manual tetap dilindungi.')
    if write.note is None:
        # Never clear unrelated Notes through a value-only update.
        write.note = cell.note
    return ledger


def execute(db, client, run, item, grid, writes, cancel_check=lambda:None, on_phase=lambda value:None):
    cancel_check()
    on_phase("CHECKING_DESTINATION")
    if grid.title.strip().casefold() == 'laporan deposit harian' or any(
            w.tab.strip().casefold() == 'laporan deposit harian' for w in writes):
        raise Issue('READ_ONLY_REPORT', 'Laporan deposit harian hanya boleh dibaca; penulisan ditolak sebelum API.')
    dest = run.config_snapshot['destination']
    fresh = grid.refresh() if hasattr(grid,'refresh') else client.grid(dest['spreadsheet_id'], grid.title)
    try:
        if hasattr(fresh,'prefetch'):
            fresh.prefetch([(w.row,w.col) for w in writes])
        return _execute_checked(db,client,run,item,grid,fresh,writes,cancel_check,on_phase)
    finally:
        close_view(fresh)


def _execute_checked(db,client,run,item,grid,fresh,writes,cancel_check,on_phase):
    dest = run.config_snapshot['destination']
    if structural(fresh) != structural(grid):
        raise Issue('DESTINATION_CHANGED', 'Header atau batas tanggal tujuan berubah selama penyusunan rencana. Ulangi pratinjau.')
    formulas = formula_map(fresh)
    plan = []
    for w in writes:
        ledger = check_write(db, run, item, fresh, w)
        plan.append({"tab": w.tab, "cell": w.address, "existing": fresh.cell(w.row, w.col).snapshot,
                     "proposed": w.proposed, "bank": w.bank, "source_transaction": w.transaction})
    cancel_check()
    if run.preview:
        return {"plan": plan, "formula_cells_checked": len(formulas), "verified": False}
    # Persist intent before contacting Google: restart recovery can recognize
    # both pre-write and intended post-write values, never append blindly.
    for w in writes:
        ledger = get_ledger(db, run, w)
        if not ledger:
            ledger = WriteLedger(run_item_id=item.id, destination_document_id=dest['id'], destination_revision=dest['revision'],
                destination_tab=w.tab, target_range=w.address, output_type=item.metric_type,
                owner_key=owner_key(run, item), source_fingerprint=fingerprint([item.result, w.value, w.transaction]),
                previous_managed_value=fresh.cell(w.row, w.col).snapshot, written_value=w.proposed,
                note_fingerprint=fingerprint(w.note), verification_status='PREPARED')
            db.add(ledger)
        else:
            ledger.previous_managed_value = fresh.cell(w.row, w.col).snapshot
            ledger.written_value, ledger.run_item_id = w.proposed, item.id
            ledger.verification_status, ledger.last_written_at = 'PREPARED', utcnow()
            ledger.note_fingerprint = fingerprint(w.note)
            ledger.owner_key = owner_key(run, item)
        if w.transaction and w.bank:
            owned = db.scalar(select(TransferOwnership).where(TransferOwnership.destination_document_id == dest['id'],
                  TransferOwnership.destination_revision == dest['revision'],
                  TransferOwnership.source_transaction_fingerprint == w.transaction))
            if not owned and w.previous_transaction and run.config_snapshot.get('authorized_previous_run_id'):
                owned = db.scalar(select(TransferOwnership).where(TransferOwnership.destination_document_id == dest['id'],
                    TransferOwnership.destination_revision == dest['revision'],
                    TransferOwnership.source_transaction_fingerprint == w.previous_transaction))
                if owned:
                    owned.source_transaction_fingerprint, owned.run_item_id = w.transaction, item.id
            if not owned:
                db.add(TransferOwnership(run_item_id=item.id, source_transaction_fingerprint=w.transaction,
                     destination_document_id=dest['id'], destination_revision=dest['revision'], destination_tab=w.tab,
                     destination_bank=w.bank, description_cell=w.address,
                     amount_cell=next(x.address for x in writes if x.row == w.row and x.col == w.col + 1),
                     note_cell=w.address))
    db.commit()
    # Google batchUpdate is atomic within this item. Retrying writes sets the same
    # exact cells; no append, insertion, formatting or formula updates are used.
    cancel_check()
    previous_check=getattr(client,'cancel_check',None)
    if previous_check is not None:
        client.cancel_check=lambda:None
    try:
        return _submit_and_verify(db,client,run,grid,fresh,writes,formulas,plan,on_phase)
    finally:
        if previous_check is not None:
            client.cancel_check=previous_check


def _submit_and_verify(db,client,run,grid,fresh,writes,formulas,plan,on_phase):
    dest=run.config_snapshot['destination']
    on_phase('WRITING')
    client.write(dest['spreadsheet_id'], fresh, writes)
    # An already submitted write must be verified even if Stop arrives now.
    on_phase('VERIFYING')
    verified = grid.refresh() if hasattr(grid,'refresh') else client.grid(dest['spreadsheet_id'], grid.title)
    try:
        if hasattr(verified,'prefetch'):
            verified.prefetch([(w.row,w.col) for w in writes])
        if formula_map(verified) != formulas:
            raise Issue('FORMULA_CHANGED', 'Formula tujuan berubah saat verifikasi. Periksa spreadsheet sebelum mencoba lagi.')
        for w in writes:
            if verified.cell(w.row, w.col).snapshot != w.proposed:
                raise Issue('READBACK_FAILED', f'Pembacaan ulang {w.tab}!{w.address} tidak sesuai rencana.',
                            'Periksa izin dan perubahan manual. Crawl Ulang akan merekonsiliasi sel milik robot.')
            ledger = get_ledger(db, run, w)
            ledger.verification_status, ledger.last_written_at = 'VERIFIED', utcnow()
    finally:
        close_view(verified)
    db.commit()
    return {"plan": plan, "formula_cells_checked": len(formulas), "verified": True}

