"""API terautentikasi tujuan tunggal, batch, rekonsiliasi dan Clear."""
import json
from datetime import date
from pathlib import Path
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import api as core
from .auth import admin
from .batches import batch_progress, enqueue_batch
from .config import settings
from .db import get_db, utcnow
from .job_control import request_run_cancel, request_batch_cancel
from .models import (BatchEntry, Clearance, CrawlBatch, Destination, DestinationRevision, FinalClearance,
                     MonthlyDestination, Reconciliation, Run, RunItem, TaskError, Website)
from .reconciliation import date_overview, last_reconciliation
from .sheets import spreadsheet_id
from .workflow import (ACTIVE, assert_available, context_signature, create_run, current_source_signature,
    destination_snapshot, is_clear, is_current_run, lock_date, make_snapshot, monthly_destination,
    run_source_signature)

router = APIRouter(dependencies=[Depends(admin)])


class BatchStart(BaseModel):
    selected_date: date
    preview: bool = False
    idempotency_key: str = Field(min_length=16, max_length=100)


class CheckRequest(BaseModel):
    idempotency_key: str = Field(default_factory=lambda: str(uuid4()), min_length=16, max_length=100)


class DateCheck(CheckRequest):
    selected_date: date


class Resync(CheckRequest):
    selected_dates: list[date] = Field(default_factory=list, max_length=31)


@router.get('/destinations')
def destinations(db: Session = Depends(get_db)):
    bindings = {m.destination_document_id for m in db.scalars(select(MonthlyDestination))}
    docs = list(db.scalars(select(Destination).order_by(Destination.year.desc(), Destination.month.desc(), Destination.id)))
    # A single legacy URL can be shown as active before its lazy adoption.
    for doc in docs:
        same = [d for d in docs if (d.year, d.month) == (doc.year, doc.month)]
        if len(same) == 1:
            bindings.add(doc.id)
    return [{**core.serialize(d), 'is_current': d.id in bindings} for d in docs]


@router.put('/destinations')
def save_destination(body: core.DestinationSave, db: Session = Depends(get_db), user=Depends(admin)):
    sid = spreadsheet_id(body.spreadsheet_url)
    binding = db.scalar(select(MonthlyDestination).where(MonthlyDestination.year == body.year, MonthlyDestination.month == body.month))
    obj = db.get(Destination, binding.destination_document_id) if binding else None
    if obj and obj.spreadsheet_url == body.spreadsheet_url:
        return {**core.serialize(obj), 'is_current': True}
    if not obj:
        options = list(db.scalars(select(Destination).where(Destination.year == body.year, Destination.month == body.month,
                                                           Destination.spreadsheet_url == body.spreadsheet_url)))
        obj = options[0] if len(options) == 1 else None
    if obj:
        obj.revision += 1
        obj.spreadsheet_url, obj.spreadsheet_id = body.spreadsheet_url, sid
    else:
        obj = Destination(year=body.year, month=body.month, environment='WORKING', spreadsheet_url=body.spreadsheet_url,
                          spreadsheet_id=sid, revision=1)
        db.add(obj)
        db.flush()
    if not binding:
        binding = MonthlyDestination(year=body.year, month=body.month, destination_document_id=obj.id)
        db.add(binding)
    else:
        binding.destination_document_id = obj.id
    obj.validation_status, obj.validated_at, obj.spreadsheet_title = 'UNVALIDATED', None, None
    obj.production_authorized_by, obj.authorized_at = None, None
    db.add(DestinationRevision(destination_document_id=obj.id, revision_number=obj.revision,
                               spreadsheet_url=body.spreadsheet_url, changed_by=user.id))
    core.audit(db, user, 'save_monthly_destination', obj, {'revision': obj.revision})
    core.save(db)
    return {**core.serialize(obj), 'is_current': True}


@router.post('/destinations/{id}/validate')
def validate_destination(id: int, db: Session = Depends(get_db), user=Depends(admin)):
    return core.validate_document(db, core.require(db, Destination, id), 'DESTINATION', user)


@router.get('/destinations/{id}/history')
def destination_history(id: int, db: Session = Depends(get_db)):
    core.require(db, Destination, id)
    return [core.serialize(o) for o in db.scalars(select(DestinationRevision).where(
        DestinationRevision.destination_document_id == id).order_by(DestinationRevision.revision_number.desc()))]


@router.get('/destinations/{id}/revision-status')
def revision_status(id: int, selected_date: date, db: Session = Depends(get_db)):
    core.require(db, Destination, id)
    return date_overview(db, selected_date)


@router.post('/destinations/{id}/authorize')
def deprecated_authorize(id: int):
    raise HTTPException(409, 'Tujuan bulanan kini satu salinan kerja. Otorisasi TEST/produksi terpisah tidak digunakan; jalankan penarikan secara manual.')


@router.post('/runs', status_code=202)
def start_run(body: core.RunStart, db: Session = Depends(get_db), user=Depends(admin)):
    lock_date(db, body.selected_date)
    old = db.scalar(select(Run).where(Run.idempotency_key == body.idempotency_key))
    if old:
        if (old.website_id, old.selected_date, old.preview) != (body.website_id, body.selected_date, body.preview):
            raise HTTPException(409, 'Kunci permintaan dipakai untuk operasi lain.')
        return core.serialize(old)
    assert_available(db, body.selected_date, body.website_id)
    snapshot = make_snapshot(db, body.website_id, body.selected_date)
    run = create_run(db, body.website_id, body.selected_date, body.preview, body.idempotency_key, user.id, snapshot)
    core.audit(db, user, 'preview' if body.preview else 'start', run)
    core.save(db)
    return core.serialize(run)


@router.get('/runs')
def runs(limit: int = Query(default=100, ge=1, le=500), before_id: int = None, db: Session = Depends(get_db)):
    query = select(Run).order_by(Run.id.desc()).limit(limit)
    if before_id:
        query = query.where(Run.id < before_id)
    return [{**core.serialize(r), 'reconciliation': core.serialize(c) if (c := last_reconciliation(db, run_id=r.id)) else None}
            for r in db.scalars(query)]


@router.get('/runs/{id}')
def run_detail(id: int, db: Session = Depends(get_db)):
    run = core.require(db, Run, id)
    reco = last_reconciliation(db, run_id=id)
    overview = date_overview(db, run.selected_date)
    row = next((r for r in overview['websites'] if r['website_id'] == run.website_id), None)
    dest = db.get(Destination, overview['destination']['id']) if overview['destination'] else None
    return {**core.serialize(run), 'reconciliation': core.serialize(reco) if reco else None,
        'current_revision': bool(dest and is_current_run(db, run, dest)),
        'is_latest_current': bool(row and row['run_id'] == id), 'date_status': overview,
        'items': [core.serialize(i) for i in db.scalars(select(RunItem).where(RunItem.run_id == id))],
        'errors': [core.serialize(e) for e in db.scalars(select(TaskError).where(TaskError.run_id == id, TaskError.is_resolved == False))]}


def queue_retry(db, run, body, user):
    lock_date(db, run.selected_date)
    assert_available(db, run.selected_date, run.website_id)
    dest = monthly_destination(db, run.selected_date, validated=True)
    if is_clear(db, run.selected_date, dest):
        raise HTTPException(409, 'Tanggal sudah Clear. Buka kembali sebelum koreksi.')
    if not is_current_run(db, run, dest):
        raise HTTPException(409, 'URL sumber/tujuan berubah. Gunakan Crawl Ulang ke URL Baru; retry lama tidak dipindahkan ke dokumen lain.')
    query = select(RunItem).where(RunItem.run_id == run.id, RunItem.status.in_(['FAILED','CANCELED','PENDING']),
                                 RunItem.metric_type.notin_(['reconciliation', 'configuration']))
    if body.source_document_id is not None:
        query = query.where(RunItem.source_document_id == body.source_document_id)
    if body.item_ids is not None:
        query = query.where(RunItem.id.in_(body.item_ids))
    if body.metric_types is not None:
        query = query.where(RunItem.metric_type.in_(body.metric_types))
    items = list(db.scalars(query))
    if not items and not (run.status in ('CANCELED','PARTIAL') and body.source_document_id is None and body.item_ids is None and body.metric_types is None):
        raise HTTPException(409, 'Tidak ada item pemrosesan yang perlu diulang dalam pilihan ini. Untuk saldo, gunakan Periksa Ulang Rekonsiliasi.')
    for item in items:
        item.status = 'PENDING'
        for err in db.scalars(select(TaskError).where(TaskError.run_item_id == item.id, TaskError.is_resolved == False)):
            err.retry_count += 1
    aggregate = db.scalar(select(RunItem).where(RunItem.run_id == run.id, RunItem.metric_type == 'expense_total'))
    if aggregate and aggregate.status in ('FAILED','CANCELED') and any(i.metric_type == 'expense_input' for i in items):
        aggregate.status = 'PENDING'
    snapshot = dict(run.config_snapshot)
    path = Path(settings().transfer_palette_file)
    if path.is_file():
        try:
            snapshot['palette'] = json.loads(path.read_text())
        except (ValueError, OSError):
            raise HTTPException(409, 'Palet kiriman tidak dapat dibaca.')
    run.config_snapshot = snapshot
    run.status, run.finished_at = 'QUEUED', None
    run.cancel_requested_at,run.cancel_requested_by,run.current_phase=None,None,'QUEUED'
    # Retry is a new explicit authorization. Original destinations and source
    # revisions stay pinned. Verified outputs are left untouched.
    snapshot = dict(run.config_snapshot)
    snapshot['engine_revision'] = make_snapshot(db, run.website_id, run.selected_date, dest)['engine_revision']
    run.config_snapshot = snapshot
    if run.batch_id:
        batch = db.get(CrawlBatch, run.batch_id)
        entry = db.scalar(select(BatchEntry).where(BatchEntry.batch_id == batch.id, BatchEntry.run_id == run.id))
        if entry:
            entry.status = 'WAITING'
        batch.status, batch.finished_at = 'QUEUED', None
        batch.cancel_requested_at,batch.cancel_requested_by,batch.current_phase=None,None,'QUEUED'
    core.audit(db, user, 'retry_failed_items', run, body.model_dump(exclude_none=True))
    return run


@router.post('/runs/{id}/retry', status_code=202)
def retry(id: int, body: core.Retry, db: Session = Depends(get_db), user=Depends(admin)):
    run = queue_retry(db, core.require(db, Run, id), body, user)
    core.save(db)
    return core.serialize(run)


@router.post('/runs/{id}/resync', status_code=202)
def resync(id: int, body: Resync, db: Session = Depends(get_db), user=Depends(admin)):
    original = core.require(db, Run, id)
    dates = sorted(set(body.selected_dates or [original.selected_date]))
    result = []
    for selected in dates:
        if (selected.year, selected.month) != (original.year, original.month):
            raise HTTPException(409, 'Sinkronisasi harus tetap dalam bulan proses asal. Pilih periode lain dari halaman utama.')
        lock_date(db, selected)
        key = f"resync:{body.idempotency_key}:{selected.isoformat()}"
        old = db.scalar(select(Run).where(Run.idempotency_key == key))
        if old:
            result.append(core.serialize(old))
            continue
        assert_available(db, selected, original.website_id)
        snapshot = make_snapshot(db, original.website_id, selected)
        prior = original if selected == original.selected_date else next((candidate for candidate in db.scalars(
            select(Run).where(Run.website_id == original.website_id, Run.selected_date == selected,
                              Run.preview == False).order_by(Run.id.desc()))
            if run_source_signature(candidate) == run_source_signature(original)
            and candidate.config_snapshot.get('destination') == original.config_snapshot.get('destination')), None)
        if prior:
            snapshot['authorized_previous_run_id'] = prior.id
        new = create_run(db, original.website_id, selected, False, key, user.id, snapshot)
        core.audit(db, user, 'manual_resync_new_url', new, {'original_run_id': original.id, 'selected_date': str(selected)})
        result.append(core.serialize(new))
    core.save(db)
    return {'runs': result}


@router.post('/batches', status_code=202)
def start_batch(body: BatchStart, db: Session = Depends(get_db), user=Depends(admin)):
    batch = enqueue_batch(db, body.selected_date, body.preview, body.idempotency_key, user.id)
    core.audit(db, user, 'start_all_websites', batch, {'preview': body.preview})
    core.save(db)
    return batch_progress(db, batch)


@router.get('/batches')
def batches(db: Session = Depends(get_db)):
    return [batch_progress(db, b) for b in db.scalars(select(CrawlBatch).order_by(CrawlBatch.id.desc()).limit(100))]


@router.get('/batches/{id}')
def batch_detail(id: int, db: Session = Depends(get_db)):
    batch = core.require(db, CrawlBatch, id)
    return {**batch_progress(db, batch), 'date_status': date_overview(db, batch.selected_date)}


class BatchRetry(BaseModel):
    website_id: int


@router.post('/batches/{id}/retry', status_code=202)
def retry_batch_website(id: int, body: BatchRetry, db: Session = Depends(get_db), user=Depends(admin)):
    batch = core.require(db, CrawlBatch, id)
    entry = db.scalar(select(BatchEntry).where(BatchEntry.batch_id == id, BatchEntry.website_id == body.website_id))
    if not entry:
        raise HTTPException(404, 'WEB tidak termasuk dalam kelompok ini.')
    run = db.get(Run, entry.run_id)
    configuration = db.scalar(select(RunItem).where(RunItem.run_id == run.id, RunItem.metric_type == 'configuration'))
    if configuration:
        lock_date(db, run.selected_date)
        assert_available(db, run.selected_date)
        dest = monthly_destination(db, run.selected_date, validated=True)
        original = run.config_snapshot['destination']
        if (dest.id, dest.revision) != (original['id'], original['revision']):
            raise HTTPException(409, 'Tujuan berubah. Gunakan Crawl Ulang ke URL Baru pada hasil proses asal.')
        snapshot = make_snapshot(db, run.website_id, run.selected_date, dest)
        child = create_run(db, run.website_id, run.selected_date, batch.preview, str(uuid4()), user.id, snapshot, batch.id)
        entry.run_id, entry.status = child.id, 'WAITING'
        batch.status, batch.finished_at = 'QUEUED', None
        batch.cancel_requested_at,batch.cancel_requested_by,batch.current_phase=None,None,'QUEUED'
        core.audit(db, user, 'retry_website_configuration', child, {'original_run_id': run.id})
    else:
        queue_retry(db, run, core.Retry(), user)
    core.save(db)
    return batch_progress(db, batch)


@router.get('/reconciliations/date')
def reconciliation_date(selected_date: date, db: Session = Depends(get_db)):
    return date_overview(db, selected_date)


@router.get('/reconciliations/history')
def reconciliation_history(selected_date: date = None, website_id: int = None, db: Session = Depends(get_db)):
    query = select(Reconciliation).order_by(Reconciliation.id.desc()).limit(500)
    if selected_date:
        query = query.where(Reconciliation.selected_date == selected_date)
    if website_id:
        query = query.where(Reconciliation.website_id == website_id)
    return [core.serialize(r) for r in db.scalars(query)]


@router.post('/runs/{id}/reconcile', status_code=202)
def recheck_run(id: int, body: CheckRequest, db: Session = Depends(get_db), user=Depends(admin)):
    run = core.require(db, Run, id)
    dest = monthly_destination(db, run.selected_date, validated=True)
    if not is_current_run(db, run, dest):
        raise HTTPException(409, 'Proses ini memakai konfigurasi lama. Gunakan Crawl Ulang ke URL Baru.')
    batch = enqueue_batch(db, run.selected_date, False, body.idempotency_key, user.id, True, run)
    core.audit(db, user, 'recheck_website_read_only', batch, {'run_id': id})
    core.save(db)
    return batch_progress(db, batch)


@router.post('/reconciliations/recheck', status_code=202)
def recheck_date(body: DateCheck, db: Session = Depends(get_db), user=Depends(admin)):
    batch = enqueue_batch(db, body.selected_date, False, body.idempotency_key, user.id, True)
    core.audit(db, user, 'recheck_all_read_only', batch)
    core.save(db)
    return batch_progress(db, batch)


def clear_date(db, selected, user):
    lock_date(db, selected)
    assert_available(db, selected)
    dest = monthly_destination(db, selected, validated=True)
    state = date_overview(db, selected)
    if not state['eligible']:
        raise HTTPException(409, 'Belum dapat Clear: seluruh WEB harus selesai, tanpa kesalahan, BALANCE setiap WEB dan konsolidasi harus nol.')
    obj = db.scalar(select(FinalClearance).where(FinalClearance.selected_date == selected,
        FinalClearance.destination_document_id == dest.id, FinalClearance.destination_revision == dest.revision,
        FinalClearance.context_signature == state['context_signature']))
    if not obj:
        obj = FinalClearance(selected_date=selected, destination_document_id=dest.id, destination_revision=dest.revision,
            context_signature=state['context_signature'], confirmed_by=user.id)
        db.add(obj)
        db.flush()
    obj.is_clear, obj.confirmed_by, obj.confirmed_at = True, user.id, utcnow()
    core.audit(db, user, 'final_clear_all_websites', obj)
    return obj


@router.post('/runs/{id}/clear')
def clear_run(id: int, db: Session = Depends(get_db), user=Depends(admin)):
    run = core.require(db, Run, id)
    dest = monthly_destination(db, run.selected_date)
    if run.preview or not is_current_run(db, run, dest):
        raise HTTPException(409, 'Pratinjau atau hasil revisi lama tidak dapat ditandai Clear.')
    obj = clear_date(db, run.selected_date, user)
    core.save(db)
    return core.serialize(obj)


@router.post('/reconciliations/clear')
def clear_all(body: DateCheck, db: Session = Depends(get_db), user=Depends(admin)):
    obj = clear_date(db, body.selected_date, user)
    core.save(db)
    return core.serialize(obj)


@router.get('/clearances')
def clearances(db: Session = Depends(get_db)):
    return [{**core.serialize(c), 'website_id': None, 'environment': 'WORKING', 'scope': 'ALL'} for c in db.scalars(
        select(FinalClearance).order_by(FinalClearance.id.desc()).limit(500))]


@router.get('/clearances/legacy')
def legacy_clearances(db: Session = Depends(get_db)):
    return [core.serialize(c) for c in db.scalars(select(Clearance).order_by(Clearance.id.desc()).limit(500))]


@router.post('/clearances/{id}/reopen')
def reopen(id: int, body: core.Reopen, db: Session = Depends(get_db), user=Depends(admin)):
    obj = core.require(db, FinalClearance, id)
    lock_date(db, obj.selected_date)
    assert_available(db, obj.selected_date)
    obj.is_clear, obj.reopened_at, obj.reopen_reason = False, utcnow(), body.reason
    core.audit(db, user, 'reopen_all_websites', obj, body.model_dump())
    core.save(db)
    return core.serialize(obj)



@router.post('/runs/{id}/cancel')
def cancel_run(id:int,db:Session=Depends(get_db),user=Depends(admin)):
    run=core.require(db,Run,id)
    lock_date(db,run.selected_date)
    request_run_cancel(db,run,user.id)
    core.audit(db,user,'cancel_run',run,{'status':run.status})
    core.save(db)
    return core.serialize(run)


@router.post('/batches/{id}/cancel')
def cancel_batch(id:int,db:Session=Depends(get_db),user=Depends(admin)):
    batch=core.require(db,CrawlBatch,id)
    lock_date(db,batch.selected_date)
    request_batch_cancel(db,batch,user.id)
    core.audit(db,user,'cancel_batch',batch,{'status':batch.status})
    core.save(db)
    return batch_progress(db,batch)
