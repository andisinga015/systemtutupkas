#!/usr/bin/env bash
set -euo pipefail
project_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
test_root=$(mktemp -d /tmp/tutupkas-e2e.XXXXXX)
trap 'rm -rf -- "$test_root"' EXIT
export TK_DATABASE_URL="sqlite:///$test_root/test.sqlite3"
export TK_COOKIE_SECURE=false
export TK_APP_ORIGIN=http://127.0.0.1:5173
export TK_CREDENTIAL_FILE="$test_root/no-service-account.json"
export TK_E2E_PASSWORD
TK_E2E_PASSWORD=$("$project_root/.venv/bin/python" -c 'import secrets; print(secrets.token_urlsafe(32))')
cd "$project_root/backend"
../.venv/bin/alembic upgrade head
../.venv/bin/python - <<'PY'
import os
from app.auth import hasher
from app.db import SessionLocal
from app.models import User
with SessionLocal() as db:
    db.add(User(username='e2e-admin',password_hash=hasher.hash(os.environ['TK_E2E_PASSWORD'])))
    db.commit()
PY
cd "$project_root/frontend"
npm run test:e2e

