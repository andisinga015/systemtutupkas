"""Isolated browser fixture only; declares source identities without Google I/O."""
import argparse
import os
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from app.db import SessionLocal
from app.models import SourceDocument,SourceRevision,SourceSheet,Website
from app.lineage import refresh_bindings

parser=argparse.ArgumentParser();parser.add_argument('slug');parser.add_argument('--legacy',action='store_true');args=parser.parse_args()
url=os.environ.get('TK_DATABASE_URL','')
assert os.environ.get('TK_E2E_PASSWORD') and url.startswith('sqlite:////tmp/tutupkas-e2e.'), 'Only isolated E2E database permitted'
assert args.slug.startswith('period-e2e-')
with SessionLocal() as db:
    site=Website(display_name='PERIODE '+args.slug,slug=args.slug);db.add(site);db.flush()
    for month in (10,11):
        for n,period in enumerate(('FIRST_HALF','SECOND_HALF','MONTHLY'),1):
            if args.legacy and (period=='SECOND_HALF' or month==11):continue
            spreadsheet=f'e2e-{args.slug}-{month}-{period}'
            doc=SourceDocument(website_id=site.id,document_type='QRIS' if period=='MONTHLY' else 'DEPO',
                source_period='UNASSIGNED' if args.legacy and period=='FIRST_HALF' else period,
                year=2026,month=month,spreadsheet_id=spreadsheet,spreadsheet_url=f'https://docs.google.com/spreadsheets/d/{spreadsheet}/edit',
                validation_status='VALID',spreadsheet_title=f'Sumber {period} {month}')
            db.add(doc);db.flush()
            rev=SourceRevision(source_document_id=doc.id,revision_number=1,spreadsheet_url=doc.spreadsheet_url,
                spreadsheet_id=spreadsheet,changed_by=1)
            db.add(rev);db.flush();doc.active_revision_id=rev.id
            names=['QRIS E-POWER','QRIS QRIZZ'] if period=='MONTHLY' else ['WD BCA / SAMA','WD BCA / KHUSUS '+('A' if period=='FIRST_HALF' else 'B')]
            for j,name in enumerate(names):
                db.add(SourceSheet(source_document_id=doc.id,source_revision_id=rev.id,tab_name=name,
                    is_active=bool(month==10 and (period=='FIRST_HALF' and j==0 or period=='SECOND_HALF' and j==1 or period=='MONTHLY'))))
            db.flush()
            refresh_bindings(db,doc,{'sheets':[{'properties':{'sheetId':j+1,'title':name}} for j,name in enumerate(names)]})
    db.commit()
