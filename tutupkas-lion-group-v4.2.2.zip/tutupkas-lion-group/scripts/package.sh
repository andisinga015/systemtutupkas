#!/usr/bin/env bash
set -euo pipefail
project_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
cd "$project_root/frontend"
npm ci
npm run build
cd "$project_root"
python3 scripts/package.py

