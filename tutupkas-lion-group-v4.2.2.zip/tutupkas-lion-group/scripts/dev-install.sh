#!/usr/bin/env bash
set -euo pipefail
project_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
cd "$project_root"
export UV_CACHE_DIR="${UV_CACHE_DIR:-/tmp/tutupkas-uv-cache}"
export PIP_CACHE_DIR="${PIP_CACHE_DIR:-/tmp/tutupkas-pip-cache}"
if command -v uv >/dev/null 2>&1; then
  [[ -d .venv ]] || uv venv .venv
  uv pip sync --require-hashes --python .venv/bin/python backend/requirements.txt
else
  [[ -d .venv ]] || python3 -m venv .venv
  .venv/bin/python -m pip install --require-hashes -r backend/requirements.txt
fi
cd backend
../.venv/bin/alembic upgrade head
cd ../frontend
npm ci --cache /tmp/tutupkas-npm-cache
npm run build

