"""Read-only verification against the consistent pre-upgrade V4.2 backup.

Only audited queue cancellation and append-only cancellation/audit records may
change. This does not contact Google or acknowledge any financial write.
"""
import argparse
from itertools import zip_longest
import json
from pathlib import Path
import sqlite3

ACTIVE={'QUEUED','RUNNING','CANCEL_REQUESTED'}
RUN_FIELDS={'status','current_phase','finished_at','cancel_requested_at','cancel_requested_by'}


def quote(name):return '"'+name.replace('"','""')+'"'

def connect(path):
    conn=sqlite3.connect(Path(path).resolve().as_uri()+'?mode=ro',uri=True)
    conn.row_factory=sqlite3.Row
    return conn

def rows(db,table,where=''):
    columns=list(db.execute('PRAGMA table_info('+quote(table)+')'))
    keys=[r['name'] for r in sorted(columns,key=lambda r:r['pk']) if r['pk']]
    order=','.join(map(quote,keys)) if keys else 'rowid'
    return db.execute('SELECT * FROM '+quote(table)+where+' ORDER BY '+order)


def verify(before,after):
    for db in (before,after):
        if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok' or db.execute('PRAGMA foreign_key_check').fetchone():
            raise RuntimeError('Integritas/FK database tidak sesuai; worker harus tetap berhenti.')
        if db.execute('SELECT version_num FROM alembic_version').fetchone()[0]!='c92448ce233b':
            raise RuntimeError('Patch ini memerlukan schema V4.2 c92448ce233b.')
    schema="SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name"
    if [tuple(r) for r in before.execute(schema)]!=[tuple(r) for r in after.execute(schema)]:
        raise RuntimeError('Schema berubah; V4.2.1 tidak memerlukan perubahan schema.')
    active_runs={r[0] for r in before.execute("SELECT id FROM task_runs WHERE status IN ('QUEUED','RUNNING','CANCEL_REQUESTED')")}
    active_batches={r[0] for r in before.execute("SELECT id FROM crawl_batches WHERE status IN ('QUEUED','RUNNING','CANCEL_REQUESTED')")}
    tables=[r[0] for r in before.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
    total=0
    for table in tables:
        where=''
        if table in ('audit_logs','reconciliations'):
            maximum=before.execute('SELECT coalesce(max(id),0) FROM '+quote(table)).fetchone()[0]
            where=' WHERE id<='+str(int(maximum))
        for left,right in zip_longest(rows(before,table),rows(after,table,where)):
            if left is None or right is None:raise RuntimeError('Jumlah/identitas histori berubah pada '+table)
            allowed=set();old,new=dict(left),dict(right);expected=None
            if table=='task_runs' and old['id'] in active_runs:allowed=RUN_FIELDS;expected='CANCELED'
            elif table=='crawl_batches' and old['id'] in active_batches:allowed=RUN_FIELDS;expected='CANCELED'
            elif table=='task_run_items' and old['run_id'] in active_runs and old['status']=='PENDING':
                allowed={'status','processed_at'};expected='CANCELED'
            elif table=='crawl_batch_entries' and old['batch_id'] in active_batches and old['status'] in ('WAITING','RUNNING'):
                allowed={'status'};expected='CANCELED'
            elif table=='item_retry_requests' and old['run_id'] in active_runs and old['state'] in ('QUEUED','CLAIMED'):
                allowed={'state','finished_at'}
                if new['state']!='CANCELED':raise RuntimeError('Retry lama belum ditahan.')
            elif table=='destination_conflicts' and old['run_id'] in active_runs and old['state'] in ('WRITE_PENDING','KEEP_PENDING'):
                allowed={'state'}
                if new['state'] not in (old['state'],'OPEN'):raise RuntimeError('Keputusan konflik berubah secara tidak sah.')
            if expected is not None and new['status']!=expected:raise RuntimeError('Antrean lama belum CANCELED pada '+table)
            if any(old[k]!=new[k] for k in old.keys()-allowed):raise RuntimeError('Data terlindungi berubah pada '+table)
            total+=1
    return {'schema':'c92448ce233b','tables':len(tables),'preserved_rows':total,'financial_state_preserved':True,'active_runs_held':len(active_runs)}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('backup');parser.add_argument('current');args=parser.parse_args()
    with connect(args.backup) as before,connect(args.current) as after:result=verify(before,after)
    print(json.dumps(result))


if __name__=='__main__':main()
