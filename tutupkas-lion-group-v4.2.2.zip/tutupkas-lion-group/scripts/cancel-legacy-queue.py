"""Offline rollback maintenance; stdlib only, compatible with the V2 schema."""
import argparse
import fcntl
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

p=argparse.ArgumentParser(description='Finalkan antrean snapshot lama tanpa menghapus hasil tulis')
p.add_argument('database');p.add_argument('--services-stopped',required=True,action='store_true')
p.add_argument('--lock',default='/var/lib/tutupkas/worker.lock')
a=p.parse_args()
if not Path(a.database).is_file():p.error('Database yang ada harus tersedia; tidak membuat database baru')
with Path(a.lock).open('a') as lock:
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:p.error('Worker masih berjalan; hentikan layanan sebelum melanjutkan.')
    now=datetime.now(timezone.utc).replace(tzinfo=None).isoformat()
    with sqlite3.connect(a.database) as db:
        db.execute('PRAGMA foreign_keys=ON')
        tables={v[0] for v in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        db.execute("UPDATE task_run_items SET status='CANCELED',processed_at=? WHERE status='PENDING' AND run_id IN (SELECT id FROM task_runs WHERE status IN ('QUEUED','RUNNING','CANCEL_REQUESTED'))",(now,))
        runs=db.execute("UPDATE task_runs SET status='CANCELED',finished_at=? WHERE status IN ('QUEUED','RUNNING','CANCEL_REQUESTED')",(now,)).rowcount
        if 'crawl_batches' in tables:
            db.execute("UPDATE crawl_batch_entries SET status='CANCELED' WHERE status IN ('WAITING','RUNNING') AND batch_id IN (SELECT id FROM crawl_batches WHERE status IN ('QUEUED','RUNNING','CANCEL_REQUESTED'))")
            db.execute("UPDATE crawl_batches SET status='CANCELED',finished_at=? WHERE status IN ('QUEUED','RUNNING','CANCEL_REQUESTED')",(now,))
        db.execute("INSERT INTO audit_logs(action,entity_type,entity_id,metadata,created_at) VALUES (?,?,?,?,?)",('rollback_cancel_legacy_queue','maintenance','queue',json.dumps({'runs':runs}),now))
    print(f'Antrean snapshot lama dibatalkan: {runs} proses. Hasil, error, ledger dan kepemilikan tetap tersimpan.')
