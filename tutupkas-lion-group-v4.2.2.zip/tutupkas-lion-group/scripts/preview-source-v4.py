"""VPS-only, read-only reference acceptance probe; no financial writes or DB edits.

Run with the existing environment loaded, as tutupkas, while the worker is stopped:
  python ../scripts/preview-source-v4.py 5
This is a source probe; also run the full website PREVIEW in the existing UI.
"""
import fcntl
import json
import logging
from pathlib import Path
import sys
import time

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from app.config import settings
from app.db import SessionLocal
from app.diagnostics import memory
from app.engine.types import Issue, column
from app.models import Run
from app.sheets import SheetsClient


def main():
    if len(sys.argv)!=2:
        raise SystemExit('Penggunaan: python ../scripts/preview-source-v4.py RUN_ID')
    title='WD BCA 1 TOKEN / IVAN RAKHMANDA ( PP )'
    with Path(settings().worker_lock).open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise SystemExit('Hentikan worker sebelum menjalankan probe sumber.')
        with SessionLocal() as db:
            run=db.get(Run,int(sys.argv[1]))
            if not run or str(run.selected_date)!='2026-10-18' or run.config_snapshot.get('website')!='VELBETT':
                raise SystemExit('Pilih riwayat run VELBETT tanggal 2026-10-18.')
            docs=[d for d in run.config_snapshot['sources'] if d['type']=='DEPO' and title in d.get('tabs',[])]
            if len(docs)!=1:raise SystemExit('Tab referensi tidak ditemukan secara unik dalam snapshot run.')
            client=SheetsClient()
            client.diagnostic_context={'run_id':run.id,'website':'VELBETT','selected_date':'2026-10-18',
                                       'source_tab':title,'phase':'READ_ONLY_SOURCE_PREVIEW'}
            started=time.monotonic()
            day=client.source_day(docs[0]['spreadsheet_id'],title,run.selected_date,'DEPO')
            values=[day.metric(label) for label in ('Total','Total WD','SALDO')]
            result={'probe':'READ_ONLY_SOURCE_PREVIEW','run_id':run.id,'selected_date':str(run.selected_date),
                'source_tab':title,'total_depo':values[0],'total_wd':values[1],'saldo':values[2],
                'saldo_cell':f'{column(day.metric_column("SALDO"))}{day.last_metric_row+1}',
                'expected_match':values==[0,0,2355000],'duration_ms':round((time.monotonic()-started)*1000),**memory()}
            print(json.dumps(result))
            if not result['expected_match']:raise SystemExit('Nilai aktual berbeda dari target penerimaan; tinjau sumber.')


if __name__=='__main__':
    logging.basicConfig(level=logging.INFO,format='%(message)s')
    try:main()
    except Issue as error:raise SystemExit(f'{error.code}: {error.message}')
