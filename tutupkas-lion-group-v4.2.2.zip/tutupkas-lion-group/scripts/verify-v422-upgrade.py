"""Compare stopped V4.2/V4.2.1 backup to V4.2.2 without contacting Google.

Only the source period/schema migration, audited queue hold, and append-only
audit/reconciliation rows are allowed. All original protected columns must match.
"""
import argparse
from itertools import zip_longest
import json
from pathlib import Path
import sqlite3

HEAD='d422a61e908f'
RUN_FIELDS={'status','current_phase','finished_at','cancel_requested_at','cancel_requested_by'}


def quote(name):return '"'+name.replace('"','""')+'"'


def connect(path):
    db=sqlite3.connect(Path(path).resolve().as_uri()+'?mode=ro',uri=True)
    db.row_factory=sqlite3.Row
    return db


def columns(db,table):return list(db.execute('PRAGMA table_info('+quote(table)+')'))


def rows(db,table,where=''):
    keys=[r['name'] for r in sorted(columns(db,table),key=lambda r:r['pk']) if r['pk']]
    return db.execute('SELECT * FROM '+quote(table)+where+' ORDER BY '+(','.join(map(quote,keys)) if keys else 'rowid'))


def verify(before,after):
    for db in (before,after):
        if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok' or db.execute('PRAGMA foreign_key_check').fetchone():
            raise RuntimeError('Integritas/FK tidak sesuai; worker harus tetap berhenti.')
    prior_head=before.execute('SELECT version_num FROM alembic_version').fetchone()[0]
    if prior_head not in ('c92448ce233b',HEAD) or after.execute('SELECT version_num FROM alembic_version').fetchone()[0]!=HEAD:
        raise RuntimeError('Schema bukan jalur V4.2/V4.2.1 → V4.2.2 yang didukung.')
    tables=lambda db:{r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
    if tables(before)!=tables(after):raise RuntimeError('Daftar tabel berubah di luar migrasi periode sumber.')
    schema="SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' AND tbl_name!='source_documents' ORDER BY type,name"
    if [tuple(r) for r in before.execute(schema)]!=[tuple(r) for r in after.execute(schema)]:
        raise RuntimeError('Schema selain source_documents berubah.')
    old_columns=[tuple(r) for r in columns(before,'source_documents')]
    new_columns=[tuple(r) for r in columns(after,'source_documents')]
    if [r for r in new_columns if r[1]!='source_period']!=[r for r in old_columns if r[1]!='source_period']:
        raise RuntimeError('Kolom lama source_documents berubah.')
    period=next((r for r in new_columns if r[1]=='source_period'),None)
    if not period or period[3]!=1 or period[4] is not None:raise RuntimeError('Kolom periode tidak wajib/masih memiliki default tebakan.')
    sql=after.execute("SELECT sql FROM sqlite_master WHERE name='source_documents'").fetchone()[0]
    if 'ck_source_documents_period' not in sql or 'uq_source_documents_period' not in sql:
        raise RuntimeError('Constraint periode sumber tidak tersedia.')
    active_runs={r[0] for r in before.execute("SELECT id FROM task_runs WHERE status IN ('QUEUED','RUNNING','CANCEL_REQUESTED')")}
    active_batches={r[0] for r in before.execute("SELECT id FROM crawl_batches WHERE status IN ('QUEUED','RUNNING','CANCEL_REQUESTED')")}
    total=0;unassigned=0
    for table in sorted(tables(before)):
        where=''
        if table in ('audit_logs','reconciliations'):
            maximum=before.execute('SELECT coalesce(max(id),0) FROM '+quote(table)).fetchone()[0]
            where=' WHERE id<='+str(int(maximum))
        for left,right in zip_longest(rows(before,table),rows(after,table,where)):
            if left is None or right is None:raise RuntimeError('Identitas/jumlah histori berubah pada '+table)
            old,new=dict(left),dict(right);allowed=set();expected=None
            if table=='alembic_version':allowed={'version_num'}
            if table=='source_documents':
                expected_period=old.get('source_period','UNASSIGNED' if old['document_type']=='DEPO' else 'MONTHLY')
                if new.get('source_period')!=expected_period:raise RuntimeError('Periode lama ditebak/berubah saat migrasi.')
                unassigned+=new['source_period']=='UNASSIGNED'
            elif table=='task_runs' and old['id'] in active_runs:allowed=RUN_FIELDS;expected='CANCELED'
            elif table=='crawl_batches' and old['id'] in active_batches:allowed=RUN_FIELDS;expected='CANCELED'
            elif table=='task_run_items' and old['run_id'] in active_runs and old['status']=='PENDING':
                allowed={'status','processed_at'};expected='CANCELED'
            elif table=='crawl_batch_entries' and old['batch_id'] in active_batches and old['status'] in ('WAITING','RUNNING'):
                allowed={'status'};expected='CANCELED'
            elif table=='item_retry_requests' and old['run_id'] in active_runs and old['state'] in ('QUEUED','CLAIMED'):
                allowed={'state','finished_at'}
                if new['state']!='CANCELED':raise RuntimeError('Retry lama belum ditahan.')
            elif table=='destination_conflicts' and old['run_id'] in active_runs and old['state'] in ('WRITE_PENDING','KEEP_PENDING'):
                allowed={'state'}
                if new['state'] not in (old['state'],'OPEN'):raise RuntimeError('Keputusan konflik berubah.')
            if expected is not None and new['status']!=expected:raise RuntimeError('Pekerjaan lama belum ditahan pada '+table)
            if any(old[k]!=new[k] for k in old.keys()-allowed):raise RuntimeError('Data terlindungi berubah pada '+table)
            total+=1
    return {'from_schema':prior_head,'schema':HEAD,'tables':len(tables(before)),
        'preserved_rows':total,'legacy_depo_unassigned':unassigned,'active_runs_held':len(active_runs),
        'financial_state_preserved':True}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('backup');parser.add_argument('current');args=parser.parse_args()
    with connect(args.backup) as before,connect(args.current) as after:result=verify(before,after)
    print(json.dumps(result))


if __name__=='__main__':main()
