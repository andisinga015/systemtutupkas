#!/usr/bin/env bash
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo 'Gunakan sudo.' >&2; exit 1; }
exec runuser -u tutupkas -- bash -c 'set -a; source /etc/tutupkas/app.env; set +a; cd /opt/tutupkas/current/backend; exec /opt/tutupkas/current/.venv/bin/python -m app.cli "$@"' bash "$@"

