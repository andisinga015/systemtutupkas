#!/usr/bin/env bash
set -euo pipefail
umask 027
if [[ $EUID -ne 0 ]]; then
  echo 'Jalankan: sudo bash deploy/install.sh' >&2
  exit 1
fi
release_source=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
if [[ ! -f "$release_source/public/index.html" ]]; then
  echo 'Paket belum memuat public/index.html. Jalankan scripts/package.sh di komputer build, lalu unggah ZIP hasilnya.' >&2
  exit 1
fi
credential_path=/home/aksesfinancebot/spreadsheet-robot/credentials/robot-key.json
if [[ ! -f "$credential_path" ]]; then
  echo 'File Service Account yang sudah ada tidak ditemukan. Periksa path sebelum instalasi.' >&2
  exit 1
fi
python3 -c 'import sys; assert sys.version_info >= (3,10), "Python 3.10+ diperlukan"'
apt-get update
apt-get install -y python3-venv python3-pip rsync acl curl
if ! id tutupkas >/dev/null 2>&1; then
  useradd --system --user-group --home-dir /var/lib/tutupkas --shell /usr/sbin/nologin tutupkas
fi
install -d -m 0755 /opt/tutupkas /opt/tutupkas/releases
if [[ -e /opt/tutupkas/current && ! -L /opt/tutupkas/current ]]; then
  echo '/opt/tutupkas/current sudah ada dan bukan symlink rilis. Periksa sebelum melanjutkan.' >&2
  exit 1
fi
install -d -m 0700 -o tutupkas -g tutupkas /var/lib/tutupkas /var/lib/tutupkas/backups
install -d -m 0750 -o root -g tutupkas /etc/tutupkas
release_name=$(date -u +%Y%m%dT%H%M%S)-$$
release_path="/opt/tutupkas/releases/$release_name"
install -d -m 0755 "$release_path"
rsync -a --exclude='.git' --exclude='.venv' --exclude='.env' --exclude='node_modules' --exclude='data' --exclude='__pycache__' --exclude='test-results' --exclude='playwright-report' "$release_source/" "$release_path/"
chmod -R o+rX "$release_path"
python3 -m venv "$release_path/.venv"
"$release_path/.venv/bin/python" -m pip install --require-hashes -r "$release_path/backend/requirements.txt"
chown -R root:tutupkas "$release_path"
chmod -R g+rX "$release_path"
if [[ ! -f /etc/tutupkas/app.env ]]; then
  install -m 0640 -o root -g tutupkas "$release_path/deploy/app.env.example" /etc/tutupkas/app.env
fi
# Add per-user ACLs; preserve the robot owner, key contents and all existing ACLs.
for credential_parent in /home/aksesfinancebot /home/aksesfinancebot/spreadsheet-robot /home/aksesfinancebot/spreadsheet-robot/credentials; do
  setfacl -m u:tutupkas:--x "$credential_parent"
done
setfacl -m u:tutupkas:r-- "$credential_path"
runuser -u tutupkas -- test -r "$credential_path"
if [[ -L /opt/tutupkas/current ]]; then
  readlink -f /opt/tutupkas/current > /etc/tutupkas/previous-release
fi
if [[ -f /var/lib/tutupkas/tutupkas.sqlite3 ]]; then
  # Quiesce workers before migrations. They finish authorized in-flight work.
  systemctl stop tutupkas-worker tutupkas-api
  runuser -u tutupkas -- bash -c 'set -a; source /etc/tutupkas/app.env; set +a; cd "$1/backend"; exec "$1/.venv/bin/python" -m app.cli backup "$2"' bash "$release_path" "/var/lib/tutupkas/backups/pre-$release_name.sqlite3"
fi
runuser -u tutupkas -- bash -c 'set -a; source /etc/tutupkas/app.env; set +a; cd "$1/backend"; exec "$1/.venv/bin/alembic" upgrade head' bash "$release_path"
ln -s "$release_path" /opt/tutupkas/current.next
mv -Tf /opt/tutupkas/current.next /opt/tutupkas/current
install -m 0644 "$release_path/deploy/tutupkas-api.service" /etc/systemd/system/tutupkas-api.service
install -m 0644 "$release_path/deploy/tutupkas-worker.service" /etc/systemd/system/tutupkas-worker.service
# Publish hashed frontend assets before index; preserve existing unrelated files.
install -d -m 0755 /var/www/html
rsync -a --exclude='index.html' "$release_path/public/" /var/www/html/
install -m 0644 "$release_path/public/index.html" /var/www/html/index.html
systemctl daemon-reload
systemctl enable --now tutupkas-api tutupkas-worker
systemctl restart tutupkas-api tutupkas-worker
for attempt in {1..15}; do
  if curl --fail --silent http://127.0.0.1:8000/api/health; then
    echo
    echo 'API sehat. Nginx dan HTTPS belum diubah. Ikuti docs/DEPLOYMENT.md untuk admin pertama dan include Nginx.'
    exit 0
  fi
  sleep 2
done
echo 'Health check gagal. Periksa journalctl -u tutupkas-api -n 50; lihat prosedur rollback.' >&2
exit 1

