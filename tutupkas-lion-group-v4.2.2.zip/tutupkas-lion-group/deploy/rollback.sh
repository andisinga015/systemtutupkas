#!/usr/bin/env bash
# Invoke only when intentionally restoring the pre-upgrade application + database.
set -euo pipefail
umask 077
[[ $EUID -eq 0 && $# -eq 1 ]] || { echo 'Penggunaan: sudo bash deploy/rollback.sh /var/lib/tutupkas/backups/upgrade-v4.2.2-...' >&2; exit 1; }
release_source=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
backup_path=$(realpath -- "$1")
[[ ( "$backup_path" == /var/lib/tutupkas/backups/upgrade-v2-* || "$backup_path" == /var/lib/tutupkas/backups/upgrade-v3-* || "$backup_path" == /var/lib/tutupkas/backups/upgrade-v4-* || "$backup_path" == /var/lib/tutupkas/backups/upgrade-v4.1-* || "$backup_path" == /var/lib/tutupkas/backups/upgrade-v4.2-* || "$backup_path" == /var/lib/tutupkas/backups/upgrade-v4.2.1-* || "$backup_path" == /var/lib/tutupkas/backups/upgrade-v4.2.2-* ) && -s "$backup_path/database.sqlite3" && -s "$backup_path/frontend.tar.gz" ]] || { echo 'Backup upgrade tidak lengkap.' >&2; exit 1; }
previous_release=$(cat "$backup_path/previous-release")
database_path=$(cat "$backup_path/database-path")
[[ "$previous_release" == /opt/tutupkas/releases/* && -d "$previous_release/backend" && "$database_path" == /var/lib/tutupkas/* && -L /opt/tutupkas/current ]] || { echo 'Path rollback tidak sesuai instalasi; gunakan pemulihan manual.' >&2; exit 1; }
# Preserve post-upgrade data too. Restoring intentionally discards later changes
# from the active DB; those remain available in this additional backup.
systemctl stop tutupkas-api
systemctl stop tutupkas-worker
recovery_path="$backup_path/post-upgrade-$(date -u +%Y%m%dT%H%M%S)-$$.sqlite3"
python3 - "$database_path" "$recovery_path" "$backup_path/database.sqlite3" <<'PY'
import sqlite3,sys
from pathlib import Path
active,snapshot,backup=map(Path,sys.argv[1:])
with sqlite3.connect(active) as source,sqlite3.connect(snapshot) as target: source.backup(target)
with sqlite3.connect(backup) as conn: assert conn.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
PY
chown tutupkas:tutupkas "$recovery_path"
install -m 0600 -o tutupkas -g tutupkas "$backup_path/database.sqlite3" "$database_path.restore"
# SQLite sidecars are valid only for the database they belong to; services are stopped.
rm -f -- "$database_path-wal" "$database_path-shm"
mv -f "$database_path.restore" "$database_path"
ln -s "$previous_release" /opt/tutupkas/current.rollback
mv -Tf /opt/tutupkas/current.rollback /opt/tutupkas/current
tar -C /var/www/html -xzf "$backup_path/frontend.tar.gz"
nginx -t
# Restored V2 snapshots can contain queued jobs canceled later in V3.
# Finalize that old queue before any worker is allowed to start.
python3 "$release_source/scripts/cancel-legacy-queue.py" "$database_path" --services-stopped
systemctl start tutupkas-api
echo 'Worker tetap dihentikan. Tinjau hasil/intent dan panduan rollback sebelum sudo systemctl start tutupkas-worker.'
curl --retry 10 --retry-connrefused --retry-delay 2 --fail http://127.0.0.1:8000/api/health
echo 'Rollback selesai. Lakukan hard refresh. Database setelah upgrade juga disimpan dalam folder backup.'
