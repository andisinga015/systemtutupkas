#!/usr/bin/env bash
# Upgrade v4.2/v4.2.1 -> v4.2.2. Does not edit Nginx, certificates, app.env, or credentials.
set -euo pipefail
umask 027
[[ $EUID -eq 0 ]] || { echo 'Jalankan sudo bash deploy/upgrade.sh' >&2; exit 1; }
release_source=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
credential_path=/home/aksesfinancebot/spreadsheet-robot/credentials/robot-key.json
[[ -s "$release_source/public/index.html" && -d "$release_source/backend/migrations" ]] || { echo 'Gunakan ZIP rilis lengkap dengan public/index.html.' >&2; exit 1; }
[[ -d /opt/tutupkas/current/backend && -f /etc/tutupkas/app.env ]] || { echo 'Instalasi lama atau app.env tidak ditemukan. Ikuti docs/UPGRADE_V422.md.' >&2; exit 1; }
[[ -x /opt/tutupkas/current/.venv/bin/python ]] || { echo 'Python environment release terpasang tidak ditemukan. Tinjau instalasi lama sebelum stop/migrasi.' >&2; exit 1; }
[[ -r "$credential_path" ]] || { echo 'Kredensial lama tidak ditemukan; isi key tidak akan diubah.' >&2; exit 1; }
for executable in python3 rsync tar curl runuser systemctl nginx; do command -v "$executable" >/dev/null; done
[[ $(systemctl show -p User --value tutupkas-api) == tutupkas && $(systemctl show -p User --value tutupkas-worker) == tutupkas ]] || { echo 'User layanan berbeda dari tutupkas. Sesuaikan panduan manual sebelum upgrade.' >&2; exit 1; }
for service in tutupkas-api tutupkas-worker; do
  [[ $(systemctl show -p WorkingDirectory --value "$service") == /opt/tutupkas/current/backend ]] || { echo "WorkingDirectory $service berbeda; periksa unit tanpa menggantinya." >&2; exit 1; }
  [[ $(systemctl show -p EnvironmentFiles --value "$service") == /etc/tutupkas/app.env\ * ]] || { echo "EnvironmentFile $service berbeda." >&2; exit 1; }
done
nginx -t
installed_release=$(head -n 1 /opt/tutupkas/current/README.md)
printf 'Release terpasang: %s\n' "$installed_release"
runuser -u tutupkas -- test -r "$credential_path"
release_name="v4.2.2-$(date -u +%Y%m%dT%H%M%S)-$$"
release_path="/opt/tutupkas/releases/$release_name"
backup_path="/var/lib/tutupkas/backups/upgrade-$release_name"
install -d -m 0755 /opt/tutupkas/releases "$release_path"
rsync -a --exclude='.git' --exclude='.venv' --exclude='.env*' --exclude='node_modules' --exclude='data' --exclude='__pycache__' --exclude='test-results' --exclude='playwright-report' "$release_source/" "$release_path/"
python3 -m venv "$release_path/.venv"
"$release_path/.venv/bin/python" -m pip install --require-hashes -r "$release_path/backend/requirements.txt"
chown -R root:tutupkas "$release_path"
chmod -R u=rwX,g=rX,o=rX "$release_path"
app_run() {
  runuser -u tutupkas -- bash -c 'set -a; source /etc/tutupkas/app.env; set +a; cd "$1/backend"; shift; exec "$@"' bash "$release_path" "$@"
}
installed_app_run() {
  # Before migration use the installed model/workflow, including recheck batch
  # cancellation signatures. New period-aware code requires the NEW schema.
  runuser -u tutupkas -- bash -c 'set -a; source /etc/tutupkas/app.env; set +a; cd /opt/tutupkas/current/backend; exec /opt/tutupkas/current/.venv/bin/python "$@"' bash "$@"
}
app_run "$release_path/.venv/bin/python" -c 'import app.models, app.operations; print("Modul pembaruan dapat dimuat.")'
database_path=$(app_run "$release_path/.venv/bin/python" -c 'from app.config import settings; from pathlib import Path; u=settings().database_url; assert u.startswith("sqlite:////var/lib/tutupkas/"); print(Path(u[10:]).resolve())')
[[ "$database_path" == /var/lib/tutupkas/* && -f "$database_path" ]] || { echo 'Database lama tidak ditemukan di /var/lib/tutupkas. Dibatalkan.' >&2; exit 1; }
# V4.2 and V4.2.1 share c92448ce233b; detect the actual installed schema.
# V4.2.2 changes source periods only, never rebuilds destination mapping.
app_run "$release_path/.venv/bin/python" - "$database_path" <<'SCHEMA'
import pathlib,sqlite3,sys
with sqlite3.connect(pathlib.Path(sys.argv[1]).resolve().as_uri()+'?mode=ro',uri=True) as db:
    version=db.execute('SELECT version_num FROM alembic_version').fetchone()[0]
    assert version in ('c92448ce233b','d422a61e908f'), 'Diperlukan schema V4.2/V4.2.1 atau V4.2.2; gunakan panduan versi sebelumnya dahulu.'
    print('Schema terpasang:',version)
    print('Run finansial aktif:',db.execute("SELECT count(*) FROM task_runs WHERE status IN ('QUEUED','RUNNING','CANCEL_REQUESTED')").fetchone()[0])
SCHEMA
install -d -m 0700 -o tutupkas -g tutupkas "$backup_path"
printf '%s\n' "$database_path" > "$backup_path/database-path"
previous_release=$(readlink -f /opt/tutupkas/current)
printf '%s\n' "$previous_release" > "$backup_path/previous-release"
echo "Backup: $backup_path"
# Prevent new requests; retain a consistent pre-stop snapshot before asking
# the OLD worker to cancel through the existing database cancellation protocol.
systemctl stop tutupkas-api
app_run "$release_path/.venv/bin/python" -m app.cli backup "$backup_path/pre-stop.sqlite3"
installed_app_run - <<'STOP'
from sqlalchemy import select
from app.db import SessionLocal
from app.models import AuditLog,CrawlBatch,Run
from app.job_control import request_batch_cancel,request_run_cancel
from app.workflow import lock_date
with SessionLocal() as db:
    count=0
    for model,request in ((CrawlBatch,request_batch_cancel),(Run,request_run_cancel)):
        for job in db.scalars(select(model).where(model.status.in_(['QUEUED','RUNNING','CANCEL_REQUESTED']))):
            lock_date(db,job.selected_date)
            request(db,job,None)
            count+=1
    db.add(AuditLog(action='prepare_v422_stop_requested',entity_type='maintenance',entity_id='queue',details={'jobs':count}))
    db.commit()
print('Permintaan Stop tercatat; tulisan yang sudah dikirim tetap harus diverifikasi.')
STOP
systemctl stop tutupkas-worker
# Keep a reboot from silently activating held financial work during acceptance.
systemctl disable tutupkas-worker
trap 'echo "Upgrade terhenti. Backup: $backup_path. Lihat docs/UPGRADE_V422.md atau jalankan sudo bash $release_source/deploy/rollback.sh $backup_path" >&2' ERR
app_run "$release_path/.venv/bin/python" -m app.cli backup "$backup_path/database.sqlite3"
tar -C /opt/tutupkas/current -czf "$backup_path/application.tar.gz" .
tar -C /var/www/html -czf "$backup_path/frontend.tar.gz" .
cp -p /etc/tutupkas/app.env "$backup_path/app.env.backup"
chmod 0600 "$backup_path/app.env.backup"
app_run "$release_path/.venv/bin/alembic" current
app_run "$release_path/.venv/bin/alembic" upgrade head
app_run "$release_path/.venv/bin/alembic" check
# Finalize held work without changing snapshots, READY mappings, ledgers or history.
app_run "$release_path/.venv/bin/python" -m app.cli prepare-v42-upgrade --services-stopped
app_run "$release_path/.venv/bin/python" "$release_path/scripts/verify-v422-upgrade.py" "$backup_path/database.sqlite3" "$database_path"
if [[ ! -L /opt/tutupkas/current ]]; then
  previous_release="/opt/tutupkas/releases/legacy-$release_name"
  mv /opt/tutupkas/current "$previous_release"
  printf '%s\n' "$previous_release" > "$backup_path/previous-release"
fi
ln -s "$release_path" /opt/tutupkas/current.next
mv -Tf /opt/tutupkas/current.next /opt/tutupkas/current
# Keep old hashed assets for cached pages and rollback. Publish HTML last.
rsync -a --exclude='index.html' "$release_path/public/" /var/www/html/
install -m 0644 "$release_path/public/index.html" "/var/www/html/index.html.$release_name"
mv -f "/var/www/html/index.html.$release_name" /var/www/html/index.html
nginx -t
systemctl start tutupkas-api
healthy=false
for attempt in {1..15}; do
  if curl --fail --silent http://127.0.0.1:8000/api/health >/dev/null; then healthy=true; break; fi
  sleep 2
done
[[ "$healthy" == true ]] || { echo 'API belum sehat; ikuti rollback sebelum menjalankan transaksi.' >&2; exit 1; }
trap - ERR
printf 'Upgrade selesai. Backup: %s\n' "$backup_path"
echo 'Worker tetap STOPPED dan dinonaktifkan saat boot. Tinjau antrean/intent, lalu ikuti PREVIEW dan manual-start pada docs/UPGRADE_V422.md. MemoryMax, Nginx, HTTPS, kredensial, akun, dan app.env dipertahankan.'
cat <<'VERIFY'
Verifikasi berikutnya:
  curl --fail http://127.0.0.1:8000/api/health
  sudo systemctl status tutupkas-api --no-pager
  sudo systemctl is-active tutupkas-worker
  sudo systemctl show tutupkas-worker -p MemoryMax -p MemoryHigh
  sudo -u tutupkas bash -c 'set -a; source /etc/tutupkas/app.env; set +a; cd /opt/tutupkas/current/backend; ../.venv/bin/alembic current; ../.venv/bin/alembic check'
Pertahankan sumber dan versi registry READY yang sudah ada; tidak perlu mapping ulang untuk patch ini.
Tetapkan setiap DOC DEPO lama menjadi DOC A atau DOC B secara eksplisit; QRIS tetap bulanan.
Jangan melanjutkan Run historis otomatis. Antrekan hanya Preview yang telah ditinjau, kemudian jalankan manual:
  sudo systemctl start tutupkas-worker
VERIFY
