import type { Doc } from './api'

export const sourceOptions = [
 {key:'FIRST_HALF',type:'DEPO',name:'DOC A — DEPO/WD',choice:'DOC A — DEPO/WD (1–15)'},
 {key:'SECOND_HALF',type:'DEPO',name:'DOC B — DEPO/WD',choice:'DOC B — DEPO/WD (16–akhir bulan)'},
 {key:'MONTHLY',type:'QRIS',name:'DOC QRIS',choice:'DOC QRIS — Bulanan'},
] as const

export function periodRange(period:string,year:number,month:number){
 const last=new Date(year,month,0).getDate()
 return period==='FIRST_HALF'?'1–15':period==='SECOND_HALF'?`16–${last}`:`1–${last}`
}

export function sourceName(doc:Pick<Doc,'document_type'|'source_period'>){
 return sourceOptions.find(o=>o.type===doc.document_type&&o.key===doc.source_period)?.name||'DOC DEPO lama — belum ditetapkan'
}
