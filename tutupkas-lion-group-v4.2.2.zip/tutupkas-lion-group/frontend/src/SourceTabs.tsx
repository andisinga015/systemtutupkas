import {useEffect,useRef,useState} from 'react'
import {Check,ExternalLink,FileSpreadsheet,Layers3,RefreshCw,TriangleAlert} from 'lucide-react'
import {api,send} from './api'
import type {Doc,Tab} from './api'
import {Empty,Spinner,useNotice} from './components/ui'
import {HelpLink} from './Help'
import {sourceOptions} from './sourcePeriods'
import './sourcePeriods.css'

type Counts={active:number;inactive:number;unavailable:number}
const counts=(tabs:Tab[]):Counts=>({active:tabs.filter(t=>t.is_available&&t.is_active).length,
 inactive:tabs.filter(t=>t.is_available&&!t.is_active).length,unavailable:tabs.filter(t=>!t.is_available).length})
const docKey=(doc:Doc|undefined)=>`${doc?.id||'missing'}:${doc?.active_revision_id??'none'}`
type State={key:string;tabs:Tab[]|null;selected:number[];action:string;busy:boolean;error:string}

export function SourceTabManagement({docs,context}:{docs:Doc[];context:string}){
 const [period,setPeriod]=useState<string>('FIRST_HALF')
 const option=sourceOptions.find(o=>o.key===period)!
 const doc=docs.find(d=>d.document_type===option.type&&d.source_period===period)
 const key=`${context}:${period}:${docKey(doc)}`
 const current=useRef(key);current.current=key
 const sequence=useRef(0),notice=useNotice()
 const [state,setState]=useState<State>({key:'',tabs:null,selected:[],action:'active',busy:false,error:''})
 const [observed,setObserved]=useState<Record<string,Counts>>({})
 useEffect(()=>{
  const ticket=++sequence.current
  const valid=()=>current.current===key&&sequence.current===ticket
  setState({key,tabs:doc?null:[],selected:[],action:'active',busy:false,error:''})
  if(doc){
   const controller=new AbortController()
   api<Tab[]>(`/sources/${doc.id}/tabs?source_revision_id=${doc.active_revision_id}`,{signal:controller.signal})
    .then(tabs=>{if(valid()){setState(s=>({...s,tabs}));setObserved(c=>({...c,[docKey(doc)]:counts(tabs)}))}})
    .catch(e=>{if(valid()&&e.name!=='AbortError')setState(s=>({...s,error:e.message}))})
   return()=>{sequence.current++;controller.abort()}
  }
  return()=>{sequence.current++}
 },[key])
 const visible=state.key===key
 const tabs=visible?state.tabs:null,selected=visible?state.selected:[]
 const ready=!!doc&&visible&&tabs!==null&&!state.error&&!state.busy
 const canRefresh=!!doc&&visible&&!state.busy&&(tabs!==null||!!state.error)
 const act=async(refresh:boolean)=>{
  if(!doc||!(refresh?canRefresh:ready)||(!refresh&&!selected.length))return
  const ticket=sequence.current
  const valid=()=>current.current===key&&sequence.current===ticket
  setState(s=>({...s,busy:true}))
  try{
   const body=refresh?{source_revision_id:doc.active_revision_id}:{ids:selected,is_active:state.action==='active',source_revision_id:doc.active_revision_id}
   const actual=await send<Tab[]>(`/sources/${doc.id}/tabs${refresh?'/refresh':''}`,body)
   if(valid()){
    setState(s=>({...s,tabs:actual,selected:[],error:''}))
    setObserved(c=>({...c,[docKey(doc)]:counts(actual)}))
    notice(refresh?'Daftar sheet diperbarui. Sheet baru tetap nonaktif.':'Status sheet dokumen ini disimpan.')
   }
  }catch(e){if(valid())notice((e as Error).message,true)}
  finally{if(valid())setState(s=>({...s,busy:false}))}
 }
 const toggle=(id:number)=>{if(ready)setState(s=>({...s,selected:s.selected.includes(id)?s.selected.filter(v=>v!==id):[...s.selected,id]}))}
 return <>
  <div className="panel tab-controls">
   <div><span className="tiny-label">{context} · DOKUMEN SUMBER</span><div className="segmented source-options">
    {sourceOptions.map(o=>{const d=docs.find(v=>v.document_type===o.type&&v.source_period===o.key),c=observed[docKey(d)]||d?.tab_counts
     return <button key={o.key} className={period===o.key?'active':''} aria-pressed={period===o.key} onClick={()=>setPeriod(o.key)}>
      <span>{o.choice}</span><small>{d?`${c?.active||0} aktif · ${c?.inactive||0} nonaktif · ${c?.unavailable||0} tidak tersedia`:'URL belum tersedia'}</small>
     </button>})}
   </div></div>
   <button className="button" disabled={!canRefresh} onClick={()=>void act(true)}><RefreshCw size={15} className={visible&&state.busy?'spin':''}/>Refresh Daftar Sheet</button>
   <div className="selection-actions"><span>{selected.length} dipilih</span><select aria-label="Tindakan sheet" value={visible?state.action:'active'} disabled={!ready} onChange={e=>setState(s=>({...s,action:e.target.value}))}><option value="active">Aktifkan</option><option value="inactive">Nonaktifkan</option></select><button className="button primary" disabled={!ready||!selected.length} onClick={()=>void act(false)}><Check size={15}/>Terapkan</button></div>
  </div>
  {!doc&&<div className="inline-alert" role="status"><TriangleAlert size={18}/>{option.name} {period==='FIRST_HALF'?'tanggal 1–15':period==='SECOND_HALF'?'tanggal 16–akhir bulan':'bulanan'} belum memiliki URL.</div>}
  {visible&&state.error&&<div className="inline-alert error" role="alert">{state.error}</div>}
  <div className="document-grid">{[true,false].map(active=><div className="panel tab-list" key={String(active)}><div className="panel-heading"><h3><span className={'legend-dot '+(active?'green':'gray')}/>Daftar Sheet {active?'Aktif':'Nonaktif'} <HelpLink article="sheet-aktif"/></h3><span className="count-badge">{tabs?.filter(t=>t.is_available&&t.is_active===active).length||0}</span></div>
   {tabs===null?<Spinner/>:!tabs.some(t=>t.is_available&&t.is_active===active)?<Empty icon={<Layers3 size={24}/>} title={`Belum ada sheet ${active?'aktif':'nonaktif'}`} text={active?'Pilih sheet dari daftar nonaktif, lalu terapkan Aktifkan.':'Sheet baru dari Google tetap nonaktif sampai dipilih Admin.'}/>:tabs.filter(t=>t.is_available&&t.is_active===active).map(t=><label className={'tab-row '+(selected.includes(t.id)?'checked':'')} key={t.id}><input type="checkbox" disabled={!ready} checked={selected.includes(t.id)} onChange={()=>toggle(t.id)}/><FileSpreadsheet size={17}/><span>{t.tab_name}</span></label>)}
  </div>)}</div>
  {tabs?.some(t=>!t.is_available)&&<div className="panel removed-tabs"><h3>Sheet tidak lagi tersedia</h3><p>Sheet ini tidak ikut diproses. Nama yang sama di dokumen lain tidak membuktikan identitasnya.</p>{tabs.filter(t=>!t.is_available).map(t=><span className="badge inactive" key={t.id}>{t.tab_name}</span>)}</div>}
 </>
}

export function LegacySourceAssignment({docs,reload}:{docs:Doc[];reload:()=>Promise<void>}){
 const [busy,setBusy]=useState(false),notice=useNotice()
 const assign=async(doc:Doc,period:string)=>{
  setBusy(true)
  try{await send(`/sources/${doc.id}/assign-period`,{source_period:period,source_revision_id:doc.active_revision_id});await reload();notice('Periode DOC lama ditetapkan. Identitas, revisi dan status sheet tetap dipertahankan.')}
  catch(e){notice((e as Error).message,true)}finally{setBusy(false)}
 }
 return <>{docs.filter(d=>d.document_type==='DEPO'&&d.source_period==='UNASSIGNED').map(doc=><div className="panel legacy-source" key={doc.id}>
  <h3>DOC DEPO lama — perlu penetapan periode</h3><p>URL lama belum dipilih sebagai DOC A atau DOC B. Tinjau dokumen ini dan tetapkan secara eksplisit. Status sheet lama tetap mengikuti dokumen yang sama.</p>
  <a className="url-link" href={doc.spreadsheet_url} target="_blank" rel="noopener noreferrer">{doc.spreadsheet_url}<ExternalLink size={14}/></a>
  <div className="document-actions">{sourceOptions.filter(o=>o.type==='DEPO').map(o=><button key={o.key} className="button" disabled={busy||docs.some(d=>d.document_type==='DEPO'&&d.source_period===o.key)} onClick={()=>void assign(doc,o.key)}>Tetapkan sebagai {o.key==='FIRST_HALF'?'DOC A — tanggal 1–15':'DOC B — tanggal 16–akhir bulan'}</button>)}</div>
 </div>)}</>
}
