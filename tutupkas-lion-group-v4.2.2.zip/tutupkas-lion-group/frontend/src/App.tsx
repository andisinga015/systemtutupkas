import { useCallback, useEffect, useState } from 'react'
import type { FormEvent } from 'react'
import { Link, NavLink, Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom'
import { Activity, ArrowDownToLine, ArrowRight, Bell, ChevronDown, ChevronRight, CircleHelp, Crown, Database, FileClock, Globe2, LayoutDashboard, LockKeyhole, LogOut, Menu, Search, ShieldCheck, TriangleAlert, Wallet } from 'lucide-react'
import { api, send, setCsrf, dateLabel } from './api'
import type { Run, Website } from './api'
import { Field, Modal, Spinner, useNotice } from './components/ui'
import { Dashboard, RunDetail, History } from './Dashboard'
import { DestinationPage, WebsiteList, WebsiteSettings } from './Settings'
import HelpCenter from './Help'
import { BatchDetail } from './Dashboard'

type User={username:string;csrf_token:string}
export default function App(){
 const [user,setUser]=useState<User|null>(null),[loading,setLoading]=useState(true)
 useEffect(()=>{api<User>('/auth/me').then(u=>{setUser(u);setCsrf(u.csrf_token)}).catch(()=>{}).finally(()=>setLoading(false));const expire=()=>{setUser(null);setCsrf('')};window.addEventListener('session-expired',expire);return()=>window.removeEventListener('session-expired',expire)},[])
 if(loading)return <div className="full-loading"><Spinner/></div>
 if(!user)return <Login onLogin={u=>{setUser(u);setCsrf(u.csrf_token)}}/>
 return <Shell user={user} onLogout={()=>{setUser(null);setCsrf('')}}/>
}
function Login({onLogin}:{onLogin:(u:User)=>void}){
 const [busy,setBusy]=useState(false),[error,setError]=useState('')
 const navigate=useNavigate()
 const submit=async(e:FormEvent<HTMLFormElement>)=>{e.preventDefault();setBusy(true);setError('');const fields=new FormData(e.currentTarget);try{const initial=await api<{csrf_token:string}>('/auth/csrf');setCsrf(initial.csrf_token);const u=await send<User>('/auth/login',{username:fields.get('username'),password:fields.get('password')});onLogin(u);navigate('/dashboard')}catch(e){setError((e as Error).message)}finally{setBusy(false)}}
 return <div className="login-page"><div className="login-visual"><Link to="/dashboard" className="brand"><span className="brand-icon"><Crown size={26}/></span><span>TUTUP KAS<small>LION GROUP</small></span></Link><div className="login-story"><span className="eyebrow"><span className="live-dot"/> OPERASIONAL KEUANGAN</span><h1>Setiap angka.<br/>Dalam kendali.</h1><p>Satu ruang kerja untuk mengelola spreadsheet, menarik data, dan menutup hari dengan kepastian.</p><div className="orb"><div className="orb-inner"><Crown size={70}/></div><span className="orbit one"/><span className="orbit two"/><div className="float-card fc-one"><ShieldCheck size={22}/><span>Aman & terverifikasi<small>Data Anda, kendali Anda.</small></span></div><div className="float-card fc-two"><Activity size={24}/><span>Presisi di setiap proses</span></div></div></div><small>© {new Date().getFullYear()} Lion Group. Seluruh hak dilindungi.</small></div>
 <div className="login-form-side"><span className="login-secure"><LockKeyhole size={14}/> AKSES ADMINISTRATOR</span><form onSubmit={submit} className="login-form"><div className="square-icon"><ArrowDownToLine size={25}/></div><h2>Selamat datang kembali</h2><p>Masuk untuk mengelola operasional Tutup Kas.</p><Field label="Nama pengguna"><input name="username" autoComplete="username" placeholder="Masukkan nama pengguna" required maxLength={80}/></Field><Field label="Kata sandi"><input name="password" type="password" autoComplete="current-password" placeholder="Masukkan kata sandi" required maxLength={1024}/></Field>{error&&<div className="inline-alert error" role="alert"><TriangleAlert size={18}/>{error}</div>}<button disabled={busy} className="button primary full">{busy?'Memverifikasi…':'Masuk ke Dashboard'}<ArrowRight size={17}/></button><div className="login-note"><ShieldCheck size={16}/><span>Akses terbatas untuk administrator terdaftar.<br/>Hubungi pengelola server jika memerlukan akses.</span></div></form><small className="login-bottom">Sistem administrasi keuangan • Lion Group</small></div></div>
}
function Shell({user,onLogout}:{user:User;onLogout:()=>void}){
 const location=useLocation(),navigate=useNavigate(),notice=useNotice()
 const [smallScreen,setSmallScreen]=useState(()=>window.matchMedia('(max-width:760px)').matches)
 useEffect(()=>{const media=window.matchMedia('(max-width:760px)'),change=()=>{setSmallScreen(media.matches);if(!media.matches)setMobile(false)};media.addEventListener('change',change);return()=>media.removeEventListener('change',change)},[])
 const [mobile,setMobile]=useState(false),[search,setSearch]=useState(false),[query,setQuery]=useState(''),[sites,setSites]=useState<Website[]>([]),[notifications,setNotifications]=useState(false),[errors,setErrors]=useState<Run[]>([]),[health,setHealth]=useState(false)
 useEffect(()=>{setMobile(false);setNotifications(false)},[location.pathname])
 useEffect(()=>{
  if(!mobile)return
  const previous=document.activeElement as HTMLElement,overflow=document.body.style.overflow
  document.body.style.overflow='hidden'
  const sidebar=document.getElementById('app-sidebar')!
  sidebar.querySelector<HTMLElement>('.sidebar-close')?.focus()
  const keyboard=(e:KeyboardEvent)=>{
   if(e.key==='Escape')setMobile(false)
   if(e.key==='Tab'){
    const elements=Array.from(sidebar.querySelectorAll<HTMLElement>('a,button,[tabindex="0"]')).filter(x=>x.offsetParent!==null)
    const first=elements[0],last=elements[elements.length-1]
    if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}
    if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}
   }
  }
  document.addEventListener('keydown',keyboard)
  return()=>{document.body.style.overflow=overflow;document.removeEventListener('keydown',keyboard);previous?.focus()}
 },[mobile])
 useEffect(()=>{api('/health').then(()=>setHealth(true)).catch(()=>setHealth(false))},[])
 const closeSearch=useCallback(()=>setSearch(false),[])
 const openSearch=()=>{setSearch(true);setQuery('');api<Website[]>('/websites').then(setSites).catch(e=>notice(e.message,true))}
 const openNotifications=()=>{setNotifications(v=>!v);api<Run[]>('/runs').then(r=>setErrors(r.filter(x=>['FAILED','PARTIAL'].includes(x.status)||['NOT_BALANCED','ERROR'].includes(x.reconciliation?.status||'')))).catch(e=>notice(e.message,true))}
 const title=location.pathname.startsWith('/admin-setting')?'Pengaturan WEB':location.pathname.startsWith('/kas-kecil')?'Kas Kecil':location.pathname.includes('/errors')?'Pusat Kesalahan':location.pathname.startsWith('/riwayat')?'Riwayat Penarikan':location.pathname.startsWith('/panduan')?'Panduan Penggunaan':location.pathname.startsWith('/tasks')?'Tutup Kas All Web':'Dashboard'
 const links=[{to:'/dashboard',icon:LayoutDashboard,label:'Dashboard'},{to:'/tasks/1',icon:ArrowDownToLine,label:'Tutup Kas All Web',tag:'MANUAL'},{to:'/admin-setting',icon:Globe2,label:'Pengaturan WEB'},{to:'/kas-kecil',icon:Wallet,label:'Kas Kecil'}]
 return <div className="app-shell">{mobile&&<div className="sidebar-backdrop" onClick={()=>setMobile(false)}/>}<aside id="app-sidebar" inert={smallScreen&&!mobile} aria-hidden={smallScreen&&!mobile} onClick={e=>{if((e.target as Element).closest('a'))setMobile(false)}} aria-label="Navigasi utama" className={'sidebar '+(mobile?'open':'')}><button className="icon-button sidebar-close" aria-label="Tutup menu" onClick={()=>setMobile(false)}>×</button><Link to="/dashboard" className="brand"><span className="brand-icon"><Crown size={23}/></span><span>TUTUP KAS<small>LION GROUP</small></span></Link><div className="workspace-chip"><span className="workspace-symbol">LG</span><span>Ruang Kerja Keuangan<small>Administrator</small></span><ChevronDown size={14}/></div><div className="sidebar-scroll" tabIndex={0} aria-label="Menu navigasi"><span className="nav-label">RUANG KERJA</span><nav>{links.map(n=><NavLink key={n.to} to={n.to} end={n.to==='/tasks/1'}><n.icon size={18}/><span>{n.label}</span>{n.tag&&<small>{n.tag}</small>}</NavLink>)}</nav><span className="nav-label">MONITORING</span><nav><NavLink to="/riwayat"><FileClock size={18}/><span>Riwayat Penarikan</span></NavLink><NavLink to="/pusat-kesalahan"><TriangleAlert size={18}/><span>Pusat Kesalahan</span></NavLink></nav><span className="nav-label">SELANJUTNYA</span><div className="future-nav"><Database size={17}/><span>Task 02</span><LockKeyhole size={13}/></div><div className="future-nav"><Activity size={17}/><span>Task 03</span><LockKeyhole size={13}/></div><div className="sidebar-bottom"><Link to="/panduan" className="help-card"><span className="help-icon"><CircleHelp size={20}/></span><h4>Butuh panduan?</h4><p>Kenali alur penarikan data<br/>dan tutup kas harian.</p><span className="help-card-action">Lihat Panduan <ArrowRight size={14}/></span></Link><div className="service-state"><span className={health?'live-dot':'offline-dot'}/>{health?'Layanan API terhubung':'Layanan API tidak terhubung'}<ShieldCheck size={14}/></div></div></div></aside>
 <div className="main-shell" inert={mobile}><header className="topbar"><div className="breadcrumbs"><button className="icon-button mobile-menu" aria-label="Buka menu" aria-controls="app-sidebar" aria-expanded={mobile} onClick={()=>setMobile(true)}><Menu size={21}/></button><span>Ruang Kerja</span><ChevronRight size={12}/><strong>{title}</strong></div><div className="top-actions"><button className="search-button" onClick={openSearch}><Search size={15}/><span>Cari WEB…</span><kbd>⌕</kbd></button><div className="notification-wrap"><button className={'icon-button notification '+(notifications?'selected':'')} aria-label="Pemberitahuan" onClick={openNotifications}><Bell size={18}/>{errors.length>0&&<i/>}</button>{notifications&&<div className="notification-panel"><h4>Pemberitahuan</h4>{errors.length===0?<p>Tidak ada proses bermasalah.</p>:errors.slice(0,5).map(r=><Link key={r.id} to={`/tasks/1/runs/${r.id}/errors`}><TriangleAlert size={17}/><span>{r.config_snapshot.website}<small>Proses #{r.id} • {dateLabel(r.selected_date)}</small></span><ChevronRight size={14}/></Link>)}</div>}</div><span className="top-divider"/><div className="user-avatar">{user.username.slice(0,2).toUpperCase()}</div><div className="user-info"><strong>{user.username}</strong><small>Administrator</small></div><button className="icon-button" aria-label="Keluar" title="Keluar" onClick={async()=>{try{await send('/auth/logout');onLogout();navigate('/login')}catch(e){notice((e as Error).message,true)}}}><LogOut size={17}/></button></div></header>
 <main><Routes><Route path="/panduan" element={<HelpCenter/>}/><Route path="/panduan/:slug" element={<HelpCenter/>}/><Route path="/tasks/1/batches/:id" element={<BatchDetail/>}/><Route path="/dashboard" element={<Dashboard/>}/><Route path="/tasks/1" element={<Dashboard taskOnly/>}/><Route path="/admin-setting" element={<WebsiteList/>}/><Route path="/admin-setting/:slug/*" element={<WebsiteSettings/>}/><Route path="/kas-kecil/*" element={<DestinationPage/>}/><Route path="/riwayat" element={<History/>}/><Route path="/pusat-kesalahan" element={<History errorsOnly/>}/><Route path="/tasks/1/runs/:id/*" element={<RunDetail/>}/><Route path="/" element={<Navigate to="/dashboard" replace/>}/><Route path="/login" element={<Navigate to="/dashboard" replace/>}/><Route path="*" element={<div className="not-found"><h1>Halaman tidak ditemukan</h1><Link className="button primary" to="/dashboard">Kembali ke Dashboard</Link></div>}/></Routes></main><footer><span>© {new Date().getFullYear()} <strong>Lion Group.</strong> Seluruh hak dilindungi.</span><span>Tutup Kas <i/> v3.0</span></footer></div>
 {search&&<Modal title="Cari WEB" subtitle="Buka pengaturan website dengan cepat." onClose={closeSearch}><div className="search-input"><Search size={18}/><input placeholder="Ketik nama website…" value={query} onChange={e=>setQuery(e.target.value)}/></div><div className="search-results">{sites.filter(s=>s.display_name.toLowerCase().includes(query.toLowerCase())).map(s=><Link key={s.id} onClick={closeSearch} to={'/admin-setting/'+s.slug}><Globe2 size={18}/>{s.display_name}<ArrowRight size={15}/></Link>)}{sites.length===0&&<p>Belum ada WEB terdaftar.</p>}</div></Modal>}

 </div>
}
