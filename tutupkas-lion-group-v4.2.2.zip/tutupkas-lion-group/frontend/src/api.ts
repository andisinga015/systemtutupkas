export type Website = {id:number; display_name:string; slug:string; is_active:boolean; is_archived:boolean}
export type Doc = {id:number; year:number; month:number; document_type?:string; source_period?:'FIRST_HALF'|'SECOND_HALF'|'MONTHLY'|'UNASSIGNED'; active_revision_id?:number|null;tab_counts?:{active:number;inactive:number;unavailable:number}; environment?:string; spreadsheet_url:string; spreadsheet_title:string|null; validation_status:string; validated_at:string|null; revision?:number; is_current?:boolean;mapping?:{id?:number;state:string;error?:{message:string}|null;issues?:unknown[]}}
export type Tab = {id:number; tab_name:string; is_active:boolean; is_available:boolean}
export type Plan = {tab:string; cell:string; existing:{value:unknown;note:string};proposed:{value:unknown;note:string};bank:string}
export type Item = {id:number;source_document_id:number|null;source_tab_name:string;metric_type:string;status:string;result:{plan?:Plan[];source_cell?:string;closing_row?:number;verified?:boolean}|null}
export type TaskError = {id:number;run_item_id:number;source_document_id:number|null;source_tab_name:string;error_code:string;human_message:string;suggested_fix:string;retry_count:number;technical_details:Record<string,unknown>}
export type Reconciliation = {id:number;status:string;balance:string|null;cell:string|null;human_message:string;error_code:string|null}
export type ReconciliationRow = {website_id:number;website:string;run_id:number|null;historical_run_id:number|null;processing_status:string;reconciliation_status:string;balance:string|null;cell:string|null;requires_sync:boolean;complete:boolean;error_count:number}
export type DateStatus = {selected_date:string;destination:{id:number;revision:number;title:string}|null;websites:ReconciliationRow[];consolidated:{id:number;status:string;balance:string|null;cell:string|null;message:string}|null;status:string;pending_websites:string[];eligible:boolean;is_clear:boolean;message:string}
export type BatchEntry = {website_id:number;website:string;run_id:number;status:string;processing_status:string;reconciliation_status:string;balance:string|null;reused:boolean}
export type Batch = {id:number;selected_date:string;preview:boolean;recheck_only:boolean;status:string;canceled:number;current_phase?:string;total:number;processed:number;current_website:string|null;success:number;written:number;not_balanced:number;failed:number;waiting:number;entries:BatchEntry[];date_status?:DateStatus;destination:{id:number;revision:number;title:string}}
export type Conflict = {id:number;run_item_id:number;state:string;reason:string;observation_hash:string;preview?:boolean;website?:string;selected_date?:string;module?:string;read_at?:string;writes:{tab:string;row:number;col:number;value:unknown;note:string|null}[];observed:{tab:string;cell:string;value:unknown;formula:string|null;note:string}[];current_observed?:Conflict['observed'];provenance:Record<string,unknown>}
export type Run = {id:number;website_id:number;selected_date:string;environment:string;batch_id:number|null;preview:boolean;status:string;started_at:string;finished_at:string|null;current_phase?:string;config_snapshot:{source_retry_notices?:{message:string;successful_items_unchanged:number[]}[];website:string;sources:{id:number;title:string;type:string;tabs:string[]}[];destination:{id:number;revision:number;title:string}};items?:Item[];errors?:TaskError[];conflicts?:Conflict[];retry_requests?:{id:number;run_item_id:number;state:string}[];reconciliation?:Reconciliation|null;date_status?:DateStatus;current_revision?:boolean;retry_allowed?:boolean;pipeline?:{snapshots:Record<string,number>;mapped_results:number}}
export type Clearance = {id:number;website_id:number|null;selected_date:string;environment:string;is_clear:boolean;confirmed_at:string;destination_revision?:number}
export type Stats = {websites:number;active_websites:number;inactive_websites:number;active_tabs:number;inactive_tabs:number;validated_urls:number;failed_urls:number;success_runs:number;partial_runs:number;failed_runs:number;errors:number;credentials_configured:boolean;palette_configured:boolean}
let csrf = ''
export function setCsrf(value:string){csrf=value}
export async function api<T>(path:string, options:RequestInit={}):Promise<T>{
 const response = await fetch('/api'+path,{credentials:'same-origin',...options,headers:{'Content-Type':'application/json',...(csrf?{'X-CSRF-Token':csrf}:{}),...options.headers}})
 const data = await response.json().catch(()=>({detail:'Layanan tidak dapat dihubungi.'}))
 if(!response.ok){
  if(response.status===401 && !path.startsWith('/auth/')) window.dispatchEvent(new Event('session-expired'))
  throw new Error(typeof data.detail==='string'?data.detail:'Periksa kembali data formulir.')
 }
 return data as T
}
export const send = <T>(path:string, body:unknown={},method='POST')=>api<T>(path,{method,body:JSON.stringify(body)})
export const months=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember']
export function today(){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Jakarta',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())}
export function dateLabel(s:string){return new Date(s.length===10?s+'T12:00:00':s+'Z').toLocaleDateString('id-ID',{day:'numeric',month:'short',year:'numeric'})}
export const statusText:Record<string,string>={VALID:'Valid',UNVALIDATED:'Belum divalidasi',FAILED:'Gagal',SUCCESS:'Berhasil Ditulis',PARTIAL:'Sebagian Berhasil',RUNNING:'Sedang Diproses',QUEUED:'Dalam Antrean',PREVIEWED:'Pratinjau Selesai',PENDING:'Menunggu',WAITING:'Menunggu',BALANCED:'KLOP',NOT_BALANCED:'TIDAK KLOP',ERROR:'Kesalahan',INCOMPLETE:'Belum Lengkap',IN_PROGRESS:'Sedang Diproses',SYNC_REQUIRED:'Perlu Sinkronisasi',WORKING:'Salinan Kerja',CANCEL_REQUESTED:'Pembatalan Diminta',CANCELED:'Dibatalkan'}
export function formatBalance(value:string|null|undefined){
 if(value===null||value===undefined)return '—'
 if(/[eE]/.test(value))return value
 const [integer,fraction]=value.split('.')
 return integer.replace(/\B(?=(\d{3})+(?!\d))/g,'.')+(fraction?','+fraction:'')
}

export const phaseText:Record<string,string>={PREPARING:'Menyiapkan',SOURCE_READING:'Membaca Snapshot Sumber',SCANNING:'Membaca Sumber',SNAPSHOT_READY:'Snapshot Sumber Siap',MAPPING:'Menghitung dan Memetakan',MAPPED:'Hasil Pemetaan Siap',RETRY_QUEUED:'Retry Item Diantrikan',DECISION_QUEUED:'Keputusan Diantrikan',PLANNING:'Menyusun Rencana',CHECKING_DESTINATION:'Memeriksa Tujuan',WRITING:'Menulis',VERIFYING:'Memverifikasi Tulisan',RECONCILING:'Memeriksa Saldo',PROCESSING_WEBSITE:'Memproses WEB',DONE:'Selesai',FAILED:'Gagal',CANCELED:'Dibatalkan',QUEUED:'Dalam Antrean'}
