import { createContext, useContext, useEffect, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { Check, CheckCircle2, ChevronDown, Info, LoaderCircle, X, AlertCircle } from 'lucide-react'
import { months, statusText } from '../api'

const Notice = createContext<(message:string,error?:boolean)=>void>(()=>{})
export const useNotice=()=>useContext(Notice)
export function NoticeProvider({children}:{children:ReactNode}){
 const [notice,setNotice]=useState<{text:string;error:boolean}|null>(null)
 useEffect(()=>{if(notice){const timer=setTimeout(()=>setNotice(null),7000);return()=>clearTimeout(timer)}},[notice])
 return <Notice.Provider value={(text,error=false)=>setNotice({text,error})}>{children}{notice&&<div role="status" className={'toast '+(notice.error?'error':'')}>
 {notice.error?<AlertCircle size={20}/>:<CheckCircle2 size={20}/>}<span>{notice.text}</span><button className="icon-button" aria-label="Tutup pemberitahuan" onClick={()=>setNotice(null)}><X size={16}/></button></div>}</Notice.Provider>
}
export function Badge({status,children}:{status:string;children?:ReactNode}){return <span className={'badge '+status.toLowerCase()}><i/>{children||statusText[status]||status}</span>}
export function Spinner(){return <div className="loading"><LoaderCircle className="spin" size={25}/><span>Memuat data…</span></div>}
export function Empty({icon,title,text,action}:{icon?:ReactNode;title:string;text:string;action?:ReactNode}){return <div className="empty"><div className="empty-icon">{icon||<Info size={25}/>}</div><h3>{title}</h3><p>{text}</p>{action}</div>}
export function Modal({title,subtitle,onClose,children}:{title:string;subtitle?:string;onClose:()=>void;children:ReactNode}){
 const box=useRef<HTMLDivElement>(null)
 const closeRef=useRef(onClose)
 closeRef.current=onClose
 useEffect(()=>{
  const prior=document.activeElement as HTMLElement
  box.current?.querySelector<HTMLElement>('input,button,select,textarea')?.focus()
  const key=(e:KeyboardEvent)=>{
   if(e.key==='Escape')closeRef.current()
   if(e.key==='Tab'){
    const all=box.current?.querySelectorAll<HTMLElement>('button:not(:disabled), input, select, textarea, a[href]');if(!all?.length)return
    const first=all[0],last=all[all.length-1]
    if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}
    if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}
   }
  };document.addEventListener('keydown',key);return()=>{document.removeEventListener('keydown',key);prior?.focus()}
 },[])
 return <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)onClose()}}><div ref={box} className="modal" role="dialog" aria-modal="true" aria-label={title}>
 <div className="modal-head"><div><h2>{title}</h2>{subtitle&&<p>{subtitle}</p>}</div><button className="icon-button" onClick={onClose} aria-label="Tutup dialog"><X size={20}/></button></div>{children}</div></div>
}
export function PeriodPicker({year,month,onChange}:{year:number;month:number;onChange:(year:number,month:number)=>void}){
 const years=Array.from(new Set([year,...Array.from({length:10},(_,i)=>new Date().getFullYear()-5+i)])).sort((a,b)=>b-a)
 return <div className="period"><label className="select-wrap"><select aria-label="Bulan" value={month} onChange={e=>onChange(year,+e.target.value)}>{months.map((m,i)=><option key={m} value={i+1}>{m}</option>)}</select><ChevronDown size={14}/></label><label className="select-wrap"><select aria-label="Tahun" value={year} onChange={e=>onChange(+e.target.value,month)}>{years.map(y=><option key={y}>{y}</option>)}</select><ChevronDown size={14}/></label></div>
}
export function CheckRow({checked,label}:{checked:boolean;label:string}){return <div className="check-row"><span className={checked?'check-ok':'check-pending'}>{checked?<Check size={13}/>:<span/>}</span>{label}<small>{checked?'Terhubung':'Belum tersedia'}</small></div>}
export function Field({label,hint,children}:{label:string;hint?:string;children:ReactNode}){return <label className="field"><span>{label}</span>{children}{hint&&<small>{hint}</small>}</label>}
