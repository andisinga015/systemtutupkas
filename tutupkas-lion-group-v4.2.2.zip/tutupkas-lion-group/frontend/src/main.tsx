import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import '@fontsource/inter/400.css'
import '@fontsource/inter/500.css'
import '@fontsource/inter/600.css'
import '@fontsource/inter/700.css'
import './styles.css'
import App from './App'
import { NoticeProvider } from './components/ui'

ReactDOM.createRoot(document.getElementById('root')!).render(<React.StrictMode><BrowserRouter><NoticeProvider><App/></NoticeProvider></BrowserRouter></React.StrictMode>)
