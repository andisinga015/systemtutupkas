import { defineConfig } from '@playwright/test'
export default defineConfig({
 testDir:'e2e',workers:1,retries:0,reporter:'list',
 use:{baseURL:'http://127.0.0.1:5173',viewport:{width:1440,height:1000},
  launchOptions:{executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE||undefined},trace:'retain-on-failure'},
 webServer:[
  {command:'../.venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8000',cwd:'../backend',url:'http://127.0.0.1:8000/api/health',reuseExistingServer:false,timeout:30000},
  {command:'npm run dev -- --port 5173',url:'http://127.0.0.1:5173',reuseExistingServer:false,timeout:30000}
 ]
})

