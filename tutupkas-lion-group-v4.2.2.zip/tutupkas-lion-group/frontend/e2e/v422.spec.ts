import {test,expect} from '@playwright/test'
import type {Page} from '@playwright/test'

const a='DOC A — DEPO/WD (1–15)',b='DOC B — DEPO/WD (16–akhir bulan)',q='DOC QRIS — Bulanan'
const cards={FIRST_HALF:'DOC A — DEPO/WD (Tanggal 1–15)',SECOND_HALF:'DOC B — DEPO/WD (Tanggal 16–Akhir Bulan)',MONTHLY:'DOC QRIS (Tanggal 1–Akhir Bulan)'}
type Doc={id:number;source_period:string;active_revision_id:number;spreadsheet_url:string;tab_counts:{active:number;inactive:number;unavailable:number}}
type Tab={id:number;tab_name:string;is_active:boolean;is_available:boolean}

async function setup(page:Page,suffix:string,legacy=false){
 const {execFileSync}=await import('node:child_process')
 const slug='period-e2e-'+suffix
 execFileSync('../.venv/bin/python',['../scripts/e2e-seed-v422.py',slug,...(legacy?['--legacy']:[])],{env:process.env})
 await page.goto('/login');await page.getByLabel('Nama pengguna').fill('e2e-admin');await page.getByLabel('Kata sandi').fill(process.env.TK_E2E_PASSWORD!)
 await page.getByRole('button',{name:'Masuk ke Dashboard'}).click()
 await expect(page.getByRole('heading',{name:'Dashboard',exact:true})).toBeVisible()
 await page.goto('/admin-setting/'+slug)
 await expect(page.getByRole('heading',{name:/PERIODE period-e2e/})).toBeVisible()
 const site=await (await page.request.get('/api/websites/'+slug)).json()
 const docs:Doc[]=await (await page.request.get(`/api/websites/${site.id}/sources?year=2026&month=10`)).json()
 return {slug,site,docs}
}

const card=(page:Page,period:keyof typeof cards)=>page.locator('.document-card').filter({has:page.getByRole('heading',{name:cards[period],exact:true})})
const option=(page:Page,name:string)=>page.locator('.source-options button').filter({hasText:name})
async function tabs(page:Page,doc:Doc):Promise<Tab[]>{return (await page.request.get(`/api/sources/${doc.id}/tabs`)).json()}

test('V4.2.2 three URL cards, independent saves, history and real month/year ranges',async({page})=>{
 const {site,docs}=await setup(page,'urls')
 await expect(page.locator('.document-card')).toHaveCount(3)
 for(const period of ['FIRST_HALF','SECOND_HALF','MONTHLY'] as const){
  const own=docs.find(d=>d.source_period===period)!
  const panel=card(page,period);await expect(panel.getByLabel('URL Google Spreadsheet')).toHaveValue(own.spreadsheet_url)
  await expect(panel.getByRole('link',{name:'Riwayat URL'})).toBeVisible()
  const changed=`https://docs.google.com/spreadsheets/d/new-e2e-${period}-123456/edit`
  await panel.getByLabel('URL Google Spreadsheet').fill(changed)
  const saved=page.waitForResponse(r=>r.url().includes(`/api/websites/${site.id}/sources`)&&r.request().method()==='PUT')
  await panel.getByRole('button',{name:'Simpan Pengaturan'}).click()
  const response=await saved;expect(response.status()).toBe(200);expect(response.request().postDataJSON().source_period).toBe(period)
  await expect(panel.getByLabel('URL Google Spreadsheet')).toHaveValue(changed)
  const current:Doc[]=await (await page.request.get(`/api/websites/${site.id}/sources?year=2026&month=10`)).json()
  expect(current.find(d=>d.id===own.id)?.spreadsheet_url).toBe(changed)
  for(const other of docs.filter(d=>d.id!==own.id))expect(current.find(d=>d.id===other.id)?.spreadsheet_url).toBe(other.spreadsheet_url)
  own.spreadsheet_url=changed
  await expect(panel.getByRole('button',{name:'Simpan Pengaturan'})).toBeDisabled()
 }
 await card(page,'SECOND_HALF').getByRole('link',{name:'Riwayat URL'}).click()
 await expect(page.locator('.history-doc h4')).toHaveText(/Oktober 2026.*DOC B/)
 await page.getByRole('button',{name:'Lihat Riwayat Perubahan'}).click()
 await expect(page.locator('.revision')).toHaveCount(2)
 await page.getByRole('link',{name:'Pengaturan URL',exact:true}).click()
 await page.getByLabel('Bulan',{exact:true}).selectOption('2');await page.getByLabel('Tahun',{exact:true}).selectOption('2028')
 await expect(card(page,'SECOND_HALF')).toContainText('16–29 Februari')
 await page.getByLabel('Tahun',{exact:true}).selectOption('2026')
 await expect(card(page,'SECOND_HALF')).toContainText('16–28 Februari')
 await page.getByLabel('Bulan',{exact:true}).selectOption('4')
 await expect(card(page,'SECOND_HALF')).toContainText('16–30 April')
 await expect(card(page,'FIRST_HALF').getByLabel('URL Google Spreadsheet')).toHaveValue('')
})

test('V4.2.2 identical names retain independent actual activation and bulk changes',async({page})=>{
 const {docs}=await setup(page,'tabs');const da=docs.find(d=>d.source_period==='FIRST_HALF')!,db=docs.find(d=>d.source_period==='SECOND_HALF')!,dq=docs.find(d=>d.source_period==='MONTHLY')!
 await page.getByRole('link',{name:'Daftar Sheet',exact:true}).click()
 for(const name of [a,b,q])await expect(option(page,name)).toBeVisible()
 await expect(page.locator('.tab-row').filter({hasText:'WD BCA / KHUSUS A'})).toBeVisible()
 await expect(page.locator('.tab-row').filter({hasText:'WD BCA / KHUSUS B'})).toHaveCount(0)
 await page.locator('.tab-row').filter({hasText:'WD BCA / KHUSUS A'}).getByRole('checkbox').check()
 await option(page,b).click()
 await expect(page.locator('.tab-row').filter({hasText:'WD BCA / KHUSUS B'})).toBeVisible()
 await expect(page.locator('.selection-actions')).toContainText('0 dipilih')
 await expect(page.getByRole('button',{name:'Terapkan',exact:true})).toBeDisabled()
 const beforeA=await tabs(page,da),beforeQ=await tabs(page,dq)
 await page.locator('.tab-row').filter({hasText:'WD BCA / SAMA'}).getByRole('checkbox').check()
 await page.getByRole('button',{name:'Terapkan',exact:true}).click()
 await expect(page.locator('.selection-actions')).toContainText('0 dipilih')
 expect((await tabs(page,db)).find(t=>t.tab_name==='WD BCA / SAMA')?.is_active).toBe(true)
 expect(await tabs(page,da)).toEqual(beforeA);expect(await tabs(page,dq)).toEqual(beforeQ)
 for(const row of await page.locator('.tab-row').all())await row.getByRole('checkbox').check()
 await page.getByLabel('Tindakan sheet').selectOption('inactive');await page.getByRole('button',{name:'Terapkan',exact:true}).click()
 await expect(option(page,b)).toContainText('0 aktif · 2 nonaktif')
 expect((await tabs(page,db)).every(t=>!t.is_active)).toBe(true);expect(await tabs(page,da)).toEqual(beforeA)
 await option(page,q).click();await expect(page.locator('.tab-row').filter({hasText:'QRIS E-POWER'})).toBeVisible()
 await page.locator('.tab-row').filter({hasText:'QRIS E-POWER'}).getByRole('checkbox').check()
 await page.getByLabel('Tindakan sheet').selectOption('inactive');await page.getByRole('button',{name:'Terapkan',exact:true}).click()
 await expect(option(page,q)).toContainText('1 aktif · 1 nonaktif')
 expect(await tabs(page,da)).toEqual(beforeA)
 const aTab=(await tabs(page,da))[0]
 const csrf=(await (await page.request.get('/api/auth/me')).json()).csrf_token
 const rejected=await page.request.post(`/api/sources/${db.id}/tabs`,{headers:{'X-CSRF-Token':csrf},data:{ids:[aTab.id],source_revision_id:db.active_revision_id,is_active:true}})
 expect(rejected.status()).toBe(409)
})

test('V4.2.2 month switch clears checkboxes and loads independent inactive states',async({page})=>{
 await setup(page,'months');await page.getByRole('link',{name:'Daftar Sheet',exact:true}).click()
 await page.locator('.tab-row').first().getByRole('checkbox').check()
 await page.getByLabel('Tindakan sheet').selectOption('inactive')
 await page.getByLabel('Bulan',{exact:true}).selectOption('11')
 await expect(page.locator('.selection-actions')).toContainText('0 dipilih')
 await expect(page.getByLabel('Tindakan sheet')).toHaveValue('active')
 await expect(option(page,a)).toContainText('0 aktif · 2 nonaktif')
 await expect(page.getByRole('button',{name:'Terapkan',exact:true})).toBeDisabled()
 await page.getByLabel('Bulan',{exact:true}).selectOption('10')
 await expect(option(page,a)).toContainText('1 aktif · 1 nonaktif')
 await expect(page.locator('.selection-actions')).toContainText('0 dipilih')
 await page.locator('.tab-row').first().getByRole('checkbox').check()
 await page.getByLabel('Tahun',{exact:true}).selectOption('2027')
 await expect(page.locator('.tab-row')).toHaveCount(0)
 await expect(page.getByRole('button',{name:'Refresh Daftar Sheet'})).toBeDisabled()
 await page.getByLabel('Tahun',{exact:true}).selectOption('2026')
 await expect(option(page,a)).toContainText('1 aktif · 1 nonaktif')
 await expect(page.locator('.selection-actions')).toContainText('0 dipilih')
})

test('V4.2.2 delayed DOC A response never replaces DOC B even if transport ignores abort',async({page})=>{
 const {docs}=await setup(page,'stale');const da=docs.find(d=>d.source_period==='FIRST_HALF')!
 await page.evaluate(()=>{const original=window.fetch.bind(window);window.fetch=(input,options={})=>original(input,{...options,signal:undefined})})
 let release!:()=>void,received!:()=>void
 const held=new Promise<void>(r=>release=r),started=new Promise<void>(r=>received=r)
 await page.route(`**/api/sources/${da.id}/tabs?**`,async route=>{const response=await route.fetch();received();await held;await route.fulfill({response})})
 await page.getByRole('link',{name:'Daftar Sheet',exact:true}).click();await started
 await option(page,b).click()
 await expect(page.locator('.tab-row').filter({hasText:'WD BCA / KHUSUS B'})).toBeVisible()
 release()
 await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve()))))
 await expect(page.locator('.tab-row').filter({hasText:'WD BCA / KHUSUS A'})).toHaveCount(0)
 await expect(option(page,b)).toHaveAttribute('aria-pressed','true')
 await expect(page.locator('.selection-actions')).toContainText('0 dipilih')
})

test('V4.2.2 legacy assignment keeps original tabs in DOC B and missing DOC A has no fallback',async({page})=>{
 const {docs}=await setup(page,'legacy',true);const old=docs.find(d=>d.source_period==='UNASSIGNED')!
 const prior=await tabs(page,old)
 await expect(page.getByRole('heading',{name:'DOC DEPO lama — perlu penetapan periode'})).toBeVisible()
 await expect(page.getByRole('button',{name:'Tetapkan sebagai DOC A — tanggal 1–15',exact:true})).toBeEnabled()
 await page.getByRole('button',{name:'Tetapkan sebagai DOC B — tanggal 16–akhir bulan',exact:true}).click()
 await expect(page.getByRole('heading',{name:'DOC DEPO lama — perlu penetapan periode'})).toHaveCount(0)
 await expect(card(page,'SECOND_HALF').getByLabel('URL Google Spreadsheet')).toHaveValue(old.spreadsheet_url)
 await page.getByRole('link',{name:'Daftar Sheet',exact:true}).click()
 await expect(page.locator('.inline-alert[role="status"]')).toContainText('DOC A — DEPO/WD tanggal 1–15 belum memiliki URL.')
 await expect(page.getByRole('button',{name:'Refresh Daftar Sheet'})).toBeDisabled()
 await expect(page.locator('.tab-row')).toHaveCount(0)
 await option(page,b).click();await expect(page.locator('.tab-row')).toHaveCount(prior.length)
 expect(await tabs(page,old)).toEqual(prior)
})

test('V4.2.2 absent DOC B disables all actions and shows no DOC A tabs',async({page})=>{
 await setup(page,'missing',true);await page.getByRole('link',{name:'Daftar Sheet',exact:true}).click()
 await option(page,b).click()
 await expect(page.locator('.inline-alert[role="status"]')).toContainText('DOC B — DEPO/WD tanggal 16–akhir bulan belum memiliki URL.')
 await expect(page.locator('.tab-row')).toHaveCount(0)
 await expect(page.getByRole('button',{name:'Refresh Daftar Sheet'})).toBeDisabled()
 await expect(page.getByRole('button',{name:'Terapkan',exact:true})).toBeDisabled()
 await expect(page.getByLabel('Tindakan sheet')).toBeDisabled()
})

test('V4.2.2 changed URL revision removes selected old tab IDs and rejects their submission',async({page})=>{
 const {docs}=await setup(page,'revision');const old=docs.find(d=>d.source_period==='SECOND_HALF')!
 const previous=await tabs(page,old),unchanged=await tabs(page,docs.find(d=>d.source_period==='FIRST_HALF')!)
 await page.getByRole('link',{name:'Daftar Sheet',exact:true}).click();await option(page,b).click()
 await page.locator('.tab-row').first().getByRole('checkbox').check()
 await page.getByRole('link',{name:'Pengaturan URL',exact:true}).click()
 const panel=card(page,'SECOND_HALF')
 await panel.getByLabel('URL Google Spreadsheet').fill('https://docs.google.com/spreadsheets/d/new-period-revision-123456/edit')
 await panel.getByRole('button',{name:'Simpan Pengaturan'}).click()
 await expect(panel.getByRole('button',{name:'Validasi URL'})).toBeEnabled()
 await page.getByRole('link',{name:'Daftar Sheet',exact:true}).click();await option(page,b).click()
 await expect(page.locator('.tab-row')).toHaveCount(0)
 await expect(page.locator('.selection-actions')).toContainText('0 dipilih')
 const csrf=(await (await page.request.get('/api/auth/me')).json()).csrf_token
 const rejected=await page.request.post(`/api/sources/${old.id}/tabs`,{headers:{'X-CSRF-Token':csrf},data:{ids:previous.map(t=>t.id),source_revision_id:old.active_revision_id,is_active:true}})
 expect(rejected.status()).toBe(409)
 expect(await tabs(page,docs.find(d=>d.source_period==='FIRST_HALF')!)).toEqual(unchanged)
})

test('V4.2.2 a delayed first A fetch cannot overwrite newer A data after A to B to A',async({page})=>{
 const {docs}=await setup(page,'aba');const da=docs.find(d=>d.source_period==='FIRST_HALF')!
 await page.evaluate(()=>{const original=window.fetch.bind(window);window.fetch=(input,options={})=>original(input,{...options,signal:undefined})})
 let release!:()=>void,received!:()=>void,count=0,finished!:()=>void
 const gate=new Promise<void>(r=>release=r),started=new Promise<void>(r=>received=r),done=new Promise<void>(r=>finished=r)
 await page.route(`**/api/sources/${da.id}/tabs?**`,async route=>{
  count++
  if(count>1){await route.continue();return}
  const response=await route.fetch();received();await gate;await route.fulfill({response});finished()
 })
 await page.getByRole('link',{name:'Daftar Sheet',exact:true}).click();await started
 await option(page,b).click();await expect(page.locator('.tab-row').filter({hasText:'WD BCA / KHUSUS B'})).toBeVisible()
 const current=await tabs(page,da),csrf=(await (await page.request.get('/api/auth/me')).json()).csrf_token
 expect((await page.request.post(`/api/sources/${da.id}/tabs`,{headers:{'X-CSRF-Token':csrf},data:{ids:current.map(t=>t.id),source_revision_id:da.active_revision_id,is_active:false}})).status()).toBe(200)
 await option(page,a).click();await expect(option(page,a)).toContainText('0 aktif · 2 nonaktif')
 release();await done
 await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve()))))
 await expect(option(page,a)).toContainText('0 aktif · 2 nonaktif')
 await expect(page.locator('.tab-row').filter({hasText:'WD BCA / KHUSUS B'})).toHaveCount(0)
})

test('V4.2.2 website navigation resets selection and uses that websites own document IDs',async({page})=>{
 const {docs}=await setup(page,'website-a');const original=await tabs(page,docs.find(d=>d.source_period==='FIRST_HALF')!)
 const {execFileSync}=await import('node:child_process')
 execFileSync('../.venv/bin/python',['../scripts/e2e-seed-v422.py','period-e2e-website-b'],{env:process.env})
 const otherSite=await (await page.request.get('/api/websites/period-e2e-website-b')).json()
 const otherDocs:Doc[]=await (await page.request.get(`/api/websites/${otherSite.id}/sources?year=2026&month=10`)).json()
 const da=otherDocs.find(d=>d.source_period==='FIRST_HALF')!,ownTabs=await tabs(page,da)
 const csrf=(await (await page.request.get('/api/auth/me')).json()).csrf_token
 expect((await page.request.post(`/api/sources/${da.id}/tabs`,{headers:{'X-CSRF-Token':csrf},data:{ids:ownTabs.map(t=>t.id),source_revision_id:da.active_revision_id,is_active:false}})).status()).toBe(200)
 await page.getByRole('link',{name:'Daftar Sheet',exact:true}).click()
 await page.locator('.tab-row').first().getByRole('checkbox').check()
 await page.locator('.back-link').click()
 await page.locator('a[href="/admin-setting/period-e2e-website-b"]').click()
 await page.getByRole('link',{name:'Daftar Sheet',exact:true}).click()
 await expect(page.locator('.selection-actions')).toContainText('0 dipilih')
 await expect(option(page,a)).toContainText('0 aktif · 2 nonaktif')
 await expect(page.locator('.tab-controls')).toContainText('PERIODE period-e2e-website-b')
 expect(await tabs(page,docs.find(d=>d.source_period==='FIRST_HALF')!)).toEqual(original)
})
