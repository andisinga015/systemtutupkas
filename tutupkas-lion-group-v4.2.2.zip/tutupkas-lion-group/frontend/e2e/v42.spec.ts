import {test,expect} from '@playwright/test'

async function login(page:import('@playwright/test').Page){
 await page.goto('/login');await page.getByLabel('Nama pengguna').fill('e2e-admin');await page.getByLabel('Kata sandi').fill(process.env.TK_E2E_PASSWORD!);await page.getByRole('button',{name:'Masuk ke Dashboard'}).click();await expect(page.getByRole('heading',{name:'Dashboard',exact:true})).toBeVisible()
}
const run=(preview=false)=>({id:4242,website_id:1,selected_date:'2026-10-18',environment:'WORKING',batch_id:null,preview,status:'RUNNING',started_at:'2026-10-18T10:00:00',finished_at:null,current_phase:'SOURCE_READING',current_revision:true,retry_allowed:true,config_snapshot:{website:'VELBETT',sources:[{id:1,title:'Sumber',type:'DEPO',tabs:['LAMA']}],destination:{id:1,revision:1,title:'Tujuan'}},items:[{id:8,metric_type:'deposit',source_tab_name:'LAMA',status:'FAILED',result:{}}],errors:[{id:1,run_item_id:8,source_document_id:1,source_tab_name:'LAMA',error_code:'GOOGLE_TIMEOUT',human_message:'Sumber perlu diperbaiki',suggested_fix:'Periksa sumber',technical_details:{}}],conflicts:[],retry_requests:[],pipeline:{snapshots:{MAPPED:2},mapped_results:5}})

test('V4.2 active item retry asks for an unproven source choice and submits only that item',async({page})=>{
 await login(page);let body:Record<string,unknown>|undefined
 await page.route('**/api/runs/4242',r=>r.fulfill({json:run()}))
 await page.route('**/api/runs/4242/items/8/retry-options',r=>r.fulfill({json:{tabs:['BARU','LAIN'],suggested:null,requires_selection:true}}))
 await page.route('**/api/runs/4242/retry',async r=>{body=r.request().postDataJSON();await r.fulfill({status:202,json:run()})})
 await page.goto('/tasks/1/runs/4242');await page.getByRole('button',{name:'Ulangi Item Belum Selesai'}).click()
 const dialog=page.getByRole('dialog');await expect(dialog.getByRole('button',{name:'Antrekan Retry Item'})).toBeDisabled();await dialog.getByLabel('Sheet sumber aktif').selectOption('BARU');await dialog.getByRole('button',{name:'Antrekan Retry Item'}).click()
 await expect(dialog).toHaveCount(0);expect(body?.item_ids).toEqual([8]);expect(body?.source_tab_name).toBe('BARU');expect(body?.idempotency_key).toBeTruthy();await expect(page.getByText('Snapshot lengkap: 2 · Rencana tersimpan: 5')).toBeVisible()
})

for(const preview of [false,true])test(`V4.2 exact old/new group decision with Preview=${preview}`,async({page})=>{
 await login(page);let submitted:Record<string,unknown>|undefined
 const data={...run(preview),status:'PARTIAL',conflicts:[{id:77,run_item_id:8,state:'OPEN'}]}
 const conflict={id:77,state:'OPEN',reason:'EXISTING_VALUE_CONFLICT',website:'VELBETT',selected_date:'2026-10-18',module:'deposit',preview,observation_hash:'a'.repeat(64),read_at:'2026-10-18T10:00:00',provenance:{source_title:'DOC DEPO',source_tab:'LAMA',source_cell:'J309'},writes:[{tab:'TOTAL DEPO',row:74,col:421,value:123,note:''}],current_observed:[{tab:'TOTAL DEPO',cell:'PF75',row:74,col:421,value:999,note:'Catatan lama',formula:null}]}
 await page.route('**/api/runs/4242',r=>r.fulfill({json:data}));await page.route('**/api/conflicts/77/refresh',r=>r.fulfill({json:conflict}));await page.route('**/api/conflicts/77/decide',async r=>{submitted=r.request().postDataJSON();await r.fulfill({status:202,json:{id:1}})})
 await page.goto('/tasks/1/runs/4242/errors');await page.getByRole('button',{name:'Tinjau Data Lama / Baru'}).click();const dialog=page.getByRole('dialog');await expect(dialog.getByText('999',{exact:true})).toBeVisible();await expect(dialog.getByText('123',{exact:true})).toBeVisible();await expect(dialog).toContainText('Catatan lama')
 if(preview){await expect(dialog.getByRole('button',{name:'Masukkan Data Baru'})).toBeDisabled();await dialog.getByRole('button',{name:'Tetapkan Data Lama'}).click()}else{await dialog.getByRole('button',{name:'Masukkan Data Baru'}).click()}
 await expect(dialog).toHaveCount(0);expect(submitted?.action).toBe(preview?'KEEP':'NEW');expect(submitted?.observation_hash).toBe('a'.repeat(64))
})
