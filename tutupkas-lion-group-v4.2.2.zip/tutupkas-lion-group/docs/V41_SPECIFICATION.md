# TUTUP KAS LION GROUP — V4.1
# CRITICAL DESTINATION SHEET MEMORY FIX
# STRICT PATCH ONLY — ZERO FINANCIAL BEHAVIOR CHANGES

## ROLE AND MISSION

You are maintaining the EXISTING Tutup Kas Lion Group V4 application.

Your assignment is to produce a strictly scoped V4.1 patch that fixes the confirmed `SHEET_TOO_LARGE` failure when reading the horizontally wide Google Sheets DESTINATION workbook.

**DO NOT redesign the application. DO NOT reinterpret business requirements. DO NOT change where financial data is written.**

This patch must preserve the existing V4 application's business behavior, destination coordinates, Google Sheets Notes, formulas, safety checks, authentication, API contracts, database ownership protection, and user interface.

The only intended change is making destination and reconciliation data access memory-efficient for spreadsheets that extend very far horizontally and may contain large allocated but unused regions.

---

# 1. CONFIRMED PRODUCTION FAILURE

Production environment:

- Ubuntu VPS
- 4 GB RAM
- 2 vCPU
- systemd worker with `MemoryMax=1536M`
- Existing V4 release
- Google Sheets as source and destination
- SQLite as persistent application database

Confirmed running job:

- Run ID: 7
- Website: VELBETT
- Date: 2026-10-18
- Destination spreadsheet: `Salinan A. KAS SEMUA WEB OCTOBER 2026`
- Destination tab: `SALDO BANK`
- Source tab example: `WD DANA 1 / FATMAWATI ( PP )`
- Source cell example: `L24`

Observed error:

`SHEET_TOO_LARGE`

Displayed message:

`Sheet tujuan melebihi batas baca aman untuk memori VPS.`

The error occurs while PLANNING a destination write.

**The source cell is not the problem. The destination sheet is too wide for V4's current whole-grid materialization approach.**

The destination workbook intentionally contains multiple websites arranged horizontally across many columns.

This layout is a fundamental and permanent business requirement.

The spreadsheet may become considerably wider as additional websites are registered.

A large allocated Google Sheets grid is not itself an error.

Do not require the administrator to delete columns, move blocks, shrink the workbook, split the workbook, or redesign Google Sheets.

---

# 2. VERIFIED ROOT CAUSE IN THE V4 REPOSITORY

Inspect the actual repository and confirm these findings before editing.

## A. backend/app/sheets.py — SheetsClient.grid()

The current method obtains:

- `gridProperties.rowCount`
- `gridProperties.columnCount`

And performs this check:

```python
if height * width > min(cfg.max_sheet_cells, cfg.max_destination_cells):
    raise Issue("SHEET_TOO_LARGE", ...)
```

The default configuration includes:

```python
max_destination_cells = 250_000
```

This rejects documents based on the entire allocated grid size.

Example:

- 1,000 rows × 300 columns = 300,000 cells.
- Current V4 rejects it.
- Yet only a small portion may be needed to process VELBETT's SALDO on October 18.

That rejection is inappropriate for this application's horizontally expanding destination structure.

## B. SheetsClient.grid() still materializes the destination grid

After its size check, the method processes grid bands and grows `rows` into a dense in-memory representation.

The use of smaller HTTP requests does NOT solve the overall RAM problem if all fetched cells are retained afterward.

Do not simply remove the guard and leave this implementation unchanged.

## C. backend/app/engine/runner.py — target()

The runner caches destination grids in `destination_cache`.

A large destination grid may therefore remain in memory throughout a run.

This must be addressed without breaking destination mapping or item execution.

## D. backend/app/engine/writer.py

Inspect:

- `structural()`
- `formula_map()`
- `execute()`
- `_submit_and_verify()`

These operations currently depend on complete destination grids and perform additional whole-grid reads.

The new implementation must retain their safety guarantees without materializing the entire destination.

## E. backend/app/reconciliation.py — fresh_balance()

This calls:

`client.grid(destination['spreadsheet_id'], 'Laporan deposit harian')`

The report may also be horizontally wide.

This read path must not remain a hidden whole-grid memory hotspot.

**All these paths must be considered together. Do not fix only the initial `SHEET_TOO_LARGE` check.**

---

# 3. STRICTLY FORBIDDEN SHORTCUTS

You must NOT solve this issue by:

1. Increasing `max_destination_cells` from 250,000 to a larger number.
2. Deleting the size guard without replacing the reading architecture.
3. Increasing `max_sheet_cells`.
4. Increasing `MemoryMax`.
5. Disabling the OOM killer.
6. Loading the entire destination into Python lists or dictionaries.
7. Creating a dense array containing blank `Cell()` objects for every allocated cell.
8. Deep-copying complete Google Sheets API responses.
9. Fetching the entire grid using one unrestricted `includeGridData=true` request.
10. Reading every destination cell once and retaining the entire result in cache.
11. Removing formula protection.
12. Removing merged-cell protection.
13. Skipping structural-change verification.
14. Removing read-back verification.
15. Assuming destination cells are blank merely because they were not fetched.
16. Searching only the first few hundred columns and assuming no additional website blocks exist.
17. Hardcoding VELBETT's destination column.
18. Hardcoding website positions.
19. Changing business rules.
20. Changing UI layouts or labels.

If a proposed optimization sacrifices correctness, use a safer algorithm instead.

If a required safety invariant cannot be preserved, report it as a blocker.

Do not silently weaken validation to make tests pass.

---

# 4. REQUIRED SOLUTION — SPARSE AND TARGETED DESTINATION ACCESS

Replace the whole-grid destination-reading approach with a bounded, sparse, structure-aware destination reader.

Suggested internal abstraction:

`DestinationReader`

or an equivalent narrowly scoped helper.

The exact class name is optional.

Its functional behavior is mandatory.

## Step A — lightweight metadata

Read the destination spreadsheet metadata required for:

- Exact destination tab name.
- Internal sheet ID.
- Grid dimensions.
- Required merged ranges.
- Relevant structural information.

Do not fetch complete cell data at this stage.

Keep metadata requests scoped and bounded.

If merge metadata is large, use a validated bounded retrieval strategy.

Do not assume Google API returns only the merges within a range unless verified.

## Step B — find destination website blocks

The Kas Semua Web workbook contains website sections arranged horizontally.

Use the existing dynamic website identification rules.

The current `resolver.website_block()` must be studied and preserved semantically.

Important existing behavior includes:

- Finding the configured website name.
- Rejecting missing or ambiguous website markers.
- Recognizing structural boundaries.
- Respecting neighboring website sections.
- Recognizing unregistered but structurally valid neighboring blocks.
- Never crossing into another website's columns.

Use small values-only header-range requests and bounded horizontal scanning.

Do not load every row merely to find a website label.

Do not invent a fixed maximum of 100, 200, or 300 destination columns.

Scanning may continue across the allocated width as needed, but only small chunks should exist in memory at once.

## Step C — identify the selected date

After locating the correct website block:

- Read the existing date-marker column or columns.
- Locate the exact selected date.
- Reject missing or duplicate dates according to current rules.
- Preserve the same row index.
- Preserve original Google Sheets date representations and formatting semantics.

Do not substitute the current date.

Do not guess based on row order.

Do not use a fixed daily row position.

## Step D — resolve target columns

Use the unchanged V4 resolver rules for:

- Source account identity.
- Registered aliases.
- Bank headers.
- Financial module labels.
- KETERANGAN.
- Fee headers.
- Other supported header layouts.

The target coordinates must be exactly the same as before.

Only fetch the cells and structural context necessary to determine the correct column unambiguously.

## Step E — fetch actual target cells

Once the target cell coordinates have been resolved, fetch the actual cells required for:

- Existing value.
- Formula.
- Note.
- Merged-cell membership.
- Destination conflict detection.
- Write ownership verification.

Do not assume a blank cell without reading it.

Do not modify existing cell content during lookup.

## Step F — release temporary buffers

Release unneeded API responses and intermediary data after the relevant destination section has been inspected.

Do not retain a complete sheet snapshot across all 43 items.

A small reusable structural context is acceptable only when it is safe, bounded, and properly revalidated.

---

# 5. ABSOLUTE COORDINATE PRESERVATION

This requirement is extremely important.

Existing resolver and writer logic uses zero-based row and column indices.

The optimized destination reader may store only selected cells.

However, every cell must retain its ABSOLUTE original Google Sheets row and column coordinates.

Do not convert a local slice offset into a destination coordinate by mistake.

For example, if an account is located at column 420, reading a local range beginning at column 400 must NOT make the write target column 20.

The actual write must still target column 420.

Likewise, if the chosen date is at sheet row 75, reading rows 70–80 must not change the destination to row 5.

The actual write remains at sheet row 75.

### Mandatory implementation rule

If you introduce a sparse grid or grid view, preserve:

- Original tab title.
- Internal sheet ID.
- Absolute row indices.
- Absolute column indices.
- Original merge coordinates.
- Original cell values.
- Original formulas.
- Original Notes.
- All required formatting/date information.

Do not alter `Write.address`, `Write.row`, or `Write.col` semantics.

Do not use hardcoded coordinate translations.

Test far-right columns explicitly.

---

# 6. PRESERVE ALL DESTINATION MODULES

The optimized reader must work for every existing destination tab, not only SALDO BANK.

The following destination modules must remain unchanged:

1. `TOTAL DEPO`
2. `TOTAL WD`
3. `SALDO BANK`
4. `BIAYA`
5. `Pengeluaran FEE QRIS DEPO`
6. `Pengeluaran FEE QRIS WD`
7. `KET PENGIRIMAN`

Do not change:

- Module calculations.
- Metric definitions.
- Account matching.
- Date selection.
- Row placement.
- Column placement.
- Fee description formatting.
- Fee amount sign handling.
- Transfer priority.
- Bank assignment.
- Formula preservation.
- Note preservation.

Source columns remain:

### DOC DEPO

- D: description
- E: DEPO
- F: WD
- H: expense
- I: transfer
- J: cumulative DEPO
- K: cumulative WD
- L: SALDO

### DOC QRIS

- D: description
- E: DEPO
- F: WD
- G: expense
- H: transfer
- I: cumulative DEPO
- J: cumulative WD
- K: SALDO

Do not change the existing optimized V4 source-reading logic unless an absolutely necessary compatibility correction is proven.

---

# 7. EXTRA REQUIREMENTS FOR KET PENGIRIMAN

This destination has special and more complex structural requirements.

Inspect the exact implementation in:

`backend/app/engine/resolver.py`

Function:

`transfer_slots()`

The current code supports multiple layout patterns, including:

- Calendar-date sections.
- Monthly side-total layouts.
- Merged section headers.
- Website section boundaries.
- BCA, MANDIRI, BRI, BNI bank blocks.
- Paired description and amount columns.
- TOTAL boundaries.
- Limited available transaction slots.

All these behaviors must remain unchanged.

Do not replace this logic with a simplified four-column assumption.

The optimized reader must retrieve sufficient structural data to reproduce exactly the same transfer slots and allocation decisions.

It must preserve:

- DOC DEPO before DOC QRIS.
- Existing transfer row color rules.
- QRIS bank allocation priority.
- Existing descriptions.
- Original Notes.
- Source transaction identity.
- Transfer ownership.
- Duplicate prevention.
- Existing overflow behavior.

Preserve both supported transfer layout patterns.

A test that only checks normal TOTAL DEPO cells is insufficient.

---

# 8. PRESERVE GOOGLE SHEETS WRITE PROTECTION

Inspect:

`backend/app/engine/writer.py`

Do not remove or weaken:

- `check_write()`
- `get_ledger()`
- `owner_key()`
- Structural verification.
- Formula verification.
- Merged-cell conflict checks.
- Non-owned manual data protection.
- Existing Notes protection.
- Prepared write recovery.
- Write ownership ledger.
- Transfer slot ownership.
- Idempotency rules.
- Read-back verification.

The current implementation uses whole-grid snapshots for some protections.

Replace those large snapshots with memory-efficient checks that provide the SAME effective protection.

For globally defined V4 invariants, use bounded streaming scans and incremental fingerprints or equivalent exact comparisons where appropriate.

Do not narrow a global protection check without proving that no previously protected condition can be missed.

For example:

- A formula in a target cell must never be overwritten.
- Formula changes that V4 previously detected must still be detected.
- Relevant structural changes must still invalidate a stale write plan.
- A merged cell must not be treated as an ordinary editable cell.
- A Note must not be silently removed.
- A destination changed between planning and writing must not be silently accepted.

### Critical

Avoid simply fetching the target cell and skipping the old `structural()` and `formula_map()` protection behavior.

That would be a security and financial integrity regression.

If these global checks require scanning, implement the scan incrementally with bounded memory.

---

# 9. FIX EVERY DESTINATION READ STAGE

The patch is incomplete unless all relevant destination reads have been fixed.

Audit and update as necessary:

### A. Initial planning

`engine/runner.py` → `target()`

Must not load or retain a full destination grid.

### B. Pre-write verification

`engine/writer.py` → `execute()`

Must not recreate the complete destination grid just to confirm the write plan.

### C. Post-write verification

`engine/writer.py` → `_submit_and_verify()`

Must read back the actual written cells, plus all structural/formula information needed to preserve V4's existing checks.

Must not download an unrestricted complete destination grid.

### D. Reconciliation

`reconciliation.py` → `fresh_balance()`

Must not download the complete `Laporan deposit harian` sheet into RAM.

### E. Other grid consumers

Search all references to:

`client.grid(...)`

`grid.rows`

`grid.merges`

`grid.cell(...)`

`grid.inherited(...)`

Audit all consumers for assumptions that the grid is fully materialized.

If changing to a sparse representation, update every affected consumer safely.

Do not return an incomplete sparse grid to unmodified code that expects dense rows.

That would create subtle coordinate errors.

---

# 10. RECONCILIATION MUST REMAIN READ-ONLY

`Laporan deposit harian` must NEVER be modified by the robot.

Preserve:

- Website marker recognition.
- Horizontally repeated report tables.
- Vertically spelled website markers where supported.
- Date matching.
- BALANCE header detection.
- Individual website BALANCE check.
- Consolidated BALANCE check.
- Duplicate/missing marker detection.
- Existing error behavior.
- Requirement that BALANCE equals zero for KLOP.
- Existing final Clear requirements.

Because the report may be horizontally extensive, use scoped metadata and targeted value reads.

Do not assume all registered websites appear within the first few columns.

Do not treat a missing BALANCE as zero.

Do not force formulas to zero.

Do not write anything into the report.

Preserve the existing repeated-fresh-read behavior required to confirm stable zero balances.

---

# 11. KEEP MEMORY SAFETY WITHOUT REJECTING WIDE SHEETS

The current 250,000-cell destination guard must not be the criterion for rejecting the entire spreadsheet.

Replace it with bounded operational limits such as:

- Cells fetched per request.
- Decoded JSON response bytes.
- Rows retained for one operation.
- Columns retained for one structural region.
- Total active temporary buffer size.
- Timeouts and bounded retries.

Keep the existing HTTP response safety cap:

`max_api_response_bytes = 8_388_608`

Unless an independently verified defect specifically requires a different safely bounded approach.

Do not raise it merely to pass tests.

Keep the worker memory limit:

`MemoryMax=1536M`

Do not change the systemd override.

A destination with hundreds or thousands of columns must be supported without requiring a whole-grid allocation.

The amount of RAM used must primarily depend on the actual active working set, not the product of the entire sheet's allocated row and column counts.

If a single real business structure is itself extraordinarily large, process its data in bounded chunks and report a genuine resource issue if correctness cannot be preserved.

Never silently skip records to satisfy a memory target.

---

# 12. PRESERVE NAME-BASED TAB IDENTIFICATION

The administrator configures:

- Source Google Spreadsheet URLs.
- Destination Google Spreadsheet URL.
- Source tab names.
- Active/inactive tab selections.
- Website registration.

Do not introduce any new manual sheet ID configuration.

Do not hardcode `gid` numbers.

Do not bind the application to historical tab IDs.

The existing application must continue to resolve tabs using the configured names.

Internally obtaining `sheetId` from Google metadata for batchUpdate is permitted.

But application mapping and configuration must continue to depend on registered URLs, current tab names, website identity, and the existing business rules.

If a tab is renamed, preserve existing refresh/revalidation behavior.

---

# 13. STRICT NO-CHANGE SCOPE

Do not modify any of the following unless directly necessary to preserve compatibility with the new destination reader:

- Admin frontend.
- CSS.
- Dashboard layout.
- Navigation.
- Authentication.
- User accounts.
- API response contracts.
- Source URL configuration.
- Destination URL configuration.
- Monthly website activation.
- Queue processing.
- Run status semantics.
- Stop/Cancel behavior.
- Worker concurrency.
- Database schema.
- Financial calculations.
- Business mapping.
- Spreadsheet write ownership.
- Reconciliation rules.
- Existing Google credentials.
- Nginx.
- HTTPS configuration.

Do not implement the future five-worker architecture.

Do not introduce new modules or product features.

Do not change the existing optimized V4 source-date discovery unless tests establish a direct dependency on the destination patch.

Any source code changes must be narrowly justified.

---

# 14. REQUIRED TESTS — HORIZONTALLY WIDE WORKBOOKS

Create realistic automated destination fixtures.

Test at least the following:

### Test 1 — Wide sheet with mostly empty allocated cells

- 1,000 rows.
- 1,000 columns.
- Relevant data occupies a much smaller subset.
- Expected result: no false `SHEET_TOO_LARGE` error.

### Test 2 — Website far to the right

- At least 40 website blocks.
- VELBETT placed in a far-right block.
- Account columns beyond column 300.
- Verify exact absolute target coordinates.

### Test 3 — Website near the end of a very wide workbook

- At least 1,500 allocated columns.
- Website marker near the far-right area.
- Ensure the scanner reaches it without loading the complete grid.

### Test 4 — Neighboring website protection

- Two similar website blocks.
- Matching account labels exist in both.
- Verify that the robot writes only inside the selected website block.

### Test 5 — Duplicate marker rejection

- Duplicate or ambiguous website marker.
- Existing ambiguity error must remain.

### Test 6 — Unregistered structural boundary

- Adjacent website block is not in the currently registered list.
- Its structurally valid boundary must still prevent scanning into the next block.

### Test 7 — Missing selected date

- No matching destination date.
- Must fail with the proper error.
- Must not guess a row.

### Test 8 — Duplicate selected date

- Multiple matches within the relevant structure.
- Must reject ambiguity.

### Test 9 — Exact mapping comparison

Compare old V4 and V4.1 on identical valid fixtures.

Assert equality of:

- Tab.
- Absolute row.
- Absolute column.
- A1 destination address.
- Value.
- Note.
- Bank.
- Transaction identity.

### Test 10 — Formula protection

- Formula in intended destination cell.
- Formula elsewhere in the scope protected by existing V4 checks.
- Verify protection remains identical.
- No unsafe write is allowed.

### Test 11 — Merged cells

- Merged header across many columns.
- Merged website section.
- Transfer bank paired cells.
- Merged target cells.
- Merges crossing API request chunk boundaries.

All existing merge protections must work.

### Test 12 — Manual data and Notes

- Pre-existing manual value.
- Note in destination.
- Prepared ledger entry.
- Verified ledger entry.
- Unowned destination cell.

Verify unchanged conflict and ownership behavior.

### Test 13 — Destination modified during processing

Modify a relevant header, formula, or write target between planning and writing.

Ensure V4.1 detects the same conflicts as V4.

### Test 14 — Read-back verification

After a write, re-read the relevant cells.

Verify exact values and Notes.

Simulate mismatches and confirm that failures are detected.

### Test 15 — Transfer slot layouts

Test both supported KET PENGIRIMAN layouts, including:

- Bank headers.
- TOTAL rows.
- Merged ranges.
- BCA/MANDIRI/BRI/BNI ordering.
- Slot overflow.
- Duplicate-prevention data.

### Test 16 — Horizontally wide reconciliation report

Use multiple website table sections spread widely across the report.

Verify exact date matching, BALANCE values, website associations, and consolidated checks.

Verify that the report remains read-only.

### Test 17 — Memory-bounded requests

Instrument fake Google Sheets API calls.

Assert:

- No unbounded full-grid CellData fetch.
- No response larger than the configured byte cap.
- No dense allocation proportional to the entire destination sheet.
- No `height * width` false rejection.
- Correct handling of sparse row and column coordinates.

### Test 18 — Full financial regression

Run the existing backend tests.

Reuse the V4 golden financial fixture, including the previously verified 22 planned destination writes.

Verify that all pre-existing V4 tests pass, except tests explicitly asserting the old, incorrect whole-grid destination limit; those must be replaced by correct bounded-memory tests.

Do not remove unrelated tests to obtain a passing result.

---

# 15. PERFORMANCE AND ACCEPTANCE TARGETS

Run synthetic performance benchmarks using large, sparse and wide destination fixtures.

Measure:

- Number of Google Sheets requests.
- Maximum response bytes.
- Peak Python RSS.
- Source-read duration.
- Destination mapping duration.
- Pre-write validation duration.
- Read-back verification duration.
- Full run duration where feasible.

Avoid retaining complete fixture grids inside the code path being benchmarked.

Distinguish test harness memory from actual reader memory.

### Acceptance requirements

1. A 1,000 × 1,000 destination must not fail merely because of its allocated cell count.
2. A 1,500-column destination must be addressable at far-right coordinates.
3. Identical fixtures must produce identical financial destination writes.
4. Memory usage must remain bounded.
5. No OOM in representative controlled memory tests.
6. No bypass of formula, Note, merge, ownership, or conflict protection.
7. All existing source-reading optimizations must remain intact.
8. No user interface changes.
9. No database deletion.
10. No change to worker concurrency.

The production test target remains a 4 GB VPS with a 1.5 GiB worker limit.

Do not claim live success until tested against the real destination workbook.

---

# 16. PRODUCTION-SAFE V4 → V4.1 DEPLOYMENT

The application is already running on a VPS.

Current release paths:

`/opt/tutupkas/current/`

Persistent database:

`/var/lib/tutupkas/tutupkas.sqlite3`

Configuration:

`/etc/tutupkas/app.env`

Services:

- `tutupkas-api`
- `tutupkas-worker`

The existing V4 release has already processed or partially attempted Run #7.

Do not automatically restart or replay Run #7 during upgrade.

Do not delete existing job history.

Do not delete:

- `output_write_ledger`
- `transfer_slot_ownership`
- Website configurations
- User accounts
- URL settings
- Active source settings
- Financial audit data

Provide a safe V4 → V4.1 upgrade script.

It must:

1. Confirm the existing installation.
2. Stop the worker.
3. Back up the current database and release.
4. Preserve environment variables and Google credentials.
5. Install the new release.
6. Verify migration compatibility.
7. Restart the API safely.
8. Leave the worker stopped for manual activation.
9. Display health-check instructions.
10. Provide rollback instructions.

No automatic resumption of old uncertain writes.

Preserve the existing systemd memory override.

Do not touch Nginx, SSL, or domain configuration.

---

# 17. REQUIRED DELIVERY REPORT

Before delivering, inspect the Git diff and produce a concrete report.

It must contain:

## A. Root cause

Explain why the previous V4 destination reader produced `SHEET_TOO_LARGE`.

## B. Files modified

List the exact source files and functions changed.

## C. Memory design

Explain how large destination sheets are handled without full-grid materialization.

## D. Mapping safety

Explain exactly how absolute row/column coordinates and website boundaries are preserved.

## E. Write safety

Explain how formula, Note, merge, ownership, structural and read-back checks remain effective.

## F. Regression results

Report passed and failed tests with actual results.

## G. Performance

Provide actual benchmark data, not invented numbers.

## H. Upgrade

Provide the deployment procedure and rollback path.

## I. Limitations

Clearly disclose anything that remains slow, unverified, or technically blocked.

---

# 18. REQUIRED DELIVERABLES

Deliver:

1. Complete Tutup Kas Lion Group V4.1 source ZIP.
2. Revised destination-reading implementation.
3. All necessary narrowly scoped compatibility changes.
4. Automated regression tests.
5. Wide-destination memory tests.
6. Performance comparison report.
7. V4 → V4.1 upgrade script.
8. Rollback instructions.
9. Changed-file summary.
10. Confirmation that existing business behavior remains unchanged.

Do not include production credentials, real SQLite databases, or private environment files in the ZIP.

---

# 19. FINAL RELEASE GATE

Do not declare this patch complete until all the following are satisfied.

- [ ] No `SHEET_TOO_LARGE` error purely from overall allocated destination dimensions.
- [ ] No full-grid destination materialization.
- [ ] No hidden whole-grid fetch in planning.
- [ ] No hidden whole-grid fetch in pre-write validation.
- [ ] No hidden whole-grid fetch in post-write verification.
- [ ] No hidden whole-grid fetch in reconciliation.
- [ ] Correct website identification across horizontal blocks.
- [ ] Correct recognition of unregistered structural boundaries.
- [ ] Correct absolute row and column indices.
- [ ] Correct date matching.
- [ ] Correct account matching.
- [ ] Correct fee labels.
- [ ] Correct transfer slot allocations.
- [ ] All Notes preserved.
- [ ] All formulas protected.
- [ ] All relevant structural checks preserved.
- [ ] All relevant merge protections preserved.
- [ ] Manual destination entries protected.
- [ ] Existing ownership ledger preserved.
- [ ] Idempotency preserved.
- [ ] Existing financial output golden fixtures pass.
- [ ] Existing source-reader behavior unchanged.
- [ ] Existing UI unchanged.
- [ ] Existing API contracts unchanged.
- [ ] Worker architecture unchanged.
- [ ] Existing database preserved.
- [ ] Existing Google Sheets content preserved.
- [ ] No unsupported hardcoded sheet coordinates.
- [ ] Wide-sheet memory benchmarks completed.
- [ ] Safe upgrade and rollback included.

## FINAL DIRECTIVE

**This is a destination data-access correction, NOT a financial application rewrite.**

The output must satisfy the following invariant:

SAME WEBSITE
SAME SOURCE DOCUMENTS
SAME DATE
SAME BUSINESS RULES
SAME DESTINATION CELLS
SAME VALUES
SAME NOTES
SAME FORMULAS PROTECTED
SAME RECONCILIATION

But with:

**BOUNDED DESTINATION READS
NO UNNECESSARY WHOLE-GRID ALLOCATION
NO FALSE SHEET_TOO_LARGE REJECTION
LOWER MEMORY USE
SAFE PERFORMANCE**

Do not apply unrequested creative changes.

Do not weaken financial safety mechanisms for performance.

If you identify another issue that requires changing business logic, report it separately without implementing it in this release.

**Produce the complete V4.1 ZIP and supporting reports.**

# END OF V4.1 REQUEST
