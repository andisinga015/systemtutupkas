# TUTUP KAS LION GROUP — V3 BUG FIX AND WORKFLOW CORRECTION

## CRITICAL INSTRUCTIONS

You are modifying the EXISTING Tutup Kas Lion Group V2 application.

This is a corrective update based on actual failures discovered during Google Sheets testing.

DO NOT create a new application.

DO NOT redesign the application.

DO NOT invent new financial business rules.

DO NOT change already-agreed fee calculations, transfer rules, destination mappings, or reconciliation formulas.

DO NOT replace actual processing with mock implementations.

Fix the identified bugs while preserving all existing working features.

All user-facing text must remain in Indonesian.

The final result must be a complete, upgradeable V3 release compatible with the existing VPS deployment.

---

# 1. ROOT CAUSE — INCORRECT SOURCE HEADER VALIDATION

## Current Problem

The existing V2 crawler sometimes fails with:

`Header Total harus ditemukan tepat satu kali.`

Actual error example:

- Website: VELBETT
- Source document: DOC DEPO
- Source tab: WD BCA 1 TOKEN / IVAN RAKHMANDA ( PP )
- Selected date: October 18, 2026
- Reported closing row: 309
- Module: TOTAL DEPO

The spreadsheet contains the required data in fixed source columns.

The crawler incorrectly depends on searching for source header names.

Inspect and correct:

- `backend/app/engine/parser.py`
- `backend/app/engine/runner.py`
- Other source extraction code that depends on `header()`

The existing `Day.metric()` implementation calls `header()` before checking whether a day contains transactions.

This behavior must be corrected.

## Mandatory Rule

**Source document values must be read using the confirmed fixed column positions.**

Do not dynamically locate the financial source columns by searching header text.

Header validation must not prevent a valid zero-transaction date from being processed.

This rule applies to the confirmed source document layouts below.

Destination spreadsheets still use their existing dynamic website, account, date, and header mapping.

Do not confuse SOURCE COLUMN READING with DESTINATION ACCOUNT MATCHING.

---

# 2. DOC DEPO — FIXED SOURCE COLUMNS

For every supported DOC DEPO transaction tab, use the following confirmed layout:

| Column | Purpose |
|---|---|
| D | Transaction description |
| E | DEPO |
| F | WD |
| H | DLL / BIAYA |
| I | Kiriman |
| J | Total DEPO (daily cumulative total) |
| K | Total WD (daily cumulative total) |
| L | SALDO |

Use direct column indexing.

Do not call the unique-header lookup function to locate J, K, L, H, or I.

Preserve all existing destination matching logic.

## TOTAL DEPO

Read the daily closing total from source column J.

## TOTAL WD

Read the daily closing total from source column K.

## SALDO BANK

Read the daily closing balance from source column L.

## BIAYA

Read daily expense values from source column H.

## KET PENGIRIMAN

Read transfer amounts from source column I.

Use source column D for transaction descriptions.

Do not accidentally use source column M/BALANCE as the closing bank balance.

---

# 3. DOC QRIS — FIXED SOURCE COLUMNS

DOC QRIS uses a DIFFERENT confirmed layout.

Use:

| Column | Purpose |
|---|---|
| D | Transaction description |
| E | DEPO |
| F | WD |
| G | DLL / expense |
| H | Kiriman |
| I | Total DEPO |
| J | Total WD |
| K | SALDO |

Apply this layout to the supported DOC QRIS transaction tabs.

Do not use the DOC DEPO column coordinates for DOC QRIS.

Do not require unique header-name lookup for these fixed financial columns.

The special QRIS E-POWER and QRIS QRIZZ processing rules remain unchanged.

---

# 4. DAILY DATE BOUNDARY LOGIC

## Existing Confirmed Rule

To process a selected date, locate the separator for the FOLLOWING date.

The daily closing position is immediately before the following date boundary.

Example:

To process October 15, locate October 16, then use the closing position of October 15.

Do not accidentally use the previous day's transactions.

## Real Source Example

Source tab:

`WD BCA 1 TOKEN / IVAN RAKHMANDA ( PP )`

Observed date boundaries:

- Row 307: October 16, 2026
- Row 308: October 17, 2026
- Row 309: October 18, 2026
- Row 310: October 19, 2026
- Row 311: October 20, 2026
- Row 312: October 21, 2026

When processing October 18:

Find October 19 at row 310.

The closing position for October 18 is row 309.

The crawler must identify that October 18 contains no transactions.

Expected result:

- TOTAL DEPO = 0
- TOTAL WD = 0
- SALDO = 2,355,000

Do not fail because the daily Total DEPO or Total WD cells are blank.

## No-Transaction Rules

When the selected date contains no transactions:

1. TOTAL DEPO = 0.
2. TOTAL WD = 0.
3. SALDO follows the last valid closing balance.
4. Daily expense totals are 0 when there are no applicable expense transactions.
5. No transfer transaction should be invented.
6. Existing formulas and destination protection remain active.

A zero-transaction day is a NORMAL condition.

It is not a failed crawl.

## Important Distinction

Do not treat the following as equivalent:

- A valid date with no transactions.
- A missing date separator.
- A malformed source spreadsheet.
- An unreadable or nonnumeric balance.
- A Google Sheets API error.

Only a verified day without relevant transactions may produce the corresponding zero totals.

Do not silently convert malformed source data or API failures into zero.

## Nonempty Days

When transactions exist, use the correct daily closing cumulative values from the fixed total columns.

Do not replace valid totals with zero.

Use the date boundaries to select the correct daily transaction region.

Do not accidentally include the separator row for the following day.

---

# 5. PRESERVE DOC DEPO EXPENSE RULES

The administrator has already confirmed the DOC DEPO expense logic.

Do NOT change it.

For each active DOC DEPO source tab:

1. Find the transaction rows belonging to the selected date.
2. Read the applicable signed expense values from column H.
3. Sum the signed amounts.
4. Combine the signed expense amounts across the applicable DOC DEPO tabs.
5. Convert the final signed sum to a positive expense total.
6. Write the result to the website's existing BIAYA destination field.

Example:

-1,000 + -2,500 = -3,500

Destination expense:

3,500.

For a valid date without expense transactions:

BIAYA contribution = 0.

Do not require dynamic source-header lookup for column H.

Preserve the existing destination matching, ownership checks, formula protection, and write verification.

---

# 6. PRESERVE DOC QRIS EXPENSE RULES

Do NOT change the existing business calculations.

## BIAYA TARIK QRIS

Source:

DOC QRIS → `QRIS QRIZZ`

Read the applicable daily expense values from column G.

Write the resulting positive expense amount to the corresponding `BIAYA TARIK QRIS` destination.

## BIAYA AUTO WD

Source:

DOC QRIS → `QRIS E-POWER`

Read the applicable daily expense values from column G.

Write the resulting positive expense amount to the corresponding `BIAYA AUTO WD` destination.

## Important

These expense fields are separate from the FEE QRIS expenditure report sheets.

Do not merge these modules.

Do not use column H for the column-G expense calculations.

Do not require dynamic source-header lookup for column G.

---

# 7. PRESERVE PENGELUARAN FEE QRIS DEPO

Source:

DOC QRIS → `QRIS QRIZZ`

Identify transaction descriptions in column D matching:

`FEE QRIS PERIODE ...`

Read their associated fee amounts from source column H.

The exact existing description must be preserved.

Do not split fee periods into separate dates.

Do not redistribute a fee amount across the dates mentioned in its description.

Record the expense on the actual transaction date in the source document.

## Multiple Fee Descriptions on the Same Date

If two or more `FEE QRIS PERIODE ...` entries occur on the same transaction date:

- Preserve every original description.
- Combine the descriptions using separate lines in the destination KETERANGAN cell.
- Sum the corresponding signed fee amounts.
- Convert the final amount to a positive expense value.
- Write to the existing Pengeluaran FEE QRIS DEPO destination field.

Example destination description:

FEE QRIS PERIODE 15-16 october 2026

FEE QRIS PERIODE 14-15 october 2026

Do not replace these with a generic description.

Do not change the fee calculation.

---

# 8. PRESERVE PENGELUARAN FEE QRIS WD

Source:

DOC QRIS → `QRIS E-POWER`

Identify the description:

`FEE WD AUTO`

in source column D.

Read its corresponding fee amount from source column H.

Use the existing selected-date boundaries.

Convert the signed total to a positive expense value.

The destination description must be exactly:

`FEE WD AUTO`

Write this description only ONCE per selected date, even when multiple matching fee rows exist.

Do not mix this with `BIAYA AUTO WD`, which uses source column G.

---

# 9. PRESERVE KET PENGIRIMAN

Do not redesign the existing KET PENGIRIMAN module.

## DOC DEPO Transfers

Use:

- Column D: Keterangan.
- Column I: Kiriman amount.

Only include the previously agreed eligible transfer descriptions on brown transaction rows.

Exclude nonmatching and blue transaction rows.

Determine the bank from the source tab name.

Examples:

`WD BCA 2 / ALIN HELPINA`

maps to:

BCA.

`WD MANDIRI / MUHAMMAD AFFAN NASUTION ( PP )`

maps to:

MANDIRI.

Process DOC DEPO transfers before DOC QRIS transfers.

## DOC QRIS Transfers

Use:

- Column D: Keterangan.
- Column H: Kiriman amount.

Only include qualifying brown transfer rows.

The confirmed QRIS destination allocation priority is:

1. BCA.
2. MANDIRI when BCA is full.
3. BRI when MANDIRI is full.
4. BNI when BRI is full.

Preserve the existing note requirement for QRIS transfers.

Notes must allow a human administrator to identify:

- Source QRIS tab.
- Original transaction description.
- Original transfer amount.

Examples:

`QRIS E-POWER (Keterangan) 1.xxx.xxx`

`QRIS QRIZZ (Keterangan) 1.xxx.xxx`

Use actual Google Sheets cell Notes.

## Destination Safety

Never overwrite:

- Formulas.
- TOTAL rows.
- Existing unrelated descriptions.
- Existing unrelated amounts.
- Manual Notes.
- Other websites' transfer blocks.

If an available safe transfer slot cannot be found, report a clear error.

Do not invent additional transfer slots.

Do not insert rows automatically.

## Technical Correction

Stop requiring source-header lookup for the fixed Kiriman columns.

Keep the existing transaction-description filters and brown/blue classification rules.

Do not invent new color values or new transaction-description categories.

Investigate genuine transfer errors separately from source-header errors.

---

# 10. FIX TECHNICAL ERRORS WITHOUT CHANGING BUSINESS RULES

The V2 testing showed failures in multiple modules, including:

- TOTAL DEPO.
- TOTAL WD.
- SALDO BANK.
- KET PENGIRIMAN.
- BIAYA.
- QRIS-specific expenses.
- QRIS-specific fees.

Do not assume all failures have the same root cause.

Inspect the actual error handling and source parsing paths for every module.

Remove incorrect dependence on dynamic header discovery for fixed source columns.

Keep destination header and account matching dynamic.

If a different genuine error remains, preserve and report that error accurately.

Do not suppress errors to produce artificial success.

Do not claim fee or transfer functionality is fixed merely because the TOTAL DEPO bug has been corrected.

---

# 11. ADD SEPARATE DATES FOR MASS AND INDIVIDUAL EXECUTION

The current UI uses one date selector for mass and individual processing.

This must be corrected.

## Mass Execution

The date selector at the top of the `Penarikan Data Harian` panel is exclusively for:

- Pratinjau Semua.
- Mulai Penarikan Semua WEB.

All active websites in the mass run use that selected mass date.

## Individual Execution

Every website row must have its own date selector.

For example:

VELBETT:

- Individual selected date.
- Pratinjau.
- Mulai Penarikan.

Changing the mass date must not automatically change a website's individual selected date.

Changing VELBETT's individual date must not change the mass date.

## Date-Specific Status

The displayed processing and BALANCE statuses must correspond to the date currently selected for that website.

Do not show an October 15 reconciliation result as though it belongs to October 18.

The mass operation must remain independent of the individual date selectors.

Do not change the existing source-month and destination-month lookup rules.

---

# 12. ADD STOP AND CANCEL CONTROLS

## Existing Problem

An administrator selected an incorrect date while a job was already running.

The application provided no way to stop the current job.

Another job remained in the queue.

Retry actions were unavailable while processing continued.

This caused unnecessary waiting.

## Required Controls

For queued jobs:

`Batalkan Antrean`

For running jobs:

`Stop Penarikan`

These controls must be available in the relevant run details and history pages.

Provide the equivalent batch-level controls for mass execution.

## Cancellation Rules

1. Cancellation must be initiated by an authenticated authorized administrator.
2. Queued jobs must be cancellable before processing begins.
3. Running jobs must receive a cancellation request.
4. Stop at the next safe processing boundary.
5. Do not start further pending items after cancellation is acknowledged.
6. Do not interrupt a financial write in a way that creates unknown data corruption.
7. If a Google write has already been submitted, verify its outcome where possible.
8. Preserve successfully written and verified results.
9. Record any uncertain write states for reconciliation.
10. Mark the job as canceled, not successful.
11. Do not automatically resume an explicitly canceled job after worker restart.
12. Allow a new authorized run only when conflicts are safely resolved.

## Required Statuses

Use appropriate statuses such as:

- Dalam Antrean.
- Sedang Diproses.
- Pembatalan Diminta.
- Dibatalkan.
- Sebagian Berhasil.
- Gagal.
- Selesai.

Do not label a canceled run as KLOP or Selesai & Clear.

## Retry After Cancellation

After a canceled or failed run is finalized safely, allow selective retry of incomplete or failed items.

Do not allow conflicting simultaneous writes.

A retry button must not remain permanently disabled because a stale job is incorrectly marked as running.

---

# 13. PREVENT STUCK JOBS AND UNNECESSARY DELAYS

## Existing Problem

One website took an excessive amount of time to process.

Multiple modules remained in the waiting state.

Some failed items prevented practical follow-up actions.

## Required Corrections

Inspect:

- Google Sheets request count.
- Source grid loading.
- Source parsing.
- Destination mapping.
- Per-item processing.
- Write verification.
- Worker queue handling.
- Retry handling.
- Run completion logic.

## Source Reading Optimization

When several modules use the same source tab and selected date:

Read the source grid once per processing context where feasible.

Reuse that validated source snapshot for:

- TOTAL DEPO.
- TOTAL WD.
- SALDO.
- Applicable expenses.
- Applicable transfer extraction.

Do not refetch the same source grid separately for each metric without a justified need.

Preserve safe destination read-back and verification.

Do not weaken formula or existing-cell protections for performance.

## Error Handling

Distinguish between:

- Permanent structural errors.
- Missing or ambiguous dates.
- Missing source tabs.
- Invalid numeric values.
- Destination conflicts.
- Temporary Google API failures.
- Google rate limits.

Permanent structural errors should not be retried repeatedly without a configuration or data change.

Temporary errors may use bounded retry with backoff.

Avoid infinite retry loops.

A failed item must not prevent independent items from being processed, unless they explicitly depend on that failed item.

Finalize all item and job statuses accurately.

Do not leave jobs permanently stuck in RUNNING or QUEUED because an exception was not handled.

## Logging

Record enough diagnostic information to identify:

- Run ID.
- Website.
- Source tab.
- Selected date.
- Module.
- Current phase.
- Error code.
- Elapsed processing time.

Never log secrets or private Google credentials.

---

# 14. PRESERVE PREVIEW SAFETY

`Pratinjau` and `Pratinjau Semua` must remain read-only operations.

They may:

- Read source spreadsheets.
- Calculate values.
- Resolve destination cells.
- Check for conflicts.
- Display planned changes.

They must not perform financial writes.

Preview failures must not automatically retry indefinitely.

Preview jobs must also be cancelable when queued or running.

---

# 15. PRESERVE DESTINATION MATCHING

This V3 change concerns SOURCE READING.

Do not replace the dynamic destination matching system with hardcoded destination columns.

The existing destination mapping still uses:

- Registered website name.
- Website section.
- Source tab or account identity.
- Destination account header.
- Selected date.
- Destination module.

Destination spreadsheet positions may change horizontally.

The administrator must not need to configure column letters for destination sheets.

Preserve existing supported account aliases.

Preserve:

- Formula protection.
- Existing-cell conflict detection.
- Write ownership.
- Idempotency.
- Read-back verification.
- Selective retry.
- Monthly URL configuration.
- Historical URL revisions.

Keep `Laporan deposit harian` strictly read-only.

Reconciliation must still verify website BALANCE and consolidated BALANCE against zero.

Do not rewrite the financial reconciliation formulas.

---

# 16. REQUIRED AUTOMATED TESTS

## Fixed DOC DEPO Columns

Verify:

- J is used for TOTAL DEPO.
- K is used for TOTAL WD.
- L is used for SALDO.
- H is used for expense values.
- I is used for transfer amounts.

Verify that the crawler does not need a unique `Total` header to extract the confirmed source values.

## Fixed DOC QRIS Columns

Verify:

- I is used for TOTAL DEPO.
- J is used for TOTAL WD.
- K is used for SALDO.
- G is used for applicable QRIS expense values.
- H is used for applicable QRIS fee and transfer amounts.

## Empty Day

Using fixture data representing the supplied October 2026 spreadsheet layout:

Selected date:

October 18, 2026.

Expected:

- TOTAL DEPO = 0.
- TOTAL WD = 0.
- SALDO = 2,355,000.

Ensure the job does not fail merely because cumulative daily total cells are blank on a separator-only day.

## Populated Day

Use a test case with a valid closing row containing nonzero cumulative values.

Verify the crawler reads those values and does not incorrectly return zero.

## Malformed Data

Verify the crawler still reports genuine errors when:

- Date separators are missing.
- Date boundaries are ambiguous.
- Balance is invalid.
- Source data cannot be read.
- Google Sheets returns an error.

## Fees

Test:

- DOC DEPO column H expense summation.
- QRIS QRIZZ column G expense summation.
- QRIS E-POWER column G expense summation.
- QRIS QRIZZ FEE QRIS PERIODE values in column H.
- Multiple fee descriptions on the same date.
- QRIS E-POWER FEE WD AUTO values in column H.
- Single destination FEE WD AUTO description.
- Zero applicable fees.

## Transfers

Test:

- DOC DEPO bank identification.
- DOC DEPO column I transfer values.
- DOC QRIS column H transfer values.
- Brown transaction inclusion.
- Blue transaction exclusion.
- QRIS bank overflow order.
- QRIS Notes.
- Formula protection.
- TOTAL row protection.
- Slot exhaustion.
- Idempotent retry.

## Date Selection

Test:

- Mass date independent of individual dates.
- Individual date independent of mass date.
- Website status changes according to selected date.
- Mass processing uses the mass date for all active websites.

## Job Cancellation

Test:

- Cancel queued job.
- Stop running job safely.
- Preserve verified partial writes.
- Do not resume canceled jobs.
- Retry remaining failed items after cancellation.
- Prevent concurrent conflicting writes.
- Properly finalize job statuses after exceptions.

## Performance

Verify that shared source data is not unnecessarily refetched for every metric.

Demonstrate the reduction in source-read calls using automated tests or instrumentation.

Do not claim real performance improvements without measurements.

---

# 17. VPS UPGRADE REQUIREMENTS

The application is already deployed.

Preserve:

- `/var/www/html/` frontend hosting.
- `/opt/tutupkas/current/` application structure.
- `/var/lib/tutupkas/` persistent data.
- `/etc/tutupkas/app.env`.
- Existing Google Service Account credentials.
- Administrator accounts.
- Existing website configurations.
- Source and destination URLs.
- Active and inactive sheet settings.
- Historical runs and error records.
- Nginx.
- HTTPS certificates.

Create an upgradeable V3 ZIP.

Include:

1. Corrected backend source.
2. Corrected frontend source.
3. Updated worker and job cancellation logic.
4. Database migrations if required.
5. Automated tests.
6. Updated deployment documentation.
7. Updated rollback instructions.

The administrator uploads the ZIP manually through FileZilla/SFTP.

Do not assume direct access to the VPS.

Do not replace the existing SQLite database.

Do not automatically start previously canceled jobs after upgrading.

Document safe handling of unfinished V2 jobs before the V3 worker is started.

---

# 18. FINAL ACCEPTANCE CRITERIA

The corrective release is complete only when:

- [ ] DOC DEPO fixed-column reading works.
- [ ] DOC QRIS fixed-column reading works.
- [ ] Unique-header dependency no longer blocks valid source metrics.
- [ ] Empty transaction dates produce the expected zeros.
- [ ] Empty transaction dates preserve the last valid saldo.
- [ ] Real missing-date and invalid-data errors remain visible.
- [ ] Fee calculations remain unchanged.
- [ ] Transfer business rules remain unchanged.
- [ ] Fee and transfer technical failures are investigated and corrected.
- [ ] Mass and individual date selectors are separate.
- [ ] Queued jobs can be canceled.
- [ ] Running jobs can be stopped safely.
- [ ] Canceled jobs are not automatically resumed.
- [ ] Failed items can be retried safely.
- [ ] Jobs no longer remain indefinitely stuck because of unhandled errors.
- [ ] Repeated unnecessary source-grid reads are reduced.
- [ ] Preview remains strictly read-only.
- [ ] Destination mapping remains dynamic.
- [ ] Existing financial write protection remains intact.
- [ ] `Laporan deposit harian` remains strictly read-only.
- [ ] Reconciliation continues to use the existing BALANCE rules.
- [ ] All relevant automated tests pass.
- [ ] A complete deployable V3 ZIP is produced.
- [ ] Existing VPS data and configuration are preserved.

## FINAL DIRECTIVE

This is a CORRECTIVE UPDATE, not a redesign.

Fix the actual V2 failures.

Do not improvise new financial logic.

Keep every confirmed business rule unchanged.

Make the crawler correctly read fixed source columns, process empty dates, support safe cancellation, and efficiently process individual or mass jobs.

Provide an explicit implementation summary stating:

- What was broken.
- Which source files were corrected.
- Which tests passed.
- What remains unverified.
- Whether real Google Sheets were tested.
- How to safely upgrade the currently installed V2 application.

**DO NOT CLAIM THAT LIVE CRAWL + WRITE SUCCEEDED UNLESS IT WAS ACTUALLY VERIFIED AGAINST AN AUTHORIZED GOOGLE SPREADSHEET.**

# END OF V3 CORRECTIVE UPDATE