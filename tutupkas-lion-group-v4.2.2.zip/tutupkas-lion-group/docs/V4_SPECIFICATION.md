# TUTUP KAS LION GROUP — V4
# STRICT PERFORMANCE AND OUT-OF-MEMORY CORRECTION ONLY
# ZERO BUSINESS LOGIC CHANGES — ZERO FINANCIAL MAPPING CHANGES

## 0. MANDATORY ENGINEERING INSTRUCTIONS

You are a senior Python performance engineer, Google Sheets API specialist, memory optimization engineer, and backend reliability engineer.

You are modifying the EXISTING Tutup Kas Lion Group V3 project.

This is a STRICTLY LIMITED corrective maintenance release.

The current production application is already installed on an Ubuntu VPS with:

- 2 vCPU
- 4 GB RAM
- Approximately 40 GB disk
- FastAPI backend
- SQLite database
- React/TypeScript frontend
- Google Sheets integration
- A systemd-managed background worker
- Existing authenticated Admin Dashboard
- Existing production domain and HTTPS

The current worker service has the following configured memory limit:

`MemoryMax=1536M`

This limit is managed through a systemd override.

**PRIMARY OBJECTIVE: Eliminate the current excessive-memory Google Sheets reading behavior and substantially reduce memory usage and unnecessary source-reading requests.**

**SECONDARY OBJECTIVE: Improve processing speed without sacrificing accuracy, completeness, or financial data safety.**

### ABSOLUTE RESTRICTIONS

DO NOT:

1. Rewrite the entire application.
2. Change any existing financial business rules.
3. Change any confirmed source column coordinates.
4. Change any destination column or row mapping behavior.
5. Change website identification logic.
6. Change date-selection semantics.
7. Change transaction interpretation.
8. Change expense calculations.
9. Change QRIS fee calculations.
10. Change transfer allocation rules.
11. Change Google Sheets Notes behavior.
12. Change reconciliation or Clear requirements.
13. Change the Admin UI design, layout, navigation, labels, CSS, or existing frontend workflows.
14. Add unrelated features.
15. Change existing API contracts.
16. Change the existing website worker concurrency architecture in this patch.
17. Implement the previously discussed five-website worker pool yet.
18. Increase systemd memory limits as a workaround.
19. Disable the OOM killer.
20. Add swap as a substitute for correcting memory usage.
21. Delete existing application data or write ownership records.
22. Change Google credentials.
23. Change the current Nginx or HTTPS configuration.

Implement only the backend performance, memory efficiency, and reliability corrections necessary to resolve the proven V3 OOM failure.

Any modification to financial extraction or destination placement must be strictly behavior-preserving.

If performance optimization appears to require changing financial business behavior, STOP that specific optimization and report the conflict instead of silently changing the rules.

---

# 1. CONFIRMED PRODUCTION FAILURE

## Observed failure

The current V3 worker repeatedly fails while processing:

Website:

`VELBETT`

Selected date:

`2026-10-18`

Source tab:

`WD BCA 1 TOKEN / IVAN RAKHMANDA ( PP )`

Run ID:

`5`

Total planned items:

`43`

Observed progress:

`0 / 43`

The worker repeatedly enters:

`SOURCE_READING`

And subsequently crashes with:

`A process of this unit has been killed by the OOM killer.`

`Main process exited, code=killed, status=9/KILL`

`Failed with result 'oom-kill'.`

The worker then restarts and attempts unfinished processing again.

This has happened multiple times.

The problem persisted after:

- VPS memory was upgraded from 2 GB to 4 GB.
- Worker memory limit was increased from 700 MiB to 1536 MiB.

The worker was manually stopped after the latest failure.

**Treat these logs as evidence of an excessive-memory workload, not as evidence of incorrect financial calculation.**

Do not simply raise the memory limit again.

Identify the actual allocation hotspots and eliminate unnecessary materialization of Google Sheets data.

---

# 2. INVESTIGATE EXISTING SOURCE READING IMPLEMENTATION

Before editing code, audit the existing V3 implementation.

Locate all source-reading code paths used by:

- DOC DEPO
- DOC QRIS
- TOTAL DEPO
- TOTAL WD
- SALDO BANK
- BIAYA
- Pengeluaran FEE QRIS DEPO
- Pengeluaran FEE QRIS WD
- KET PENGIRIMAN

Also inspect source-reading operations used during:

- Preview
- Individual crawling
- Crawl All
- Selective retry
- Read-back verification
- Destination mapping
- Reconciliation

Inspect the actual repository structure rather than assuming source file paths.

In particular, investigate Google Sheets API calls involving:

`spreadsheets.get`

`spreadsheets.values.get`

`spreadsheets.values.batchGet`

`includeGridData=true`

And any helper that retrieves entire spreadsheet grids or full tab metadata.

Identify whether the application:

- Requests every row.
- Requests every column.
- Retrieves formatting for every cell.
- Retrieves complete Notes metadata.
- Builds large nested Python dictionaries.
- Materializes duplicated cell objects.
- Copies complete source grids repeatedly.
- Keeps source grids alive after processing.
- Fetches identical source data repeatedly for separate modules.
- Creates large intermediate JSON representations.

Document the root causes with evidence.

Do not conclude that a particular call is responsible without inspecting the actual execution path.

---

# 3. STRICT RULE — NEVER FETCH THE ENTIRE SOURCE GRID

The crawler must no longer fetch a complete source tab merely to process one selected date.

For example, when processing:

`2026-10-18`

Do not retrieve all transactional cell values and metadata for the entire October spreadsheet.

Instead, implement precise, bounded, incremental data access.

### Required architecture

Use:

`DATE DISCOVERY → RELEVANT ROW SELECTION → TARGETED COLUMN FETCH → CALCULATION`

The robot must determine which source rows belong to the selected date and obtain only the required data.

No complete source-tab CellData objects should be loaded into RAM.

### Important

Google Sheets API does not provide a general server-side text-search endpoint for arbitrary cell values.

Therefore, implement a bounded date-discovery strategy using minimal values-only requests.

Do not pretend that a server-side search function exists.

Use actual Google Sheets API functionality.

---

# 4. MEMORY-EFFICIENT DATE DISCOVERY

The existing date-boundary business rule is confirmed and must remain unchanged.

The crawler locates the separator for the date following the selected date.

That separator identifies the closing boundary for the selected date.

Do not change the definition of transaction dates or closing rows.

## Required optimization

Use small, bounded values-only requests to locate the relevant date separators.

Do not retrieve cell formatting or complete row data during initial date discovery.

Where possible:

1. Obtain lightweight sheet metadata.
2. Identify the known date-marker region.
3. Read only narrow ranges needed to discover dates.
4. Search for the selected date and its next date boundary.
5. Stop searching as soon as the required boundaries are reliably established.

Use bounded chunks of rows rather than one unrestricted request.

An initial bounded chunk size around 100–250 rows may be evaluated, but the final value should be selected based on testing.

Chunk size must be configurable in backend settings.

## Performance requirements

Avoid unnecessary repeated scanning from the first row when reliable, validated date-location information is already available.

If caching date locations, the cache must be:

- Associated with the exact spreadsheet ID.
- Associated with the exact tab identity.
- Invalidated when source content or layout changes.
- Safe against stale row positions.
- Limited in size.
- Never treated as more authoritative than the actual source document.

A stale cache must never cause transactions to be associated with the wrong date.

When date boundaries cannot be identified reliably, preserve existing error behavior.

Do not guess.

Do not silently return zero for a malformed document.

---

# 5. READ ONLY REQUIRED SOURCE COLUMNS

All previously confirmed column positions are FIXED.

They must remain unchanged.

## DOC DEPO

| Column | Purpose |
|---|---|
| D | Transaction description |
| E | DEPO transactions |
| F | WD transactions |
| H | DLL / BIAYA |
| I | Kiriman |
| J | Daily Total DEPO |
| K | Daily Total WD |
| L | SALDO |

## DOC QRIS

| Column | Purpose |
|---|---|
| D | Transaction description |
| E | DEPO transactions |
| F | WD transactions |
| G | DLL / BIAYA |
| H | Kiriman |
| I | Daily Total DEPO |
| J | Daily Total WD |
| K | SALDO |

These mappings are mandatory and must not be modified.

After resolving the selected date:

1. Read only the transaction rows belonging to that date.
2. Read only the columns needed by applicable modules.
3. Read the confirmed daily closing totals.
4. Read the necessary balance carry-forward value.
5. Do not download unrelated months or unrelated source rows.
6. Do not create a complete in-memory copy of the source spreadsheet.

Use narrow values-only requests wherever possible.

Use batchGet for bounded relevant ranges when appropriate to reduce API overhead.

Do not issue excessively large batch requests that reintroduce the memory problem.

---

# 6. PRESERVE EMPTY-DATE HANDLING

Do not modify the existing V3 empty-date financial rules.

Confirmed example:

Website:

VELBETT.

Source tab:

`WD BCA 1 TOKEN / IVAN RAKHMANDA ( PP )`

Selected date:

October 18, 2026.

Expected source results:

- TOTAL DEPO = 0
- TOTAL WD = 0
- SALDO = 2,355,000

An empty transaction date is not an error.

For a valid empty date:

- Deposit is zero.
- Withdrawal is zero.
- Balance is carried from the last valid closing balance.
- No transaction is invented.

However, a missing date boundary or unreadable source is not equivalent to an empty date.

Preserve that distinction.

If the balance needs to be retrieved from an earlier row, use a bounded backward-search strategy.

Do not fetch the entire previous transaction history into memory.

---

# 7. MINIMIZE FORMATTING AND COLOR REQUESTS

Some business rules require actual source formatting information.

In particular:

`KET PENGIRIMAN`

uses eligible brown transfer rows while excluding blue rows according to the existing confirmed rules.

This distinction must remain exactly as implemented and verified in V3.

### Mandatory approach

Do not retrieve formatting metadata for an entire source tab.

Instead:

1. Locate the required date's transaction rows using values-only requests.
2. Identify candidate transfer rows using the existing description and transaction rules.
3. Fetch only the necessary formatting metadata for those candidate rows or narrowly bounded relevant ranges.
4. Apply the existing brown/blue classification.
5. Preserve all existing transfer extraction rules.

Use tightly scoped `spreadsheets.get` requests with explicit ranges and field masks for the required formatting attributes.

Do not request unrelated properties such as complete sheet formatting or notes when not needed.

Do not replace existing color-based rules with description matching alone.

Do not invent new color codes.

Do not alter the existing distinction between eligible and ineligible transfer rows.

---

# 8. REUSE THE SAME SOURCE DATA WITHIN A WEBSITE

The current system contains multiple financial modules that operate on the same source tab and selected date.

Do not repeatedly fetch identical source ranges for every module.

Implement a small, bounded, per-website execution context.

Example:

One DOC DEPO tab is read for the selected date.

Its relevant source values may then be reused for:

- TOTAL DEPO.
- TOTAL WD.
- SALDO BANK.
- BIAYA.
- KET PENGIRIMAN.

Use the same approach for applicable DOC QRIS modules.

### Strict cache boundaries

The temporary context must be scoped to:

- One website.
- One selected date.
- One source spreadsheet revision.
- The relevant source tab.

Avoid global unbounded caches.

Avoid reusing source data from another website or date.

Do not persist full source data unnecessarily.

Do not change the existing per-item retry or write ownership semantics.

If an item requires a fresh source read for correctness, preserve that requirement.

---

# 9. RELEASE MEMORY IMMEDIATELY AFTER USE

After the necessary data has been extracted:

- Discard unneeded raw Google API responses.
- Discard temporary formatting structures.
- Discard temporary transaction arrays.
- Release references to completed source grids.
- Avoid retaining full calculation intermediates.
- Avoid creating duplicate deep copies.
- Avoid logging entire response bodies.
- Avoid serializing huge intermediate structures into SQLite.

Memory usage should remain bounded by the active processing context instead of increasing proportionally with total spreadsheet size.

Do not rely on repeatedly invoking Python garbage collection as the primary optimization.

Fix object lifetime and allocation patterns first.

If garbage collection is used, justify it with profiling.

---

# 10. KEEP ALL FINANCIAL BUSINESS RULES IDENTICAL

This is a zero-business-logic-change release.

## TOTAL DEPO

Preserve existing source calculation and destination placement.

## TOTAL WD

Preserve existing source calculation and destination placement.

## SALDO BANK

Preserve existing saldo extraction, carry-forward, and account mapping.

## BIAYA

Preserve existing signed summation and positive final output rules.

## BIAYA TARIK QRIS

Preserve existing QRIS QRIZZ source and column G calculation rules.

## BIAYA AUTO WD

Preserve existing QRIS E-POWER source and column G calculation rules.

## PENGELUARAN FEE QRIS DEPO

Preserve:

- QRIS QRIZZ source.
- Original `FEE QRIS PERIODE ...` descriptions.
- Correct transaction-date association.
- Multiple descriptions on the same date.
- Existing fee amount calculations.
- Existing destination formatting and placement.

## PENGELUARAN FEE QRIS WD

Preserve:

- QRIS E-POWER source.
- `FEE WD AUTO` matching.
- Existing fee calculation.
- Exactly one displayed `FEE WD AUTO` description per date.

## KET PENGIRIMAN

Preserve:

- Eligible brown rows.
- Exclusion of blue rows.
- DOC DEPO before DOC QRIS.
- Existing bank determination from DOC DEPO tab names.
- QRIS destination bank priority: BCA → MANDIRI → BRI → BNI.
- Existing Notes.
- Existing slot handling.
- Existing TOTAL and formula protection.
- Existing destination account matching.

No financial calculation or output transformation may be modified merely to improve speed.

---

# 11. DESTINATION MAPPING MUST REMAIN UNCHANGED

This section is critical.

The optimization applies primarily to how SOURCE data is retrieved.

It must not change where calculated values are written.

Preserve existing destination logic for:

- Registered website identity.
- Destination website blocks.
- Account/header matching.
- Date matching.
- Module matching.
- Destination sheet names.
- QRIS bank allocation.
- Protected formula cells.
- Existing non-owned entries.
- Existing Notes.
- Existing write ownership records.
- Idempotency.
- Selective retry.

Do not hardcode destination coordinates.

Do not introduce row or column offsets.

Do not insert, delete, or move destination rows or columns.

Do not change existing spreadsheet structure.

Do not write values into neighboring website blocks.

### Critical invariant

For identical source data, destination configuration, and run inputs:

**V4 must produce the same planned cell values, destination coordinates, descriptions, and Notes as the correct V3 business implementation.**

The only allowed differences are:

- Reduced memory usage.
- Reduced source-reading API overhead.
- Improved processing duration.
- More reliable handling of oversized responses.
- Internal technical logging and recovery improvements necessary to prevent repeated OOM crashes.

---

# 12. PRESERVE GOOGLE SHEETS WRITE SAFETY

Do not relax existing protection checks.

Maintain:

- Formula protection.
- Manual entry protection.
- Write ownership.
- Duplicate prevention.
- Read-before-write checks.
- Read-back verification.
- Selective retry.
- Existing conflict handling.

Do not write concurrently into the same destination range without the existing coordination guarantees.

Do not optimize by skipping important safety checks.

If destination reads are also causing excessive memory allocation, optimize their data retrieval using bounded ranges while preserving identical mapping and protection decisions.

---

# 13. PRESERVE RECONCILIATION

The destination tab:

`Laporan deposit harian`

must remain STRICTLY READ-ONLY.

Preserve:

- Website marker identification.
- Individual website BALANCE checks.
- Consolidated BALANCE checks.
- KLOP / TIDAK KLOP.
- Existing error messages.
- Existing final Clear requirements.

No modifications to formulas or values in this report are allowed.

If reconciliation reads are excessively broad, optimize them using targeted ranges while keeping the same recognition and validation logic.

Do not change any reconciliation business rule.

---

# 14. NO WORKER POOL CHANGES IN THIS PATCH

The future architecture may use up to five concurrent website workers.

**Do not implement that architecture in this maintenance release.**

The immediate problem is that a single V3 worker fails due to excessive memory use.

Adding multiple website workers before fixing this issue increases operational risk.

Therefore:

- Preserve current website execution ordering.
- Preserve current job queue semantics.
- Preserve existing concurrency behavior.
- Do not parallelize individual financial modules.
- Do not introduce new process pools.
- Do not introduce five concurrent Python workers.
- Do not introduce multi-process financial writes.

The performance target for this release is to stabilize the existing processing model.

Future website-level parallelism will be handled separately after this release passes real memory testing.

---

# 15. FIX OOM RESTART LOOP SAFETY

The previous V3 worker was repeatedly OOM-killed and restarted unfinished work.

Run #5 may still have persisted unfinished status in SQLite.

Handle this safely.

### Mandatory requirements

1. Do not automatically erase or overwrite existing run data.
2. Do not delete previously verified writes.
3. Do not blindly replay uncertain writes.
4. Do not silently convert a failed run into a successful run.
5. Do not make irreversible database changes without backup.
6. Do not automatically reactivate the previously failed Run #5 during the upgrade.
7. Provide a safe, documented administrative recovery procedure.
8. Ensure repeated worker crashes cannot cause unlimited automatic job replay.
9. Ensure cancellation records remain accurate.
10. Preserve existing Stop/Cancel behavior.

A run interrupted after a potentially completed Google Sheets write must be reconciled against actual destination values before any retry.

If restart handling requires a small backend correction, implement only the minimal change needed for safe and bounded recovery.

Do not redesign the job system.

---

# 16. TECHNICAL LOGGING — VPS ONLY

The administrator explicitly does NOT want performance metrics displayed in the Admin interface.

Record diagnostic information only through backend logs accessible on the VPS.

Use structured, concise logs for:

- Website.
- Run ID.
- Selected date.
- Source tab.
- Processing phase.
- Phase duration.
- Process memory usage.
- Memory high-water mark where available.
- API request duration.
- Retry attempts.
- Error code.

Example:

`[RUN 12] [VELBETT] [SOURCE_READ] duration_ms=1800 rss_mb=145`

These are example values only.

Use actual measured values during execution.

Do not log:

- Google Service Account private keys.
- Tokens.
- Authorization headers.
- Complete transaction data.
- Complete spreadsheet API responses.

Do not add performance charts or metrics to the Admin dashboard.

Preserve existing functional processing statuses.

Use bounded logging and log rotation.

---

# 17. DO NOT DELETE ESSENTIAL HISTORY

The objective is to reduce RAM consumption, not destroy audit records.

After processing:

- Release temporary source data from RAM.
- Release calculation buffers.
- Release temporary API response objects.
- Clean up disposable in-memory caches.

Do not delete:

- Administrator accounts.
- Website configurations.
- Monthly URL history.
- Source activation settings.
- Write ownership records.
- Confirmed write verification data.
- Reconciliation state required for Clear.
- Records required for safe selective retry.
- Existing important financial audit information.

SQLite records stored on disk do not automatically account for the worker's excessive RSS memory.

Do not delete production database records as a substitute for memory optimization.

---

# 18. STRICT RESOURCE MANAGEMENT

The target environment is a 4 GB VPS.

The existing single-worker memory limit is approximately 1.5 GiB.

The optimized crawler should operate comfortably below that limit for representative supported spreadsheet sizes.

Implement:

- Bounded API requests.
- Bounded chunk sizes.
- Controlled temporary allocations.
- Explicit HTTP request timeouts.
- Bounded retries.
- No unrestricted recursion.
- No unbounded in-memory accumulation.
- No full-grid materialization.

Do not implement infinite retries.

If a source exceeds supported resource limits, fail the affected operation with a clear diagnostic error instead of exhausting the worker's memory.

Preserve independent successful results.

Do not silently skip transactions to meet a memory target.

---

# 19. TESTING — BUSINESS OUTPUT REGRESSION

Before and after optimization, compare results using identical fixtures.

The following must match exactly:

- Date boundary selection.
- TOTAL DEPO.
- TOTAL WD.
- SALDO.
- BIAYA.
- BIAYA TARIK QRIS.
- BIAYA AUTO WD.
- FEE QRIS DEPO.
- FEE QRIS WD.
- Transfer descriptions.
- Transfer amounts.
- Transfer target bank.
- Transfer slot selection.
- QRIS Notes.
- Destination cell addresses.
- Reconciliation results.

Compare the existing V3 business outcomes against V4 for representative valid fixtures.

Do not use known V3 implementation bugs as expected financial behavior.

Preserve confirmed business requirements.

### Required regression scenarios

Test:

1. Date with transactions.
2. Date without transactions.
3. Carry-forward balance.
4. Multiple transactions on the same date.
5. Multiple fee entries on the same date.
6. Multiple source tabs.
7. QRIS-specific calculations.
8. Brown transfer rows.
9. Blue transfer rows.
10. QRIS bank slot overflow.
11. Formula conflicts.
12. Missing source dates.
13. Invalid numeric source values.
14. Selective retry.
15. Interrupted or canceled jobs.

---

# 20. TESTING — MEMORY AND PERFORMANCE

Create automated tests using large synthetic Google Sheets API fixtures.

The tests must verify that:

- No unnecessary full-sheet grid is requested.
- No unrestricted `includeGridData=true` response is requested.
- Date discovery uses bounded values-only requests.
- Formatting requests are narrowly scoped.
- Multiple modules reuse relevant data where safe.
- API response sizes remain bounded.
- Memory usage does not scale linearly with total historical cell count for a fixed-size selected-day workload.

Include a realistic large-source test containing:

- Thousands of historical rows.
- Multiple date separator rows.
- Financial values.
- Merged date markers.
- Expense records.
- Transfer records.
- Relevant formatting.

Run the tests under a controlled memory limit representative of the existing worker.

### Performance reporting

Measure:

- Total Google Sheets API calls.
- Source-reading duration.
- Peak process RSS.
- Overall processing duration.
- Largest response size.
- Whether OOM occurred.

Compare V3 and V4 where safe and possible.

Do not run intentionally memory-exhausting V3 tests against production.

A simulated passing test is not proof of successful live Google Sheets integration.

---

# 21. MANDATORY LIVE ACCEPTANCE TARGET

The reference test case is:

Website:

VELBETT.

Date:

October 18, 2026.

Source:

`WD BCA 1 TOKEN / IVAN RAKHMANDA ( PP )`

Expected source results:

- TOTAL DEPO = 0.
- TOTAL WD = 0.
- SALDO = 2,355,000.

The optimized worker must be able to retrieve these values without materializing the complete source grid or crashing.

The entire website contains additional source tabs and modules.

Those must also remain functional.

The live test must first run in PREVIEW mode.

Preview must remain read-only.

Only an explicitly authorized subsequent operation may perform financial writes.

If the development environment cannot access the real Google Sheets documents, report that the live test is pending.

Do not claim live success without evidence.

---

# 22. EXISTING VPS UPGRADE REQUIREMENTS

The application is already deployed.

Existing paths include:

Frontend:

`/var/www/html/`

Application:

`/opt/tutupkas/current/`

Environment:

`/etc/tutupkas/app.env`

Persistent application data:

`/var/lib/tutupkas/`

Existing Google Service Account credentials must remain untouched.

Preserve:

- Nginx.
- HTTPS.
- Administrator accounts.
- Website records.
- Source URL configurations.
- Destination URL configurations.
- Monthly history.
- Active and inactive sheet states.
- Historical processing records.
- Write ownership.
- Existing backup and rollback support.

The worker has been manually stopped after the V3 OOM incident.

Do not automatically resume unfinished V3 financial jobs during the upgrade.

Provide a safe recovery and manual-start procedure after verification.

## Deliverables

Provide:

1. Complete V4 source code.
2. Corrected Google Sheets reading implementation.
3. Backend memory optimization changes.
4. Tests.
5. Performance test report.
6. Complete deployable ZIP.
7. Safe V3 → V4 upgrade script.
8. Rollback instructions.
9. Instructions for verifying worker memory and API health.
10. A clear list of changed source files.

No production credentials or database files may be included in the ZIP.

---

# 23. SCOPE VERIFICATION BEFORE DELIVERY

Before completing the release, inspect the full Git diff.

Confirm that changes are limited to:

- Google Sheets source-reading optimization.
- Necessary backend parsing/data-access efficiency.
- Memory lifecycle management.
- Necessary bounded-retry and OOM recovery safety.
- VPS-only diagnostics.
- Related automated tests.
- Required deployment documentation.

Do not modify unrelated frontend files, CSS, or financial destination mapping code unless an actual resource-related defect specifically requires a behavior-preserving modification.

If any existing business rule or financial output has changed, treat this as a release-blocking regression.

Do not release until corrected.

---

# FINAL ACCEPTANCE CHECKLIST

- [ ] No entire source-tab grid is downloaded for one selected date.
- [ ] Date discovery uses bounded API requests.
- [ ] Source column mappings remain exactly unchanged.
- [ ] Transaction date boundaries remain unchanged.
- [ ] Empty-date calculations remain unchanged.
- [ ] Closing balance behavior remains unchanged.
- [ ] Expense and QRIS fee rules remain unchanged.
- [ ] Transfer color classification remains unchanged.
- [ ] Transfer allocation priority remains unchanged.
- [ ] Notes behavior remains unchanged.
- [ ] Destination matching remains unchanged.
- [ ] No existing formulas are overwritten.
- [ ] No destination rows or columns are moved.
- [ ] Reconciliation behavior remains unchanged.
- [ ] Stop/Cancel behavior remains unchanged.
- [ ] Existing UI and CSS remain unchanged.
- [ ] Existing API contracts remain unchanged.
- [ ] No website-level parallel worker pool is introduced.
- [ ] No unbounded retry or OOM restart loop.
- [ ] Temporary API data is released after use.
- [ ] Essential database history is preserved.
- [ ] Memory metrics remain VPS-only.
- [ ] Representative memory-bounded tests pass.
- [ ] Financial regression tests pass.
- [ ] Existing VPS configuration is preserved.
- [ ] A safe upgradeable V4 ZIP is delivered.

## FINAL DIRECTIVE

This is NOT a new feature-development project.

This is NOT a UI redesign.

This is NOT a financial business-logic revision.

This is a STRICT, BEHAVIOR-PRESERVING, BACKEND PERFORMANCE AND MEMORY CORRECTION.

The existing financial application must behave exactly as before, except that Google Sheets data retrieval and memory management become significantly more efficient and reliable.

The intended improvement is:

**Same inputs → Same financial results → Same destination cells → Same protections → Much lower memory usage → Faster execution → No repeated OOM crash loop.**

Produce a complete V4 ZIP and an honest technical report.

Do not claim OOM is definitively eliminated without bounded-memory tests and relevant real-world verification.

# END OF V4 STRICT OPTIMIZATION REQUEST