# Aturan dan batas engine Tutup Kas All Web

## Sumber

Sumber aktif diambil dari snapshot konfigurasi saat admin mengantrekan run. Website database adalah identitas utama. Tanggal, sumber, revisi, periode, dan tujuan disimpan di run; retry tidak mengganti dokumen dengan URL bulan terbaru. Tab baru/berganti nama selalu nonaktif. Tab yang hilang tidak ikut run baru.

Pemisah harian harus berupa sel tanggal dengan latar gelap atau merged horizontal sekurangnya tiga kolom. Parser mendukung tanggal berformat serial Sheets, tanggal ISO, serta bulan Inggris/Indonesia. Hidden/grouped rows tetap masuk data API. Kedua pemisah harus unik dan berurutan: tanggal terpilih dan hari berikutnya. Penutupan persis `baris_pemisah_berikutnya - 1`, tanpa mencari baris transaksi lain untuk hari biasa. Batas akhir yang belum memiliki pemisah berikutnya menghasilkan kesalahan.

Untuk bagian tanpa transaksi, DEPO/WD nol, saldo diambil dari saldo valid terakhir melalui baris penutupan/pemisah sebelumnya. Error formula atau nominal rusak tidak diperlakukan sebagai hari nol. Kolom SUMBER memakai tata letak tetap yang dikonfirmasi: DEPO J (deposit), K (WD), L (saldo); QRIS I (deposit), J (WD), K (saldo). Header yang kosong/ganda tidak menggeser posisi tersebut. Deskripsi tetap D. Nominal harus rupiah integer aman; teks ambigu dan error formula ditolak.

## Tujuh modul

| Tujuan | Aturan |
|---|---|
| TOTAL DEPO | Closing J pada DEPO atau I pada QRIS |
| TOTAL WD | Closing K pada DEPO atau J pada QRIS |
| SALDO BANK | Closing L pada DEPO atau K pada QRIS, carry-forward untuk hari kosong |
| BIAYA | ABS setelah menjumlahkan seluruh nilai H bertanda dari DOC DEPO aktif; input disimpan per tab |
| BIAYA TARIK QRIS | ABS(sum G harian) pada QRIS QRIZZ, tanpa pencarian header sumber |
| BIAYA AUTO WD | ABS(sum G harian) pada QRIS E-POWER; terpisah dari fee H |
| Pengeluaran FEE QRIS DEPO | H hanya untuk deskripsi D berawalan FEE QRIS PERIODE; teks asli/newline dipertahankan |
| Pengeluaran FEE QRIS WD | H hanya untuk FEE WD AUTO; deskripsi tujuan sekali |
| KET PENGIRIMAN | Warna D disetujui **dan** deskripsi transfer dikenali; DEPO lebih dahulu, lalu QRIS |

Aturan biaya/fee/kiriman tetap sesuai konfirmasi admin. Biaya DEPO dibaca langsung dari H, biaya QRIS dari G, kiriman DEPO dari I, fee/kiriman QRIS dari H. Tidak ada validasi header sumber sebagai prasyarat. Pemetaan tujuan tetap memakai header/rekening dinamis. Bandingkan sumber/tujuan salinan kerja asli sebelum menganggap live integration terverifikasi.

## Pemetaan aman

Sheet reguler memakai dua baris header, tanggal mulai baris 3, dan label WEB terdaftar sebagai anchor kolom tanggal. Website berikutnya membatasi kolom pencarian. Account matching memprioritaskan kecocokan normalisasi persis, nama kanan slash tanpa `( PP )`, atau pasangan QRIS/subheader. Tidak ada fuzzy matching. Gunakan alias nama sumber → header rekening dari Admin jika diperlukan. Lebih dari satu kandidat adalah error.

KET PENGIRIMAN mempunyai resolver berbeda. Ada dua struktur yang didukung:

1. Anchor tanggal lengkap merged melintasi kelompok bank, kemudian label WEB, header bank BCA/MANDIRI/BRI/BNI dua kolom, baris slot, dan batas TOTAL.
2. Header bulanan berupa nomor hari pada kolom TOTAL samping, sebagaimana screenshot. Pasangan hari sebelumnya/hari terpilih membatasi bagian horizontal. Header WEB merged harus mencakup empat bank di antara batas tersebut, dan kolom hari terpilih harus mempunyai label TOTAL dalam blok WEB yang sama. Hari pertama dibuktikan sebagai anchor pertama. Baris header nomor hari harus berurutan dan unik. Periode mengikuti tujuan bulanan yang dikonfigurasi. Posisi kolom/baris tidak di-hardcode, termasuk spacer dan kolom yang disembunyikan.

Satu tanggal harus memiliki bagian yang unik. Sumber DEPO mengikuti bank pada nama tab; QRIS mengisi slot tersedia BCA → MANDIRI → BRI → BNI. Angka bertanda dipertahankan. Sel dengan angka nol, formula kosong, atau Note tidak dihitung kosong. Sel merged dekoratif di bawah header bank juga dilindungi, sehingga tidak menjadi slot transaksi. Slot penuh tidak membuat baris baru.

**Struktur nomor hari/TOTAL samping telah diuji menggunakan grid yang mengikuti bentuk screenshot, bukan melalui akses workbook asli.** Jika struktur API workbook berbeda dari kedua kontrak di atas, modul kiriman akan gagal dengan pesan batas tanggal ambigu; modul independen tetap diproses. Periksa grid/merge asli pada salinan kerja sebelum memperluas resolver, tanpa memasukkan kolom tebakan atau mengubah data produksi.

Warna transfer tidak ditebak dari screenshot. Palet disetujui setelah melihat RGB aktual; warna biru yang disetujui dikecualikan. Warna lain pada deskripsi transfer menghasilkan masalah tinjauan. Deskripsi dikenali: KIRIM KE, PENGIRIMAN DARI, DARI KAS, DARI NL KAS. Penambahan frasa bisnis lain membutuhkan verifikasi terlebih dahulu.

## Tulis, retry, dan kepemilikan

Rencana semua item dibuat sebelum tulis, untuk menemukan tabrakan mapping. Tulis memakai batchUpdate updateCells dengan field mask `userEnteredValue,note`; tidak menyentuh format. Numeric ditulis numberValue, deskripsi stringValue (termasuk teks berawalan `=` tidak berubah menjadi formula). Formula dan Note seluruh tab dibaca; formula dibandingkan sebelum/sesudah operasi. QRIS mendapat cell Note nyata pada keterangan.

Ledger `PREPARED` disimpan sebelum API. Read-back memverifikasi nilai, deskripsi, dan Note; baru menjadi `VERIFIED`. Jika koneksi terputus setelah API menulis, retry mengenali nilai sebelum atau sesudah intent yang tercatat. Tidak ada append. Output asing/manual tidak diambil alih hanya karena nilainya sama dengan hasil robot.

Satu item mencakup satu tab/modul. Expense input disimpan bertanda; aggregate BIAYA menunggu semua dependensi berhasil dan menghitung ulang dari kontribusi tersimpan. Retry per dokumen/item hanya menandai item gagal atau dibatalkan yang belum selesai menjadi pending; output SUCCESS/PREVIEWED dipertahankan. Hasil sukses tidak dibaca ulang dari sumber. Palet baru yang disetujui dapat memperbaiki item gagal dengan retry eksplisit. Alias mengubah konteks pemetaan dan memerlukan run baru; perubahan dicatat dalam audit.

Identitas kiriman mencakup sumber, tanggal, revisi, baris fisik, deskripsi, dan nominal. Kiriman sama menggunakan slot lama. Jika kiriman lama berubah/hilang/pindah baris, engine tidak dapat membuktikan identitas transaksi tanpa ID stabil; ia melaporkan konflik rekonsiliasi. Koreksi otomatis untuk kasus tersebut **belum didukung**. Jangan menghapus ledger agar konflik tampak hilang. Perlu tinjauan data dan rekonsiliasi yang disetujui.

Pemeriksaan lokal dan API Google tidak membentuk transaksi atomik lintas database dan spreadsheet. Intent ledger mengatasi crash/retry, tetapi tidak mengunci editor Google secara bersamaan. Hindari edit manual saat run berjalan. Worker tunggal membatasi concurrency; retry API hanya untuk timeout/429/5xx dengan backoff dan batas percobaan.

## Batas sumber daya

Satu tab sumber ditahan di memori pada satu waktu; tujuh tab tujuan di-cache untuk mapping. API mengambil grid tab yang relevan, bukan seluruh dokumen atau sumber nonaktif. Batas default adalah 2 juta sel grid per tab (termasuk area preformatted), dikonfigurasi melalui `TK_MAX_SHEET_CELLS`. Kebutuhan memori tetap bergantung format workbook. VPS 2 GB memakai satu API worker dan satu job worker dengan batas systemd 400/700 MB. Tab sangat besar perlu pengurangan area kosong atau pembaca streaming di pengembangan berikutnya; error ukuran tidak dianggap hasil nol.


## Rekonsiliasi v2

Setelah seluruh item yang berlaku untuk WEB berhasil ditulis dan dibaca kembali, `reconciliation.py` hanya membaca `Laporan deposit harian` melalui resolver teks/header/tanggal. Hasil `SUCCESS` tidak diubah menjadi gagal hanya karena BALANCE nonnol: status finansial `NOT_BALANCED` disimpan terpisah bersama error, sel dan selisih aktual. Error formula/mapping tidak dianggap nol. Dua pengamatan nol berturut-turut diperlukan dalam batas pembacaan baru (default tiga). Tidak ada toleransi atau pembulatan.

Konsolidasi diidentifikasi dari satu tabel unik dengan header Tanggal, DEPOSIT, WITHDRAW, HASIL, ADMIN BCA/MANDIRI/BRI/BNI, TOTAL SALDO BANK, BALANCE, STATUS, KETERANGAN, di luar blok WEB. Ia baru diperiksa setelah semua WEB aktif selesai memproses. STATUS, KETERANGAN, formula, Note dan format laporan tidak ditulis. Recheck hanya membaca laporan, tanpa replay keluaran.

Selesai & Clear adalah status aplikasi untuk seluruh WEB aktif pada tanggal/konteks revisi yang sama. Seluruh tulisan harus terverifikasi, tidak ada kesalahan yang relevan, semua BALANCE WEB dan konsolidasi tepat nol. Perubahan URL/revisi/tab/alias tidak memindahkan keberhasilan atau ownership lama secara diam-diam. Sinkronisasi sumber eksplisit dapat mengadopsi transaksi yang identitas baris/deskripsi/nominalnya tetap sama dan slot lama belum diubah; transaksi yang berubah tetap memerlukan tinjauan, tanpa membuat duplikat.

## Pembatalan dan sumber V3

Aktivitas harian ditentukan dari payload B/C/D, E/F serta kolom biaya/kiriman tetap. Kolom kumulatif, SALDO, CEK SALDO, dekorasi, formula berisi string kosong dan nol template bukan bukti transaksi. Pemisah tanggal terpilih dan berikutnya tetap wajib unik/berurutan. Pada hari kosong, sel total yang blank boleh menghasilkan nol; formula error tetap ditolak dan saldo tidak boleh ditebak dari M/BALANCE DEPO.

Sumber diparsing sekali per tab/tanggal/konteks run, dipakai seluruh metrik tab itu. Kesalahan pembacaan/struktur yang sudah diketahui juga di-cache untuk konteks tersebut sehingga tidak memicu fetch ulang per metrik. Cache baru dibuat pada retry eksplisit. Instrumentasi fixture menunjukkan 3 source-grid fetch untuk 17 item sumber; V2 sudah mempunyai cache tab, sehingga angka ini bukan klaim percepatan live V3 terhadap V2. Read-back tujuan tetap dilakukan.

QUEUED dapat langsung menjadi CANCELED. RUNNING mendapat CANCEL_REQUESTED, tetap mengunci konflik sampai worker memfinalkan CANCELED. Worker memeriksa permintaan melalui pembacaan DB terpisah pada batas operasi/item, termasuk di antara retry GET. Setelah POST tulis dikirim, callback pembatalan dibisukan hanya selama write/read-back terikat item itu; verifikasi diupayakan dahulu. PREPARED yang belum pasti tetap dicatat. Hasil terverifikasi tidak dihapus. Canceled job tidak dianggap KLOP/Clear dan tidak di-resume otomatis setelah restart.

Recheck saldo yang dibatalkan tidak memainkan ulang tulisan dan tidak memakai konsolidasi hijau lama untuk Clear. Unexpected worker error difinalkan menjadi FAILED/PARTIAL dengan error tercatat; antrean berikutnya tetap dapat diproses. Log JSON mencakup run, WEB, sumber, tanggal, modul, fase, kode error dan elapsed_ms tanpa nominal/kredensial rahasia.
