# TUTUP KAS LION GROUP — V4.2
# SOURCE SNAPSHOT, ABSOLUTE DESTINATION MAPPING, SELECTIVE RETRY, CONFLICT RESOLUTION & PERFORMANCE
# STRICT EXISTING-BUSINESS-RULE PRESERVATION

## 0. MANDATORY INSTRUCTIONS

You are a senior Python backend engineer, Google Sheets API specialist, SQLite reliability engineer, and financial reconciliation systems engineer.

Work from the EXISTING Tutup Kas Lion Group V4.1 source code.

This release is V4.2.

The administrator has already approved the business requirements. You are NOT authorized to redesign or reinterpret them.

Your assignment is to improve performance and reliability while preserving every existing confirmed financial rule and destination placement.

### Non-negotiable principle

**Same source transactions, same date, same website, same authorized destination configuration must produce the same financial results, descriptions, notes, protected cells and absolute destination coordinates.**

Any proposed optimization that violates this invariant must not be implemented.

### Production environment

- Ubuntu VPS.
- 4 GB RAM.
- 2 vCPU.
- FastAPI backend.
- SQLite database.
- Google Sheets integration.
- Existing React/TypeScript Admin.
- systemd worker service.
- Worker memory limit approximately 1536 MiB.
- Existing V4.1 deployment and historical SQLite data.

Do not increase RAM limits, disable OOM protection, delete existing data or introduce unrelated functionality.

---

# 1. AUDIT THE REAL V4.1 CODE FIRST

Before editing, inspect these existing files and their callers:

- `backend/app/source_reader.py`
- `backend/app/destination_reader.py`
- `backend/app/sheets.py`
- `backend/app/engine/runner.py`
- `backend/app/engine/parser.py`
- `backend/app/engine/resolver.py`
- `backend/app/engine/writer.py`
- `backend/app/job_control.py`
- `backend/app/worker.py`
- `backend/app/operations.py`
- `backend/app/api.py`
- `backend/app/models.py`
- `backend/app/reconciliation.py`
- `backend/app/workflow.py`
- `backend/app/batches.py`

Inspect all existing database migrations and relevant frontend run-detail components.

### Known implementation problems to investigate

1. Source-date discovery scans historical source ranges using many separate API requests.
2. Destination structure discovery can require extensive horizontal and vertical scanning.
3. `google_min_interval` is currently configured at 1.2 seconds.
4. `runner.py` contains `source_cache` and `destination_cache`, but these are not the complete durable, bounded source snapshot and approved destination registry required by V4.2.
5. `runner.py` clears the source cache when changing source tabs.
6. `writer.py` uses source tab names in `owner_key()`.
7. Existing retry handling in `operations.py` sets an entire Run to `QUEUED`.
8. The current worker selects queued Runs rather than consuming targeted retry items independently within an active Run.
9. The FEE QRIS resolver can fail to recognize existing `KETERANGAN` headers in valid destination layouts.
10. The current `qris_fee` branch attempts destination resolution even when its source fee result is empty.

These are investigation starting points, not permission to rewrite modules without verifying their actual behavior.

Provide a baseline report before implementation.

---

# 2. ARCHITECTURE — ONE COORDINATOR, THREE LOGICAL STAGES

Implement three logical processing stages under ONE controlled website coordinator.

Do NOT immediately create three independent Python processes.

Do NOT introduce the future five-website worker pool in this release.

### Stage A — Source Scanner

Responsibilities:

- Read current configured DOC DEPO and DOC QRIS documents.
- Read all currently active, available source tabs.
- Identify exact date boundaries.
- Fetch source transaction ranges efficiently.
- Fetch only required color/format metadata.
- Produce a complete validated source snapshot for the relevant tab and date.

No destination financial writes.

### Stage B — Financial Mapper

Responsibilities:

- Consume complete, validated source snapshots.
- Calculate all applicable financial modules using unchanged rules.
- Produce structured financial results and source provenance.
- Identify the destination module, account/category and transaction intent.
- Store only necessary bounded information in SQLite.

No Google Sheets financial writes.

### Stage C — Destination Validator & Writer

Responsibilities:

- Resolve approved absolute coordinates from the persistent destination mapping registry.
- Validate current destination cells and critical structure.
- Detect existing values and conflicts.
- Apply explicitly authorized writes.
- Perform read-back verification.
- Preserve idempotency and financial audit records.

Only this stage may perform actual financial destination writes.

### Pipeline behavior

Independent completed snapshots may advance to mapping while the scanner reads another tab.

The coordinator must respect dependencies, including:

- BIAYA aggregation.
- DOC DEPO before DOC QRIS for transfer allocation.
- Shared destination cells.
- KET PENGIRIMAN slot ownership.
- Reconciliation prerequisites.

Never allow the mapper to consume a partially read snapshot.

Never let the writer consume an incomplete or invalid mapping result.

The architecture must support cancellation, retries, worker interruption and controlled recovery.

---

# 3. SOURCE READING — ONE DATE RANGE, ALL RELEVANT METRICS

The administrator does NOT want a separate source read for every financial module.

For each active source tab and selected date:

1. Identify the verified date start marker.
2. Identify the verified following-date closing boundary.
3. Fetch the complete relevant transaction interval using appropriately bounded requests.
4. Parse the returned values once.
5. Calculate all applicable metrics from the same snapshot.
6. Fetch eligible transfer-row color metadata separately and narrowly.
7. Release large temporary API responses after extraction.

Do not read the entire historical spreadsheet grid.

Do not retrieve full-sheet formatting, notes or grid metadata.

### Batch API usage

Use Google's actual supported API methods, including `spreadsheets.values.batchGet`, where batching safely reduces requests.

Group relevant ranges within the SAME spreadsheet into bounded requests.

Do not assume one `batchGet` request can directly combine arbitrary ranges from multiple different spreadsheet files.

Use field masks for necessary formatting/metadata.

Keep response-size limits and memory protections.

Do not create unbounded API batches.

### Most important requirement

**One source date snapshot must serve all applicable module calculations for the same source tab and date.**

Do not reconstruct the same source range individually for TOTAL DEPO, TOTAL WD, SALDO BANK, BIAYA and KET PENGIRIMAN.

---

# 4. SOURCE DATE INDEX — CONTINUE FROM THE LAST VERIFIED BOUNDARY

Implement a persistent, bounded `SourceDateIndex`.

Index entries must be scoped to:

- Source spreadsheet identity.
- Source document revision.
- Internal tab identity.
- Current registered tab name.
- Selected date.
- Verified separator row.
- Verified next-date separator row, when known.
- Necessary verification metadata.

Internal Google `sheetId` may be used to establish tab identity, but MUST NOT become an administrator-entered mapping key.

### Example

Suppose:

- October 18 transactions end at row 202.
- The separator for October 19 is at row 203.
- October 19 transactions begin after that separator, at row 204.

For the next date:

- Start by verifying the known October 19 separator at row 203.
- Begin reading transactions after that verified separator.
- Search forward for the next valid separator.
- Do not scan historical rows 1–202 again unnecessarily.

Do not blindly treat row 204 as the next date marker.

Distinguish separator rows from transaction rows.

### Support other scenarios

- Previous dates selected out of sequence.
- Missing dates.
- Duplicate separators.
- Invalid date formatting.
- Changed source URLs.
- Renamed source tabs.
- Deleted tabs.
- Recreated tabs with identical names.
- Inserted or deleted rows.
- Appended rows for the currently open date.
- Explicit retry for a previous date.

### Safety

The source index is a navigation aid, not an unquestionable financial truth.

Validate relevant boundaries before using them.

If identity or positions are inconsistent, fail with a specific error or safely rebuild the affected index.

Do not guess dates.

Do not use stale rows silently.

---

# 5. SOURCE TAB CHANGES MUST NOT CHANGE KAS KECIL MAPPING

This requirement is absolute.

Source tabs are DYNAMIC.

Destination financial mapping is NOT keyed by source tab names.

### New source tab

When a new tab is discovered:

- It appears through the existing Admin source-tab refresh mechanism.
- It remains inactive by default unless explicitly activated.
- Its date index is created when needed.
- It does not trigger a complete Kas Kecil remapping.

If its result cannot match an approved destination account, report an account-mapping error.

Never invent a new destination column.

### Renamed tab

If a tab is renamed:

- Use refreshed source configuration.
- Verify whether it is demonstrably the same underlying tab.
- Preserve source transaction identity when continuity can be proven.
- Revalidate or update only affected source indexing and source-account interpretation.
- Do not alter the monthly Kas Kecil website/date mapping.

Do not guess that differently named tabs are identical.

### Deleted then recreated tab

If a tab is deleted and a different tab is created with the same name:

- Detect the identity mismatch when evidence permits.
- Fail safely.
- Require source revalidation or explicit administrative recovery.
- Do not assume it is the original tab.

Do not silently transfer historical write ownership to the recreated tab.

---

# 6. ABSOLUTE KAS KECIL MAPPING — BUILT WHEN MONTHLY URL IS SAVED

This is a core V4.2 requirement.

When the administrator saves a NEW monthly Kas Kecil / Kas Semua Web URL:

1. Validate the actual destination spreadsheet identity.
2. Discover the real destination tabs required by all existing modules.
3. Discover the complete horizontal website layout.
4. Identify registered website blocks and valid structural boundaries.
5. Discover dates and account/category columns within each block.
6. Identify relevant header cells, merged regions and protected structural elements.
7. Map all valid KET PENGIRIMAN slots.
8. Validate uniqueness and ambiguity.
9. Persist an ABSOLUTE mapping registry in SQLite.
10. Mark the registry `READY` only after required validation succeeds.

The mapping process may run asynchronously through a bounded background job; do not falsely report it completed before verification.

### Mapping identity

The primary context is:

`Destination Spreadsheet + Monthly Period + Website + Date`

Within that context, resolve:

`Financial Module + Destination Account / Category / Authorized Slot → Absolute Google Sheets Coordinates`

### Extremely important

**The destination registry must NOT be keyed by DOC DEPO or DOC QRIS source tab names.**

Source tabs may change independently.

Source-account identification and approved aliases may still be used to select the correct destination account, but source tab names must not dictate the website/date block position.

### Coordinate requirements

Store original absolute:

- Destination spreadsheet ID.
- Destination revision.
- Destination tab.
- Row index.
- Column index.
- A1 address.
- Website boundary.
- Date identity.
- Module identity.
- Relevant account/category.
- Structural verification evidence.

Do not translate absolute columns into local slice offsets.

If a target is at column 420, it must remain column 420.

If a date is at row 75, it must remain row 75.

### Reuse

For subsequent Preview, Crawl and selective Retry:

**Read the approved destination mapping registry directly.**

Do NOT repeat full destination-sheet scanning for every Run or item.

Only perform narrowly targeted freshness and write-safety checks.

---

# 7. MONTHLY DESTINATION URL MUST REMAIN EDITABLE

The administrator must always be able to edit a monthly Kas Kecil URL.

Preserve the existing monthly URL editing workflow.

When the URL changes:

1. Preserve historical destination revisions.
2. Preserve existing write ledgers and audit records.
3. Invalidate the former active mapping for the newly configured destination.
4. Build a new mapping for the new URL.
5. Validate it.
6. Only allow writes after a new mapping is `READY`.

A Run must remain pinned to the destination identity and mapping revision captured when it was authorized.

If the URL changes while a Run is active, do NOT silently redirect its writes into the new document.

Fail safely or hold affected writes according to existing cancellation and revision rules.

### Administrator-controlled restructuring

The administrator states that monthly destination layouts are normally stable.

Do not automatically move approved coordinates.

If a human restructures Kas Kecil, they can re-enter/revalidate the monthly URL and generate a new approved mapping version.

Automatic silent remapping during a financial write is forbidden.

The write stage must still inspect critical target cells, formulas, notes and structural anchors before modifying them.

A locked mapping is NOT permission to overwrite anything at those coordinates.

---

# 8. EXACT FINANCIAL SOURCE COLUMNS — DO NOT CHANGE

## DOC DEPO

- D — Description
- E — DEPO
- F — WD
- H — DLL / expense
- I — KIRIMAN
- J — cumulative TOTAL DEPO
- K — cumulative TOTAL WD
- L — SALDO

## DOC QRIS

- D — Description
- E — DEPO
- F — WD
- G — DLL / expense
- H — KIRIMAN
- I — cumulative TOTAL DEPO
- J — cumulative TOTAL WD
- K — SALDO

Do not change these coordinates.

Do not infer new structures.

Do not alter the existing following-date separator rule.

### Empty-date behavior

A genuinely valid date without transactions can produce:

- DEPO = 0.
- WD = 0.
- Previous closing SALDO carried forward.

Known regression example:

VELBETT — October 18, 2026

`WD BCA 1 TOKEN / IVAN RAKHMANDA ( PP )`

Expected:

- TOTAL DEPO: 0
- TOTAL WD: 0
- SALDO: 2,355,000

This applies to that specific source tab, not the entire website.

An unreadable source or missing date separator is NOT an empty date.

---

# 9. SELECTIVE RETRY — ONLY THE FAILED ITEM

This requirement is explicit.

When an individual Run has 43 items and one item fails:

**Only that failed item may be retried.**

Do NOT:

- Rescan every source tab.
- Rebuild the entire website source snapshot.
- Reprocess successfully completed items.
- Recalculate unrelated metrics.
- Rebuild monthly Kas Kecil mapping.
- Repeat verified writes.
- Reset all 43 items to pending.
- Restart the entire Run unnecessarily.

### Mandatory retry flow

1. Administrator fixes the source or configuration issue.
2. Administrator clicks Retry for a SPECIFIC failed item.
3. The requested retry is durably queued.
4. The source scanner reads NEW RAW Google Sheets data required ONLY for that item.
5. A fresh, item-scoped source snapshot is created.
6. The relevant financial calculation is repeated.
7. The existing approved destination map is reused.
8. The current target cell or transfer slots are checked.
9. The item completes or presents an actionable conflict.
10. All other successful items remain untouched.

### Important distinction

The phrase "only failed item" refers to the logical unit of work.

If that item's correct calculation requires several rows within its date, read the necessary full range.

If an expense aggregate depends on a failed input, track that dependency explicitly.

Do not change already successful dependent items without authorization.

Report potential stale dependencies separately rather than silently recalculating the whole website.

### Retry snapshot rules

- Retry MUST NOT reuse an old source snapshot as the financial source of truth.
- Retry MUST fetch current raw data for its selected item.
- Retry may reuse an approved destination mapping registry.
- Retry may use a verified date-index anchor for navigation.
- Retry must revalidate source boundaries and relevant source content.
- Retry must NOT replace other item snapshots.

---

# 10. RETRY MUST WORK WHILE THE MAIN RUN IS STILL ACTIVE

The current V4.1 retry flow requires correction.

The administrator must be able to enqueue a failed-item retry while the worker is still processing other items for that website.

### Required behavior

Example:

- 30 items completed.
- 2 items failed.
- 1 item currently processing.
- 10 items pending.

The administrator selects ONE failed item and clicks Retry.

The retry must enter a priority queue immediately.

It must be picked up at the next safe scheduling point.

Do not wait for all remaining 10 items to finish merely to retry the selected failed item.

### Concurrency safety

- Do not interrupt an active Google Sheets write halfway.
- Do not process the same item twice concurrently.
- Do not spawn an uncontrolled second financial writer.
- Do not create a second independent Run that can duplicate writes.
- Do not change an active `RUNNING` Run to `QUEUED` merely to handle an internal retry.
- Use atomic claims, durable retry records or equivalent safe scheduling.
- Protect against double-clicked Retry requests.
- Respect website/date active-run uniqueness.
- Prioritize retries without starving all other work.

The single coordinator should service selected retries at safe boundaries.

Handle retries queued just before the original Run completes without losing them.

Existing cancellation semantics must remain valid.

---

# 11. IDEMPOTENT RECOVERY — NO DUPLICATE WRITES

The source tab name is currently involved in existing write identity.

This creates a rename risk.

Inspect and carefully revise:

`engine/writer.py → owner_key()`

Also inspect transfer transaction fingerprints and historical ownership relationships.

### Requirements

- Preserve historical ledger records.
- Preserve existing verified ownership.
- Allow confirmed source tab renames to retain stable transaction lineage.
- Never treat a recreated tab as the old tab without proof.
- Never append a duplicate because a source tab was renamed.
- Never silently transfer ownership between unrelated sources.

### Crash after Google accepts a write

If Google Sheets successfully applies a write but the API response times out:

1. Do not blindly repeat the write.
2. Inspect the actual destination.
3. Reconcile with prepared intents and ledger state.
4. Determine whether the exact intended write already happened.
5. Complete verification if safe.
6. Otherwise create a specific unresolved conflict.

Ensure a restart or explicit retry does not duplicate KET PENGIRIMAN descriptions, amounts or Notes.

Use database transactions and uniqueness constraints appropriate to the existing architecture.

---

# 12. EXISTING DESTINATION DATA — ADMIN DECISION REQUIRED

This is a NEW approved functional requirement.

If the robot wants to put new financial data into a destination cell or logical group that already contains old data requiring replacement or ownership resolution, it must NOT silently overwrite the old data.

Instead, create an actionable conflict.

### Conflict UI

Show the administrator:

- Website.
- Selected date.
- Module.
- Account/category.
- Destination spreadsheet.
- Destination tab.
- Exact A1 cell address or grouped cell addresses.
- Current real Google Sheets value.
- New proposed source value.
- Existing description and Note where relevant.
- Proposed description and Note.
- Reason the values conflict.
- Source document/tab/cell provenance where available.

Do not show guessed or cached values as if they were the current destination values.

### Required actions

**Action 1: Masukkan Data Baru**

Administrator authorizes replacement with the newly calculated source result.

Before applying it:

- Re-read the affected destination cells.
- Confirm they still contain the values shown to the administrator.
- Reconfirm the approved mapping revision.
- Enforce formula and protected-cell rules.
- Enforce Notes and ownership protections.
- Apply only the explicitly approved logical write group.
- Verify the result.
- Record an immutable decision/audit entry.

If the destination changed after the conflict was displayed, reject the stale approval and refresh the conflict.

If a protected formula would be overwritten, refuse the write. Do not interpret administrator approval as universal permission to destroy formulas.

**Action 2: Tetapkan Data Lama**

Administrator explicitly chooses to retain the current destination values.

- Do not modify Google Sheets.
- Record the decision and the observed current destination values.
- Mark the specific conflict resolved.
- Remove it from the active-error list after the decision is committed and relevant state is verified.
- Do not automatically rewrite the item later.

### Important finalization rule

For "Masukkan Data Baru", clear the active conflict only AFTER the authorized write has been verified.

For "Tetapkan Data Lama", clear the active conflict after the keep-old decision is durably recorded and the current destination state is confirmed.

The original error remains in the audit history.

Both choices close the actionable conflict.

However:

**Resolving a conflict does NOT automatically make financial reconciliation KLOP.**

If the administrator retains a value that differs from the latest source calculation, preserve that decision but report any remaining financial discrepancy correctly.

Do not force BALANCE to zero.

### Same-value handling

If the existing destination already contains the exact intended verified result and ownership is unambiguous, treat it as an idempotent verified write rather than inventing a replacement conflict.

If ownership or provenance is uncertain, do not assume the identical visible number proves safe ownership.

---

# 13. CONFLICT HANDLING FOR MULTI-CELL OPERATIONS

Some modules write more than one cell.

Examples:

- FEE description and amount.
- KET PENGIRIMAN description and amount.
- QRIS transfer Notes.

These must be handled as one logical conflict group.

An administrator must see all relevant existing and proposed values together.

Do not allow a partial authorized replacement to leave a mismatched description and amount.

If the group cannot be applied safely, keep the entire conflict unresolved.

On Google timeout, verify all cells in the group before retrying.

---

# 14. FEE QRIS — CORRECT THE REAL RESOLVER DEFECT

Known production errors:

- QRIS E-POWER — FEE QRIS WD.
- QRIS QRIZZ — FEE QRIS DEPO.

Error:

`Kolom KETERANGAN tidak ditemukan secara unik di blok VELBETT.`

The administrator has visually verified that the relevant destination website block and FEE headers exist.

Inspect:

`engine/resolver.py → labeled() / fees()`

And the V4.1 destination reader's inherited and merged-header semantics.

### Scope

The correction must focus on:

- `Pengeluaran FEE QRIS DEPO`
- `Pengeluaran FEE QRIS WD`

Do not broadly change unrelated destination tab resolvers.

The current VELBETT screenshots show `KETERANGAN` and FEE columns in the intended section, but their displayed coordinates are regression references only.

**Never hardcode B21, C21 or VELBETT-specific addresses into production logic.**

### Requirements

- Recognize legitimate merged headers correctly.
- Restrict matching to the correct website block.
- Do not cross into a neighboring website.
- Do not count multiple inherited cells of one merged header as independent duplicates.
- Still reject genuinely ambiguous headers.
- Preserve actual fee descriptions and amounts.
- Preserve correct destination header and column matching.

### FEE QRIS DEPO

Source:

`QRIS QRIZZ`

Match source descriptions beginning:

`FEE QRIS PERIODE ...`

Preserve the original descriptions.

If several entries exist for the same date, preserve their individual descriptions and correct summed amount.

Do not split, prorate or invent fee values.

### FEE QRIS WD

Source:

`QRIS E-POWER`

Match:

`FEE WD AUTO`

Preserve the existing summation behavior.

Display the description only once when appropriate.

### No-fee behavior

If the source was successfully read and there are no matching fee transactions for the selected date:

- Treat the source result as a valid no-transaction outcome.
- Do not create a fake fee.
- Do not write 0 just to fill the destination.
- Do not write an empty description just to fill the destination.
- Do not delete unrelated destination cells.
- Do not fail merely because a fee-write header is unnecessary for a true no-op.

However, if the destination already contains an old fee for that logical item, do NOT silently consider it equivalent to a blank current source.

Present an explicit conflict showing:

- Old destination fee.
- New source result: no fee.
- Available administrator decisions.

A confirmed "Masukkan Data Baru" may clear previously robot-owned fee cells only when the authorized correction is safe, ownership is proven, formula protection is intact and the deletion is explicitly presented to the administrator.

A confirmed "Tetapkan Data Lama" leaves the old values unchanged.

Unreadable sources must never be treated as no-fee days.

---

# 15. KET PENGIRIMAN — ABSOLUTE SLOTS, DYNAMIC SAFE ALLOCATION

The administrator has approved this interpretation.

The monthly destination registry must map the ABSOLUTE positions of all valid KET PENGIRIMAN slots.

But the actual selected slot for a particular transaction must be determined according to availability, ownership and the existing business rules.

### Preserve

- Brown eligible source rows.
- Blue excluded source rows.
- Existing approved source color palette.
- DOC DEPO processed before DOC QRIS.
- DOC DEPO source bank identification.
- QRIS bank allocation priority: BCA → MANDIRI → BRI → BNI.
- Existing bank layout structures.
- Original descriptions.
- Amounts.
- QRIS Notes.
- Merged-cell protections.
- TOTAL-row protection.
- Slot occupancy checks.
- Transfer ownership.
- Duplicate prevention.
- Existing overflow behavior.

Do not reserve transaction slots permanently at URL mapping time.

Map the available slot coordinates once.

Choose the safe slot when a particular transaction is being written.

Retry must reconcile against prior transaction ownership before allocating any new slot.

If an old or uncertain transfer conflicts with a new source result, present an actionable conflict instead of appending another transaction.

---

# 16. SOURCE SNAPSHOT STORAGE

SQLite may store bounded per-item or per-tab source snapshots and normalized results.

Do NOT dump complete historical source grids into SQLite.

A snapshot must contain sufficient information for:

- Financial calculation.
- Transaction descriptions.
- Source provenance.
- Applicable transfer classification.
- Selected date.
- Source document identity.
- Source tab identity.
- Date boundaries.
- Snapshot creation time.
- Integrity verification.
- Relevant account classification.

Use explicit completeness states.

For example:

`SCANNING → SNAPSHOT_READY → MAPPED`

A partially written snapshot must never become ready.

### Retention rules

- Successful item snapshots may be released after downstream processing and necessary recovery data are safely recorded.
- Failed-item retry uses a newly fetched source snapshot.
- Other successful item snapshots must not be overwritten by retry.
- Keep necessary write intents and durable financial audit history.
- Do not clear prepared or uncertain write records merely to save space.

Cache cleanup is not permission to delete production ledgers.

---

# 17. GOOGLE API PERFORMANCE OPTIMIZATION

Reduce API calls through better data access.

Do NOT gain speed by removing financial correctness checks.

### Required optimization

- Avoid repeated full source-date discovery.
- Use the verified Source Date Index.
- Avoid repeated full destination mapping.
- Use the approved Destination Mapping Registry.
- Batch relevant source values reads.
- Batch bounded metadata reads when appropriate.
- Reuse completed source snapshots across modules within the same normal Run.
- Batch compatible read-back operations.
- Avoid repeated lookups of the same unchanged metadata.
- Preserve current response-size and memory safety protections.

### Request pacing

Investigate the existing 1.2-second minimum request interval.

Measure actual request volume and quota behavior before changing it.

Implement a bounded, shared Google API quota controller if needed.

Do not blindly remove all pacing or introduce unrestricted concurrent API calls.

Honor Google API quotas, timeout and retry behavior.

Use official Google Sheets documentation for supported methods and batching behavior.

### Performance goal

Aim for:

- Representative complete website Preview under 60 seconds.
- Lower request counts than V4.1.
- Stable RAM below the configured worker limit.
- No OOM.
- Correct results and destination coordinates.

**Under 60 seconds is a measured performance objective, not permission to weaken validations or a guaranteed completion time for every spreadsheet size.**

Provide cold-cache and warm-index benchmark results separately.

Do not report synthetic mock performance as proof of live production speed.

---

# 18. DESTINATION SAFETY AND RECONCILIATION

Preserve all existing protections:

- Formula cells.
- Merged cells.
- Existing Notes.
- Manual data.
- Account ownership.
- Existing write ledger.
- Transfer slot ownership.
- Read-before-write.
- Read-back verification.
- Idempotent recovery.
- Structural ambiguity detection.

Do not silently switch destination documents.

Do not silently remap approved coordinates.

### Laporan deposit harian

This tab must remain STRICTLY READ-ONLY.

Preserve:

- Existing website-section identification.
- Actual BALANCE column recognition.
- Website-specific balance checks.
- Consolidated balance checks.
- Date matching.
- KLOP / TIDAK KLOP.
- Existing final Clear requirements.

Do not change any formulas.

Do not write zeros to make reconciliation pass.

Do not declare Clear based merely on completed source scanning or administrator conflict acknowledgement.

---

# 19. EXISTING FRONTEND — MINIMAL AUTHORIZED CHANGES ONLY

Preserve all existing UI styling and functionality.

You are authorized to add or adjust only the controls required for:

1. Destination mapping validation status.
2. Selective retry for a failed item while a Run is active.
3. Conflict details showing actual old/new data.
4. `Masukkan Data Baru`.
5. `Tetapkan Data Lama`.
6. Accurate progress for the newly introduced stages and retries.

Keep the existing Indonesian Admin terminology.

Do not redesign the Dashboard.

Do not change its general layout, colors, navigation or unrelated UI components.

### Preview safety

Preview mode must remain completely read-only.

Do not allow the preview flow to write financial cells indirectly through the new conflict resolution workflow.

Any decision that would result in a real write must require an explicitly authorized write-mode operation.

---

# 20. REQUIRED DATABASE DESIGN SAFETY

Use additive, reversible database migrations where needed.

Do not delete or destructively modify historical tables.

Preserve:

- Users and authentication.
- Websites and website settings.
- Source URL history.
- Destination URL history.
- Active/inactive source tabs.
- Run history.
- Item history.
- Existing errors and audit entries.
- Write ledger.
- Transfer ownership.
- Reconciliation history.
- Monthly configuration.

New tables for Source Date Index, Destination Mapping Registry, snapshots, retry requests and conflict decisions are permitted if justified.

Use proper foreign keys, unique constraints and transaction boundaries.

Prevent:

- Duplicate retry claims.
- Duplicate conflict decisions.
- Concurrent ownership corruption.
- SQLite lock storms.
- Stale mapping activation.
- Lost retry requests after worker restart.

Use appropriate SQLite concurrency settings, including WAL where justified and safely configured.

---

# 21. REQUIRED AUTOMATED REGRESSION TESTS

Implement tests for all of the following.

## Source reading

1. One selected date produces all applicable metrics from one source snapshot.
2. Correct fixed DOC DEPO columns.
3. Correct fixed DOC QRIS columns.
4. Empty date with carried-forward balance.
5. Selected-date and following-date separator rules.
6. Forward index continuation from a verified separator.
7. Backward-date selection.
8. Appended source rows.
9. Inserted historical rows invalidate unsafe index assumptions.
10. Missing and duplicate separators.
11. No whole-grid source materialization.
12. Bounded Google API requests.

## Source tab lifecycle

13. Newly discovered inactive tab.
14. Explicitly activated new tab.
15. Confirmed tab rename.
16. Deleted and recreated tab with the same name.
17. Same account but different source identity.
18. Preserved transaction ownership across a proven rename.
19. No duplicate writes caused by rename.

## Absolute destination mapping

20. New monthly URL triggers mapping.
21. Full horizontal website discovery.
22. Far-right website blocks.
23. Multiple websites with similar account headers.
24. Absolute coordinates preserved.
25. Source tab rename does not change destination website/date mapping.
26. Destination URL changed after mapping.
27. Old Run remains pinned to the old destination.
28. Missing/ambiguous destination headers.
29. Stale destination mapping blocks unsafe writes.
30. Revalidation produces a new mapping version without deleting historical ownership.

## FEE

31. Valid FEE QRIS DEPO destination header.
32. Valid FEE QRIS WD destination header.
33. Merged KETERANGAN header.
34. Website-boundary protection.
35. Multiple fee entries.
36. No fee in source: valid no-op.
37. Source read failure is not interpreted as no fee.
38. Existing old fee with no new fee creates an actionable conflict.
39. Admin-authorized fee correction.
40. Formula and Notes remain protected.

## Retry

41. One failed item retried while 42 others exist.
42. Other successful items remain unchanged.
43. Retry reads current source raw data.
44. Retry does not reuse the previous snapshot as financial truth.
45. Retry does not rebuild destination mapping.
46. Retry while original Run is active.
47. Retry added while another item is writing.
48. Retry double-click is idempotent.
49. Retry queue survives worker restart.
50. No concurrent duplicate execution.
51. Existing dependent aggregate is handled safely.
52. Existing prepared writes remain protected.

## Existing destination conflicts

53. Old value differs from proposed value.
54. Display exact existing and proposed values.
55. `Masukkan Data Baru` after revalidation.
56. `Tetapkan Data Lama` preserves the destination.
57. Conflict resolution clears only the corresponding active error.
58. Historical audit remains.
59. Keeping old data does not force KLOP.
60. Formula cannot be overwritten merely through conflict approval.
61. Conflict changes between display and approval.
62. Multi-cell fee conflicts.
63. Multi-cell transfer and Note conflicts.
64. Timeout after an actual Google write.

## Transfer and reconciliation

65. DOC DEPO transfer priority.
66. QRIS bank priority.
67. Brown and blue classification.
68. Transfer slot occupancy.
69. Changed transaction identity.
70. Duplicate transfer prevention.
71. Read-only reconciliation.
72. Individual and consolidated BALANCE checks.

## Operational safety

73. Cancel while reading.
74. Cancel while retry is pending.
75. Worker interrupted after planned write.
76. Worker interrupted after Google accepted write.
77. API restart.
78. Database migration and rollback.
79. Memory-bounded large-source tests.
80. Accurate full-website performance instrumentation.

Retain all prior V4.1 tests.

Do not delete failing tests merely to declare success.

---

# 22. REAL PERFORMANCE VALIDATION

Measure a representative full VELBETT Run for October 18, 2026 using real or safely isolated equivalent spreadsheets.

Report separately:

- Cold destination mapping time.
- Warm mapping lookup time.
- Source date-discovery time.
- Source reading time.
- Financial calculation time.
- Destination validation time.
- Actual write time, if authorized.
- Read-back verification time.
- Reconciliation time.
- Total API reads.
- Total API writes.
- Total retries.
- Peak RSS.
- Total duration.

Measure both initial processing and one-item retry.

Do not execute destructive live financial writes in testing without authorization.

Verify that no destination cell addresses have shifted.

Include existing V4.1 financial golden fixtures.

If live Google access is unavailable, clearly mark live validation as pending.

---

# 23. SAFE DEPLOYMENT V4.1 → V4.2

Provide a production-safe upgrade script.

Existing installation:

`/opt/tutupkas/current/`

Database:

`/var/lib/tutupkas/tutupkas.sqlite3`

Environment:

`/etc/tutupkas/app.env`

Services:

- `tutupkas-api`
- `tutupkas-worker`

Mandatory steps:

1. Detect installed release.
2. Confirm permissions and deployment prerequisites.
3. Stop the worker safely.
4. Back up SQLite using a database-consistent backup method.
5. Back up the existing release.
6. Preserve Google credentials and environment configuration.
7. Apply additive database migrations.
8. Install V4.2.
9. Verify schema and application health.
10. Restart API safely.
11. Leave worker stopped pending manual verification.
12. Print exact verification commands.
13. Provide rollback instructions.

Do not automatically resume historical failed or uncertain writes.

Preserve the configured worker memory limit.

Do not alter Nginx, HTTPS or server accounts.

Do not include private credentials or production databases in the distribution ZIP.

---

# 24. OUT OF SCOPE

Do NOT:

- Change financial calculations.
- Change DOC source column coordinates.
- Change Kas Kecil existing financial layout.
- Change destination formulas.
- Change the website registration model.
- Make source tab names destination mapping keys.
- Hardcode VELBETT coordinates.
- Introduce five simultaneous website workers.
- Create three uncontrolled Python processes.
- Add automatic financial correction without an Admin decision.
- Reprocess successfully completed items on selective Retry.
- Automatically delete or overwrite old destination values.
- Delete financial ledgers or audit records.
- Implement Run History deletion in this release.
- Add unrelated UI features.
- Change visual design or navigation.
- Change Google Sheets credentials.
- Raise RAM or response limits as a shortcut.

If another issue is discovered, report it separately instead of silently expanding this release.

---

# 25. REQUIRED DELIVERY

Provide:

1. Complete Tutup Kas Lion Group V4.2 ZIP.
2. Corrected source-reading architecture.
3. Persistent Source Date Index.
4. Persistent absolute monthly Destination Mapping Registry.
5. Controlled Scanner → Mapper → Writer pipeline.
6. Selective retry during active Runs.
7. Current-source re-read for only the failed item.
8. Actionable old/new destination conflict system.
9. FEE QRIS resolver correction.
10. Preserved transfer and reconciliation behavior.
11. Automated tests.
12. Performance benchmark report.
13. Changed-file summary.
14. Database migration instructions.
15. V4.1 → V4.2 upgrade script.
16. Rollback instructions.
17. Known limitations and unverified scenarios.

Before delivery, inspect the complete Git diff.

Explain every changed file and why that change is required.

No unrelated changes are allowed.

---

# FINAL ACCEPTANCE GATE

V4.2 is acceptable only when:

- [ ] Source data for a selected date is read efficiently once per relevant tab during normal processing.
- [ ] All applicable modules reuse the same validated source snapshot.
- [ ] Retry reads fresh raw source data for only the failed logical item.
- [ ] Other successful items remain untouched.
- [ ] Retry can be queued during an active Run.
- [ ] No duplicate retry executions.
- [ ] Date Index continues from valid saved boundaries.
- [ ] Tab rename does not silently duplicate transactions.
- [ ] Recreated tabs are not guessed to be original tabs.
- [ ] Monthly destination URL remains editable.
- [ ] Saving a new monthly URL initiates absolute destination mapping.
- [ ] Mapping keys are independent of source tab names.
- [ ] No full destination remapping is performed on ordinary Crawl or Retry.
- [ ] All absolute target coordinates are preserved.
- [ ] Existing destination values are not silently overwritten.
- [ ] Admin can choose Masukkan Data Baru or Tetapkan Data Lama.
- [ ] Conflict decisions are persisted.
- [ ] Resolved conflicts disappear from active error lists.
- [ ] Historical audit is retained.
- [ ] Retaining old data does not falsely mark reconciliation KLOP.
- [ ] No-fee dates are handled correctly.
- [ ] FEE QRIS destination headers are resolved correctly.
- [ ] KET PENGIRIMAN slot rules remain unchanged.
- [ ] Google Notes and formulas remain protected.
- [ ] Financial results match prior approved rules.
- [ ] No unnecessary OOM exposure.
- [ ] API request counts are measured and reduced.
- [ ] Existing V4.1 frontend remains visually unchanged except authorized controls.
- [ ] All regression tests pass.
- [ ] A safe production upgrade and rollback are provided.

## FINAL DIRECTIVE

Build V4.2 as a financial correctness-preserving performance and workflow release.

**READ SOURCE ONCE PER DATE/TAB.**

**CALCULATE ALL APPLICABLE MODULES FROM THE SAME VALIDATED SOURCE SNAPSHOT.**

**MAP KAS KECIL ABSOLUTELY WHEN THE MONTHLY DESTINATION URL IS REGISTERED.**

**NEVER USE SOURCE TAB NAMES AS THE PRIMARY DESTINATION MAPPING KEY.**

**RETRY ONLY THE FAILED ITEM USING NEW RAW SOURCE DATA.**

**DO NOT REPROCESS SUCCESSFUL ITEMS.**

**DO NOT SILENTLY OVERWRITE EXISTING FINANCIAL DATA.**

**ALLOW EXPLICIT ADMIN DECISIONS FOR OLD-VERSUS-NEW DESTINATION VALUES.**

**PRESERVE ALL FINANCIAL RULES, DESTINATION COORDINATES, FORMULAS, NOTES, LEDGERS AND RECONCILIATION REQUIREMENTS.**

Do not claim success merely because unit tests pass.

Provide honest evidence, especially for retry safety, actual mapping coordinates, Google API request counts and memory consumption.

# END OF V4.2 REQUEST