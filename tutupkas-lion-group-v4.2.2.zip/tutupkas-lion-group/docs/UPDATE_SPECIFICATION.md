# TUTUP KAS LION GROUP
# COMPREHENSIVE SYSTEM UPDATE — WEBSITE RECONCILIATION, URL RECONFIGURATION, CRAWL ALL, SIDEBAR UX, AND SEARCHABLE HELP CENTER

## ROLE AND IMPLEMENTATION INSTRUCTIONS

You are a senior full-stack engineer, Google Sheets integration specialist, database architect, DevOps engineer, QA engineer, and professional UI/UX designer.

You are working on an existing deployed application named:

**Tutup Kas Lion Group**

Domain:

`https://tutupkasliongroup.com`

The application already includes:

- React and TypeScript frontend.
- FastAPI backend.
- SQLite database.
- Google Sheets integration.
- Website configuration.
- Source spreadsheet validation.
- Source tab management.
- Manual Task 01 execution.
- Task 01 processing workers.
- Selective retry.
- Error Center.
- Monthly destination spreadsheet configuration.
- Administrator authentication.
- Dark Navy and Electric Blue interface.

Implement all changes defined below directly into the existing project.

Do not create a separate application.

Do not rewrite the project unnecessarily.

Do not destroy existing configuration or operational data.

**Implement real backend functionality, not UI-only demonstrations.**

The requirements below are mandatory acceptance conditions.

All application UI labels, documentation, and user-facing messages must be written in Indonesian.

---

# SECTION 1 — THE ULTIMATE FINANCIAL OBJECTIVE

## 1.1 Fundamental Objective

The ultimate purpose of Tutup Kas Lion Group is to reconcile the financial balances for every website and the consolidated totals for all websites.

The system reads source Google Spreadsheets and writes processed data into the configured monthly Kas Semua Web spreadsheet.

The destination includes several processing sheets such as:

1. TOTAL DEPO.
2. TOTAL WD.
3. SALDO BANK.
4. BIAYA.
5. Pengeluaran FEE QRIS DEPO.
6. Pengeluaran FEE QRIS WD.
7. KET PENGIRIMAN.

After applicable processing and writing operations are complete, the system must evaluate:

`Laporan deposit harian`

This report is the principal financial reconciliation reference.

## 1.2 Critical Read-Only Rule

The `Laporan deposit harian` sheet is **STRICTLY READ-ONLY FOR THE ROBOT**.

The robot may:

- Read spreadsheet values.
- Read calculated formula results.
- Read headers.
- Read website names.
- Read dates.
- Read merged-cell metadata.
- Identify website section boundaries.
- Evaluate whether BALANCE equals zero.

The robot must never:

- Modify values on this sheet.
- Replace formulas.
- Force BALANCE to zero.
- Change formatting.
- Insert or delete rows.
- Insert or delete columns.
- Modify merged cells.
- Write processing statuses into the spreadsheet.
- Change STATUS or KETERANGAN cells.
- Modify any other cells in this report.

Store reconciliation statuses in the application's own SQLite database, not inside this spreadsheet.

Use the Google Sheets API strictly for reading this report.

---

# SECTION 2 — AUTOMATIC WEBSITE BLOCK DETECTION

## 2.1 Spreadsheet Layout

The `Laporan deposit harian` sheet contains multiple website sections arranged horizontally.

Examples:

- VELBETT.
- FANTASI.
- BBTOTO.
- Additional websites configured by administrators.

Each website has its own financial report section.

A section typically includes:

- Website name marker.
- Financial summary values.
- A daily report table.
- Tanggal.
- DEPOSIT.
- WITHDRAW.
- HASIL.
- ADMIN BCA.
- ADMIN MANDIRI.
- ADMIN BRI.
- ADMIN BNI.
- TOTAL SALDO BANK.
- BALANCE.

Website sections can be separated by blank columns, merged cells, images, or other decorative spreadsheet elements.

The website names are authoritative section markers.

## 2.2 Website Name Markers

The system must search for the website name as actual spreadsheet text.

Example:

`VELBETT`

marks the VELBETT section.

`FANTASI`

marks the FANTASI section.

`BBTOTO`

marks the BBTOTO section.

Use website identities registered in the Admin database.

Do not use decorative logos or images to identify websites.

For example, an image may display FANTASITOTO while the actual section text identifies the website as FANTASI.

The registered website name and text marker must be used for matching.

## 2.3 Vertical Text and Merged Cells

Some website markers may appear vertically or inside merged cells.

Support:

- Vertically rotated text.
- Merged text cells.
- Centered website labels.
- Different cell formatting.
- Different horizontal positions.

Obtain data using Google Sheets API, not screenshot analysis or image OCR.

Read merged-cell ranges and actual text values.

Normalize case, harmless whitespace, and line breaks where necessary.

For vertically stacked text, reconstruct the label only when a deterministic unique match can be established.

Do not rely on font color or image appearance for website identification.

## 2.4 Determining Website Boundaries

The robot must locate registered website markers across the report.

Example:

`VELBETT → FANTASI → BBTOTO`

Determine where each section begins and ends based on:

1. Website text marker.
2. Neighboring website markers.
3. The section's own Tanggal header.
4. Its own BALANCE header.
5. Structural consistency of the daily table.

The next website section must not be included in the previous website's lookup range.

For example:

The BALANCE located under FANTASI must never be interpreted as the VELBETT balance.

## 2.5 No Hardcoded Columns

Do not use fixed column letters for individual website sections.

The screenshots show that website sections appear in different positions.

For example, VELBETT's BALANCE appears in a different column than FANTASI's BALANCE.

These coordinates are illustrative, not permanent configuration.

The system must automatically discover the correct BALANCE column for the selected website.

No administrator should need to enter:

- Start column.
- End column.
- Date column.
- BALANCE column.
- Section width.
- Physical row number.

## 2.6 Resolve Daily BALANCE

For a selected website and date:

1. Open the configured monthly destination spreadsheet.
2. Open `Laporan deposit harian`.
3. Find the website's registered section.
4. Identify that section's Tanggal column.
5. Locate the administrator-selected date.
6. Identify that section's BALANCE header.
7. Read the corresponding calculated BALANCE.
8. Verify that the result equals numeric zero.

Validate values numerically, not as simple text strings.

Handle valid representations of zero such as:

- Numeric 0.
- 0.00.
- Formatted zero.
- Negative zero.

Do not use rounded screen display values when the underlying calculated amount is different.

Do not introduce arbitrary financial rounding tolerances.

## 2.7 Missing or Ambiguous Website Sections

If the website marker cannot be found:

Create:

`Blok website {WEBSITE} tidak ditemukan pada Laporan deposit harian.`

If multiple valid sections are detected and the correct one cannot be uniquely established:

Create:

`Blok website {WEBSITE} terdeteksi lebih dari satu. Periksa struktur laporan.`

Never choose an arbitrary section.

Never read another website's balance as a fallback.

---

# SECTION 3 — WEBSITE BALANCE RECONCILIATION

## 3.1 When to Reconcile

After all applicable Task 01 outputs for an individual website have been written and verified, perform reconciliation for that website.

The reconciliation must use freshly read Google Sheets calculated values.

If formula results are still updating, apply limited read-back retries with a reasonable delay.

Do not treat a stale calculated value as definitive without checking.

## 3.2 Website Is KLOP

When all applicable Task 01 operations are complete, no unresolved errors remain, and BALANCE equals zero:

Set:

`KLOP`

Display a green success indicator.

Example:

`VELBETT — 15 Oktober 2026 — KLOP`

## 3.3 Website Is Not KLOP

When BALANCE is nonzero:

Set:

`TIDAK KLOP`

Create the exact style of error requested by the administrator:

`Kas Velbett tidak klop Bagian Laporan deposit harian`

Similarly:

`Kas Fantasi tidak klop Bagian Laporan deposit harian`

`Kas Bbtoto tidak klop Bagian Laporan deposit harian`

Include:

- Website.
- Selected date.
- Actual BALANCE amount.
- Expected amount: 0.
- Difference.
- Destination spreadsheet title.
- Destination sheet.
- Actual resolved cell address.
- Processing run ID.
- Human-readable explanation.

## 3.4 Example

Website:

VELBETT.

Date:

October 15, 2026.

Example BALANCE:

-125,173,298.

Result:

`TIDAK KLOP`

Display:

`Kas Velbett tidak klop Bagian Laporan deposit harian`

`Tanggal: 15 Oktober 2026`

`Selisih BALANCE: -125.173.298`

Do not silently change the balance.

## 3.5 Processing Failure Versus Balance Failure

If some required source tabs have not been successfully processed, do not claim the website is fully reconciled merely because its displayed BALANCE happens to be zero.

A website is fully KLOP only when:

- All required source processing is complete.
- Applicable writes are verified.
- No unresolved processing errors remain.
- Its daily BALANCE is zero.

---

# SECTION 4 — CONSOLIDATED ALL-WEBSITE RECONCILIATION

## 4.1 Consolidated Report

The `Laporan deposit harian` sheet also contains a consolidated financial table representing all websites.

The consolidated table includes:

- Tanggal.
- DEPOSIT.
- WITHDRAW.
- HASIL.
- ADMIN BCA.
- ADMIN MANDIRI.
- ADMIN BRI.
- ADMIN BNI.
- TOTAL SALDO BANK.
- BALANCE.
- STATUS.
- KETERANGAN.

This is a separate report from the individual website sections.

## 4.2 Consolidated Identification

Identify the consolidated table structurally using its financial headers and date column.

Do not confuse it with the VELBETT or FANTASI individual website tables.

The consolidated table must be uniquely identified.

If the system cannot distinguish it reliably, return a structural mapping error.

## 4.3 Consolidated BALANCE Requirement

After every required active website has completed Task 01 for the selected date:

1. Read the consolidated daily report.
2. Find the selected date.
3. Locate the consolidated BALANCE cell.
4. Read the calculated value.
5. Verify that it equals zero.

The consolidated value is the primary overall financial reconciliation indicator.

## 4.4 Incomplete Website Processing

Do not declare an overall final reconciliation failure while other required websites are still being processed.

Statuses:

- MENUNGGU WEBSITE LAIN.
- SEDANG DIPROSES.
- KLOP.
- TIDAK KLOP.
- ERROR.

Display which websites remain incomplete.

## 4.5 Final Clear Rule

The selected date can be marked:

`Selesai & Clear`

only when:

1. Every required active website has completed its applicable Task 01 processing.
2. All required writes are verified.
3. There are no unresolved errors.
4. Each website's BALANCE equals zero.
5. The consolidated BALANCE equals zero.

Formula:

`FINAL_CLEAR = ALL_REQUIRED_WEBSITES_SUCCESSFUL AND ALL_WEBSITE_BALANCES_ZERO AND CONSOLIDATED_BALANCE_ZERO AND NO_UNRESOLVED_ERRORS`

A consolidated zero alone is insufficient if one website has an outstanding discrepancy.

Never force a financial value to zero.

---

# SECTION 5 — MONTHLY SPREADSHEET URL CONFIGURATION

## 5.1 Single Monthly Destination

The administrator has confirmed that every destination spreadsheet registered in the Admin application is already a dedicated working copy.

Therefore, maintain one configured Kas Semua Web destination URL per month and year.

Do not require separate permanent TEST and PRODUCTION destinations.

Do not require a permanent environment selector.

Keep the application safe using:

- Explicit manual Start.
- Optional Preview.
- URL validation.
- Formula protection.
- Write ownership validation.
- Read-back verification.
- Duplicate prevention.
- Error reporting.

## 5.2 Centralized Configuration

All Task 01 modules must resolve the current destination URL using one authoritative monthly configuration.

Do not store separate copies of the destination URL in each processing module.

Do not hardcode destination spreadsheet IDs in the code.

Example:

`October 2026 → Kas Semua Web October 2026`

All relevant Task 01 modules use this destination.

## 5.3 Changing the Destination URL

Suppose the administrator replaces the October 2026 Kas Semua Web URL.

Required behavior:

1. Save the new URL.
2. Preserve the old URL in history.
3. Reset URL validation.
4. Validate the new spreadsheet.
5. Refresh destination metadata and structure.
6. Invalidate cached destination coordinates.
7. Recalculate all destination mappings for subsequent runs.
8. Ensure all subsequent October 2026 Task 01 executions target the new document.
9. Keep other months unaffected.
10. Preserve historical write records belonging to the old destination.

## 5.4 Critical Manual Execution Rule

**Changing a URL must NOT automatically trigger transaction crawling or writing.**

Saving a URL is a configuration operation.

Validating a URL is a verification operation.

Crawling is a separately authorized manual operation.

This rule prevents accidental writes and uncontrolled duplicate processing.

## 5.5 Existing Completed Dates After URL Replacement

Previously successful runs may belong to the old destination spreadsheet.

Do not treat those writes as successful writes to the new destination.

Track completion and write verification against the exact destination document revision.

For affected dates, display a status such as:

`Perlu Sinkronisasi ke Spreadsheet Baru`

Provide an administrator-controlled action:

`Crawl Ulang ke URL Baru`

This action must run real processing against the newly configured destination.

The administrator chooses the date or explicitly selected date range.

Do not automatically rerun an entire month merely because the URL was replaced.

## 5.6 Source URL Replacement

Source URLs remain independently configured for:

- DOC DEPO.
- DOC QRIS.

When a source URL changes:

1. Preserve the original URL history.
2. Reset validation.
3. Validate the replacement spreadsheet.
4. Refresh discovered source tabs.
5. Default newly discovered tabs to INACTIVE.
6. Require the administrator to activate the needed source tabs.
7. Invalidate affected source caches.
8. Mark affected previous results as requiring review or reprocessing.
9. Do not automatically start transaction crawling.

A change to one website's DOC DEPO URL must not overwrite another website's source configuration.

## 5.7 Historical Integrity

Track URL revisions for both source and destination documents.

Processing and write records must retain the document revision and exact Google Spreadsheet ID used for that run.

Do not accidentally retry an old run into a new document without explicit administrator authorization.

---

# SECTION 6 — MANUAL CRAWL ALL WEBSITES

## 6.1 Main User Requirement

Add a real:

`Mulai Penarikan Semua WEB`

button.

This is an essential feature.

The system must not require the administrator to manually click Start for every website during normal daily operation.

## 6.2 Location

Place the button prominently inside the `Penarikan Data Harian` panel, close to the selected date.

The interface should support:

- Selected date.
- Optional Preview.
- Individual website Start.
- Crawl All Websites Start.

## 6.3 Website Selection

Crawl All processes every website marked ACTIVE.

Inactive websites are excluded.

Do not silently mark an active but incorrectly configured website as successful.

Display configuration errors where appropriate.

## 6.4 Execution Order

Process websites sequentially to remain efficient on the existing 2 GB RAM VPS.

For each website:

1. Load the selected date and month.
2. Read current source document configuration.
3. Validate source readiness.
4. Read active source tabs.
5. Extract required transaction information.
6. Calculate all applicable Task 01 values.
7. Resolve destination positions.
8. Protect formulas and existing manual data.
9. Perform authorized writes.
10. Verify written results.
11. Read `Laporan deposit harian`.
12. Evaluate the individual website BALANCE.
13. Record the result.
14. Continue to the next website.

After all websites have completed their required processing, perform consolidated reconciliation.

## 6.5 Progress Tracking

Display genuine backend-reported progress.

Examples:

`Memproses 2 dari 8 website`

`Sedang memproses: FANTASI`

`Berhasil: 1`

`Tidak Klop: 1`

`Gagal: 0`

`Menunggu: 6`

Distinguish processing success from reconciliation success.

Do not display simulated progress unrelated to actual job execution.

## 6.6 Partial Success

If seven websites succeed and one fails:

- Preserve successful processing results.
- Record the failed website.
- Keep successful writes.
- Allow selective retry.
- Do not rerun successful website operations unnecessarily.

## 6.7 Retry

Provide retry actions for:

- Failed website processing.
- Failed source tabs.
- Failed metrics.
- Reconciliation rechecking after corrections.

Do not blindly replay all writes when only a reconciliation formula needs rechecking.

## 6.8 Duplicate Prevention

Prevent:

- Double-clicked Start.
- Duplicate batch jobs.
- Conflicting individual and batch runs.
- Repeated transfer insertion.
- Repeated QRIS Notes.
- Overwriting unrelated content.

Jobs must be durable across page reloads and service restarts.

---

# SECTION 7 — RENAME TASK 01 TO TUTUP KAS ALL WEB

## 7.1 Main Name Change

Rename the user-facing feature:

`Task 01`

to:

**`Tutup Kas All Web`**

Use this new name consistently across the application.

Update:

- Sidebar navigation.
- Page title.
- Breadcrumb.
- Dashboard module heading.
- Run history labels.
- Error Center references.
- Help Center documentation.
- Notifications.
- Status descriptions.
- Confirmation messages.
- Relevant UI badges.

## 7.2 Preserve Internal Identity

Do not change the internal task identifier merely for cosmetic renaming.

The backend may continue using:

`task_number = 1`

or an existing stable internal task code.

Preserve:

- Existing task records.
- Processing history.
- Database relationships.
- Existing API integrations.
- Current crawler calculation rules.

Existing routes must not suddenly break.

If new user-friendly routes are introduced, maintain redirects or compatible aliases for old routes.

## 7.3 New Main Page Heading

Use:

`Tutup Kas All Web`

Subtitle:

`Kelola penarikan data, pemeriksaan saldo, dan tutup kas seluruh website secara otomatis dengan eksekusi manual.`

## 7.4 Individual and All-Website Actions

Keep both:

`Mulai Penarikan`

for one website.

`Mulai Penarikan Semua WEB`

for all active websites.

The feature name change must not remove individual website processing.

---

# SECTION 8 — SCROLLABLE SIDEBAR

## 8.1 Existing Problem

The current sidebar does not provide sufficiently convenient scrolling when navigation items and supporting controls exceed the viewport height.

The Help card can appear near the bottom and may be difficult to reach on smaller screens.

Fix this properly.

## 8.2 Required Sidebar Behavior

Implement a vertically scrollable navigation area.

Requirements:

- Sidebar fits available viewport height.
- Navigation can scroll independently of main content.
- Main page scrolling remains independent.
- No navigation item becomes inaccessible.
- The Help entry remains accessible.
- No elements overlap.
- No clipping of buttons or text.
- No horizontal scrollbar caused by navigation.
- Active navigation states remain visible.
- Mouse wheel and touchpad scrolling work.
- Keyboard scrolling works.
- Mobile touch scrolling works.

Use responsive, maintainable CSS.

Avoid fragile pixel-based height assumptions.

## 8.3 Recommended Layout

Use a flex-based sidebar structure.

Suggested structure:

- Brand/logo area.
- Workspace identity.
- Scrollable navigation.
- Persistent footer/help area where space permits.

The navigation container should have appropriate:

`min-height: 0`

and:

`overflow-y: auto`

Use correctly calculated viewport heights and responsive behavior.

A custom subtle scrollbar may be used, but functionality is more important than decoration.

## 8.4 Mobile Responsiveness

On mobile:

- Use an accessible drawer or collapsible navigation.
- Allow vertical scrolling within the menu.
- Keep menu close functionality visible.
- Avoid the sidebar blocking the full page indefinitely.
- Preserve touch interactions.
- Preserve readable typography.

## 8.5 UI Testing

Test at least:

- 1920 × 1080.
- 1366 × 768.
- 1280 × 720.
- 1024 × 768.
- 390 × 844.

Also verify that browser zoom does not make critical navigation unreachable.

---

# SECTION 9 — COMPLETE HELP CENTER

## 9.1 New Route

Create:

`/panduan`

This is the central user documentation and Help Center.

The purpose is to help administrators and nontechnical staff understand the application.

Do not create a blank placeholder.

The Help Center must contain practical, comprehensive content explaining every important feature.

## 9.2 Sidebar Integration

The existing:

`Butuh panduan?`

card must become clickable.

Clicking it navigates to:

`/panduan`

Optionally provide an additional navigation item named:

`Panduan Penggunaan`

Do not leave help controls without functional actions.

## 9.3 Premium Help Center Design

Maintain the existing Dark Navy and Electric Blue design.

Required elements:

- Clear page heading.
- Prominent search field.
- Category navigation.
- Structured help articles.
- Expandable FAQ sections.
- Contextual explanations.
- Step-by-step procedures.
- Error-resolution guides.
- Related article links.
- Mobile-friendly navigation.
- Clear visual distinction between instructions and warnings.

The Help Center must remain easy to use by nontechnical staff.

## 9.4 Search Functionality

Provide a functional search field.

Placeholder:

`Cari panduan, tombol, atau pesan kesalahan...`

Search must work against actual Help Center content.

Support:

- Article titles.
- Keywords.
- Button names.
- Error messages.
- Relevant explanations.

Search must be case-insensitive.

Support common Indonesian keyword variations and useful aliases.

Examples:

Search:

`validasi`

returns URL validation articles.

Search:

`sheet aktif`

returns tab activation instructions.

Search:

`crawl semua`

returns Crawl All instructions.

Search:

`balance tidak klop`

returns financial reconciliation troubleshooting.

Search:

`url baru`

returns monthly URL replacement instructions.

Provide:

- Search-result titles.
- Short summaries.
- Relevant categories.
- Clickable article links.
- Empty search-result state.
- Keyboard-accessible controls.

Search should work without requiring an external paid search service.

## 9.5 Required Help Categories

### A. Pengenalan Aplikasi

Explain:

- What Tutup Kas Lion Group does.
- What DOC DEPO means.
- What DOC QRIS means.
- What Kas Semua Web means.
- What source and destination spreadsheets are.
- What website reconciliation means.

### B. Dashboard

Explain every dashboard statistic and status.

Include:

- Total Website.
- URL Tervalidasi.
- Penarikan Berhasil.
- Perlu Perhatian.
- Aktivitas Terakhir.
- Status website.
- Status reconciliation.

### C. Pengaturan WEB

Explain:

- Adding a website.
- Editing a website.
- Activating a website.
- Deactivating a website.
- Opening website settings.
- Website identity and dynamic URLs.

### D. Pengaturan URL

Explain:

- DOC DEPO URL.
- DOC QRIS URL.
- Optional URLs.
- Month and year.
- Saving configurations.
- URL validation.
- Green validation indicators.
- Opening the original spreadsheet.
- Monthly URL history.
- What happens after replacing a URL.

Explicitly explain:

`Mengganti URL tidak otomatis menjalankan penarikan data.`

### E. Daftar Sheet

Explain:

- ACTIVE and INACTIVE.
- Why newly discovered tabs are inactive.
- How to activate multiple tabs.
- How to deactivate tabs.
- How Refresh Daftar Sheet works.
- What happens when a tab is renamed.
- Why inactive tabs are not crawled.

### F. Kas Kecil

Explain:

- The monthly Kas Semua Web URL.
- Why it changes every month.
- How to validate it.
- What happens when the destination URL changes.
- How to synchronize old dates into a new destination.
- How to avoid writing into the wrong month.

### G. Tutup Kas All Web

Explain:

- Individual website Start.
- Crawl All Websites.
- Date selection.
- Preview.
- Actual execution.
- Progress display.
- Partial success.
- Completion statuses.
- Selective retry.
- Duplicate prevention.

### H. Financial Output Modules

Explain all seven modules:

1. TOTAL DEPO.
2. TOTAL WD.
3. SALDO BANK.
4. BIAYA.
5. Pengeluaran FEE QRIS DEPO.
6. Pengeluaran FEE QRIS WD.
7. KET PENGIRIMAN.

For each module explain:

- Purpose.
- Source document.
- Destination sheet.
- Data extraction logic.
- Data writing behavior.
- Common errors.

Use existing confirmed business rules.

### I. Laporan Deposit Harian

Explain:

- Website markers.
- Website section boundaries.
- Daily BALANCE.
- KLOP.
- TIDAK KLOP.
- Consolidated BALANCE.
- Why the robot only reads this sheet.
- Why BALANCE cannot be forced to zero.
- Why all websites must be complete before final Clear.

### J. Pusat Kesalahan

Explain:

- Where errors appear.
- Reading error details.
- Missing headers.
- Missing source tabs.
- Missing destination accounts.
- Date mismatch.
- URL access problems.
- Spreadsheet formula conflicts.
- Transfer-slot overflow.
- Balance not zero.
- Selective retry.

### K. Selesai & Clear

Explain:

- What Clear means.
- Conditions for Clear.
- How to Clear a date.
- How to reopen a date.
- Why incomplete or nonzero balances cannot be Cleared.

### L. Keamanan dan Troubleshooting

Explain:

- Google Service Account access.
- Why credentials must remain private.
- Missing Google Sheets permissions.
- Temporary Google API failures.
- Browser refresh during processing.
- What to do after a failed job.
- Why repeated clicking of Start is unnecessary.

## 9.6 Contextual Help

Where useful, provide small help icons near complex controls.

Examples:

- Validasi URL.
- Refresh Daftar Sheet.
- Mulai Penarikan Semua WEB.
- Crawl Ulang.
- Selesai & Clear.
- BALANCE.
- KLOP/TIDAK KLOP.

Clicking the help icon should open the relevant `/panduan` article or provide a short explanatory tooltip.

Do not implement decorative help buttons without actual explanations.

## 9.7 Documentation Accuracy

Help Center instructions must match the application's actual behavior.

Do not document features that are not implemented as though they already work.

Whenever a feature changes, update its relevant documentation.

## 9.8 Help Center Content Architecture

Store Help Center articles in a structured, maintainable format.

A static article registry or version-controlled Markdown/JSON documentation system is acceptable.

Articles should support:

- Stable IDs.
- Slugs.
- Titles.
- Categories.
- Keywords.
- Content.
- Related articles.

The system should be easy to expand when Task 02 and Task 03 are implemented later.

---

# SECTION 10 — DATABASE AND BACKEND INTEGRITY

## 10.1 Required Persistent Records

Extend the existing database as necessary for:

- Website balance reconciliation.
- Consolidated balance reconciliation.
- Source URL revisions.
- Destination URL revisions.
- Destination reprocessing requirements.
- Crawl All batch runs.
- Individual website jobs within a batch.
- Processing statuses.
- Retry ownership.
- Clearance eligibility.

Use Alembic migrations.

Do not drop existing tables or destroy historical data.

## 10.2 Destination Revision Tracking

When the monthly destination URL changes, associate new writes with the new destination revision.

Old write ledgers must remain tied to the old destination.

Do not assume a previous write is present in a different spreadsheet.

## 10.3 Job Durability

All long-running operations must be persisted.

Browser refresh must not cancel or duplicate jobs unexpectedly.

A service restart must not cause blindly repeated financial writes.

## 10.4 API Requirements

Add or update authenticated API endpoints for:

- Crawl All execution.
- Crawl All progress.
- Individual website reconciliation.
- Consolidated reconciliation.
- Reconciliation history.
- Monthly destination revision status.
- Manual reprocessing against a new destination.
- Selective retry.
- Help Center article retrieval if served dynamically.

Use the existing authentication and authorization mechanisms.

Do not create unauthenticated financial-processing endpoints.

---

# SECTION 11 — USER EXPERIENCE AND ERROR STATES

## 11.1 Clear Terminology

Use consistent Indonesian statuses.

Examples:

- Belum Diproses.
- Menunggu.
- Sedang Diproses.
- Berhasil Ditulis.
- Sebagian Berhasil.
- Gagal.
- KLOP.
- TIDAK KLOP.
- Menunggu Website Lain.
- Perlu Sinkronisasi.
- Selesai & Clear.

Do not treat `Berhasil Ditulis` as equivalent to `KLOP`.

## 11.2 Reconciliation Dashboard

Show:

- Website.
- Selected date.
- Processing status.
- Actual BALANCE.
- Reconciliation status.
- Outstanding errors.
- Available retry action.

Provide consolidated status separately.

Example:

VELBETT — KLOP — 0.

FANTASI — TIDAK KLOP — -30.278.535.

BBTOTO — Menunggu.

Consolidated — Menunggu Website Lain.

## 11.3 Never Hide Financial Failures

Do not replace a failed BALANCE calculation with zero.

Do not hide mapping failures.

Do not display green completion badges solely because the backend job finished.

Show accurate processing and reconciliation states.

---

# SECTION 12 — AUTOMATED TESTING

Implement tests for every affected area.

## 12.1 Website Block Detection

Test:

- VELBETT block.
- FANTASI block.
- BBTOTO block.
- Vertically displayed names.
- Merged headers.
- Different horizontal positions.
- Adjacent blocks.
- Blank columns.
- Decorative logos.
- Duplicate markers.
- Missing markers.
- Missing BALANCE header.
- Missing selected date.

## 12.2 Read-Only Report Protection

Assert that reconciliation never sends Google Sheets write requests targeting `Laporan deposit harian`.

Verify that:

- Formulas remain unchanged.
- STATUS cells remain unchanged.
- KETERANGAN cells remain unchanged.
- Formatting remains unchanged.

## 12.3 URL Replacement

Test:

- Same month, new destination.
- Different month, separate destination.
- URL validation reset.
- Historical URL preservation.
- Source URL change.
- Source tab activation reset.
- Destination mapping cache invalidation.
- Previously completed dates marked for reprocessing when necessary.
- No automatic crawling on Save.
- No automatic crawling on Validate.
- Manual reprocessing writes to the new authorized destination.

## 12.4 Crawl All

Test:

- Multiple active websites.
- Inactive website exclusion.
- Missing source configuration.
- Sequential processing.
- Partial success.
- Live progress.
- Restart recovery.
- Duplicate start prevention.
- Selective retry.
- Reconciliation after completion.

## 12.5 Financial Reconciliation

Test:

- Website BALANCE = 0.
- Website BALANCE nonzero.
- Consolidated BALANCE = 0.
- Consolidated BALANCE nonzero.
- Consolidated BALANCE = 0 but a website is not reconciled.
- Missing website section.
- Missing consolidated section.
- Stale formula result.
- Formula error.
- Incomplete source processing.
- Clear eligibility.
- Clear rejection.

## 12.6 Sidebar UX

Use browser tests to verify:

- Vertical scrolling.
- Independent content scrolling.
- Help link visibility.
- Responsive layout.
- Navigation functionality.
- No clipped elements.

## 12.7 Help Center

Test:

- `/panduan` loads.
- Sidebar Help card opens it.
- Search works.
- Search is case-insensitive.
- Keywords return expected articles.
- Empty results display correctly.
- Article navigation works.
- Contextual help links open the correct content.
- All critical actions are documented.

---

# SECTION 13 — DEPLOYMENT REQUIREMENTS

## 13.1 Existing VPS Deployment

The application is already deployed on the user's VPS.

Existing layout includes:

Frontend:

`/var/www/html/`

Backend application:

`/opt/tutupkas/current/`

Google Service Account:

`/home/aksesfinancebot/spreadsheet-robot/credentials/robot-key.json`

Database location:

`/var/lib/tutupkas/`

Existing Nginx and Let's Encrypt HTTPS are operational.

## 13.2 Preserve Existing Services

Do not remove or unnecessarily reinstall:

- Nginx.
- Certbot.
- Existing SSL certificates.
- Existing Google credentials.
- Existing robot directory.
- SQLite production data.
- Existing administrator accounts.

## 13.3 Build and Upgrade Package

Provide a complete updated deployable ZIP.

Include:

- Updated frontend.
- Updated backend.
- Database migrations.
- Worker changes.
- New reconciliation services.
- Crawl All API and UI.
- Sidebar changes.
- Help Center.
- Automated tests.
- Updated deployment scripts.
- Indonesian deployment documentation.

Do not include:

- Real credentials.
- Administrator passwords.
- Production SQLite database.
- Virtual environments.
- node_modules.
- Temporary build caches.

## 13.4 Safe Upgrade Procedure

Provide exact steps for:

1. Backing up the existing database.
2. Backing up the current application release.
3. Uploading the new ZIP through FileZilla/SFTP.
4. Extracting into a separate staging directory.
5. Reviewing migrations.
6. Deploying without destroying existing data.
7. Updating frontend assets.
8. Restarting required application services.
9. Verifying API health.
10. Verifying frontend functionality.
11. Running smoke tests.
12. Rolling back safely if needed.

Do not assume the developer has direct SSH access to the VPS.

The user will manually upload the project files.

## 13.5 Frontend Cache Handling

Because the frontend is served from `/var/www/html`, account for caching of static assets and HTML after upgrades.

Ensure the updated interface is loaded correctly.

Use hashed frontend asset filenames and appropriate cache policies.

Do not modify Nginx unnecessarily.

---

# SECTION 14 — FINAL ACCEPTANCE CONDITIONS

The implementation must not be considered complete unless:

- [ ] `Laporan deposit harian` is strictly read-only.
- [ ] Website markers are identified automatically.
- [ ] VELBETT is never confused with FANTASI.
- [ ] FANTASI is never confused with BBTOTO.
- [ ] Website sections require no manually configured columns.
- [ ] Individual daily BALANCE can be resolved correctly.
- [ ] Nonzero website BALANCE creates the requested error.
- [ ] Consolidated BALANCE is checked separately.
- [ ] Consolidated reconciliation waits for required websites.
- [ ] Final Clear requires all individual balances and consolidated balance to be zero.
- [ ] Monthly destination URL replacement works.
- [ ] New URL validation is required.
- [ ] Changing a URL does not automatically crawl.
- [ ] Subsequent manual runs use the updated monthly URL.
- [ ] Previously completed runs are not falsely treated as verified on a different destination.
- [ ] Manual Crawl Ulang ke URL Baru is available.
- [ ] Crawl All Websites executes actual Task 01 processing.
- [ ] Individual website Start remains available.
- [ ] Failed websites can be retried selectively.
- [ ] Sidebar scrolling works.
- [ ] Help card remains accessible.
- [ ] User-facing Task 01 is renamed to Tutup Kas All Web.
- [ ] Existing task history and APIs remain compatible.
- [ ] `/panduan` is implemented.
- [ ] Help Center search works.
- [ ] All important features are documented for nontechnical users.
- [ ] Existing dashboard styling is preserved.
- [ ] Existing financial calculation logic is not unintentionally modified.
- [ ] Existing Google Service Account credentials remain secure.
- [ ] Existing SQLite data is preserved.
- [ ] Deployment ZIP and upgrade instructions are provided.
- [ ] Automated tests pass.
- [ ] Real Google Sheets integration tests are reported accurately.

---

# FINAL ENGINEERING DIRECTIVE

Implement this update thoroughly across frontend, backend, database, worker, and automated tests.

Do not provide a superficial visual update.

Do not implement mock buttons or simulated processing.

Do not hardcode spreadsheet coordinates that should be discovered dynamically.

Do not change financial formulas to make balances appear correct.

Do not automatically crawl or write data merely because a URL changes.

Do not overwrite existing credentials, Nginx configuration, administrator accounts, or operational history.

Maintain compatibility with the currently installed Tutup Kas Lion Group application.

The ultimate user workflow must be:

**Configure Sources and Destination → Select Date → Start Individual Website or Crawl All → Extract → Calculate → Write → Verify → Read Daily Financial Report → Check Every Website Balance → Check Consolidated Balance → Report KLOP or Errors → Selesai & Clear.**

The application must be understandable by nontechnical administrators through a complete searchable Help Center.

Provide the complete updated project ZIP, tests, clear status report, and safe VPS upgrade instructions.

**IMPLEMENT THE FULL FUNCTIONALITY, NOT JUST THE INTERFACE.**

# END OF IMPLEMENTATION INSTRUCTIONS