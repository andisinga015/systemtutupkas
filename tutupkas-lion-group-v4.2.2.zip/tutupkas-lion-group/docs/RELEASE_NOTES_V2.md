# Tutup Kas Lion Group v2

- Satu tujuan salinan kerja per bulan, dengan revisi dan history tetap tersimpan.
- Tombol Mulai Penarikan Semua WEB memakai batch persisten, progress nyata, recovery dan retry selektif.
- Status Berhasil Ditulis terpisah dari KLOP/TIDAK KLOP/ERROR.
- Laporan deposit harian dibaca saja; pemetaan WEB, tanggal dan BALANCE otomatis, tanpa koordinat manual atau OCR.
- Rekonsiliasi konsolidasi menunggu semua WEB; Clear memerlukan seluruh saldo WEB dan konsolidasi tepat nol.
- URL baru tidak menjalankan penarikan otomatis. Resync manual memilih tanggal/rentang eksplisit, dengan snapshot dan ownership yang terjaga.
- Nama menu Tutup Kas All Web, sidebar yang dapat di-scroll dan akses seluler dengan keyboard.
- `/panduan` berisi 21 artikel dalam 12 kategori, pencarian, FAQ dan bantuan kontekstual.
- Migrasi aditif dari v1, pelestarian akun/riwayat, skrip backup/upgrade/rollback serta frontend hash/cache.

106 pengujian backend lulus pada Python 3.10 dan 3.12; 4 pengujian browser lulus. Integrasi Google Sheets dan VPS asli belum dijalankan pengembang. Rincian: TEST_REPORT.md. Untuk instalasi yang sudah berjalan, gunakan UPGRADE_V2.md dan `deploy/upgrade.sh`, bukan membuat DB/admin baru.
