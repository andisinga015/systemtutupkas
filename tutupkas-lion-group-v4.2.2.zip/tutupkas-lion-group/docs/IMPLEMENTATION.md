# Implementasi V3 (koreksi V2)

## Pemrosesan dan rekonsiliasi

Tutup Kas All Web tetap `task_number=1`; rute `/tasks/1` dan API `/runs` dipertahankan. Berhasil Ditulis (`SUCCESS`) adalah hasil ekstraksi/tulis/read-back. Rekonsiliasi tersimpan terpisah sebagai `WAITING`, `IN_PROGRESS`, `INCOMPLETE`, `BALANCED`, `NOT_BALANCED`, `ERROR`. Preview tidak menulis atau membuktikan Clear.

`engine/report.py` membaca penanda WEB terdaftar berupa teks, normalisasi whitespace/case/newline, merged/rotated text dan huruf vertikal berurutan. Header Tanggal/BALANCE serta batas tabel menentukan kolom dan baris secara struktural. Tidak ada koordinat per WEB atau OCR. Konsolidasi harus unik, memiliki semua header finansial plus STATUS/KETERANGAN, serta tidak terasosiasi dengan blok WEB. Ambiguitas atau tanggal/header hilang adalah kesalahan; tidak mengambil saldo blok tetangga.

`fresh_balance` mengambil grid baru 2–5 kali (default 3), maksimal jeda yang dikonfigurasi, dan memerlukan dua pengamatan nol berturut-turut untuk KLOP. Decimal diperiksa tepat nol, bukan formattedValue, integer rounding, atau toleransi. Formula error, kosong, bool dan nonfinite ditolak. Laporan tidak di-cache antar pengamatan. Recheck hanya membaca laporan; writer dan Sheets client mempunyai guard penolakan penulisan laporan sebelum HTTP POST.

Konsolidasi menunggu seluruh WEB aktif selesai pada konfigurasi saat ini. Global Clear memeriksa kelengkapan item, verifikasi proses, error yang belum selesai, BALANCE setiap WEB dan konsolidasi. Context signature mencakup revisi tujuan, identitas WEB aktif, revisi sumber, tab aktif dan alias. Clear lama tidak otomatis berlaku pada konteks baru. Reopen harus disertai alasan minimal 10 karakter. History Clear v1 tersedia melalui `/clearances/legacy` dan bagian riwayat UI, tanpa mengubahnya menjadi bukti global.

## API admin (prefix `/api`)

Semua operasi konfigurasi/run memerlukan sesi admin. Mutasi memerlukan CSRF dan origin yang sesuai. Login Argon2id, session cookie HttpOnly/Secure pada HTTPS, limiter login, logout dan masa berlaku tetap dipertahankan.

| Operasi | API |
|---|---|
| WEB/sumber/tab/alias | `/websites`, `/websites/{id}/sources`, `/sources/{id}/validate`, `/sources/{id}/tabs`, `/sources/{id}/tabs/refresh`, `/websites/{id}/aliases` |
| Tujuan satu bulan | GET/PUT `/destinations`, POST `/{id}/validate`, GET `/{id}/history`, `/{id}/revision-status?selected_date=...` |
| Satu WEB | POST `/runs`, GET `/runs`, GET `/runs/{id}` |
| Retry | POST `/runs/{id}/retry` dengan `source_document_id`, `item_ids`, atau `metric_types` opsional; hanya item gagal |
| Sinkronisasi | POST `/runs/{id}/resync`: `selected_dates` maksimal 31 tanggal dalam bulan asal, `idempotency_key` |
| Semua WEB | POST/GET `/batches`, GET `/batches/{id}`, POST `/batches/{id}/retry` dengan `website_id` |
| Saldo/status tanggal | GET `/reconciliations/date?selected_date=...`, GET `/reconciliations/history` |
| Recheck hanya baca | POST `/runs/{id}/reconcile`, POST `/reconciliations/recheck` dengan tanggal dan kunci idempotensi |
| Clear/reopen | POST `/reconciliations/clear`, alias POST `/runs/{id}/clear`, GET `/clearances`, POST `/clearances/{id}/reopen` |

POST run memerlukan `website_id`, `selected_date`, `preview` opsional dan kunci idempotensi 16–100 karakter. POST batch memerlukan tanggal, preview opsional dan kunci. Field `environment` lama diterima tetapi tidak menjadi pemilih tujuan/gate; run baru memakai WORKING. Endpoint authorize lama menjelaskan bahwa gate terpisah telah dihentikan. Run list mendukung limit 1–500 dan `before_id` untuk pagination.

## Revisi, antrean dan recovery

`monthly_destinations` mengikat tepat satu tujuan per bulan. Save URL baru merevisi objek tujuan dan mempertahankan URL sebelumnya di tabel history; sumber mempunyai revisi dan state tab masing-masing. Save/Validate tidak pernah enqueue. Tidak ada cache pemetaan lintas run. Snapshot berisi Google Spreadsheet ID dan revisi yang benar-benar diotorisasi; retry lama ditolak bila konfigurasi berubah. Sinkronisasi eksplisit membuat run baru dan menyimpan relasi otorisasi run asal.

`crawl_batches` menyimpan status induk dan snapshot WEB yang dibutuhkan; `crawl_batch_entries` menyimpan urutan/status/child run setiap WEB. WEB aktif yang belum siap mendapat run gagal dengan kesalahan konfigurasi. Worker melanjutkan WEB berikutnya. Retry per WEB/item tidak mengulang item sukses. Recheck adalah batch hanya baca yang menggunakan run lengkap tanpa mengubah hasil tulis.

Tiap enqueue/retry/Clear mengambil write gate tanggal SQLite sebelum cek konflik batch/run. Ini menutup race lintas tabel. Partial unique indexes menolak run/batch aktif ganda; idempotency key mencegah klik ulang identik. Worker memakai flock satu proses. Saat restart, RUNNING menjadi QUEUED dan entry RUNNING kembali WAITING. Item sukses dilewati; intent PREPARED direkonsiliasi dengan hasil read-back. Batch selesai yang terhenti sebelum rekonsiliasi membaca laporan tanpa replay tulisan.

Ledger dan kepemilikan transfer lama dipertahankan. Pada sinkronisasi sumber yang diotorisasi eksplisit ke tujuan yang sama, transaksi yang persis sama (baris/deskripsi/nominal) dapat mengadopsi slot terverifikasi sebelumnya, tanpa append. Transaksi berubah/hilang/pindah baris tetap konflik. Sel manual/formula/Note di luar ownership tidak diambil alih.

## Migrasi dan UI

Alembic `daf814b2a736` menambah tabel/kolom/index; tidak copy/drop tabel lama SQLite. Hanya periode dengan satu tujuan lama yang otomatis diikat. Dua URL lama memerlukan pilihan eksplisit. Downgrade destruktif ditolak; rollback memakai backup aplikasi/DB/frontend yang konsisten.

React mempertahankan tema navy/biru. Dashboard menampilkan status pemrosesan dan saldo terpisah, batch dipolling dari backend, kesalahan per item, resync tanggal/rentang eksplisit, dan Clear global. Sidebar memakai scroll internal, min-height:0, focus trap/Escape/close dan inert pada menu seluler tertutup. Help Center `/panduan` mempunyai 21 artikel/12 kategori, stable slug, search isi/keyword case-insensitive dan alias, FAQ, serta bantuan kontekstual. Akun admin lama tetap digunakan.

## Koreksi sumber dan kontrol V3

`engine/parser.py` memakai LAYOUTS tetap, bukan header() untuk membaca sumber. Day.resolve menerima jenis DEPO/QRIS dari snapshot dokumen. Day.metric dan diagnostik source_cell memakai kolom yang sama; untuk carry-forward, source_cell menunjuk sel saldo yang benar-benar dibaca. `runner.py` memakai satu Day per tab dan cache error sumber/tujuan, memisahkan genuine errors dari nol yang terverifikasi. Fee, transfer, palette, pemetaan tujuan dan formula rekonsiliasi tidak berubah.

`job_control.py` menambah claim terjaga gate tanggal, observasi pembatalan dari session DB terpisah, finalisasi canceled/failure, dan log fase. Endpoint POST `/runs/{id}/cancel` serta `/batches/{id}/cancel` memerlukan admin/CSRF. CANCEL_REQUESTED tetap aktif di gate dan indeks unik. Nullable cancel_requested_at/by serta current_phase ditambahkan melalui migrasi b7c31ef05a92 tanpa rebuild tabel lama.

Writer memeriksa Stop sebelum submit. Setelah submit, retry POST/read-back tetap bounded dan hasil diupayakan verifikasi; tidak dihentikan hanya karena Stop. Retry GET di luar verifikasi dapat dihentikan pada attempt berikutnya. Tidak ada kill HTTP tulis atau penghapusan intent. Retry mencakup FAILED/CANCELED/PENDING pada run terminal dan tetap melewati SUCCESS/PREVIEWED. Bila tulisan semua selesai tetapi finalisasi saldo dibatalkan/gagal, retry hanya melakukan finalisasi/pemeriksaan tanpa replay tulisan.

Tanggal massal tersimpan terpisah dari Record tanggal per WEB di Dashboard. Setiap row mengambil status untuk tanggalnya, membuang respons usang/aborted dan tidak menampilkan BALANCE tanggal sebelumnya saat loading tanggal baru. Dialog Start menangkap tanggal eksekusi yang dikonfirmasi. Riwayat/detail menampilkan tombol Stop/Cancel dan status dari backend.

Upgrade CLI `prepare-v3-upgrade --services-stopped` memfinalkan antrean lama setelah backup/migrasi dan sebelum worker baru menyala. Rollback helper memfinalkan antrean snapshot V2 melalui helper stdlib, menyalakan API saja dan meninggalkan worker berhenti untuk tinjauan operator. Rincian deployment: UPGRADE_V3.md.
