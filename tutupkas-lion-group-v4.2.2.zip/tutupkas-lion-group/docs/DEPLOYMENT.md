# Instalasi baru pada VPS

**Jika aplikasi sudah berjalan di `/opt/tutupkas/current` dan frontend di `/var/www/html`, gunakan [UPGRADE_V3.md](UPGRADE_V3.md). Jangan membuat ulang DB atau akun lama.**

## Instalasi pertama

Paket memerlukan Ubuntu/Debian, Python 3.10+ dan key Google yang sudah disimpan aman di `/home/aksesfinancebot/spreadsheet-robot/credentials/robot-key.json`. Aktifkan Sheets API pada project Google dan bagikan sumber serta salinan kerja tujuan kepada Service Account; tujuan memerlukan Editor. Validasi metadata hanya membuktikan akses baca.

Unggah ZIP serta checksum melalui SFTP, cek `sha256sum -c tutupkas-lion-group-v3.zip.sha256`, lalu:

```bash
unzip tutupkas-lion-group-v3.zip
cd tutupkas-lion-group
sudo bash deploy/install.sh
sudo bash deploy/admin.sh create-admin namaadmin
```

Password diminta tersembunyi; tidak ada password bawaan. Installer membuat user layanan `tutupkas`, menyiapkan rilis dan venv, memasang dependensi dengan hash, menjalankan Alembic, memasang unit API/worker, serta menerbitkan frontend siap pakai ke `/var/www/html/`. ACL tambahan hanya memberi user layanan akses baca key dan traversal parent; key, direktori robot dan ACL lain dipertahankan. Isi key tidak ditampilkan atau dimasukkan ke ZIP.

Periksa `/etc/tutupkas/app.env` sesuai domain/DB Anda. Jangan menaruh private key atau password di source. Path DB dan palet default ada di `/var/lib/tutupkas/`; file environment berizin 0640 root:tutupkas. Setelah mengganti environment, restart kedua layanan. Cookie produksi harus Secure dan APP_ORIGIN harus persis origin HTTPS.

## Nginx yang sudah ada

Installer tidak mengubah Nginx/Certbot/sertifikat. Backup konfigurasi situs HTTPS yang berfungsi. Cocokkan `deploy/nginx-locations.conf` dengan server block yang sudah ada, lalu gabungkan root `/var/www/html`, location SPA dan proxy `/api/` seperlunya. Jangan membuat server/listen/SSL duplikat. Pertahankan sertifikat, renewal, redirect HTTP dan listener IPv4 aktual. Jika konfigurasi sudah benar, tidak perlu mengubahnya.

```bash
sudo nginx -t
# Hanya jika konfigurasi memang diubah:
sudo systemctl reload nginx
curl --fail http://127.0.0.1:8000/api/health
sudo systemctl is-active tutupkas-api tutupkas-worker
```

HTML SPA harus tidak di-cache lama (`Cache-Control: no-cache`/`no-store`), sementara aset hash boleh di-cache lama. Periksa nama aset yang disajikan, lalu hard refresh browser. Lihat prosedur cache pada panduan upgrade.

## Palet transfer

Gunakan warna RGB aktual dari Sheets API pada transaksi yang telah diperiksa, bukan tebakan screenshot. Buat JSON `approved_brown` dan `excluded_blue` berupa array triplet RGB 0..1. Jalankan `sudo bash deploy/admin.sh approve-palette /path/palet-yang-ditinjau.json`. CLI meminta konfirmasi palet aktual; pengaturan dan audit tersimpan di VPS. Jangan memakai palet contoh pengujian sebagai bukti warna workbook asli.

## Penggunaan pertama dan operasi

Masuk, daftarkan WEB, simpan sumber bulan yang benar, validasi, dan aktifkan tab. DOC DEPO/QRIS diisi sesuai sumber yang tersedia. Di Kas Kecil, simpan **satu** URL salinan kerja tujuan bulanan dan validasi. Lakukan Pratinjau, tinjau hasil, lalu Start yang Anda otorisasi. Uji formula, angka, Note QRIS dan retry pada salinan kerja tersebut; baca seluruh saldo WEB dan konsolidasi. Panduan di `/panduan` tersedia untuk operator.

Worker memproses satu WEB setiap saat; satu instance dijaga file lock. Tidak ada cron penarikan otomatis. Setelah crash, pekerjaan yang sebelumnya diotorisasi dilanjutkan dari item/intent yang tersimpan. Jangan menjalankan worker kedua dengan lock path lain untuk DB yang sama. Unit worker memakai TimeoutStopSec 600 agar penghentian memberi kesempatan item selesai.

Backup rutin dapat dibuat dengan `sudo bash deploy/admin.sh backup /var/lib/tutupkas/backups/NAMA-UNIK.sqlite3`. CLI memakai API backup SQLite dan integrity check. Jangan menyalin hanya file DB aktif tanpa memperhatikan WAL. Simpan backup serta konfigurasi secara privat dan uji pemulihannya. Jangan menghapus ledger untuk menyembunyikan konflik transfer.

Troubleshooting: gunakan `journalctl -u tutupkas-api -u tutupkas-worker -n 60 --no-pager`, Pusat Kesalahan dan panduan kontekstual. Log aplikasi tidak mencetak request body, password, private key atau exception Google mentah. Integrasi Google/VPS belum dijalankan dari lingkungan pengembang; jalankan smoke test dan verifikasi read-only dalam [UPGRADE_V3.md](UPGRADE_V3.md).
