"""V3 pembatalan persisten; kolom nullable dan indeks tanpa rebuild tabel lama."""
from alembic import op
import sqlalchemy as sa

revision = 'b7c31ef05a92'
down_revision = 'daf814b2a736'
branch_labels = None
depends_on = None


def upgrade():
    for table in ('task_runs', 'crawl_batches'):
        op.add_column(table, sa.Column('cancel_requested_at', sa.DateTime(), nullable=True))
        op.add_column(table, sa.Column('current_phase', sa.String(40), nullable=True))
        if op.get_bind().dialect.name == 'sqlite':
            op.execute(f'ALTER TABLE {table} ADD COLUMN cancel_requested_by INTEGER REFERENCES users(id)')
        else:
            op.add_column(table, sa.Column('cancel_requested_by', sa.Integer(), sa.ForeignKey('users.id', name='fk_cancel_'+table), nullable=True))
    for table, name, columns in [('task_runs','one_active_run',['website_id','selected_date','environment']),
                                 ('crawl_batches','one_active_batch_per_date',['selected_date'])]:
        op.drop_index(name, table_name=table)
        condition = sa.text("status IN ('QUEUED','RUNNING','CANCEL_REQUESTED')")
        op.create_index(name, table, columns, unique=True, sqlite_where=condition, postgresql_where=condition)


def downgrade():
    raise RuntimeError('Pulihkan backup V2 dan rilis sebelumnya sesuai UPGRADE_V3.md; riwayat tidak dihapus otomatis.')
