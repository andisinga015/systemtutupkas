"""Explicit half-month DEPO and monthly QRIS; preserve every source ID.

SQLite must rebuild the parent table to replace its anonymous unique constraint.
Do so in one explicit transaction with FK enforcement temporarily disabled on
this migration connection, then check every FK before committing. Deployment
stops both services and takes a consistent database backup beforehand.
"""
from contextlib import contextmanager

from alembic import op
import sqlalchemy as sa

revision='d422a61e908f'
down_revision='c92448ce233b'
branch_labels=None
depends_on=None

PERIOD_CHECK="(document_type = 'DEPO' AND source_period IN ('FIRST_HALF','SECOND_HALF','UNASSIGNED')) OR (document_type = 'QRIS' AND source_period = 'MONTHLY')"
OLD_UNIQUE='uq_source_documents_website_id_document_type_year_month'
NEW_UNIQUE='uq_source_documents_period'
NAMING={'uq':'uq_%(table_name)s_%(column_0_N_name)s'}


@contextmanager
def parent_rebuild():
    connection=op.get_bind()
    if connection.dialect.name!='sqlite':
        raise RuntimeError('Migrasi ini khusus SQLite; jangan menebak prosedur database lain.')
    with op.get_context().autocommit_block():
        connection.exec_driver_sql('PRAGMA foreign_keys=OFF')
        try:
            connection.exec_driver_sql('BEGIN IMMEDIATE')
            try:
                yield connection
                if connection.exec_driver_sql('PRAGMA foreign_key_check').first():
                    raise RuntimeError('Referensi sumber tidak utuh; migrasi dibatalkan.')
                connection.exec_driver_sql('COMMIT')
            except BaseException:
                connection.exec_driver_sql('ROLLBACK')
                raise
        finally:
            connection.exec_driver_sql('PRAGMA foreign_keys=ON')


def upgrade():
    connection=op.get_bind()
    if 'source_period' in {c['name'] for c in sa.inspect(connection).get_columns('source_documents')}:
        # A process may stop after the atomic parent-table commit but before
        # Alembic records the revision. Resume only that exact completed shape;
        # never stamp an unknown partial schema or assign periods by guessing.
        sql=connection.exec_driver_sql("SELECT sql FROM sqlite_master WHERE name='source_documents'").scalar()
        column=next(c for c in sa.inspect(connection).get_columns('source_documents') if c['name']=='source_period')
        invalid=connection.execute(sa.text("SELECT 1 FROM source_documents WHERE NOT ((document_type='DEPO' AND source_period='UNASSIGNED') OR (document_type='QRIS' AND source_period='MONTHLY')) LIMIT 1")).first()
        if (NEW_UNIQUE not in sql or 'ck_source_documents_period' not in sql or column['nullable'] or
                column['default'] is not None or invalid or connection.exec_driver_sql('PRAGMA foreign_key_check').first()):
            raise RuntimeError('Schema periode parsial/tidak dikenal. Worker tetap berhenti; pulihkan backup atau tinjau migrasi.')
        return
    with parent_rebuild() as connection:
        op.add_column('source_documents',sa.Column('source_period',sa.String(16),nullable=False,server_default='UNASSIGNED'))
        connection.execute(sa.text("UPDATE source_documents SET source_period='MONTHLY' WHERE document_type='QRIS'"))
        with op.batch_alter_table('source_documents',recreate='always',naming_convention=NAMING) as batch:
            batch.drop_constraint(OLD_UNIQUE,type_='unique')
            batch.alter_column('source_period',existing_type=sa.String(16),server_default=None)
            batch.create_unique_constraint(NEW_UNIQUE,['website_id','document_type','year','month','source_period'])
            batch.create_check_constraint('ck_source_documents_period',PERIOD_CHECK)


def downgrade():
    connection=op.get_bind()
    if connection.execute(sa.text("SELECT 1 FROM source_documents WHERE document_type='DEPO' AND source_period!='UNASSIGNED' LIMIT 1")).first():
        raise RuntimeError('downgrade destruktif ditolak: periode DOC A/B telah ditetapkan. Pulihkan backup beserta release lama.')
    with parent_rebuild():
        with op.batch_alter_table('source_documents',recreate='always',naming_convention=NAMING) as batch:
            batch.drop_constraint('ck_source_documents_period',type_='check')
            batch.drop_constraint(NEW_UNIQUE,type_='unique')
            batch.drop_column('source_period')
            batch.create_unique_constraint(OLD_UNIQUE,['website_id','document_type','year','month'])
