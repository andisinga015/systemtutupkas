"""Lazy Sheets wire fixture: only builds the exact requested API ranges."""
import json
import re
from datetime import date

from app.sheets import SheetsClient
from app.engine.types import Cell, column
from helpers import depo, marker


class RangeAPI(SheetsClient):
    def __init__(self, grid=None, history=0, empty=False, retain_calls=True):
        self.fixture = grid or depo()
        if empty:
            self.fixture.rows.extend([[Cell() for _ in range(self.fixture.width)] for _ in range(2)])
            marker(self.fixture,308,date(2026,10,18))
            marker(self.fixture,309,date(2026,10,19))
        self.history, self.calls = history, []
        self.count, self.largest, self.total_bytes = 0, 0, 0
        self.retain_calls = retain_calls
        self.cancel_check = lambda:None
        self.hook = lambda:None

    def properties(self):
        return {'sheetId':self.fixture.sheet_id,'title':self.fixture.title,
                'gridProperties':{'rowCount':self.history+len(self.fixture.rows),'columnCount':self.fixture.width}}

    def cell(self,r,c):
        if r >= self.history:
            return self.fixture.cell(r-self.history,c)
        if c == 0 and r % max(1,self.history//14) == 0 and r//max(1,self.history//14) < 14:
            return Cell(f'{r//max(1,self.history//14)+1}-Oct-2026',color=(0.,0.,0.))
        # Financial history that must not be materialized by the source reader.
        if c == 3:
            return Cell('HISTORICAL TRANSACTION',color=(1.,.6,0.))
        if c in (4,5,7,8,9,10,11):
            return Cell(10000000+r,formula='=SUM(E1:E9)' if c>8 else None)
        return Cell()

    def merges(self):
        return [{**m,'startRowIndex':m['startRowIndex']+self.history,
                 'endRowIndex':m['endRowIndex']+self.history} for m in self.fixture.merges]

    def decode(self,range_):
        match=re.fullmatch(r"'((?:[^']|'')*)'!([A-Z]+)(\d+):([A-Z]+)(\d+)",range_)
        assert match and match[1].replace("''", "'")==self.fixture.title,range_
        def col(text):
            n=0
            for x in text:n=n*26+ord(x)-64
            return n-1
        return int(match[3])-1,int(match[5])-1,col(match[2]),col(match[4])

    @staticmethod
    def raw(cell,fields):
        out={}
        if 'effectiveValue' in fields and cell.value is not None:
            kind='boolValue' if isinstance(cell.value,bool) else 'numberValue' if isinstance(cell.value,(int,float)) else 'stringValue'
            out['effectiveValue']={kind:cell.value}
        if 'userEnteredValue' in fields and cell.formula is not None:
            out['userEnteredValue']={'formulaValue':cell.formula}
        if 'note' in fields and cell.note:out['note']=cell.note
        fmt={}
        broad='effectiveFormat' in fields and 'effectiveFormat(' not in fields
        if ('backgroundColor' in fields or broad) and cell.color is not None:
            fmt['backgroundColor']=dict(zip(['red','green','blue'],cell.color))
        if ('numberFormat' in fields or broad) and cell.date_format:fmt['numberFormat']={'type':'DATE'}
        if broad:
            # Representative preformatted historical cells. V3 requests these
            # unrelated properties too; scoped V4 field masks exclude them.
            fmt.update({'textFormat':{'fontFamily':'Merriweather','fontSize':10,'bold':True,
                'foregroundColor':{'red':0,'green':0,'blue':0}},
                'borders':{side:{'style':'SOLID','color':{'red':0,'green':0,'blue':0}}
                    for side in ['top','bottom','left','right']},
                'horizontalAlignment':'CENTER','verticalAlignment':'MIDDLE','wrapStrategy':'CLIP',
                'padding':{'top':2,'bottom':2,'left':3,'right':3}})
        if fmt:out['effectiveFormat']=fmt
        return out

    def request(self,method,path,**kwargs):
        self.cancel_check()
        self.hook()
        assert method=='GET','Preview/source fixture must never write'
        p=kwargs.get('params',{})
        if 'ranges' not in p:
            reply={'sheets':[{'properties':self.properties()}]}
        elif path.endswith('/values:batchGet'):
            ranges=p['ranges']
            assert p['valueRenderOption']=='UNFORMATTED_VALUE'
            reply={'valueRanges':[]}
            for a1 in ranges:
                first,last,left,right=self.decode(a1)
                values=[[self.cell(r,c).value for c in range(left,right+1)] for r in range(first,last+1)]
                for row in values:
                    while row and row[-1] is None:row.pop()
                while values and not values[-1]:values.pop()
                reply['valueRanges'].append({'range':a1,'values':values})
        else:
            sheet={'data':[]}
            if 'properties' in p.get('fields',''):sheet['properties']={'sheetId':self.fixture.sheet_id}
            if 'merges' in p['fields']:sheet['merges']=self.merges()
            for a1 in p['ranges']:
                first,last,left,right=self.decode(a1)
                sheet['data'].append({'startRow':first,'startColumn':left,'rowData':[
                    {'values':[self.raw(self.cell(r,c),p['fields']) for c in range(left,right+1)]}
                    for r in range(first,last+1)]})
            reply={'sheets':[sheet]}
        size=len(json.dumps(reply,separators=(',',':')).encode())
        self.count+=1;self.largest=max(self.largest,size);self.total_bytes+=size
        if self.retain_calls:self.calls.append((path,p))
        return reply
