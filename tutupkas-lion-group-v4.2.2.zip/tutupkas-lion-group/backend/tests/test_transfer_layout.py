from datetime import date

import pytest

from app.engine.resolver import transfer_slots
from app.engine.types import Issue
from helpers import blank, put


def monthly_layout():
    # Mirrors the screenshot's shape, with variable absolute row/column offsets:
    # previous day's side total | four-bank detail section | current side total.
    g=blank('KET PENGIRIMAN',20,41)
    for col,day in [(1,14),(20,15),(39,16)]:
        put(g,1,col,float(day),color=(0.,0.,0.))
    for top,website in [(1,'VELBETT'),(11,'FANTASI')]:
        put(g,top,3,website)
        g.merges.append({'startRowIndex':top,'endRowIndex':top+1,'startColumnIndex':3,'endColumnIndex':19})
        put(g,top+7,20,'TOTAL')
        for col,bank in [(3,'BCA'),(7,'MANDIRI'),(11,'BRI'),(15,'BNI')]:
            put(g,top+2,col,bank)
            g.merges.append({'startRowIndex':top+2,'endRowIndex':top+3,'startColumnIndex':col,'endColumnIndex':col+2})
            put(g,top+7,col,'TOTAL')
            put(g,top+7,col+1,0,formula='=SUM(A1:A2)')
    return g


def test_monthly_day_number_with_side_totals_and_vertical_websites():
    g=monthly_layout()
    velbett=transfer_slots(g,'VELBETT',['VELBETT','FANTASI'],date(2026,10,15))
    fantasi=transfer_slots(g,'FANTASI',['VELBETT','FANTASI'],date(2026,10,15))
    assert velbett['BCA'][0]==(4,3,4)
    assert velbett['BNI'][-1]==(7,15,16)
    assert fantasi['BCA'][0]==(14,3,4)


def test_day_number_alone_cannot_authorize_a_transfer_region():
    g=monthly_layout()
    put(g,8,20,'')
    with pytest.raises(Issue) as err:
        transfer_slots(g,'VELBETT',['VELBETT','FANTASI'],date(2026,10,15))
    assert err.value.code=='TRANSFER_LAYOUT_AMBIGUOUS'


def test_previous_day_boundary_must_exist_and_be_unambiguous():
    g=monthly_layout()
    put(g,1,1,13,color=(0.,0.,0.))
    with pytest.raises(Issue):
        transfer_slots(g,'VELBETT',['VELBETT','FANTASI'],date(2026,10,15))
    put(g,1,2,15,color=(0.,0.,0.))
    with pytest.raises(Issue):
        transfer_slots(g,'VELBETT',['VELBETT','FANTASI'],date(2026,10,15))

