"""Exact document/revision source routing, with all Google access isolated."""
from copy import deepcopy
from datetime import date
from uuid import uuid4

import pytest
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.engine.runner import process_run
from app.models import (AuditLog,DestinationMapping,Run,RunItem,SourceBinding,SourceDocument,
    SourceIdentity,SourceRevision,SourceSheet,SourceSnapshot,WriteLedger)
from app.source_periods import depo_period
from app.workflow import create_run,current_source_signature,is_current_run,make_snapshot,source_configuration
from helpers import DAY,DEPO_NAME,marker,put
from test_engine import configured,start


def save_doc(logged,site,period,spreadsheet,year=2026,month=10):
    return logged.put(f"/api/websites/{site['id']}/sources",json={'year':year,'month':month,
        'document_type':'QRIS' if period=='MONTHLY' else 'DEPO','source_period':period,
        'spreadsheet_url':f'https://docs.google.com/spreadsheets/d/{spreadsheet}/edit'})


def activate(logged,doc,names=None):
    result=logged.post(f"/api/sources/{doc['id']}/validate",json={'source_revision_id':doc['active_revision_id']})
    assert result.status_code==200 and result.json()['document']['validation_status']=='VALID',result.text
    tabs=logged.get(f"/api/sources/{doc['id']}/tabs").json()
    result=logged.post(f"/api/sources/{doc['id']}/tabs",json={'ids':[t['id'] for t in tabs if names is None or t['tab_name'] in names],
        'source_revision_id':doc['active_revision_id'],'is_active':True})
    assert result.status_code==200,result.text
    return result.json()


def dual_world(logged,db,monkeypatch,tmp_path):
    site,fake=configured(logged,db,monkeypatch,tmp_path)
    fake.documents['depo-b-document-12345']=deepcopy(fake.documents['depo-document-12345'])
    b=save_doc(logged,site,'SECOND_HALF','depo-b-document-12345').json();activate(logged,b)
    docs={d['source_period']:d for d in logged.get(f"/api/websites/{site['id']}/sources?year=2026&month=10").json()}
    return site,fake,docs


def financial_world(logged,db,monkeypatch,tmp_path,selected):
    period=depo_period(selected)
    site,fake=configured(logged,db,monkeypatch,tmp_path,source_period=period)
    for doc in ('depo-document-12345','qris-document-12345'):
        for grid in fake.documents[doc].values():
            for row,offset in ([(290,0),(306,1),(307,2)] if doc.startswith('depo') else [(83,0),(88,1),(89,2)]):
                marker(grid,row,date(selected.year,selected.month,selected.day+offset))
    for grid in fake.documents['destination-copy-12345'].values():
        for row in grid.rows:
            for cell in row:
                if cell.value=='15-Oct-2026':cell.value=f'{selected.day}-Oct-2026'
    fake.rebuild_mapping()
    unused='FIRST_HALF' if period=='SECOND_HALF' else 'SECOND_HALF'
    fake.documents['unused-half-document-12345']=deepcopy(fake.documents['depo-document-12345'])
    other=save_doc(logged,site,unused,'unused-half-document-12345').json();activate(logged,other)
    fake.reads.clear();fake.writes.clear()
    return site,fake,other


@pytest.mark.parametrize('selected,expected',[
    ('2026-10-01','FIRST_HALF'),('2026-10-15','FIRST_HALF'),('2026-10-16','SECOND_HALF'),
    ('2026-10-18','SECOND_HALF'),('2026-02-28','SECOND_HALF'),('2028-02-29','SECOND_HALF'),
    ('2026-04-30','SECOND_HALF'),('2026-10-31','SECOND_HALF'),('2028-02-15','FIRST_HALF'),
    ('2028-02-16','SECOND_HALF')])
def test_calendar_routing_selects_exactly_one_depo_and_monthly_qris(logged,db,monkeypatch,tmp_path,selected,expected):
    site,fake,docs=dual_world(logged,db,monkeypatch,tmp_path);selected=date.fromisoformat(selected)
    if (selected.year,selected.month)!=(2026,10):
        for period,spreadsheet in (('FIRST_HALF','depo-document-12345'),('SECOND_HALF','depo-b-document-12345'),('MONTHLY','qris-document-12345')):
            doc=save_doc(logged,site,period,spreadsheet,selected.year,selected.month).json();activate(logged,doc)
    fake.reads.clear()
    sources,_=source_configuration(db,site['id'],selected)
    assert [d['source_period'] for d in sources]==[expected,'MONTHLY']
    assert len([d for d in sources if d['type']=='DEPO'])==1
    assert sources[0]['spreadsheet_id']==('depo-document-12345' if expected=='FIRST_HALF' else 'depo-b-document-12345')
    assert not fake.reads


@pytest.mark.parametrize('period',['FIRST_HALF','SECOND_HALF','MONTHLY'])
def test_edit_validate_refresh_only_touches_one_document_and_history(logged,db,monkeypatch,tmp_path,period):
    site,fake,docs=dual_world(logged,db,monkeypatch,tmp_path)
    protected={d.id:(d.active_revision_id,d.spreadsheet_url,d.validation_status) for d in db.scalars(select(SourceDocument)) if d.id!=docs[period]['id']}
    protected_tabs={t.id:(t.source_revision_id,t.tab_name,t.is_active,t.is_available) for t in db.scalars(
        select(SourceSheet).where(SourceSheet.source_document_id!=docs[period]['id']))}
    mapping=[(m.id,m.state,deepcopy(m.evidence)) for m in db.scalars(select(DestinationMapping))]
    own=docs[period];new_id='replacement-period-document-12345'
    fake.documents[new_id]=deepcopy(fake.documents[own['spreadsheet_id']])
    first=save_doc(logged,site,period,new_id);assert first.status_code==200
    second=save_doc(logged,site,period,new_id);assert first.json()==second.json()
    updated=second.json();assert updated['id']==own['id'] and updated['active_revision_id']!=own['active_revision_id']
    assert not logged.get(f"/api/sources/{own['id']}/tabs").json()
    assert logged.post(f"/api/sources/{own['id']}/validate",json={'source_revision_id':updated['active_revision_id']}).status_code==200
    tabs=logged.post(f"/api/sources/{own['id']}/tabs/refresh",json={'source_revision_id':updated['active_revision_id']}).json()
    assert tabs and all(not t['is_active'] for t in tabs)
    assert all((db.get(SourceDocument,id).active_revision_id,db.get(SourceDocument,id).spreadsheet_url,db.get(SourceDocument,id).validation_status)==value for id,value in protected.items())
    assert all((db.get(SourceSheet,id).source_revision_id,db.get(SourceSheet,id).tab_name,
        db.get(SourceSheet,id).is_active,db.get(SourceSheet,id).is_available)==value for id,value in protected_tabs.items())
    assert [(m.id,m.state,m.evidence) for m in db.scalars(select(DestinationMapping))]==mapping
    history=logged.get(f"/api/sources/{own['id']}/history").json()
    assert len(history)==2 and all(r['source_period']==period and r['website_id']==site['id'] for r in history)


@pytest.mark.parametrize('kind,period', [('DEPO','MONTHLY'),('QRIS','FIRST_HALF'),('QRIS','SECOND_HALF'),('QRIS','UNASSIGNED'),('DEPO','UNASSIGNED'),('DEPO','WRONG')])
def test_invalid_or_migration_only_source_period_cannot_be_saved(logged,kind,period):
    site=logged.post('/api/websites',json={'display_name':'VELBETT','slug':'velbett'}).json()
    result=logged.put(f"/api/websites/{site['id']}/sources",json={'year':2026,'month':10,'document_type':kind,
        'source_period':period,'spreadsheet_url':'https://docs.google.com/spreadsheets/d/valid-source-12345/edit'})
    assert result.status_code==422


def test_missing_period_is_rejected_without_guessing(logged):
    site=logged.post('/api/websites',json={'display_name':'VELBETT','slug':'velbett'}).json()
    assert logged.put(f"/api/websites/{site['id']}/sources",json={'year':2026,'month':10,'document_type':'DEPO',
        'spreadsheet_url':'https://docs.google.com/spreadsheets/d/valid-source-12345/edit'}).status_code==422


@pytest.mark.parametrize('source,target,active',[
    ('FIRST_HALF','SECOND_HALF',True),('SECOND_HALF','FIRST_HALF',False),('MONTHLY','FIRST_HALF',False),
    ('FIRST_HALF','MONTHLY',True),('SECOND_HALF','MONTHLY',True)])
def test_tab_ids_are_bound_to_one_exact_document_even_with_equal_names(logged,db,monkeypatch,tmp_path,source,target,active):
    site,fake,docs=dual_world(logged,db,monkeypatch,tmp_path)
    tabs={p:logged.get(f"/api/sources/{d['id']}/tabs").json() for p,d in docs.items()}
    old={t.id:t.is_active for t in db.scalars(select(SourceSheet))}
    wrong=logged.post(f"/api/sources/{docs[target]['id']}/tabs",json={'ids':[tabs[source][0]['id']],
        'source_revision_id':docs[target]['active_revision_id'],'is_active':active})
    assert wrong.status_code==409 and {t.id:t.is_active for t in db.scalars(select(SourceSheet))}==old
    own=docs[source]
    actual=logged.post(f"/api/sources/{own['id']}/tabs",json={'ids':[t['id'] for t in tabs[source]],
        'source_revision_id':own['active_revision_id'],'is_active':active})
    assert actual.status_code==200 and all(t['is_active']==active for t in actual.json())
    assert all(db.get(SourceSheet,id).is_active==value for id,value in old.items() if id not in {t['id'] for t in tabs[source]})
    if source!='MONTHLY' and target!='MONTHLY':
        a=db.get(SourceBinding,tabs[source][0]['id']);b=db.get(SourceBinding,tabs[target][0]['id'])
        assert db.get(SourceIdentity,a.identity_id).lineage!=db.get(SourceIdentity,b.identity_id).lineage


@pytest.mark.parametrize('action',['get','activate','deactivate','refresh','validate'])
def test_stale_revision_requests_are_rejected_without_touching_new_revision(logged,db,monkeypatch,tmp_path,action):
    site,fake,docs=dual_world(logged,db,monkeypatch,tmp_path);old=docs['FIRST_HALF']
    tabs=logged.get(f"/api/sources/{old['id']}/tabs").json()
    fake.documents['changed-source-document-12345']=deepcopy(fake.documents[old['spreadsheet_id']])
    new=save_doc(logged,site,'FIRST_HALF','changed-source-document-12345').json()
    if action=='get':result=logged.get(f"/api/sources/{old['id']}/tabs?source_revision_id={old['active_revision_id']}")
    else:
        suffix='/tabs' if action in ('activate','deactivate') else '/tabs/refresh' if action=='refresh' else '/validate'
        body={'source_revision_id':old['active_revision_id']}
        if action in ('activate','deactivate'):body.update(ids=[t['id'] for t in tabs],is_active=action=='activate')
        result=logged.post(f"/api/sources/{old['id']}"+suffix,json=body)
    assert result.status_code==409
    assert db.get(SourceDocument,new['id']).validation_status=='UNVALIDATED'
    assert not logged.get(f"/api/sources/{old['id']}/tabs").json()
    assert logged.post(f"/api/sources/{old['id']}/tabs",json={'ids':[t['id'] for t in tabs],'is_active':True}).status_code==409


@pytest.mark.parametrize('action',['validate','tabs/refresh'])
def test_metadata_response_from_previous_revision_cannot_mark_new_url_valid(logged,db,monkeypatch,tmp_path,action):
    site,fake,docs=dual_world(logged,db,monkeypatch,tmp_path);doc=docs['FIRST_HALF'];raw=fake.metadata
    def changed(spreadsheet):
        value=raw(spreadsheet)
        with Session(db.get_bind()) as other:
            target=other.get(SourceDocument,doc['id']);target.spreadsheet_id='new-actual-document-12345';target.validation_status='UNVALIDATED'
            other.commit()
        return value
    fake.metadata=changed
    response=logged.post(f"/api/sources/{doc['id']}/{action}",json={'source_revision_id':doc['active_revision_id']})
    assert response.status_code==409,response.text
    assert db.get(SourceDocument,doc['id']).validation_status=='UNVALIDATED'


def test_new_tabs_months_and_url_revisions_stay_inactive_with_accurate_counts(logged,db,monkeypatch,tmp_path):
    site,fake,docs=dual_world(logged,db,monkeypatch,tmp_path);doc=docs['FIRST_HALF']
    old=logged.get(f"/api/sources/{doc['id']}/tabs").json()
    extra=deepcopy(fake.documents[doc['spreadsheet_id']][DEPO_NAME]);extra.sheet_id=99;extra.title='WD BCA / NEW ACCOUNT'
    fake.documents[doc['spreadsheet_id']][extra.title]=extra
    tabs=logged.post(f"/api/sources/{doc['id']}/tabs/refresh").json()
    assert not next(t for t in tabs if t['tab_name']==extra.title)['is_active']
    del fake.documents[doc['spreadsheet_id']][DEPO_NAME]
    assert logged.post(f"/api/sources/{doc['id']}/tabs/refresh").status_code==200
    nov=save_doc(logged,site,'FIRST_HALF',doc['spreadsheet_id'],month=11).json()
    assert logged.post(f"/api/sources/{nov['id']}/validate").status_code==200
    assert all(not t['is_active'] for t in logged.get(f"/api/sources/{nov['id']}/tabs").json())
    records=logged.get(f"/api/websites/{site['id']}/sources?year=2026&month=10").json()
    own=next(d for d in records if d['id']==doc['id'])
    assert own['tab_counts']=={'active':0,'inactive':1,'unavailable':1}
    dashboard=logged.get('/api/dashboard').json()
    current=list(db.scalars(select(SourceSheet).join(SourceDocument,SourceSheet.source_document_id==SourceDocument.id)
        .where(SourceSheet.source_revision_id==SourceDocument.active_revision_id)))
    assert dashboard['active_tabs']==sum(t.is_active and t.is_available for t in current)
    assert dashboard['inactive_tabs']==sum(not t.is_active and t.is_available for t in current)
    assert not db.get(SourceSheet,old[0]['id']).is_active


@pytest.mark.parametrize('selected',['2026-10-10','2026-10-18'])
def test_run_reads_and_snapshots_only_selected_active_document_and_monthly_qris(logged,db,monkeypatch,tmp_path,selected):
    selected=date.fromisoformat(selected);site,fake,unused=financial_world(logged,db,monkeypatch,tmp_path,selected)
    run=db.get(Run,start(logged,site,selected_date=str(selected))['id']);process_run(db,run,fake)
    assert run.status=='SUCCESS',logged.get(f'/api/runs/{run.id}').json()['errors']
    assert [d['source_period'] for d in run.config_snapshot['sources']]==[depo_period(selected),'MONTHLY']
    assert len([i for i in db.scalars(select(RunItem).where(RunItem.run_id==run.id)) if i.metric_type!='reconciliation'])==18
    assert not db.scalar(select(RunItem.id).where(RunItem.run_id==run.id,RunItem.source_document_id==unused['id']))
    snapshots=list(db.scalars(select(SourceSnapshot).where(SourceSnapshot.run_id==run.id)))
    assert len(snapshots)==3 and all(s.source_document_id!=unused['id'] for s in snapshots)
    assert all(s.provenance['source_period'] in (depo_period(selected),'MONTHLY') for s in snapshots)
    assert not any(doc=='unused-half-document-12345' for doc,title in fake.reads)
    assert fake.documents['destination-copy-12345']['BIAYA'].cell(2,1).value==5500


@pytest.mark.parametrize('selected,tab',[
    ('2026-10-10',DEPO_NAME),('2026-10-18',DEPO_NAME),('2026-10-10','QRIS E-POWER'),('2026-10-18','QRIS E-POWER')])
def test_selective_retry_fetches_fresh_raw_from_exact_period_only(logged,db,monkeypatch,tmp_path,selected,tab):
    selected=date.fromisoformat(selected);site,fake,unused=financial_world(logged,db,monkeypatch,tmp_path,selected)
    fake.fail_tabs.add(tab)
    run=db.get(Run,start(logged,site,selected_date=str(selected))['id']);process_run(db,run,fake)
    failed=db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.source_tab_name==tab,RunItem.metric_type=='deposit'))
    assert failed.status=='FAILED'
    preserved={i.id:deepcopy(i.result) for i in db.scalars(select(RunItem).where(RunItem.run_id==run.id,RunItem.status=='SUCCESS'))}
    snapshot_ids=set(db.scalars(select(SourceSnapshot.id).where(SourceSnapshot.run_id==run.id)))
    mapping=[(m.id,m.state) for m in db.scalars(select(DestinationMapping))]
    fake.fail_tabs.clear();fake.reads.clear();fake.writes.clear()
    source='depo-document-12345' if tab==DEPO_NAME else 'qris-document-12345'
    put(fake.documents[source][tab],305 if tab==DEPO_NAME else 87,9 if tab==DEPO_NAME else 8,12345)
    response=logged.post(f'/api/runs/{run.id}/retry',json={'item_ids':[failed.id]});assert response.status_code==202,response.text
    process_run(db,run,fake)
    assert failed.status=='SUCCESS' and failed.result['plan'][0]['proposed']['value']==12345
    assert all(db.get(RunItem,id).result==value for id,value in preserved.items())
    assert {(doc,title) for doc,title in fake.reads if doc in ('depo-document-12345','qris-document-12345','unused-half-document-12345')}=={(source,tab)}
    assert [(m.id,m.state) for m in db.scalars(select(DestinationMapping))]==mapping
    assert set(db.scalars(select(SourceSnapshot.id).where(SourceSnapshot.run_id==run.id)))>snapshot_ids


@pytest.mark.parametrize('selected,other',[('2026-10-10','SECOND_HALF'),('2026-10-18','FIRST_HALF')])
def test_unused_half_changes_do_not_stale_run_or_source_context(logged,db,monkeypatch,tmp_path,selected,other):
    site,fake,docs=dual_world(logged,db,monkeypatch,tmp_path);selected=date.fromisoformat(selected)
    snapshot=make_snapshot(db,site['id'],selected)
    run=create_run(db,site['id'],selected,False,str(uuid4()),1,snapshot);db.commit()
    before=current_source_signature(db,site['id'],selected)
    fake.documents['other-half-edited-12345']=deepcopy(fake.documents[docs[other]['spreadsheet_id']])
    assert save_doc(logged,site,other,'other-half-edited-12345').status_code==200
    assert current_source_signature(db,site['id'],selected)==before
    from app.models import Destination
    assert is_current_run(db,run,db.scalar(select(Destination)))
    selected_period=depo_period(selected)
    fake.documents['selected-half-edited-12345']=deepcopy(fake.documents[docs[selected_period]['spreadsheet_id']])
    assert save_doc(logged,site,selected_period,'selected-half-edited-12345').status_code==200
    assert current_source_signature(db,site['id'],selected)!=before
    assert not is_current_run(db,run,db.scalar(select(Destination)))


@pytest.mark.parametrize('period,day',[('FIRST_HALF',10),('SECOND_HALF',18)])
def test_missing_required_half_never_falls_back_or_fabricates_zero(logged,db,monkeypatch,tmp_path,period,day):
    site,fake=configured(logged,db,monkeypatch,tmp_path,source_period='SECOND_HALF' if period=='FIRST_HALF' else 'FIRST_HALF')
    response=logged.post('/api/runs',json={'website_id':site['id'],'selected_date':f'2026-10-{day}','preview':False,'idempotency_key':str(uuid4())})
    assert response.status_code==409 and ('DOC A' if period=='FIRST_HALF' else 'DOC B') in response.text
    assert not list(db.scalars(select(Run))) and not list(db.scalars(select(WriteLedger)))


def test_legacy_unassigned_requires_explicit_assignment_preserving_identity_and_tab_history(logged,db,monkeypatch,tmp_path):
    site,fake=configured(logged,db,monkeypatch,tmp_path)
    doc=db.scalar(select(SourceDocument).where(SourceDocument.document_type=='DEPO'));doc.source_period='UNASSIGNED';db.commit()
    before={t.id:(t.source_document_id,t.source_revision_id,t.is_active,t.is_available) for t in db.scalars(select(SourceSheet))}
    revs=[(r.id,r.spreadsheet_id) for r in db.scalars(select(SourceRevision))]
    assert logged.post('/api/runs',json={'website_id':site['id'],'selected_date':'2026-10-18','idempotency_key':str(uuid4())}).status_code==409
    body={'source_period':'SECOND_HALF','source_revision_id':doc.active_revision_id}
    result=logged.post(f'/api/sources/{doc.id}/assign-period',json=body);assert result.status_code==200,result.text
    assert result.json()['id']==doc.id and result.json()['source_period']=='SECOND_HALF'
    assert [(r.id,r.spreadsheet_id) for r in db.scalars(select(SourceRevision))]==revs
    assert {t.id:(t.source_document_id,t.source_revision_id,t.is_active,t.is_available) for t in db.scalars(select(SourceSheet))}==before
    assert len(list(db.scalars(select(SourceDocument).where(SourceDocument.document_type=='DEPO'))))==1
    assert logged.post(f'/api/sources/{doc.id}/assign-period',json=body).status_code==200
    assert len(list(db.scalars(select(AuditLog).where(AuditLog.action=='assign_legacy_source_period'))))==1
    assert logged.post(f'/api/sources/{doc.id}/assign-period',json={**body,'source_period':'FIRST_HALF'}).status_code==409
    assert [d['source_period'] for d in source_configuration(db,site['id'],date(2026,10,18))[0]]==['SECOND_HALF','MONTHLY']


@pytest.mark.parametrize('target',['FIRST_HALF','SECOND_HALF'])
def test_legacy_assignment_to_either_half_preserves_disabled_tabs(logged,db,monkeypatch,tmp_path,target):
    site,fake=configured(logged,db,monkeypatch,tmp_path)
    doc=db.scalar(select(SourceDocument).where(SourceDocument.document_type=='DEPO'));doc.source_period='UNASSIGNED'
    tab=db.scalar(select(SourceSheet).where(SourceSheet.source_document_id==doc.id));tab.is_active=False;db.commit()
    assert logged.post(f'/api/sources/{doc.id}/assign-period',json={'source_period':target,'source_revision_id':doc.active_revision_id}).status_code==200
    assert not db.get(SourceSheet,tab.id).is_active


def test_occupied_period_and_stale_legacy_assignment_do_not_replace_any_source(logged,db,monkeypatch,tmp_path):
    site,fake,docs=dual_world(logged,db,monkeypatch,tmp_path)
    legacy=db.get(SourceDocument,docs['SECOND_HALF']['id']);legacy.source_period='UNASSIGNED';db.commit()
    body={'source_period':'FIRST_HALF','source_revision_id':legacy.active_revision_id}
    assert logged.post(f'/api/sources/{legacy.id}/assign-period',json=body).status_code==409
    assert legacy.source_period=='UNASSIGNED' and db.get(SourceDocument,docs['FIRST_HALF']['id']).source_period=='FIRST_HALF'
    assert logged.post(f'/api/sources/{legacy.id}/assign-period',json={'source_period':'SECOND_HALF','source_revision_id':-1}).status_code==409
    assert logged.post(f"/api/sources/{docs['MONTHLY']['id']}/assign-period",json={'source_period':'FIRST_HALF','source_revision_id':docs['MONTHLY']['active_revision_id']}).status_code==409


def test_crawl_all_isolates_website_missing_doc_b_without_stopping_valid_website(logged,db,monkeypatch,tmp_path):
    from app.batches import enqueue_batch,process_batch
    from app.models import Website
    site,fake,unused=financial_world(logged,db,monkeypatch,tmp_path,date(2026,10,18))
    other=logged.post('/api/websites',json={'display_name':'FANTASI','slug':'fantasi'}).json()
    fake.documents['fantasi-a-document-12345']=deepcopy(fake.documents['depo-document-12345'])
    a=save_doc(logged,other,'FIRST_HALF','fantasi-a-document-12345').json();activate(logged,a)
    batch=enqueue_batch(db,date(2026,10,18),False,str(uuid4()),1);db.commit();process_batch(db,batch,fake)
    good=db.scalar(select(Run).where(Run.batch_id==batch.id,Run.website_id==site['id']))
    bad=db.scalar(select(Run).where(Run.batch_id==batch.id,Run.website_id==other['id']))
    assert good.status=='SUCCESS' and bad.status=='FAILED'
    assert not bad.config_snapshot['sources']
    assert all(d['id']!=a['id'] for d in good.config_snapshot['sources'])
    assert not any(doc=='fantasi-a-document-12345' for doc,title in fake.reads)


@pytest.mark.parametrize('problem',['inactive','unavailable','identity_conflict'])
def test_required_period_with_no_usable_tabs_is_not_satisfied_by_other_half_or_qris(logged,db,monkeypatch,tmp_path,problem):
    site,fake,docs=dual_world(logged,db,monkeypatch,tmp_path);doc=docs['SECOND_HALF']
    tab=db.scalar(select(SourceSheet).where(SourceSheet.source_document_id==doc['id']))
    if problem=='inactive':tab.is_active=False
    elif problem=='unavailable':tab.is_available=False
    else:db.get(SourceBinding,tab.id).status='IDENTITY_CHANGED'
    db.commit()
    response=logged.post('/api/runs',json={'website_id':site['id'],'selected_date':'2026-10-18','idempotency_key':str(uuid4())})
    assert response.status_code==409
    assert not list(db.scalars(select(Run))) and not list(db.scalars(select(WriteLedger)))
    if problem=='identity_conflict':
        assert logged.post(f"/api/sources/{doc['id']}/tabs",json={'ids':[tab.id],'is_active':True}).status_code==409


@pytest.mark.parametrize('qris',['absent','invalid'])
def test_optional_qris_is_not_confused_with_invalid_configured_qris(logged,db,monkeypatch,tmp_path,qris):
    site,fake=configured(logged,db,monkeypatch,tmp_path)
    doc=db.scalar(select(SourceDocument).where(SourceDocument.document_type=='QRIS'))
    if qris=='absent':doc.month=11
    else:doc.validation_status='FAILED'
    db.commit()
    response=logged.post('/api/runs',json={'website_id':site['id'],'selected_date':str(DAY),'idempotency_key':str(uuid4())})
    if qris=='invalid':assert response.status_code==409 and 'QRIS' in response.text
    else:
        assert response.status_code==202,response.text
        run=db.get(Run,response.json()['id']);process_run(db,run,fake)
        assert run.status=='SUCCESS' and len(run.config_snapshot['sources'])==1
        assert not db.scalar(select(RunItem.id).where(RunItem.run_id==run.id,RunItem.source_document_id==doc.id))


def test_source_date_index_never_reuses_other_documents_rows_or_identity(logged,db,monkeypatch,tmp_path):
    from app.engine.types import Cell
    from app.models import SourceDateIndex
    from app.source_index import indexed_source_day
    from range_api import RangeAPI
    site,fake,docs=dual_world(logged,db,monkeypatch,tmp_path)
    a=next(d for d in source_configuration(db,site['id'],DAY)[0] if d['type']=='DEPO')
    b=next(d for d in source_configuration(db,site['id'],date(2026,10,18))[0] if d['type']=='DEPO')
    grid=fake.documents[b['spreadsheet_id']][DEPO_NAME]
    for r,day in [(290,18),(306,19),(307,20)]:marker(grid,r,date(2026,10,day))
    grid.rows[:0]=[[Cell() for _ in range(grid.width)] for _ in range(50)]
    grid.merges=[{**m,'startRowIndex':m['startRowIndex']+50,'endRowIndex':m['endRowIndex']+50} for m in grid.merges]
    apis=[RangeAPI(fake.documents[d['spreadsheet_id']][DEPO_NAME]) for d in (a,b)]
    for api in apis:api.content_revision=lambda doc:'same-file-version-token'
    first=indexed_source_day(db,apis[0],a,DEPO_NAME,DAY,a['identities'][DEPO_NAME])
    preserved=[(r.id,r.selected_date,r.separator_row,deepcopy(r.evidence)) for r in db.scalars(select(SourceDateIndex).where(SourceDateIndex.identity_id==a['identities'][DEPO_NAME]['id']))]
    second=indexed_source_day(db,apis[1],b,DEPO_NAME,date(2026,10,18),b['identities'][DEPO_NAME])
    assert first.start==290 and second.start==340 and first.end+50==second.end
    assert a['identities'][DEPO_NAME]['id']!=b['identities'][DEPO_NAME]['id']
    assert [(r.id,r.selected_date,r.separator_row,r.evidence) for r in db.scalars(select(SourceDateIndex).where(SourceDateIndex.identity_id==a['identities'][DEPO_NAME]['id']))]==preserved
    warmed=indexed_source_day(db,apis[0],a,DEPO_NAME,DAY,a['identities'][DEPO_NAME])
    assert warmed.start==290 and warmed.metric('SALDO')==2355000


@pytest.mark.parametrize('assignment',['FIRST_HALF','SECOND_HALF'])
def test_historical_item_retry_requires_explicit_assignment_to_its_correct_period(logged,db,monkeypatch,tmp_path,assignment):
    from writer_fixture import configure_writer,SELECTED
    site,fake,apis=configure_writer(logged,db,monkeypatch,tmp_path,heavy=False,batch=True)
    fake.fail_tabs.add(DEPO_NAME)
    run=db.get(Run,start(logged,site,selected_date=str(SELECTED))['id']);process_run(db,run,fake)
    failed=db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.source_tab_name==DEPO_NAME,RunItem.metric_type=='deposit'))
    total=db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type=='expense_total'))
    snapshot=deepcopy(run.config_snapshot)
    for d in snapshot['sources']:d.pop('source_period',None)
    run.config_snapshot=snapshot
    doc=db.get(SourceDocument,failed.source_document_id);doc.source_period='UNASSIGNED';db.commit()
    old=deepcopy(run.config_snapshot)
    assert logged.get(f'/api/runs/{run.id}').status_code==200 and run.config_snapshot==old
    assert logged.post(f'/api/runs/{run.id}/retry',json={'item_ids':[failed.id]}).status_code==409
    assert logged.post(f'/api/runs/{run.id}/retry',json={'item_ids':[total.id]}).status_code==409
    preserved={i.id:deepcopy(i.result) for i in db.scalars(select(RunItem).where(RunItem.run_id==run.id,RunItem.status=='SUCCESS'))}
    response=logged.post(f'/api/sources/{doc.id}/assign-period',json={'source_period':assignment,'source_revision_id':doc.active_revision_id})
    assert response.status_code==200,response.text
    fake.fail_tabs.clear();fake.reads.clear();fake.writes.clear()
    retry=logged.post(f'/api/runs/{run.id}/retry',json={'item_ids':[failed.id]})
    if assignment=='FIRST_HALF':
        assert retry.status_code==409 and not fake.reads and not fake.writes
        assert logged.post(f'/api/runs/{run.id}/retry',json={'item_ids':[total.id]}).status_code==409
    else:
        assert retry.status_code==202,retry.text
        authorization=run.config_snapshot['item_source_authorizations'][str(failed.id)]
        assert authorization['document']['id']==doc.id and authorization['document']['source_period']=='SECOND_HALF'
        process_run(db,run,fake)
        assert failed.status=='SUCCESS'
        assert {(id,name) for id,name in fake.reads if id in ('depo-document-12345','qris-document-12345')}=={('depo-document-12345',DEPO_NAME)}
    assert all(db.get(RunItem,id).result==value for id,value in preserved.items())


def test_43_item_writer_keeps_v421_performance_with_ten_unused_active_doc_a_tabs():
    import json
    from pathlib import Path
    import subprocess
    import sys
    script=Path(__file__).parent/'performance/measure_v422_periods.py'
    result=subprocess.run([sys.executable,str(script)],capture_output=True,text=True)
    assert result.returncode==0,result.stderr
    data=json.loads(result.stdout)
    assert data['financial_plans']==43 and data['source_snapshots']==8
    assert data['unused_active_doc_a_tabs']==10 and data['unused_period_source_reads']==0
    assert data['selected_source_periods']==['SECOND_HALF','MONTHLY']
    assert data['destination_gets']==77 and data['destination_posts']==1
    assert data['destination_response_bytes']<=120000 and data['multi_megabyte_gets']==0
    assert data['output_fingerprint']=='32c0ec33ef1164c5d971b66a16d6cd74ab842e6155053b5a34e48a59fc93f095'
