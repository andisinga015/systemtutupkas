"""V4.2 source completeness, revision-bound navigation and proven identity."""
from copy import deepcopy
from datetime import timedelta
from uuid import uuid4

import pytest
from sqlalchemy import select

from app.engine.runner import process_run
from app.engine.types import Cell,Issue
from app.models import Run,RunItem,SourceDocument,SourceSnapshot,SourceIdentity,SourceBinding,SourceSheet,SourceDateIndex,WriteLedger
from app.snapshots import source_snapshot,unpack
from app.source_index import indexed_source_day
from app.workflow import source_configuration
from helpers import DAY,DEPO_NAME,marker,put
from range_api import RangeAPI
from test_engine import configured,start


def source_context(logged,db,monkeypatch,tmp_path):
    website,fake=configured(logged,db,monkeypatch,tmp_path)
    doc=next(d for d in source_configuration(db,website['id'],DAY)[0] if d['type']=='DEPO')
    return website,fake,doc,doc['identities'][DEPO_NAME]


def test_one_complete_snapshot_serves_every_normal_metric(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    calls=[];original=fake.source_day
    def read(*args):calls.append(args);return original(*args)
    fake.source_day=read
    run=start(logged,w);process_run(db,db.get(Run,run['id']),fake)
    assert db.get(Run,run['id']).status=='SUCCESS'
    assert len(calls)==3 and len(set((c[0],c[1]) for c in calls))==3
    snapshots=list(db.scalars(select(SourceSnapshot).where(SourceSnapshot.run_id==run['id'])))
    assert len(snapshots)==3 and all(s.state=='MAPPED' and s.checksum for s in snapshots)
    for s in snapshots:
        day=unpack(s.payload)
        assert day.selected==DAY and day.end+1==s.provenance['following_row']
        # No historical grids: only selected interval/necessary closing evidence.
        assert all(r>=day.start or c==11 for r,c,*rest in s.payload['rows'])


@pytest.mark.parametrize('kind,deposit,withdrawal,balance',[('DEPO',0,9399000,2355000),('QRIS',75342988,59804000,449057834)])
def test_snapshot_keeps_confirmed_fixed_source_columns(logged,db,monkeypatch,tmp_path,kind,deposit,withdrawal,balance):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    record=start(logged,w,preview=True);run=db.get(Run,record['id'])
    doc=next(d for d in run.config_snapshot['sources'] if d['type']==kind)
    tab=doc['tabs'][0]
    saved,day=source_snapshot(db,fake,run,doc,tab)
    restored=unpack(saved.payload)
    assert (restored.metric('Total'),restored.metric('Total WD'),restored.metric('SALDO'))==(deposit,withdrawal,balance)
    assert saved.state=='SNAPSHOT_READY' and saved.provenance['identity']['sheet_id']==day.grid.sheet_id


def test_incomplete_snapshot_is_not_consumed_and_retry_fetches_raw(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    record=start(logged,w);run=db.get(Run,record['id']);doc=run.config_snapshot['sources'][0];tab=doc['tabs'][0]
    fake.fail_tabs.add(tab)
    with pytest.raises(Issue):source_snapshot(db,fake,run,doc,tab)
    snapshot=db.scalar(select(SourceSnapshot));assert snapshot.state=='FAILED' and snapshot.payload is None
    before=len(fake.reads)
    with pytest.raises(Issue):source_snapshot(db,fake,run,doc,tab)
    assert len(fake.reads)==before
    fake.fail_tabs.clear()
    from app.retry_queue import enqueue
    item=db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.source_tab_name==tab))
    retry=enqueue(db,run,item,1);db.commit()
    saved,day=source_snapshot(db,fake,run,doc,tab,retry)
    assert saved.id!=snapshot.id and saved.retry_request_id==retry.id and len(fake.reads)>before


def test_source_snapshot_integrity_is_enforced(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);record=start(logged,w);run=db.get(Run,record['id'])
    doc=run.config_snapshot['sources'][0];tab=doc['tabs'][0]
    saved,_=source_snapshot(db,fake,run,doc,tab)
    saved.payload={**saved.payload,'end':saved.payload['end']-1};db.commit()
    with pytest.raises(Issue,match='Integritas'):source_snapshot(db,fake,run,doc,tab)


def test_forward_and_backward_date_index_uses_verified_boundaries(logged,db,monkeypatch,tmp_path):
    w,fake,doc,identity=source_context(logged,db,monkeypatch,tmp_path)
    api=RangeAPI(fake.documents[doc['spreadsheet_id']][DEPO_NAME],history=4000)
    api.content_revision=lambda _: 'v1'
    first=indexed_source_day(db,api,doc,DEPO_NAME,DAY,identity)
    cold=api.count;api.calls.clear();api.count=0
    following=indexed_source_day(db,api,doc,DEPO_NAME,DAY+timedelta(days=1),identity)
    assert first.end+1==following.start and following.metric('SALDO')==2355000
    assert api.count<cold/2
    assert all(not (api.decode(a1)[0]<following.start and api.decode(a1)[2]==0)
               for path,p in api.calls for a1 in p.get('ranges',[]) if path.endswith('/values:batchGet'))
    prior=indexed_source_day(db,api,doc,DEPO_NAME,DAY-timedelta(days=1),identity)
    assert prior.start<first.start and prior.end+1==first.start
    assert db.scalar(select(SourceDateIndex).where(SourceDateIndex.selected_date==DAY)).content_revision=='v1'


@pytest.mark.parametrize('change',['inserted_history','appended_current_date'])
def test_changed_revision_invalidates_unsafe_rows_then_rebuilds(logged,db,monkeypatch,tmp_path,change):
    w,fake,doc,identity=source_context(logged,db,monkeypatch,tmp_path)
    grid=deepcopy(fake.documents[doc['spreadsheet_id']][DEPO_NAME]);api=RangeAPI(grid,history=4000)
    version=['v1'];api.content_revision=lambda _:version[0]
    first=indexed_source_day(db,api,doc,DEPO_NAME,DAY,identity)
    if change=='inserted_history':api.history+=1
    else:
        grid.rows.insert(306,[Cell() for _ in range(grid.width)])
        for merge in grid.merges:
            if merge['startRowIndex']>=306:merge['startRowIndex']+=1;merge['endRowIndex']+=1
    version[0]='v2'
    with pytest.raises(Issue) as caught:indexed_source_day(db,api,doc,DEPO_NAME,DAY,identity)
    assert caught.value.code=='SOURCE_CHANGED'
    again=indexed_source_day(db,api,doc,DEPO_NAME,DAY,identity)
    assert again.end>first.end and {x.content_revision for x in db.scalars(select(SourceDateIndex))}=={'v2'}


@pytest.mark.parametrize('problem',['missing','duplicate','invalid_format'])
def test_index_does_not_guess_missing_duplicate_or_invalid_separators(logged,db,monkeypatch,tmp_path,problem):
    w,fake,doc,identity=source_context(logged,db,monkeypatch,tmp_path)
    grid=deepcopy(fake.documents[doc['spreadsheet_id']][DEPO_NAME])
    if problem=='missing':grid.rows[290][0]=Cell()
    elif problem=='duplicate':marker(grid,100,DAY)
    else:grid.rows[290][0]=Cell('15/xx/2026',color=(0.,0.,0.))
    api=RangeAPI(grid);api.content_revision=lambda _:'version'
    with pytest.raises(Issue) as caught:indexed_source_day(db,api,doc,DEPO_NAME,DAY,identity)
    assert caught.value.code=='DATE_NOT_FOUND'


def test_revision_unavailable_never_reuses_cached_navigation(logged,db,monkeypatch,tmp_path):
    w,fake,doc,identity=source_context(logged,db,monkeypatch,tmp_path)
    api=RangeAPI(fake.documents[doc['spreadsheet_id']][DEPO_NAME],history=4000)
    api.content_revision=lambda _:None
    indexed_source_day(db,api,doc,DEPO_NAME,DAY,identity);cold=api.count
    api.count=0
    indexed_source_day(db,api,doc,DEPO_NAME,DAY,identity)
    assert api.count==cold and not list(db.scalars(select(SourceDateIndex)))


def test_new_source_tab_is_inactive_and_does_not_rebuild_destination(logged,db,monkeypatch,tmp_path):
    w,fake,doc,identity=source_context(logged,db,monkeypatch,tmp_path)
    before=logged.get('/api/destinations').json()[0]['mapping']['id']
    clone=deepcopy(fake.documents[doc['spreadsheet_id']][DEPO_NAME]);clone.sheet_id=77;clone.title='WD BCA / NEW ACCOUNT'
    fake.documents[doc['spreadsheet_id']][clone.title]=clone
    tabs=logged.post(f"/api/sources/{doc['id']}/tabs/refresh").json()
    new=next(t for t in tabs if t['tab_name']==clone.title)
    assert not new['is_active'] and new['is_available']
    assert logged.get('/api/destinations').json()[0]['mapping']['id']==before
    assert logged.post(f"/api/sources/{doc['id']}/tabs",json={'ids':[new['id']],'is_active':True}).status_code==200
    assert db.get(SourceBinding,new['id']).identity_id!=identity['id']


def test_proven_rename_preserves_account_coordinates_and_transaction_lineage(logged,db,monkeypatch,tmp_path):
    w,fake,doc,identity=source_context(logged,db,monkeypatch,tmp_path)
    initial=start(logged,w);process_run(db,db.get(Run,initial['id']),fake)
    coordinates={(x.tab,x.address) for x in fake.writes};before=len(fake.writes)
    grid=fake.documents[doc['spreadsheet_id']].pop(DEPO_NAME);grid.title='WD BCA / JUDUL BARU'
    fake.documents[doc['spreadsheet_id']][grid.title]=grid
    tabs=logged.post(f"/api/sources/{doc['id']}/tabs/refresh").json()
    new=next(t for t in tabs if t['tab_name']==grid.title)
    assert not new['is_active'] and db.get(SourceBinding,new['id']).identity_id==identity['id']
    logged.post(f"/api/sources/{doc['id']}/tabs",json={'ids':[new['id']],'is_active':True})
    # A completed date must be explicitly reopened before another authorized Run.
    another=start(logged,w);process_run(db,db.get(Run,another['id']),fake)
    assert db.get(Run,another['id']).status=='SUCCESS'
    assert len(fake.writes)==before  # Ownership continuity; no repeated POST.
    results=logged.get(f"/api/runs/{another['id']}").json()['items']
    assert any(i['source_tab_name']==grid.title for i in results)
    assert all((p['tab'],p['cell']) in coordinates for i in results for p in (i['result'] or {}).get('plan',[]))


def test_deleted_and_recreated_same_name_requires_revalidation_and_new_identity(logged,db,monkeypatch,tmp_path):
    w,fake,doc,identity=source_context(logged,db,monkeypatch,tmp_path)
    fake.documents[doc['spreadsheet_id']][DEPO_NAME].sheet_id=999
    tabs=logged.post(f"/api/sources/{doc['id']}/tabs/refresh").json()
    tab=next(t for t in tabs if t['tab_name']==DEPO_NAME)
    assert not tab['is_active'] and db.get(SourceBinding,tab['id']).status=='IDENTITY_CHANGED'
    assert db.get(SourceDocument,doc['id']).validation_status=='FAILED'
    logged.post(f"/api/sources/{doc['id']}/validate")
    assert db.get(SourceBinding,tab['id']).identity_id!=identity['id']
    assert not db.get(SourceSheet,tab['id']).is_active


@pytest.mark.parametrize('reverse',[False,True])
def test_alias_signature_follows_active_name_priority_after_rename(reverse):
    from app.workflow import source_signature
    identity={'lineage':'physical-proof','names':['OLD','NEW']}
    doc={'id':1,'type':'DEPO','revision':1,'spreadsheet_id':'same','tabs':['OLD'],'identities':{'OLD':identity}}
    prior=source_signature([doc],{'OLD':'ACCOUNT A'})
    current={**doc,'tabs':['NEW'],'identities':{'OLD':identity,'NEW':identity}}
    pairs=[('NEW','ACCOUNT B'),('OLD','ACCOUNT A')]
    if reverse:pairs.reverse()
    assert source_signature([current],dict(pairs))!=prior
    assert source_signature([current],{'OLD':'ACCOUNT A'})==prior
    assert source_signature([current],dict(pairs))==source_signature([current],{**dict(pairs),'INACTIVE':'UNRELATED'})
