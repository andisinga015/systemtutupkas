"""Populated c924 database, real FK graph, exact old-column preservation."""
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys

import pytest
from sqlalchemy import select

from app.models import Run,SourceDateIndex,SourceIdentity,SourceDocument,SourceSheet,WriteLedger
from app.engine.runner import process_run
from test_engine import start
from writer_fixture import configure_writer,SELECTED

BACKEND=Path(__file__).resolve().parents[1]
HEAD='d422a61e908f'


def command(path,*args,ok=True):
    env={**os.environ,'TK_DATABASE_URL':'sqlite:///'+str(path),'TK_WORKER_LOCK':str(path.parent/'upgrade-worker.lock')}
    result=subprocess.run([sys.executable,*args],cwd=BACKEND,env=env,capture_output=True,text=True)
    assert (result.returncode==0)==ok,result.stdout+result.stderr
    return result


def state(connection):
    result={}
    for name, in connection.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"):
        cols=[r[1] for r in connection.execute('PRAGMA table_info("'+name+'")')]
        result[name]=(cols,connection.execute('SELECT * FROM "'+name+'" ORDER BY rowid').fetchall())
    return result


def legacy_copy(db,path):
    command(path,'-m','alembic','upgrade','c92448ce233b')
    source_path=db.get_bind().url.database
    with sqlite3.connect(source_path) as source,sqlite3.connect(path) as target:
        source.row_factory=sqlite3.Row
        target.execute('PRAGMA foreign_keys=OFF')
        for name,(cols,_) in state(target).items():
            if name=='alembic_version':continue
            select_cols=','.join('"'+c+'"' for c in cols)
            for row in source.execute('SELECT '+select_cols+' FROM "'+name+'"'):
                values=list(row)
                # Represent pre-V4.2.2 JSON exactly: no period was guessed or
                # embedded in old Run/snapshot history by the old application.
                for field in ('config_snapshot','provenance'):
                    if field in cols and values[cols.index(field)]:
                        payload=json.loads(values[cols.index(field)])
                        payload.pop('source_period',None)
                        for doc in payload.get('sources',[]):doc.pop('source_period',None)
                        values[cols.index(field)]=json.dumps(payload)
                target.execute('INSERT INTO "'+name+'" ('+select_cols+') VALUES ('+','.join('?' for _ in cols)+')',values)
        assert not target.execute('PRAGMA foreign_key_check').fetchall()


@pytest.mark.parametrize('held',['terminal','active'])
def test_upgrade_preserves_complete_financial_graph_ids_history_and_mapping(logged,db,monkeypatch,tmp_path,held):
    site,fake,apis=configure_writer(logged,db,monkeypatch,tmp_path,heavy=False,batch=True)
    run=db.get(Run,start(logged,site,selected_date=str(SELECTED))['id']);process_run(db,run,fake)
    assert run.status=='SUCCESS'
    identity=db.scalar(select(SourceIdentity).where(SourceIdentity.source_document_id==run.config_snapshot['sources'][0]['id']))
    db.add(SourceDateIndex(identity_id=identity.id,content_revision='original-version',selected_date=SELECTED,
        separator_row=290,separator_col=0,following_row=306,following_col=0,evidence={'original':'preserve'}))
    # Preserve an uncertain existing financial intent without acknowledging it.
    db.scalar(select(WriteLedger)).verification_status='PREPARED'
    source=db.get(SourceDocument,identity.source_document_id)
    db.add(SourceSheet(source_document_id=source.id,source_revision_id=source.active_revision_id,tab_name='DISABLED ORIGINAL TAB',is_active=False))
    if held=='active':run.status='RUNNING';run.current_phase='CHECKING_DESTINATION'
    db.commit()
    legacy=tmp_path/'v42.sqlite3';backup=tmp_path/'backup.sqlite3'
    legacy_copy(db,legacy)
    with sqlite3.connect(legacy) as old,sqlite3.connect(backup) as target:old.backup(target)
    with sqlite3.connect(backup) as old:before=state(old)
    command(legacy,'-m','alembic','upgrade','head')
    command(legacy,'-m','alembic','check')
    with sqlite3.connect(legacy) as current:
        assert current.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        assert not current.execute('PRAGMA foreign_key_check').fetchall()
        for name,(cols,rows) in before.items():
            if name=='alembic_version':continue
            assert current.execute('SELECT '+','.join('"'+c+'"' for c in cols)+' FROM "'+name+'" ORDER BY rowid').fetchall()==rows,name
        assert current.execute('SELECT id,source_period FROM source_documents ORDER BY id').fetchall()==[(1,'UNASSIGNED'),(2,'MONTHLY')]
        assert current.execute('SELECT verification_status FROM output_write_ledger ORDER BY id LIMIT 1').fetchone()[0]=='PREPARED'
    # The actual stopped-upgrade cancellation protocol is allowed; source and
    # financial rows remain protected by the standalone verifier.
    command(legacy,'-m','app.cli','prepare-v42-upgrade','--services-stopped')
    verifier=BACKEND.parent/'scripts/verify-v422-upgrade.py'
    result=command(legacy,str(verifier),str(backup),str(legacy))
    proof=json.loads(result.stdout)
    assert proof['financial_state_preserved'] and proof['legacy_depo_unassigned']==1
    assert proof['active_runs_held']==(held=='active')
    with sqlite3.connect(legacy) as current:
        current.execute("UPDATE output_write_ledger SET verification_status='CORRUPTED' WHERE id=(SELECT min(id) FROM output_write_ledger)")
    rejected=command(legacy,str(verifier),str(backup),str(legacy),ok=False)
    assert 'output_write_ledger' in rejected.stderr
    # Consistent backup restore retains the old app/schema/data as a pair.
    with sqlite3.connect(backup) as old,sqlite3.connect(legacy) as restored:old.backup(restored)
    with sqlite3.connect(legacy) as restored:assert state(restored)==before


@pytest.mark.parametrize('period,kind,valid',[
    ('FIRST_HALF','DEPO',True),('SECOND_HALF','DEPO',True),('UNASSIGNED','DEPO',True),('MONTHLY','QRIS',True),
    ('MONTHLY','DEPO',False),('FIRST_HALF','QRIS',False),('UNASSIGNED','QRIS',False),('SECOND_HALF','QRIS',False),('OTHER','DEPO',False)])
def test_sqlite_enforces_valid_period_combinations(tmp_path,period,kind,valid):
    path=tmp_path/'constraint.sqlite3';command(path,'-m','alembic','upgrade','head')
    with sqlite3.connect(path) as db:
        db.execute("INSERT INTO websites(id,display_name,slug,is_active,is_archived,created_at,updated_at) VALUES(1,'VELBETT','velbett',1,0,'2026-10-01','2026-10-01')")
        values=(kind,period)
        sql="INSERT INTO source_documents(website_id,document_type,source_period,year,month,spreadsheet_url,spreadsheet_id,validation_status,created_at,updated_at) VALUES(1,?,?,2026,10,'old-url','old-id','VALID','2026-10-01','2026-10-01')"
        if valid:db.execute(sql,values)
        else:
            with pytest.raises(sqlite3.IntegrityError):db.execute(sql,values)


def test_unique_slots_and_downgrade_guard_preserve_period_assignments(tmp_path):
    path=tmp_path/'unique.sqlite3';command(path,'-m','alembic','upgrade','head')
    with sqlite3.connect(path) as db:
        db.execute("INSERT INTO websites(id,display_name,slug,is_active,is_archived,created_at,updated_at) VALUES(1,'VELBETT','velbett',1,0,'2026-10-01','2026-10-01')")
        sql="INSERT INTO source_documents(website_id,document_type,source_period,year,month,spreadsheet_url,spreadsheet_id,validation_status,created_at,updated_at) VALUES(1,'DEPO',?,2026,10,'url','id','VALID','2026-10-01','2026-10-01')"
        db.execute(sql,('FIRST_HALF',));db.execute(sql,('SECOND_HALF',))
        with pytest.raises(sqlite3.IntegrityError):db.execute(sql,('FIRST_HALF',))
    refused=command(path,'-m','alembic','downgrade','c92448ce233b',ok=False)
    assert 'downgrade destruktif ditolak' in refused.stderr
    with sqlite3.connect(path) as db:assert db.execute('SELECT source_period FROM source_documents ORDER BY id').fetchall()==[('FIRST_HALF',),('SECOND_HALF',)]


def test_failed_parent_rebuild_rolls_back_without_losing_old_ids_or_foreign_keys(tmp_path):
    path=tmp_path/'invalid-legacy.sqlite3';command(path,'-m','alembic','upgrade','c92448ce233b')
    with sqlite3.connect(path) as db:
        db.execute("INSERT INTO websites(id,display_name,slug,is_active,is_archived,created_at,updated_at) VALUES(1,'VELBETT','velbett',1,0,'2026-10-01','2026-10-01')")
        db.execute("INSERT INTO source_documents(id,website_id,document_type,year,month,spreadsheet_url,spreadsheet_id,validation_status,created_at,updated_at) VALUES(7,1,'UNKNOWN',2026,10,'url','id','VALID','2026-10-01','2026-10-01')")
        before=state(db)
    command(path,'-m','alembic','upgrade','head',ok=False)
    with sqlite3.connect(path) as db:
        assert state(db)==before and not db.execute('PRAGMA foreign_key_check').fetchall()
        assert not db.execute("SELECT name FROM sqlite_master WHERE name LIKE '_alembic_tmp%'").fetchall()
        db.execute("UPDATE source_documents SET document_type='DEPO' WHERE id=7")
    command(path,'-m','alembic','upgrade','head')
    with sqlite3.connect(path) as db:assert db.execute('SELECT id,source_period FROM source_documents').fetchall()==[(7,'UNASSIGNED')]


def test_completed_atomic_schema_can_resume_after_revision_stamp_interruption(tmp_path):
    path=tmp_path/'resume.sqlite3';command(path,'-m','alembic','upgrade','head')
    with sqlite3.connect(path) as db:
        db.execute("UPDATE alembic_version SET version_num='c92448ce233b'")
        before=state(db)
    command(path,'-m','alembic','upgrade','head')
    command(path,'-m','alembic','check')
    with sqlite3.connect(path) as db:
        after=state(db)
        assert {k:v for k,v in after.items() if k!='alembic_version'}=={k:v for k,v in before.items() if k!='alembic_version'}
        assert db.execute('SELECT version_num FROM alembic_version').fetchone()[0]==HEAD
