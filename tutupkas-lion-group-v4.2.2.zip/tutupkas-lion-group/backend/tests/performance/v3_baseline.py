"""Offline comparison only: V3's actual full-grid allocation path.

Copied from the delivered V3 ZIP. Never imported by the worker.
"""
from app.sheets import google_cell
from app.engine.types import Cell, Grid


def v3_grid(api):
    meta=api.request('GET','synthetic',params={'fields':'sheets(properties)'})
    p=meta['sheets'][0]['properties']
    title=p['title']
    raw=api.request('GET','synthetic',params={
        'ranges':[api.a1(title,0,p['gridProperties']['rowCount']-1,0,p['gridProperties']['columnCount']-1)],
        'includeGridData':'true',
        'fields':'sheets(properties,merges,data(startRow,startColumn,rowData(values(userEnteredValue,effectiveValue,effectiveFormat,note,formattedValue))))'})
    sheet=raw['sheets'][0]
    rows=[]
    for band in sheet.get('data',[]):
        start,col=band.get('startRow',0),band.get('startColumn',0)
        for i,row in enumerate(band.get('rowData',[])):
            while len(rows)<=start+i:rows.append([])
            rows[start+i]=[Cell() for _ in range(col)]+[google_cell(v) for v in row.get('values',[])]
    return Grid(title,p['sheetId'],rows,sheet.get('merges',[]))
