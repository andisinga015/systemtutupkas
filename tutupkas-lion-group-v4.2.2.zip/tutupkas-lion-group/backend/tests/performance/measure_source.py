"""Offline lazy API benchmark, not a live Google acceptance test."""
import argparse
import json
from pathlib import Path
import resource
import sys
import time
from datetime import date

sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

parser=argparse.ArgumentParser()
parser.add_argument('--history',type=int,default=40000)
parser.add_argument('--limit-mib',type=int,default=1536)
parser.add_argument('--version',choices=['v3','v4'],default='v4')
args=parser.parse_args()
resource.setrlimit(resource.RLIMIT_AS,(args.limit_mib*1048576,)*2)

from range_api import RangeAPI
from benchmark_memory import memory

start=time.monotonic()
api=RangeAPI(history=args.history,empty=True,retain_calls=False)
read_start=time.monotonic()
if args.version=='v3':
    from v3_baseline import v3_grid
    from app.engine.parser import Day
    day=Day.resolve(v3_grid(api),date(2026,10,18),'DEPO')
else:
    day=api.source_day('synthetic',api.fixture.title,date(2026,10,18),'DEPO')
read_duration=time.monotonic()-read_start
metrics=[day.metric(x) for x in ['Total','Total WD','SALDO']]
print(json.dumps({'version':args.version,'historical_rows':args.history,'historical_cells':args.history*13,
    'api_calls':api.count,'source_read_ms':round(read_duration*1000,2),
    'overall_ms':round((time.monotonic()-start)*1000,2),**memory(),
    'largest_response_bytes':api.largest,'response_bytes':api.total_bytes,
    'retained_rows':len(day.grid.rows.rows) if hasattr(day.grid.rows,'rows') else len(day.grid.rows),'metrics':metrics,'oom':False,
    'address_space_limit_mib':args.limit_mib,'network':'offline lazy fixture; no throttle/latency'}))
