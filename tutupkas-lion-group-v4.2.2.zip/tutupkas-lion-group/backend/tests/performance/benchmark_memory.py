"""Measure the fresh executable's Linux memory high-water mark.

ru_maxrss can include the pytest parent's high-water mark inherited across
fork/exec. VmHWM belongs to the current executable's address space instead.
This keeps source-reader regression thresholds meaningful after memory tests.
"""
from pathlib import Path
import resource


def memory():
    inherited = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024
    fields = {}
    for line in Path('/proc/self/status').read_text().splitlines():
        if line.startswith(('VmRSS:','VmHWM:')):
            name,value,*_ = line.split()
            fields[name] = int(value)/1024
    return {'rss_mb':round(fields['VmRSS:'],2),'peak_rss_mb':round(fields['VmHWM:'],2),
            'resource_peak_rss_mb':round(inherited,2)}
