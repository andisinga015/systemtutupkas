"""Offline full-run memory probe: three large source tabs + real engine/SQLite.

Destination/report transport is an isolated fixture. No Google credentials used.
"""
import argparse
import json
import logging
import resource
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
parser=argparse.ArgumentParser()
parser.add_argument('--history',type=int,default=40000)
args=parser.parse_args()
resource.setrlimit(resource.RLIMIT_AS,(1536*1048576,)*2)

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from app.auth import hasher
from app.db import Base, get_db
from app.config import settings
from benchmark_memory import memory
from app.main import app
from app.models import User, Run
from app.engine.runner import process_run
from app.engine.types import column
from range_api import RangeAPI
from test_v41_destination import wire_destinations
from test_engine import configured, start

logging.disable(logging.CRITICAL)
with tempfile.TemporaryDirectory(prefix='tutupkas-v4-perf-') as folder, pytest.MonkeyPatch.context() as patch:
    path=Path(folder)
    engine=create_engine('sqlite:///'+str(path/'test.sqlite3'),connect_args={'check_same_thread':False})
    Base.metadata.create_all(engine)
    with Session(engine,expire_on_commit=False) as db:
        db.add(User(username='finance',password_hash=hasher.hash('fixture-only-password-123')));db.commit()
        app.dependency_overrides[get_db]=lambda:db
        patch.setattr(settings(),'cookie_secure',False)
        patch.setattr(settings(),'app_origin','http://testserver')
        patch.setattr(settings(),'reconciliation_delay',0)
        with TestClient(app) as client:
            token=client.get('/api/auth/csrf').json()['csrf_token']
            response=client.post('/api/auth/login',json={'username':'finance','password':'fixture-only-password-123'},headers={'x-csrf-token':token})
            assert response.status_code==200
            client.headers['x-csrf-token']=response.json()['csrf_token']
            w,fake=configured(client,db,patch,path)
            reads=[]
            def source(id,title,selected,kind):
                api=RangeAPI(fake.documents[id][title],history=args.history,retain_calls=False)
                began=time.monotonic();day=api.source_day(id,title,selected,kind)
                reads.append({'api_calls':api.count,'response_bytes':api.total_bytes,
                    'largest_response_bytes':api.largest,'duration_ms':(time.monotonic()-began)*1000})
                return day
            fake.source_day=source
            apis=wire_destinations(fake)
            r=start(client,w)
            began=time.monotonic();process_run(db,db.get(Run,r['id']),fake)
            duration=(time.monotonic()-began)*1000
            assert db.get(Run,r['id']).status=='SUCCESS'
            golden=json.loads((Path(__file__).parents[1]/'fixtures/v3_financial_outputs.json').read_text())
            assert [[x.tab,f'{column(x.col-420)}{x.row-73+1}',x.value,x.note,x.bank] for x in fake.writes]==[x[:5] for x in golden['writes']]
            print(json.dumps({'historical_rows_per_tab':args.history,'source_tabs':len(reads),
                'source_api_calls':sum(x['api_calls'] for x in reads),
                'destination_api_calls':sum(a.count for a in apis.values()),
                'destination_get_calls':sum(a.count-a.post_requests for a in apis.values()),
                'destination_post_calls':sum(a.post_requests for a in apis.values()),'cell_writes':len(fake.writes),
                'source_read_ms':round(sum(x['duration_ms'] for x in reads),2),'overall_processing_ms':round(duration,2),
                'largest_response_bytes':max([x['largest_response_bytes'] for x in reads]+[a.largest for a in apis.values()]),**memory(),
                'status':'SUCCESS','golden_values_coordinates_notes_banks_match':True,
                'oom':False,'address_space_limit_mib':1536,'destination_allocated_rows':1000,'destination_allocated_columns':1500,'network':'offline fixture; no Google/throttle/latency'}))
        app.dependency_overrides.clear()
    engine.dispose()
