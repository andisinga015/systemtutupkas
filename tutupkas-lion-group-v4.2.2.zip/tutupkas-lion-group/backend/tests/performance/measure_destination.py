"""Offline wide-destination benchmark, real writer/SQLite, lazy API fixture."""
import argparse,json,logging,resource,sys,tempfile,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
parser=argparse.ArgumentParser()
parser.add_argument('--width',type=int,default=1500)
parser.add_argument('--height',type=int,default=1000)
parser.add_argument('--formatted-blanks',action='store_true')
args=parser.parse_args()
resource.setrlimit(resource.RLIMIT_AS,(1536*1048576,)*2)
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine,select
from sqlalchemy.orm import Session
from app.auth import hasher
from app.config import settings
from app.db import Base,get_db
from benchmark_memory import memory
from app.main import app
from app.models import User,Run,RunItem
from app.engine import resolver
from app.engine.writer import execute
from app.engine.types import Issue
from fixtures.v4_grid_reader import V4GridReader
from test_engine import configured,start
from wide_api import WideAPI,wide_regular
from datetime import date
logging.disable(logging.CRITICAL)
with tempfile.TemporaryDirectory(prefix='tutupkas-v41-probe-') as folder,pytest.MonkeyPatch.context() as patch:
    path=Path(folder)
    engine=create_engine('sqlite:///'+str(path/'fixture.sqlite3'),connect_args={'check_same_thread':False})
    Base.metadata.create_all(engine)
    with Session(engine,expire_on_commit=False) as db:
        db.add(User(username='finance',password_hash=hasher.hash('fixture-only-password-123')));db.commit()
        app.dependency_overrides[get_db]=lambda:db
        patch.setattr(settings(),'cookie_secure',False);patch.setattr(settings(),'app_origin','http://testserver')
        with TestClient(app) as client:
            token=client.get('/api/auth/csrf').json()['csrf_token']
            reply=client.post('/api/auth/login',json={'username':'finance','password':'fixture-only-password-123'},headers={'x-csrf-token':token})
            client.headers['x-csrf-token']=reply.json()['csrf_token']
            website,fake=configured(client,db,patch,path)
            r=start(client,website);run=db.get(Run,r['id'])
            item=db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type=='deposit'))
            sheet,names=wide_regular(width=args.width,height=args.height,target=args.width-80,title='SALDO BANK')
            sheet.formatted_blanks=args.formatted_blanks
            old_api=WideAPI(sheet,retain_calls=False)
            try:V4GridReader.grid(old_api,'dest',sheet.title)
            except Issue as error:old_status=error.code
            else:old_status='ACCEPTED'
            api=WideAPI(sheet,retain_calls=False)
            baseline=memory()
            began=time.monotonic()
            view=api.destination_grid('dest',sheet.title,names)
            write=resolver.regular(view,'VELBETT',names,date(2026,10,18),'WD DANA 1 / FATMAWATI ( PP )',2355000)
            mapping=(time.monotonic()-began)*1000
            marks={}
            def phase(value):marks[value]=time.monotonic()
            result=execute(db,api,run,item,view,[write],on_phase=phase)
            ended=time.monotonic()
            pre=(marks['WRITING']-marks['CHECKING_DESTINATION'])*1000
            post=(ended-marks['VERIFYING'])*1000
            index_bytes=view.db.execute('PRAGMA page_count').fetchone()[0]*view.db.execute('PRAGMA page_size').fetchone()[0]
            indexed=view.db.execute('SELECT count(*) FROM cells').fetchone()[0]
            view.close()
            assert result['verified'] and api.posts[-1][:3]==(74,args.width-79,2355000)
            print(json.dumps({'allocated_rows':args.height,'allocated_columns':args.width,
                'formatted_blanks':args.formatted_blanks,'v4_result':old_status,'v41_result':'VERIFIED',
                'api_calls':api.count,'get_calls':api.count-api.post_requests,'post_calls':api.post_requests,'largest_response_bytes':api.largest,'response_bytes':api.total_bytes,
                'source_read_ms':0,'source_read_note':'destination-only probe',
                'destination_mapping_ms':round(mapping,2),'prewrite_validation_ms':round(pre,2),
                'readback_verification_ms':round(post,2),'full_probe_ms':round((ended-began)*1000,2),
                'baseline_rss_mb':baseline['rss_mb'],**memory(),'indexed_cells':indexed,
                'temporary_index_bytes':index_bytes,'target_row':write.row,'target_col':write.col,
                'target_address':write.address,'oom':False,'address_space_limit_mib':1536,
                'harness':'auth/SQLite + lazy sparse fixtures, no complete allocated grid',
                'network':'offline; excludes Google throttle and latency'}))
        app.dependency_overrides.clear()
    engine.dispose()
