"""Compare V4.2.1 and V4.2.2 on 43 plans, with ten unused active DOC A tabs.

Network, auth and source logic are fixture-controlled; destination transport
returns full requested CellData, including ~8MiB ordinary historical Notes.
No Google credentials, source changes or actual financial writes are used.
"""
import argparse,hashlib,json,logging,os,resource,sys,tempfile,time
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--engine-root',type=Path);parser.add_argument('--legacy',action='store_true');parser.add_argument('--light',action='store_true');parser.add_argument('--no-token',action='store_true');a=parser.parse_args()
root=Path(__file__).resolve().parents[3];engine_root=a.engine_root or root
sys.path[:0]=[str(engine_root/'backend'),str(root/'backend/tests')]
resource.setrlimit(resource.RLIMIT_AS,(1536*1048576,)*2)
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine,select
from sqlalchemy.orm import Session
from app.auth import hasher
from app.db import Base,get_db
from app.config import settings
from app.main import app
from app.models import User,Run,RunItem,SourceSnapshot
from app.engine.runner import process_run
from app.destination_reader import DestinationReader
from app.engine.types import fingerprint
from writer_fixture import configure_writer,SELECTED
from test_engine import start
from benchmark_memory import memory
logging.disable(logging.CRITICAL)
with tempfile.TemporaryDirectory(prefix='tutupkas-v421-probe-') as directory,pytest.MonkeyPatch.context() as patch:
 path=Path(directory);engine=create_engine('sqlite:///'+str(path/'test.sqlite3'),connect_args={'check_same_thread':False});Base.metadata.create_all(engine)
 patch.setattr(settings(),'cookie_secure',False);patch.setattr(settings(),'app_origin','http://testserver');patch.setattr(settings(),'worker_lock',str(path/'worker.lock'));patch.setattr(settings(),'reconciliation_delay',0)
 with Session(engine,expire_on_commit=False) as db:
  db.add(User(username='finance',password_hash=hasher.hash('test-only-password-123')));db.commit();app.dependency_overrides[get_db]=lambda:db
  with TestClient(app) as client:
   csrf=client.get('/api/auth/csrf').json()['csrf_token'];login=client.post('/api/auth/login',json={'username':'finance','password':'test-only-password-123'},headers={'x-csrf-token':csrf});assert login.status_code==200;client.headers['x-csrf-token']=login.json()['csrf_token']
   batch=not a.legacy and hasattr(__import__('app.sheets',fromlist=['SheetsClient']).SheetsClient,'write_batch')
   w,fake,apis=configure_writer(client,db,patch,path,heavy=not a.light,batch=batch,token=not a.no_token)
   from app.models import SourceDocument
   unused=0
   if hasattr(SourceDocument,'source_period'):
    from copy import deepcopy
    from helpers import DEPO_NAME
    source_grid=fake.documents['depo-document-12345'][DEPO_NAME]
    unused_doc='unused-first-half-document-12345'
    fake.documents[unused_doc]={}
    for n in range(10):
     grid=deepcopy(source_grid);grid.title=f'UNUSED DOC A / ACCOUNT {n+1}';grid.sheet_id=n+101
     fake.documents[unused_doc][grid.title]=grid
    result=client.put(f"/api/websites/{w['id']}/sources",json={'year':2026,'month':10,'document_type':'DEPO','source_period':'FIRST_HALF','spreadsheet_url':f'https://docs.google.com/spreadsheets/d/{unused_doc}/edit'})
    assert result.status_code==200,result.text
    doc=result.json();assert client.post(f"/api/sources/{doc['id']}/validate").json()['document']['validation_status']=='VALID'
    tabs=client.get(f"/api/sources/{doc['id']}/tabs").json();unused=len(tabs)
    assert client.post(f"/api/sources/{doc['id']}/tabs",json={'ids':[t['id'] for t in tabs],'is_active':True,'source_revision_id':doc['active_revision_id']}).status_code==200
    fake.reads.clear();fake.writes.clear()
   stages={};scans={};calls=[]
   def stage_name():
    value=fake.diagnostic_context.get('phase','PLANNING') if hasattr(fake,'diagnostic_context') else 'PLANNING'
    return 'planning' if value in ('PLANNING','SOURCE_READING','PREPARING') else 'pre_write_validation' if value=='CHECKING_DESTINATION' else 'writing' if value=='WRITING' else 'readback_verification' if value=='VERIFYING' else 'reconciliation' if value=='RECONCILING' else value
   def record(method,kind,size,title,largest=0):
    phase=stage_name();entry=stages.setdefault(phase,{'get':0,'post':0,'bytes':0,'largest_response_bytes':0})
    entry['get' if method=='GET' else 'post']+=1;entry['bytes']+=size;entry['largest_response_bytes']=max(entry['largest_response_bytes'],size)
    calls.append([phase,method,title,kind,size])
   for title,api in apis.items():
    raw=api.request
    def tracked(method,*args,raw=raw,api=api,title=title,**kw):
     before=api.total_bytes
     try:return raw(method,*args,**kw)
     finally:
      fields=kw.get('params',{}).get('fields','');ranges=kw.get('params',{}).get('ranges',[])
      kind='global_cells' if any((lambda v:(v[1]-v[0]+1)*(v[3]-v[2]+1)>32)(api.decode(v)) for v in ranges) else 'target_cells' if 'rowData' in fields else 'metadata'
      record(method,kind,api.total_bytes-before,title)
    api.request=tracked
   if not a.no_token:
    raw_revision=fake.content_revision
    def revision(doc):
     token=raw_revision(doc);record('GET','drive_version',len(json.dumps({'id':doc,'version':token}).encode()),'DRIVE')
     return token
    fake.content_revision=revision
   if batch:
    raw=fake.request
    def request(method,*args,**kw):
     result=raw(method,*args,**kw)
     if method=='POST' or not kw.get('params',{}).get('ranges'):record(method,'atomic_batch' if method=='POST' else 'metadata',len(json.dumps(result).encode()),'MULTIPLE')
     return result
    fake.request=request
   original_scan=DestinationReader._scan
   def scan(self):
    key=stage_name()+':'+self.title;scans[key]=scans.get(key,0)+1
    return original_scan(self)
   patch.setattr(DestinationReader,'_scan',scan)
   run=db.get(Run,start(client,w,selected_date=str(SELECTED))['id']);began=time.monotonic();process_run(db,run,fake);wall=(time.monotonic()-began)*1000
   detail=client.get(f'/api/runs/{run.id}').json();assert run.status=='SUCCESS',detail['errors']
   items=list(db.scalars(select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type!='reconciliation')));assert len(items)==43
   assert db.query(SourceSnapshot).filter(SourceSnapshot.run_id==run.id).count()==8
   output=[[v.tab,v.address,v.value,v.note,v.bank,v.transaction] for v in fake.writes]
   result={'version':'V4.2.1 baseline' if a.engine_root else 'V4.2.2' if batch else 'legacy compatibility','selected_date':str(SELECTED),'financial_plans':len(items),'source_snapshots':8,'unused_active_doc_a_tabs':unused,'unused_period_source_reads':sum(doc=='unused-first-half-document-12345' for doc,title in fake.reads),'selected_source_periods':[d.get('source_period') for d in run.config_snapshot['sources']],'batch':batch,'version_token':not a.no_token,'heavy_formatted_biaya':not a.light,'destination_phases':stages,'global_scans':scans,'destination_gets':sum(x['get'] for x in stages.values()),'destination_posts':sum(x['post'] for x in stages.values()),'destination_response_bytes':sum(x['bytes'] for x in stages.values()),'multi_megabyte_gets':sum(x[1]=='GET' and x[4]>=2*1048576 for x in calls),'expense_total_value':next(i.result['plan'][0]['proposed']['value'] for i in items if i.metric_type=='expense_total'),'absolute_output':output,'output_fingerprint':fingerprint(output),'item_statuses':[(i.source_tab_name,i.metric_type,i.status) for i in items],'wall_clock_ms':round(wall,3),'status':run.status,'oom':False,'address_space_limit_mib':1536,**memory(),'network':'isolated equivalent fixture, no Google latency/quota waiting; live acceptance pending'}
   assert result['unused_period_source_reads']==0
   print(json.dumps(result))
  app.dependency_overrides.clear()
 engine.dispose()
