"""Real batched writer protocol: eight snapshots, 43 plans, independent guards."""
from copy import deepcopy
from datetime import date
from uuid import uuid4

import pytest
from sqlalchemy import select

from app.engine.runner import process_run
from app.engine.types import Cell,Issue,Write,fingerprint
from app.models import (AuditLog,Destination,DestinationMapping,DestinationConflict,MappedResult,Run,RunItem,
    SourceDocument,SourceSnapshot,TaskError,TransferOwnership,WriteLedger)
from app.destination_reader import DestinationReader
from app.engine.writer import owner_key
from app.sheets import SheetsClient
from test_engine import start
from test_v42_conflicts import decision
from writer_fixture import configure_writer,SELECTED


def world(logged,db,monkeypatch,tmp_path,**kwargs):
    site,fake,apis=configure_writer(logged,db,monkeypatch,tmp_path,heavy=False,batch=True,**kwargs)
    requests=[];raw=fake.request
    def request(method,*args,**kw):
        if method=='POST':requests.append(deepcopy(kw['json']))
        return raw(method,*args,**kw)
    fake.request=request;fake.batch_requests=requests
    return site,fake,apis


def execute(logged,db,site,fake,**kwargs):
    run=db.get(Run,start(logged,site,selected_date=str(SELECTED),**kwargs)['id']);process_run(db,run,fake)
    return run


def detail(logged,run):return logged.get(f'/api/runs/{run.id}').json()


def item(db,run,metric,tab=None):
    query=select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type==metric)
    if tab is not None:query=query.where(RunItem.source_tab_name==tab)
    return db.scalar(query)


def test_43_plans_share_one_post_with_identical_v42_values_and_cells(logged,db,monkeypatch,tmp_path):
    site,fake,apis=world(logged,db,monkeypatch,tmp_path)
    run=execute(logged,db,site,fake)
    assert run.status=='SUCCESS',detail(logged,run)['errors']
    assert len([i for i in detail(logged,run)['items'] if i['metric_type']!='reconciliation'])==43
    assert db.query(SourceSnapshot).filter(SourceSnapshot.run_id==run.id).count()==8
    assert len(fake.batch_requests)==1 and len(fake.writes)==57
    assert item(db,run,'expense_total').result['plan'][0]['proposed']['value']==33000
    targets=[u['updateCells']['range'] for u in fake.batch_requests[0]['requests']]
    assert len({(t['sheetId'],t['startRowIndex'],t['startColumnIndex']) for t in targets})==len(targets)
    assert not apis['Laporan deposit harian'].posts
    assert all(l.verification_status=='VERIFIED' for l in db.scalars(select(WriteLedger)))
    fake.batch_requests.clear();fake.writes.clear()
    repeated=execute(logged,db,site,fake)
    assert repeated.status=='SUCCESS' and not fake.batch_requests and not fake.writes
    assert db.query(TransferOwnership).count()==13


def test_biaya_has_one_shared_post_proof_and_no_warm_prewrite_rescan(logged,db,monkeypatch,tmp_path):
    site,fake,apis=world(logged,db,monkeypatch,tmp_path);scans=[];raw=DestinationReader._scan
    def scan(view):scans.append((view.title,fake.diagnostic_context.get('phase')));return raw(view)
    monkeypatch.setattr(DestinationReader,'_scan',scan)
    run=execute(logged,db,site,fake)
    assert run.status=='SUCCESS'
    assert [p for title,p in scans if title=='BIAYA']==['VERIFYING']
    assert all(sum(t==title for t,p in scans)==1 for title in apis if title!='Laporan deposit harian')
    assert len(fake.batch_requests)==1


@pytest.mark.parametrize('token',[True,False])
def test_expense_total_retry_is_one_item_and_preserves_ready_mapping(logged,db,monkeypatch,tmp_path,token):
    site,fake,apis=world(logged,db,monkeypatch,tmp_path,token=token);run=execute(logged,db,site,fake)
    assert run.status=='SUCCESS';total=item(db,run,'expense_total');map_id=run.config_snapshot['mapping_id']
    old={i.id:deepcopy(i.result) for i in db.scalars(select(RunItem).where(RunItem.run_id==run.id,RunItem.id!=total.id))}
    total.status='FAILED';run.status='PARTIAL';db.commit();fake.batch_requests.clear();fake.writes.clear();fake.reads.clear()
    assert logged.post(f'/api/runs/{run.id}/retry',json={'item_ids':[total.id]}).status_code==202
    process_run(db,run,fake)
    assert total.status=='SUCCESS' and not fake.batch_requests and not fake.writes
    assert all(db.get(RunItem,id).result==value for id,value in old.items())
    assert not any(doc.endswith('document-12345') for doc,title in fake.reads)
    assert db.get(DestinationMapping,map_id).state=='READY' and run.config_snapshot['mapping_id']==map_id


@pytest.mark.parametrize('fault',['manual_value','manual_note','formula','merged','missing_header','identity'])
def test_one_invalid_group_isolated_without_weakening_protection(logged,db,monkeypatch,tmp_path,fault):
    site,fake,apis=world(logged,db,monkeypatch,tmp_path);sheet=apis['TOTAL DEPO'].fixture
    if fault=='manual_value':sheet.put(2,1,789)
    elif fault=='manual_note':sheet.put(2,1,None,note='Preserve manual note')
    elif fault=='formula':sheet.put(2,1,789,formula='=789')
    elif fault=='merged':sheet.merge(2,3,1,2)
    elif fault=='missing_header':sheet.put(1,1,'DIFFERENT')
    else:sheet.sheet_id+=100
    if fault in ('merged','missing_header','identity'):fake.versions['destination-copy-12345']+=1
    original=deepcopy(sheet.cell(2,1).snapshot)
    run=execute(logged,db,site,fake)
    assert run.status=='PARTIAL' and sheet.cell(2,1).snapshot==original
    assert any(i['status']=='SUCCESS' for i in detail(logged,run)['items'] if i['metric_type']=='withdrawal')
    assert not any(w.tab=='TOTAL DEPO' and w.address=='B3' for w in fake.writes)
    assert not detail(logged,run)['date_status']['eligible']


@pytest.mark.parametrize('action',['NEW','KEEP'])
def test_group_conflict_decisions_remain_explicit_and_independent(logged,db,monkeypatch,tmp_path,action):
    site,fake,apis=world(logged,db,monkeypatch,tmp_path)
    apis['TOTAL DEPO'].fixture.put(2,1,999,note='Manual retained note')
    run=execute(logged,db,site,fake)
    conflict=db.scalar(select(DestinationConflict).where(DestinationConflict.run_id==run.id,DestinationConflict.state=='OPEN'))
    assert conflict and conflict.observed[0]['value']==999
    written_before={(w.tab,w.address) for w in fake.writes};fake.writes.clear();fake.batch_requests.clear()
    if action=='KEEP':
        from app.models import MappingTarget
        entry=db.scalar(select(MappingTarget).where(MappingTarget.mapping_id==run.config_snapshot['mapping_id'],MappingTarget.module=='Laporan deposit harian',MappingTarget.website=='VELBETT',MappingTarget.selected_date==SELECTED))
        r,c=entry.coordinates['row'],entry.coordinates['column'];old=apis['Laporan deposit harian'].fixture.cell(r,c)
        apis['Laporan deposit harian'].fixture.put(r,c,-999,formula=old.formula,note=old.note)
    assert decision(logged,conflict,action).status_code==202
    process_run(db,run,fake)
    assert conflict.state=='RESOLVED' and apis['TOTAL DEPO'].fixture.cell(2,1).note=='Manual retained note'
    assert apis['TOTAL DEPO'].fixture.cell(2,1).value==(0 if action=='NEW' else 999)
    assert not any((w.tab,w.address) in written_before for w in fake.writes)
    if action=='KEEP':assert detail(logged,run)['reconciliation']['status']=='NOT_BALANCED'


def test_preview_never_batches_or_mutates_financial_ledger(logged,db,monkeypatch,tmp_path):
    site,fake,apis=world(logged,db,monkeypatch,tmp_path)
    run=execute(logged,db,site,fake,preview=True)
    assert run.status=='PREVIEWED' and not fake.batch_requests and not fake.writes
    assert not list(db.scalars(select(WriteLedger))) and not list(db.scalars(select(TransferOwnership)))


@pytest.mark.parametrize('change',['value','note','formula','header','mapping','source','snapshot','expense_dependency'])
def test_final_boundary_detects_changes_during_preparation(logged,db,monkeypatch,tmp_path,change):
    import app.engine.batch_writer as batched
    site,fake,apis=world(logged,db,monkeypatch,tmp_path);raw=batched._execute_checked;once=[]
    def prepare(db_arg,client,run,row,grid,fresh,writes,*args,**kw):
        result=raw(db_arg,client,run,row,grid,fresh,writes,*args,**kw)
        if not once:
            once.append((row.id,grid.title,writes[0].address))
            if change in ('value','note','formula'):
                apis[grid.title].fixture.put(writes[0].row,writes[0].col,654 if change!='note' else None,
                    note='late manual' if change=='note' else '',formula='=654' if change=='formula' else None)
            elif change=='header':
                apis[grid.title].fixture.put(1,1,'changed header');fake.versions['destination-copy-12345']+=1
            elif change=='mapping':
                db.get(Destination,run.config_snapshot['destination']['id']).revision+=1;db.commit()
            elif change=='source':
                doc=db.get(SourceDocument,row.source_document_id);doc.spreadsheet_id='changed-source-document';doc.validation_status='FAILED';db.commit()
            elif change=='snapshot':
                source=db.get(SourceSnapshot,row.result.get('snapshot_id')) if row.result else db.scalar(select(SourceSnapshot).where(SourceSnapshot.source_document_id==row.source_document_id))
                source.checksum='0'*64;db.commit()
            else:
                dependency=db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type=='expense_input'))
                dependency.result={**dependency.result,'signed_value':-999};db.commit()
        return result
    monkeypatch.setattr(batched,'_execute_checked',prepare)
    run=execute(logged,db,site,fake)
    assert run.status in ('PARTIAL','FAILED'),detail(logged,run)['errors']
    target=(once[0][1],once[0][2]) if change!='expense_dependency' else ('BIAYA','B3')
    assert not any((w.tab,w.address)==target for w in fake.writes)
    assert not detail(logged,run)['date_status']['eligible']


@pytest.mark.parametrize('change',['formula_elsewhere','date_elsewhere','merge_elsewhere','fee_duplicate','epoch_during_scan'])
def test_post_global_invariants_remain_mandatory(logged,db,monkeypatch,tmp_path,change):
    site,fake,apis=world(logged,db,monkeypatch,tmp_path);original=fake.write_batch
    def write(*args):
        result=original(*args)
        if change=='formula_elsewhere':apis['TOTAL DEPO'].fixture.put(30,60,1,formula='=1')
        elif change=='date_elsewhere':apis['TOTAL DEPO'].fixture.put(30,60,'18-Oct-2026')
        elif change=='merge_elsewhere':apis['TOTAL DEPO'].fixture.merge(30,31,60,62)
        elif change=='fee_duplicate':apis['Pengeluaran FEE QRIS DEPO'].fixture.put(1,3,'KETERANGAN')
        return result
    fake.write_batch=write
    if change=='epoch_during_scan':
        raw=DestinationReader._scan;once=[]
        def scan(view):
            result=raw(view)
            if getattr(view.client,'invariant_epoch',None) is not None and not once:
                once.append(True);fake.versions['destination-copy-12345']+=1
            return result
        monkeypatch.setattr(DestinationReader,'_scan',scan)
    run=execute(logged,db,site,fake)
    assert run.status=='PARTIAL',detail(logged,run)['errors']
    ledgers=list(db.scalars(select(WriteLedger)))
    assert any(l.verification_status=='PREPARED' for l in ledgers)
    if change=='epoch_during_scan':assert all(l.verification_status=='PREPARED' for l in ledgers)
    assert not detail(logged,run)['date_status']['eligible']


@pytest.mark.parametrize('mode',['reply_lost','worker_death','one_amount_mismatch','one_note_mismatch'])
def test_grouped_post_and_recovery_never_split_or_replay(logged,db,monkeypatch,tmp_path,mode):
    from app.worker import recover_jobs
    site,fake,apis=world(logged,db,monkeypatch,tmp_path);original=fake.write_batch
    def write(*args):
        original(*args)
        if mode=='reply_lost':raise ConnectionError('accepted reply lost')
        if mode=='worker_death':raise SystemExit('accepted then worker terminated')
        if mode=='one_amount_mismatch':apis['KET PENGIRIMAN'].fixture.put(3,1,123)
        if mode=='one_note_mismatch':
            # The final QRIS source writes row 15 after twelve DEPO transfers.
            apis['KET PENGIRIMAN'].fixture.put(15,0,apis['KET PENGIRIMAN'].fixture.cell(15,0).value,note='manual changed')
    fake.write_batch=write;run=db.get(Run,start(logged,site,selected_date=str(SELECTED))['id'])
    if mode=='worker_death':
        with pytest.raises(SystemExit):process_run(db,run,fake)
        assert all(l.verification_status=='PREPARED' for l in db.scalars(select(WriteLedger)))
        count=db.query(TransferOwnership).count();recover_jobs(db);fake.write_batch=original;fake.batch_requests.clear();fake.writes.clear()
        assert logged.post(f'/api/runs/{run.id}/retry',json={}).status_code==202
        process_run(db,run,fake)
        assert run.status=='SUCCESS',detail(logged,run)['errors']
        assert not fake.batch_requests and not fake.writes and db.query(TransferOwnership).count()==count
    else:
        process_run(db,run,fake)
        if mode=='reply_lost':assert run.status=='SUCCESS' and len(fake.batch_requests)==1
        else:
            assert run.status=='PARTIAL' and len(fake.batch_requests)==1
            errors=detail(logged,run)['errors'];failed={e['run_item_id'] for e in errors}
            ledgers=[l for l in db.scalars(select(WriteLedger)) if l.run_item_id in failed]
            assert len(ledgers)>=2 and all(l.verification_status=='PREPARED' for l in ledgers)
            assert any(l.verification_status=='VERIFIED' for l in db.scalars(select(WriteLedger)))


@pytest.mark.parametrize('when',['preflight','submitted'])
def test_cancel_stops_before_post_or_verifies_whole_submitted_batch(logged,db,monkeypatch,tmp_path,when):
    from test_cancellation import cancel_other
    import app.engine.batch_writer as batched
    site,fake,apis=world(logged,db,monkeypatch,tmp_path);run=db.get(Run,start(logged,site,selected_date=str(SELECTED))['id'])
    if when=='preflight':
        raw=batched._execute_checked;once=[]
        def prepare(*args,**kw):
            result=raw(*args,**kw)
            if not once:once.append(True);cancel_other(db,run.id)
            return result
        monkeypatch.setattr(batched,'_execute_checked',prepare)
    else:
        raw=fake.write_batch
        def write(*args):result=raw(*args);cancel_other(db,run.id);return result
        fake.write_batch=write
    process_run(db,run,fake)
    assert run.status=='CANCELED'
    if when=='preflight':assert not fake.batch_requests
    else:
        assert len(fake.batch_requests)==1
        assert all(l.verification_status=='VERIFIED' for l in db.scalars(select(WriteLedger)))


def test_transport_rejects_duplicate_cells_and_readonly_report_before_post(monkeypatch):
    from helpers import blank
    client=object.__new__(SheetsClient);calls=[];client.request=lambda *a,**k:calls.append((a,k))
    grid=blank('TOTAL DEPO',4,4,10)
    with pytest.raises(Issue) as duplicate:client.write_batch('document',[(grid,[Write(grid.title,2,1,1)]),(grid,[Write(grid.title,2,1,2)])])
    assert duplicate.value.code=='DUPLICATE_DESTINATION' and not calls
    grid.title='Laporan deposit harian'
    with pytest.raises(Issue) as report:client.write_batch('document',[(grid,[Write(grid.title,2,1,1)])])
    assert report.value.code=='READ_ONLY_REPORT' and not calls


@pytest.mark.parametrize('mode',['stale_token','no_token','lost_after_post','lost_during_proof','metadata_response_limit'])
def test_unknown_revision_and_metadata_fallback_preserve_full_protection(logged,db,monkeypatch,tmp_path,mode):
    site,fake,apis=world(logged,db,monkeypatch,tmp_path,token=mode!='no_token')
    if mode=='stale_token':fake.versions['destination-copy-12345']+=1
    if mode in ('lost_after_post','lost_during_proof'):
        token=fake.content_revision;lost=[False];fake.content_revision=lambda doc:None if lost[0] else token(doc)
        if mode=='lost_after_post':
            write=fake.write_batch
            def submit(*args):result=write(*args);lost[0]=True;return result
            fake.write_batch=submit
        else:
            scan=DestinationReader._scan
            def read(view):
                result=scan(view)
                if getattr(view.client,'invariant_epoch',None) is not None:lost[0]=True
                return result
            monkeypatch.setattr(DestinationReader,'_scan',read)
    if mode=='metadata_response_limit':
        request=fake.request
        def get(method,*args,**kwargs):
            params=kwargs.get('params',{})
            if method=='GET' and not params.get('ranges') and 'merges' in params.get('fields',''):
                raise Issue('RESPONSE_TOO_LARGE','Fixture metadata cap')
            return request(method,*args,**kwargs)
        fake.request=get
    run=execute(logged,db,site,fake)
    if mode=='lost_during_proof':
        assert run.status=='PARTIAL'
        assert all(l.verification_status=='PREPARED' for l in db.scalars(select(WriteLedger)))
    else:assert run.status=='SUCCESS',detail(logged,run)['errors']
    if mode=='no_token':assert len(fake.batch_requests)==7


def test_changed_formula_is_rejected_on_unknown_revision_fallback(logged,db,monkeypatch,tmp_path):
    site,fake,apis=world(logged,db,monkeypatch,tmp_path,token=False)
    apis['TOTAL DEPO'].fixture.merge(2,3,1,2)
    run=execute(logged,db,site,fake)
    assert run.status=='PARTIAL' and not any(w.tab=='TOTAL DEPO' and w.address=='B3' for w in fake.writes)


def test_ready_mapping_is_required_before_any_batched_post(logged,db,monkeypatch,tmp_path):
    site,fake,apis=world(logged,db,monkeypatch,tmp_path)
    run=db.get(Run,start(logged,site,selected_date=str(SELECTED))['id'])
    db.get(DestinationMapping,run.config_snapshot['mapping_id']).state='FAILED';db.commit()
    process_run(db,run,fake)
    assert run.status in ('PARTIAL','FAILED') and not fake.batch_requests


def test_read_logs_classify_geometry_and_target_ranges_without_payload():
    classify=SheetsClient.request_info
    assert classify('GET','sheets','doc',{'params':{'ranges':["'BIAYA'!B3:B3"],'fields':'rowData'}})=={'read_kind':'target_cells','range_count':1,'requested_cells':1}
    assert classify('GET','sheets','doc',{'params':{'ranges':["'BIAYA'!A1:BL125"],'fields':'rowData'}})['requested_cells']==8000
    assert classify('GET','sheets','doc',{'params':{'fields':'merges'}})['read_kind']=='merged_geometry'
    assert classify('GET','drive','doc',{})['read_kind']=='drive_version'
    assert 'private_key' not in str(classify('POST','sheets','doc',{'json':{'private_key':'not logged'}}))


@pytest.mark.parametrize('geometry',['ceiling','sparse_header','only_one_full_header','notes_extend_body','numeric_dates','merges','padded_header_stripes'])
def test_invariant_reader_is_exactly_equivalent_or_uses_original_fallback(geometry):
    from contextlib import closing
    from app.engine.writer import structural,formula_map
    from app.engine.resolver import regular
    from writer_fixture import FormattedExpense
    from wide_api import LazySheet,WideAPI
    sheet=(FormattedExpense if geometry in ('ceiling','numeric_dates','merges') else LazySheet)('BIAYA',height=256,width=192 if geometry=='padded_header_stripes' else 64)
    sheet.formatted_blanks=geometry in ('ceiling','numeric_dates','merges')
    sheet.put(0,0,'VELBETT');sheet.put(0,8,'FANTASI');sheet.put(1,1,'ACCOUNT');sheet.put(2,0,'18-Oct-2026')
    sheet.put(1,2,'TOTAL');sheet.put(2,2,0,formula='=SUM(B3:B3)')
    if geometry=='only_one_full_header':sheet.put(0,63,None,note='header extent')
    if geometry in ('sparse_header','notes_extend_body'):sheet.put(230,63,None,note='body extends original padded geometry')
    if geometry=='padded_header_stripes':sheet.put(100,190,None,note='original padded header extents')
    if geometry=='numeric_dates':sheet.put(2,0,(SELECTED-date(1899,12,30)).days,date_format=True)
    if geometry=='merges':sheet.merge(0,1,0,5)
    api=WideAPI(sheet)
    with closing(DestinationReader(api,'document',sheet.title,['VELBETT','FANTASI'])) as original,closing(DestinationReader(api,'document',sheet.title,['VELBETT','FANTASI'],invariants_only=True)) as optimized:
        assert structural(original)==structural(optimized) and formula_map(original)==formula_map(optimized)
        assert as_target(regular(original,'VELBETT',['VELBETT','FANTASI'],SELECTED,'ACCOUNT',123))==as_target(regular(optimized,'VELBETT',['VELBETT','FANTASI'],SELECTED,'ACCOUNT',123))
        assert optimized.invariants_only_used==(geometry in ('ceiling','numeric_dates','merges'))
        # Financial targets still fetch Notes and formatting through FULL fields.
        assert optimized.cell(2,1).snapshot==original.cell(2,1).snapshot


def as_target(write):return write.tab,write.row,write.col,write.value,write.note


@pytest.mark.parametrize('offset',[1,2])
def test_thin_proof_preserves_black_day_headers_on_third_and_fourth_rows(offset):
    from contextlib import closing
    from app.engine.resolver import transfer_slots
    from test_transfer_layout import monthly_layout
    from wide_api import LazySheet,WideAPI
    original=monthly_layout();sheet=LazySheet(original.title,height=30,width=64)
    sheet.formatted_blanks=True
    for r,row in enumerate(original.rows):
        for c,cell in enumerate(row):
            if not cell.empty or cell.color is not None:sheet.cells[r+offset,c]=deepcopy(cell)
    sheet.merges=[{**m,'startRowIndex':m['startRowIndex']+offset,'endRowIndex':m['endRowIndex']+offset} for m in original.merges]
    api=WideAPI(sheet)
    with closing(DestinationReader(api,'document',sheet.title,['VELBETT','FANTASI'])) as full,closing(DestinationReader(api,'document',sheet.title,['VELBETT','FANTASI'],invariants_only=True)) as thin:
        assert thin.invariants_only_used
        for website in ('VELBETT','FANTASI'):
            assert transfer_slots(thin,website,['VELBETT','FANTASI'],date(2026,10,15))==transfer_slots(full,website,['VELBETT','FANTASI'],date(2026,10,15))


@pytest.mark.parametrize('content',['manual_note','formula'])
def test_thin_proof_does_not_hide_protected_target_content(logged,db,monkeypatch,tmp_path,content):
    site,fake,apis=configure_writer(logged,db,monkeypatch,tmp_path,heavy=True,batch=True)
    sheet=apis['BIAYA'].fixture
    old=deepcopy(sheet.cell(2,1));sheet.put(2,1,None,note='manual target' if content=='manual_note' else '',formula='=123' if content=='formula' else None,color=(.2,.4,.6))
    protected=deepcopy(sheet.cell(2,1).snapshot)
    run=execute(logged,db,site,fake)
    assert run.status=='PARTIAL' and sheet.cell(2,1).snapshot==protected and sheet.cell(2,1).color==(.2,.4,.6)
    assert not any(w.tab=='BIAYA' and w.address=='B3' for w in fake.writes)


def test_fee_anchor_note_below_header_is_still_checked_with_thin_proof(logged,db,monkeypatch,tmp_path):
    site,fake,apis=world(logged,db,monkeypatch,tmp_path)
    sheet=apis['Pengeluaran FEE QRIS WD'].fixture;sheet.formatted_blanks=True
    for (r,c),cell in list(sheet.cells.items()):
        if r==2:sheet.cells[7,c]=sheet.cells.pop((r,c))
    for c in (1,2):sheet.cells[4,c]=sheet.cells.pop((1,c))
    fake.rebuild_mapping()
    old=sheet.cell(4,1);sheet.put(4,1,old.value,note='Changed protected anchor note')
    run=execute(logged,db,site,fake)
    assert run.status=='PARTIAL' and not any(w.tab==sheet.title for w in fake.writes)
    assert any(e['error_code']=='DESTINATION_CHANGED' for e in detail(logged,run)['errors'])


def test_upgrade_hold_keeps_ready_registry_snapshots_ledgers_and_history(logged,db,monkeypatch,tmp_path):
    import os,sqlite3,subprocess,sys
    from pathlib import Path
    from app.db import utcnow
    site,fake,apis=world(logged,db,monkeypatch,tmp_path);original=fake.write_batch
    def crash(*args):original(*args);raise SystemExit('accepted then stopped')
    fake.write_batch=crash;run=db.get(Run,start(logged,site,selected_date=str(SELECTED))['id'])
    with pytest.raises(SystemExit):process_run(db,run,fake)
    for state in ('SUCCESS','FAILED','CANCELED'):
        db.add(Run(website_id=site['id'],selected_date=SELECTED,year=2026,month=10,environment='TEST',started_by=1,
            idempotency_key=str(uuid4()),status=state,config_snapshot=deepcopy(run.config_snapshot)))
    db.commit();database=Path(db.get_bind().url.database);backup=tmp_path/'v42.sqlite3'
    with sqlite3.connect(database) as connection:
        connection.execute('CREATE TABLE alembic_version(version_num VARCHAR(32) NOT NULL PRIMARY KEY)')
        connection.execute("INSERT INTO alembic_version VALUES ('c92448ce233b')")
    with sqlite3.connect(database) as source,sqlite3.connect(backup) as target:source.backup(target)
    mutable={'task_runs','task_run_items','crawl_batches','crawl_batch_entries','item_retry_requests','destination_conflicts','audit_logs','reconciliations'}
    with sqlite3.connect(backup) as connection:
        tables=[r[0] for r in connection.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        protected={t:connection.execute('SELECT * FROM '+t).fetchall() for t in tables if t not in mutable}
        history=connection.execute("SELECT * FROM task_runs WHERE status IN ('SUCCESS','FAILED','CANCELED')").fetchall()
    env={**os.environ,'TK_DATABASE_URL':str(db.get_bind().url),'TK_WORKER_LOCK':str(tmp_path/'worker.lock')}
    result=subprocess.run([sys.executable,'-m','app.cli','prepare-v42-upgrade','--services-stopped'],cwd=Path(__file__).parents[1],env=env,capture_output=True,text=True)
    assert result.returncode==0,result.stderr
    with sqlite3.connect(database) as connection:
        assert all(connection.execute('SELECT * FROM '+t).fetchall()==rows for t,rows in protected.items())
        assert connection.execute("SELECT * FROM task_runs WHERE status IN ('SUCCESS','FAILED','CANCELED') AND id!=?",(run.id,)).fetchall()==history
        assert connection.execute('SELECT status FROM task_runs WHERE id=?',(run.id,)).fetchone()[0]=='CANCELED'
        assert connection.execute('PRAGMA integrity_check').fetchone()[0]=='ok' and not connection.execute('PRAGMA foreign_key_check').fetchall()
        assert connection.execute('SELECT version_num FROM alembic_version').fetchall()==[('c92448ce233b',)]
    verifier=Path(__file__).parents[2]/'scripts/verify-v421-upgrade.py'
    result=subprocess.run([sys.executable,str(verifier),str(backup),str(database)],capture_output=True,text=True)
    assert result.returncode==0,result.stderr
    with sqlite3.connect(database) as connection:connection.execute("UPDATE output_write_ledger SET verification_status='WRONG' WHERE id=(SELECT min(id) FROM output_write_ledger)")
    result=subprocess.run([sys.executable,str(verifier),str(backup),str(database)],capture_output=True,text=True)
    assert result.returncode!=0 and 'output_write_ledger' in result.stderr


def test_43_item_performance_regression_matches_baseline_output_and_reduces_io(tmp_path):
    import json,subprocess,sys
    from pathlib import Path
    probe=Path(__file__).with_name('performance')/'measure_v421_writer.py'
    results=[]
    for args in (['--legacy'],[]):
        result=subprocess.run([sys.executable,str(probe),*args],capture_output=True,text=True,timeout=60)
        assert result.returncode==0,result.stderr
        results.append(json.loads(result.stdout))
    before,after=results
    assert before['financial_plans']==after['financial_plans']==43 and before['source_snapshots']==after['source_snapshots']==8
    assert before['absolute_output']==after['absolute_output'] and before['item_statuses']==after['item_statuses']
    assert after['destination_gets']<before['destination_gets']//2 and after['destination_posts']==1<before['destination_posts']
    assert after['destination_response_bytes']<before['destination_response_bytes']//50 and after['multi_megabyte_gets']==0
    assert after['peak_rss_mb']<512 and not after['oom'] and after['wall_clock_ms']>0


def test_priority_qris_retry_waits_for_depo_transfer_slots_without_replaying_success(logged,db,monkeypatch,tmp_path):
    from sqlalchemy.orm import Session
    from app.models import RetryRequest,User
    from app.operations import queue_retry
    from app.api import Retry
    site,fake,apis=world(logged,db,monkeypatch,tmp_path);fake.fail_tabs.add('QRIS E-POWER')
    run=db.get(Run,start(logged,site,selected_date=str(SELECTED))['id']);raw=fake.source_day;queued=[]
    def source(doc,title,*args):
        if title=='QRIS QRIZZ' and not queued:
            fake.fail_tabs.clear()
            with Session(db.get_bind(),expire_on_commit=False) as other:
                selected=item(other,run,'transfers','QRIS E-POWER');assert selected.status=='FAILED'
                queue_retry(other,other.get(Run,run.id),Retry(item_ids=[selected.id]),other.get(User,1));other.commit()
                queued.append(selected.id)
        return raw(doc,title,*args)
    fake.source_day=source;write=fake.write_batch;first=[]
    def submit(*args):
        if not first:
            first.append(True)
            assert db.scalar(select(RetryRequest)).state=='QUEUED'
        return write(*args)
    fake.write_batch=submit
    process_run(db,run,fake)
    assert queued and db.get(RunItem,queued[0]).status=='SUCCESS'
    descriptions=[w for w in fake.writes if w.transaction]
    qris=[w for w in descriptions if w.note.startswith('QRIS E-POWER')]
    depo=[w for w in descriptions if not w.note]
    assert len(depo)==12 and len(qris)==1 and max(w.row for w in depo)<qris[0].row
    assert db.scalar(select(RetryRequest)).state=='SUCCEEDED' and len(fake.batch_requests)==2
    assert item(db,run,'deposit','QRIS E-POWER').status=='FAILED'


def test_shared_registry_handle_tracks_authorized_structural_financial_overlay(logged,db,monkeypatch,tmp_path):
    from app.destination_registry import RegistryView
    from app.engine.writer import structural
    site,fake,apis=world(logged,db,monkeypatch,tmp_path)
    run=db.get(Run,start(logged,site,selected_date=str(SELECTED))['id'])
    # A dated fee description is an allowed financial write which also
    # matches the global structural date predicate. A stale handle must pick
    # up its accepted durable signature without hiding external changes.
    handle=RegistryView(db,fake,run,'Pengeluaran FEE QRIS DEPO');before=structural(handle)
    process_run(db,run,fake);assert run.status=='SUCCESS',detail(logged,run)['errors']
    fresh=handle.refresh()
    try:assert structural(handle)==structural(fresh)!=before
    finally:fresh.close();handle.close()


def test_cancel_at_last_boundary_before_http_does_not_submit_batch(logged,db,monkeypatch,tmp_path):
    from test_cancellation import cancel_other
    import app.engine.batch_writer as batched
    site,fake,apis=world(logged,db,monkeypatch,tmp_path);run=db.get(Run,start(logged,site,selected_date=str(SELECTED))['id'])
    phase=batched.phase
    def record(session,job,value):
        phase(session,job,value)
        if value=='WRITING':cancel_other(db,run.id)
    monkeypatch.setattr(batched,'phase',record)
    process_run(db,run,fake)
    assert run.status=='CANCELED' and not fake.batch_requests and not fake.writes
    assert all(l.verification_status=='PREPARED' for l in db.scalars(select(WriteLedger)))


def test_final_read_failure_is_isolated_to_its_destination_tab(logged,db,monkeypatch,tmp_path):
    import app.engine.batch_writer as batched
    site,fake,apis=world(logged,db,monkeypatch,tmp_path);original=batched.ObservedTargets
    class FailBoundary(original):
        seen=0
        def __init__(self,view,positions,budget,**kwargs):
            if view.title=='TOTAL DEPO':
                FailBoundary.seen+=1
                if FailBoundary.seen==2:raise Issue('GOOGLE_TIMEOUT','One final tab GET failed')
            super().__init__(view,positions,budget,**kwargs)
    monkeypatch.setattr(batched,'ObservedTargets',FailBoundary)
    run=execute(logged,db,site,fake)
    assert run.status=='PARTIAL' and not any(w.tab=='TOTAL DEPO' for w in fake.writes)
    assert any(w.tab=='TOTAL WD' for w in fake.writes) and len(fake.batch_requests)==1


def test_single_leftover_expense_total_uses_narrow_proof_without_source_or_success_replay(logged,db,monkeypatch,tmp_path):
    from test_cancellation import cancel_other
    site,fake,apis=configure_writer(logged,db,monkeypatch,tmp_path,heavy=True,batch=False)
    run=db.get(Run,start(logged,site,selected_date=str(SELECTED))['id']);original=fake.write
    def stop_after_last_prior_write(doc,grid,writes):
        original(doc,grid,writes)
        if grid.title=='Pengeluaran FEE QRIS DEPO':cancel_other(db,run.id)
    fake.write=stop_after_last_prior_write;process_run(db,run,fake)
    total=item(db,run,'expense_total')
    assert run.status=='CANCELED' and total.status=='CANCELED'
    assert not db.scalar(select(WriteLedger.id).where(WriteLedger.run_item_id==total.id))
    snapshots=[(s.id,s.checksum,deepcopy(s.payload)) for s in db.scalars(select(SourceSnapshot).where(SourceSnapshot.run_id==run.id))]
    preserved={i.id:deepcopy(i.result) for i in db.scalars(select(RunItem).where(RunItem.run_id==run.id,RunItem.id!=total.id))}
    fake.write=original;fake.writes.clear();fake.reads.clear();posts=[]
    fake._write_requests=SheetsClient._write_requests
    def write_batch(doc,groups):
        posts.append(groups);fake.writes.extend(deepcopy([w for grid,writes in groups for w in writes]))
        return SheetsClient.write_batch(fake,doc,groups)
    fake.write_batch=write_batch
    masks=[];raw=apis['BIAYA'].request
    def read(method,*args,**kw):
        if method=='GET':masks.append((kw.get('params',{}).get('fields',''),kw.get('params',{}).get('ranges',[])))
        return raw(method,*args,**kw)
    apis['BIAYA'].request=read
    assert logged.post(f'/api/runs/{run.id}/retry',json={'item_ids':[total.id]}).status_code==202
    process_run(db,run,fake)
    assert run.status=='SUCCESS',detail(logged,run)['errors']
    assert len(posts)==1 and [(w.tab,w.address,w.value) for w in fake.writes]==[('BIAYA','B3',33000)]
    assert all(db.get(RunItem,id).result==value for id,value in preserved.items())
    assert [(s.id,s.checksum,s.payload) for s in db.scalars(select(SourceSnapshot).where(SourceSnapshot.run_id==run.id))]==snapshots
    assert not any(doc in ('depo-document-12345','qris-document-12345') for doc,title in fake.reads)
    assert any('rowData' in mask and 'note' not in mask and 'numberFormat(type)' in mask for mask,ranges in masks)
    assert all(api.largest<=8388608 for api in apis.values())
