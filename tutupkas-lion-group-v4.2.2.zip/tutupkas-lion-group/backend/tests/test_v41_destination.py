from contextlib import closing
from copy import deepcopy
from datetime import date
import json
from pathlib import Path
import subprocess
import sys

import pytest
from sqlalchemy import select

from app.config import settings
from app.destination_reader import read_destination
from app.engine import resolver
from app.engine.report import resolve_balance
from app.engine.runner import process_run
from app.engine.types import Cell, Issue, Write, column
from app.engine.writer import check_write, execute, formula_map, structural
from app.models import Run,RunItem,WriteLedger
from app.reconciliation import fresh_balance
from fixtures.v4_grid_reader import V4GridReader
from helpers import DAY, DEPO_NAME, destinations, report
from test_engine import configured,start
from wide_api import LazySheet, WideAPI, wide_regular

SELECTED=date(2026,10,18)
SOURCE='WD DANA 1 / FATMAWATI ( PP )'


@pytest.mark.parametrize('width,target',[(1000,820),(1500,1420),(1800,1750)])
def test_wide_allocated_grid_and_far_right_absolute_coordinates(width,target):
    sheet,names=wide_regular(width=width,target=target)
    api=WideAPI(sheet)
    with closing(api.destination_grid('destination',sheet.title,names)) as view:
        w=resolver.regular(view,'VELBETT',names,SELECTED,SOURCE,2355000)
        assert (w.row,w.col,w.address)==(74,target+1,f'{column(target+1)}75')
        assert not hasattr(view,'rows')  # No dense/sparse rows ambiguity.
        assert view.db.execute('SELECT count(*) FROM cells').fetchone()[0]<1000
        for path,params in api.calls:
            total=0
            for a1 in params.get('ranges',[]):
                top,bottom,left,right=api.decode(a1)
                assert (bottom-top+1)*(right-left+1)<=settings().grid_chunk_cells
                assert '!' in a1
                total+=(bottom-top+1)*(right-left+1)
            assert total<=settings().destination_batch_cells
        assert api.largest<settings().max_api_response_bytes


def test_v4_differential_mapping_and_exact_global_structure_hash():
    sheet,names=wide_regular(width=450,height=60,target=420,date_row=44)
    sheet.put(0,423,'',formula=None)
    sheet.merge(0,1,420,428)
    old=V4GridReader.grid(WideAPI(sheet),'destination',sheet.title)
    api=WideAPI(sheet)
    with closing(api.destination_grid('destination',sheet.title,names)) as view:
        a=resolver.regular(old,'VELBETT',names,SELECTED,SOURCE,2355000)
        b=resolver.regular(view,'VELBETT',names,SELECTED,SOURCE,2355000)
        assert vars(a)==vars(b)
        assert structural(view)==structural(old)
        assert formula_map(view)==formula_map(old)
        assert view.merges==old.merges


@pytest.mark.parametrize('fault,code',[('duplicate_marker','WEBSITE_BLOCK_MISSING'),('missing_date','DESTINATION_DATE_MISSING'),
    ('duplicate_date','DESTINATION_DATE_MISSING'),('unregistered_boundary','ACCOUNT_MISSING')])
def test_old_ambiguity_and_unregistered_boundaries_match(fault,code):
    sheet,names=wide_regular(width=450,height=60,target=420,date_row=44)
    if fault=='duplicate_marker':sheet.put(3,430,'VELBETT')
    if fault=='missing_date':sheet.cells.pop((44,420))
    if fault=='duplicate_date':sheet.put(45,420,'18-Oct-2026')
    if fault=='unregistered_boundary':
        sheet.put(1,421,'OTHER');sheet.put(0,424,'UNREGISTERED');sheet.put(44,424,'18-Oct-2026');sheet.put(1,425,'FATMAWATI')
    old=V4GridReader.grid(WideAPI(sheet),'dest',sheet.title)
    with closing(WideAPI(sheet).destination_grid('dest',sheet.title,names)) as view:
        errors=[]
        for grid in (old,view):
            with pytest.raises(Issue) as caught:resolver.regular(grid,'VELBETT',names,SELECTED,SOURCE,1)
            errors.append((caught.value.code,caught.value.context))
        assert errors[0]==errors[1] and errors[1][0]==code


def test_numeric_dates_similar_neighbors_and_merged_headers_cross_chunk():
    sheet,names=wide_regular(width=500,height=100,target=420)
    sheet.put(74,420,(SELECTED-date(1899,12,30)).days,date_format=True)
    names.append('VELBETT TWO');sheet.put(0,460,'VELBETT TWO');sheet.put(1,461,'FATMAWATI');sheet.put(74,460,'18-Oct-2026')
    sheet.merge(0,1,420,450)  # crosses the 448-column scan edge
    with closing(WideAPI(sheet).destination_grid('dest',sheet.title,names)) as view:
        assert resolver.regular(view,'VELBETT',names,SELECTED,SOURCE,1).col==421
        assert resolver.regular(view,'VELBETT TWO',names,SELECTED,SOURCE,1).col==461


@pytest.mark.parametrize('mode',['formula','manual_value','manual_note','merged'])
def test_real_sparse_target_checks_preserve_conflicts(logged,db,monkeypatch,tmp_path,mode):
    w,fake=configured(logged,db,monkeypatch,tmp_path);r=start(logged,w)
    run=db.get(Run,r['id']);item=db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type=='deposit'))
    sheet,names=wide_regular(width=450,height=100,target=420)
    if mode=='formula':sheet.put(74,421,0,formula='=SUM(A1:A2)')
    if mode=='manual_value':sheet.put(74,421,'manual')
    if mode=='manual_note':sheet.put(74,421,None,note='manual note')
    if mode=='merged':sheet.merge(74,75,420,422)
    api=WideAPI(sheet)
    with closing(api.destination_grid('destination',sheet.title,names)) as view:
        write=Write(sheet.title,74,421,123)
        with pytest.raises(Issue) as caught:execute(db,api,run,item,view,[write])
        assert caught.value.code=={'formula':'FORMULA_CONFLICT','manual_value':'EXISTING_VALUE_CONFLICT',
            'manual_note':'EXISTING_VALUE_CONFLICT','merged':'MERGED_CELL_CONFLICT'}[mode]
        assert not api.posts


@pytest.mark.parametrize('change,code',[('header','DESTINATION_CHANGED'),('merge','DESTINATION_CHANGED'),
    ('target','EXISTING_VALUE_CONFLICT'),('after_formula','FORMULA_CHANGED'),('readback','READBACK_FAILED')])
def test_changes_during_plan_and_global_formula_after_post(logged,db,monkeypatch,tmp_path,change,code):
    w,fake=configured(logged,db,monkeypatch,tmp_path);r=start(logged,w)
    run=db.get(Run,r['id']);item=db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type=='deposit'))
    sheet,names=wide_regular(width=500,height=100,target=420)
    sheet.put(99,499,0,formula='=1+1')  # far outside selected website and date
    api=WideAPI(sheet)
    with closing(api.destination_grid('destination',sheet.title,names)) as view:
        if change=='header':sheet.put(1,421,'OTHER')
        if change=='merge':sheet.merge(80,82,440,449)
        if change=='target':sheet.put(74,421,999,note='external')
        if change=='readback':api.corrupt=True
        if change=='after_formula':
            def changed():
                if api.posts:sheet.put(99,499,0,formula='=2+2')
            api.hook=changed
        with pytest.raises(Issue) as caught:execute(db,api,run,item,view,[Write(sheet.title,74,421,123)])
        assert caught.value.code==code
        if change in ('after_formula','readback'):
            assert db.scalar(select(WriteLedger)).verification_status=='PREPARED'
        else:assert not api.posts


def test_prepared_verified_ledger_and_readback_note_are_preserved(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);r=start(logged,w)
    run=db.get(Run,r['id']);item=db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type=='deposit'))
    sheet,names=wide_regular(width=450,height=100,target=420)
    api=WideAPI(sheet)
    with closing(api.destination_grid('dest',sheet.title,names)) as view:
        result=execute(db,api,run,item,view,[Write(sheet.title,74,421,123,note='Original QRIS note')])
        assert result['verified'] and sheet.cell(74,421).note=='Original QRIS note'
    ledger=db.scalar(select(WriteLedger));assert ledger.verification_status=='VERIFIED'
    ledger.verification_status='PREPARED';db.commit()
    with closing(api.destination_grid('dest',sheet.title,names)) as view:
        with pytest.raises(Issue) as caught:execute(db,api,run,item,view,[Write(sheet.title,74,421,456,note='Original QRIS note')])
        assert caught.value.code=='UNCERTAIN_WRITE'
        result=execute(db,api,run,item,view,[Write(sheet.title,74,421,123,note='Original QRIS note')])
        assert result['verified'] and ledger.verification_status=='VERIFIED'


def shifted(grid,rows=1000,cols=1500,dy=73,dx=420):
    sheet=LazySheet(grid.title,rows,cols,grid.sheet_id)
    regular=grid.title not in ('KET PENGIRIMAN','Laporan deposit harian')
    for r,row in enumerate(grid.rows):
        for c,cell in enumerate(row):
            if not cell.empty or cell.color is not None or cell.date_format:
                sheet.cells[r if regular and r<2 else r+dy,c+dx]=deepcopy(cell)
    sheet.merges=[{**m,'startRowIndex':m['startRowIndex']+(0 if regular and m['endRowIndex']<=2 else dy),'endRowIndex':m['endRowIndex']+(0 if regular and m['endRowIndex']<=2 else dy),
                  'startColumnIndex':m['startColumnIndex']+dx,'endColumnIndex':m['endColumnIndex']+dx} for m in grid.merges]
    return sheet


@pytest.mark.parametrize('layout',['calendar','monthly'])
def test_transfer_layouts_slots_notes_and_merges_match_v4(layout):
    from test_transfer_layout import monthly_layout
    if layout=='calendar':g=destinations()['KET PENGIRIMAN']
    else:g=monthly_layout()
    # Keep a small allowed V4 fixture for exact differential comparison.
    sheet=shifted(g,rows=120,cols=500,dy=15 if layout=='calendar' else 0,dx=70)
    api=WideAPI(sheet)
    old=V4GridReader.grid(api,'dest',sheet.title)
    with closing(WideAPI(sheet).destination_grid('dest',sheet.title,['VELBETT','FANTASI'])) as view:
        assert resolver.transfer_slots(view,'VELBETT',['VELBETT','FANTASI'],DAY)==resolver.transfer_slots(old,'VELBETT',['VELBETT','FANTASI'],DAY)
        assert structural(view)==structural(old)


@pytest.mark.parametrize('vertical',[False,True])
def test_wide_readonly_report_and_stable_zero(vertical):
    g=report(balances={'VELBETT':-30278535})
    if vertical:
        g.rows[0][13]=Cell()
        for r,letter in enumerate('VELBETT'):g.rows[r][13]=Cell(letter)
    sheet=shifted(g)
    api=WideAPI(sheet)
    with closing(api.destination_grid('dest',sheet.title,['VELBETT','FANTASI','BBTOTO'])) as view:
        result=resolve_balance(view,DAY,'VELBETT',['VELBETT','FANTASI','BBTOTO'])
        assert result['balance']=='-30278535' and result['row']==75 and result['column']==443
        assert resolve_balance(view,DAY,None,['VELBETT','FANTASI','BBTOTO'])['balance']=='0'
        with pytest.raises(Issue) as caught:api.write('dest',view,[Write(sheet.title,75,443,0)])
        assert caught.value.code=='READ_ONLY_REPORT' and not api.posts
    # Two separate fresh readers are required for stable zero.
    api=WideAPI(shifted(report()))
    result=fresh_balance(api,{'spreadsheet_id':'dest'},DAY,'VELBETT',['VELBETT','FANTASI','BBTOTO'])
    assert result['balance']=='0'
    assert len([1 for _,p in api.calls if p.get('fields','').startswith('sheets(properties(sheetId,title')])==2


def wire_destinations(fake,dy=73,dx=420):
    apis={title:WideAPI(shifted(g),retain_calls=False) for title,g in fake.documents['destination-copy-12345'].items()}
    def destination(id,title,registered=()):
        return apis[title].destination_grid(id,title,registered)
    def write(id,grid,writes):
        fake.writes.extend(deepcopy(writes));apis[grid.title].write(id,grid,writes)
    fake.destination_grid=destination;fake.write=write
    original_request=fake.request
    def request(method,path,**kwargs):
        import re
        if path.startswith('destination-copy-12345') and kwargs.get('params',{}).get('ranges'):
            title=re.match(r"'((?:[^']|'')*)'!",kwargs['params']['ranges'][0])[1].replace("''", "'")
            return apis[title].request(method,path,**kwargs)
        return original_request(method,path,**kwargs)
    fake.request=request
    fake.rebuild_mapping()  # Approve the deliberately shifted fixture first.
    return apis


def test_all_22_golden_writes_on_large_sparse_destination_and_reconciliation(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);apis=wire_destinations(fake)
    r=start(logged,w);process_run(db,db.get(Run,r['id']),fake)
    detail=logged.get(f"/api/runs/{r['id']}").json()
    assert detail['status']=='SUCCESS',detail['errors']
    golden=json.loads((Path(__file__).with_name('fixtures')/'v3_financial_outputs.json').read_text())['writes']
    actual=[]
    for w in fake.writes:
        actual.append([w.tab,f'{column(w.col-420)}{w.row-73+1}',w.value,w.note,w.bank,w.transaction])
    assert actual==golden
    assert detail['reconciliation']['status']=='BALANCED'
    assert not apis['Laporan deposit harian'].posts
    assert all(l.verification_status=='VERIFIED' for l in db.scalars(select(WriteLedger)))


def test_batched_byte_limit_splits_without_changing_v4_tiles_or_coordinates():
    sheet,names=wide_regular(width=1500)
    for row in (250,500,750):sheet.put(row,10,None,note='padding'*100)
    api=WideAPI(sheet);api.byte_limit=4500
    with closing(api.destination_grid('dest',sheet.title,names)) as view:
        assert api.rejected>0
        assert max(api.returned_sizes)<=4500
        assert resolver.regular(view,'VELBETT',names,SELECTED,SOURCE,1).col==1421
        # Oversized direct target batches also split, without guessing blanks.
        sheet.put(80,1421,None,note='x'*3500);sheet.put(80,1422,None,note='y'*3500)
        view.prefetch([(80,1421),(80,1422)])
        assert view.cell(80,1421).note=='x'*3500
        assert view.cell(80,1422).note=='y'*3500


def test_cache_is_bounded_by_bytes_and_never_treats_unfetched_target_as_empty():
    sheet,names=wide_regular(width=1500)
    api=WideAPI(sheet)
    with closing(api.destination_grid('dest',sheet.title,names)) as view:
        sheet.put(800,1400,'manual after scan',note='do not clear')
        before=api.count
        assert view.cell(800,1400).note=='do not clear' and api.count>before
        # A cell larger than the cache is read correctly without being retained.
        from app.engine.types import Cell
        huge=Cell(note='x'*1_100_000)
        view._remember((801,1400),huge)
        assert (801,1400) not in view.cache
        assert view.cache_bytes<=4*1048576
        assert view.db.execute('PRAGMA cache_size').fetchone()[0]==-512


def test_merged_metadata_is_global_and_filtered_by_exact_sheet_identity():
    sheet,names=wide_regular(width=1500)
    sheet.merge(800,801,1420,1422)  # outside the A1 metadata request
    api=WideAPI(sheet)
    original=api.request
    def request(method,path,**kwargs):
        reply=original(method,path,**kwargs)
        if 'merges(' in kwargs.get('params',{}).get('fields',''):
            reply['sheets'].append({'properties':{'sheetId':999},'merges':[
                {'startRowIndex':74,'endRowIndex':75,'startColumnIndex':1420,'endColumnIndex':1422}]})
        return reply
    api.request=request
    with closing(api.destination_grid('dest',sheet.title,names)) as view:
        assert view.merges.at(800,1421) is not None
        assert view.merges.at(74,1421) is None


def test_merge_response_limit_and_cancel_close_private_temporary_index(monkeypatch):
    from app.job_control import JobCanceled
    sheet,names=wide_regular(width=1000,target=820)
    api=WideAPI(sheet)
    original=api.request
    def request(method,path,**kwargs):
        if 'merges(' in kwargs.get('params',{}).get('fields',''):
            raise Issue('RESPONSE_TOO_LARGE','fixture')
        return original(method,path,**kwargs)
    api.request=request
    with pytest.raises(Issue) as caught:api.destination_grid('dest',sheet.title,names)
    assert caught.value.code=='MERGE_METADATA_LIMIT'
    api=WideAPI(sheet)
    api.cancel_check=lambda:(_ for _ in ()).throw(JobCanceled())
    with pytest.raises(JobCanceled):api.destination_grid('dest',sheet.title,names)


def test_memory_bounded_wide_and_preformatted_destinations():
    script=Path(__file__).with_name('performance')/'measure_destination.py'
    measured=[]
    for width,formatted in [(1000,False),(1500,True)]:
        cmd=[sys.executable,str(script),'--width',str(width)]
        if formatted:cmd.append('--formatted-blanks')
        p=subprocess.run(cmd,capture_output=True,text=True,timeout=90,check=True)
        result=json.loads(p.stdout);measured.append(result)
        assert result['v4_result']=='SHEET_TOO_LARGE' and result['v41_result']=='VERIFIED'
        assert result['peak_rss_mb']<512 and result['largest_response_bytes']<=8_388_608
        assert result['indexed_cells']<1000 and result['oom'] is False
    assert measured[1]['peak_rss_mb']-measured[0]['peak_rss_mb']<192


def test_private_index_is_removed_when_view_closes():
    import stat
    sheet,names=wide_regular(width=1000,target=820)
    view=WideAPI(sheet).destination_grid('dest',sheet.title,names)
    file=Path(view.db.execute('PRAGMA database_list').fetchone()[2])
    assert stat.S_IMODE(file.stat().st_mode)==0o600
    view.close()
    assert not file.exists() and not file.parent.exists()


def test_stop_after_submitted_post_still_verifies_sparse_readback(logged,db,monkeypatch,tmp_path):
    from app.job_control import check_cancel,JobCanceled
    from test_cancellation import cancel_other
    w,fake=configured(logged,db,monkeypatch,tmp_path);r=start(logged,w)
    run=db.get(Run,r['id']);run.status='RUNNING';db.commit()
    item=db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type=='deposit'))
    sheet,names=wide_regular(width=450,height=100,target=420)
    api=WideAPI(sheet);api.cancel_check=lambda:check_cancel(db,run=run)
    def before(method,params):
        if method=='POST':cancel_other(db,run.id)
    api.before=before
    with closing(api.destination_grid('dest',sheet.title,names)) as view:
        result=execute(db,api,run,item,view,[Write(sheet.title,74,421,123)])
        assert result['verified'] and db.scalar(select(WriteLedger)).verification_status=='VERIFIED'
    with pytest.raises(JobCanceled):api.cancel_check()
    db.refresh(run);assert run.status=='CANCEL_REQUESTED'


@pytest.mark.parametrize('fault,code',[('duplicate','DUPLICATE_REPORT_DATE'),
    ('header','REPORT_BALANCE_HEADER_MISSING'),('blank','INVALID_REPORT_BALANCE')])
def test_wide_report_never_substitutes_missing_or_ambiguous_balance(fault,code):
    sheet=shifted(report())
    if fault=='duplicate':sheet.put(76,434,'15-Oct-2026')
    if fault=='header':sheet.cells.pop((74,443))
    if fault=='blank':sheet.cells.pop((75,443))
    with closing(WideAPI(sheet).destination_grid('dest',sheet.title,['VELBETT','FANTASI','BBTOTO'])) as view:
        with pytest.raises(Issue) as caught:resolve_balance(view,DAY,'VELBETT',['VELBETT','FANTASI','BBTOTO'])
        assert caught.value.code==code
