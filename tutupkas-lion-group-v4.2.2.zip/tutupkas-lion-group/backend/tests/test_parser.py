from datetime import date

import pytest

from app.engine.parser import Day, parse_date, transfer_rows
from app.engine.types import Cell, Issue, number
from helpers import DAY, BLUE, PALETTE, depo, qris, put


def test_confirmed_minus_one_examples():
    d = Day.resolve(depo(), DAY)
    assert d.end + 1 == 306
    assert [d.metric(h) for h in ['Total', 'Total WD', 'SALDO']] == [0, 9399000, 2355000]
    q = Day.resolve(qris(), DAY, 'QRIS')
    assert q.end + 1 == 88
    assert [q.metric(h) for h in ['Total Depo', 'Total WD', 'SALDO']] == [75342988, 59804000, 449057834]


@pytest.mark.parametrize('raw,expected', [('Thursday, 15 October 2026', DAY), ('15-Okt-2026', DAY),
    ('15 Oktober 2026', DAY), ('2026-10-15', DAY), ('FEE QRIS PERIODE 14 - 15 october 2026', DAY)])
def test_date_formats(raw, expected):
    assert parse_date(Cell(raw)) == expected


def test_serial_date():
    assert parse_date(Cell(46310, date_format=True)) == date(2026, 10, 15)


def test_empty_day_and_carry_forward():
    g = depo()
    put(g, 306, 11, 2355000)
    day = Day.resolve(g, DAY.replace(day=16))
    assert day.transaction_rows == []
    assert [day.metric(h) for h in ['Total', 'Total WD', 'SALDO']] == [0, 0, 2355000]


def test_missing_next_marker_does_not_invent_closing():
    with pytest.raises(Issue, match='2026-10-18'):
        Day.resolve(depo(), DAY.replace(day=17))


def test_duplicate_source_headers_do_not_override_fixed_columns():
    g=depo();put(g,1,4,'Total');put(g,1,9,'HEADER LAIN')
    d=Day.resolve(g,DAY,'DEPO')
    assert d.metric('Total')==0 and d.metric('Total WD')==9399000
    assert d.metric('SALDO')==2355000


def test_expense_signed_sum_first():
    d = Day.resolve(depo(), DAY)
    assert abs(d.signed_sum(7)) == 5500


def test_qris_fee_separation_and_original_description():
    q = Day.resolve(qris(), DAY, 'QRIS')
    assert abs(q.signed_sum(6)) == 492000
    assert q.fees('FEE WD AUTO') == ('FEE WD AUTO', 732340)
    z = Day.resolve(qris('QRIS QRIZZ'), DAY, 'QRIS')
    assert z.fees('FEE QRIS PERIODE') == ('FEE QRIS PERIODE 14 - 15 october 2026', 621134)
    assert abs(z.signed_sum(6)) == 5000


def test_multiple_fee_descriptions_preserve_newlines_and_sum_recorded_only():
    g = qris('QRIS QRIZZ')
    put(g, 86, 3, 'FEE QRIS PERIODE 15- 16 october 2026\nFEE QRIS PERIODE 14 - 15 october 2026')
    put(g, 86, 7, -100)
    desc, amount = Day.resolve(g, DAY, 'QRIS').fees('FEE QRIS PERIODE')
    assert desc.count('\n') == 2
    assert amount == 621234


def test_brown_and_description_and_depo_bank_authority():
    out = transfer_rows(Day.resolve(depo(), DAY), 'DEPO', PALETTE)
    assert len(out) == 2
    assert out[1]['amount'] == -1741000
    assert all(t['bank'] == 'BCA' for t in out)


def test_blue_is_excluded_and_unapproved_fails():
    g = qris()
    g.rows[85][3].color = BLUE
    assert transfer_rows(Day.resolve(g, DAY, 'QRIS'), 'QRIS', PALETTE) == []
    g.rows[85][3].color = (.8, .5, .1)
    with pytest.raises(Issue) as err:
        transfer_rows(Day.resolve(g, DAY, 'QRIS'), 'QRIS', PALETTE)
    assert err.value.code == 'UNRECOGNIZED_TRANSFER_FORMAT'


def test_qris_note_sign_and_h_column():
    tx = transfer_rows(Day.resolve(qris(), DAY, 'QRIS'), 'QRIS', PALETTE)[0]
    assert tx['note'] == 'QRIS E-POWER ( KIRIM KE KAS BESAR BRI ) -1.000.000'


@pytest.mark.parametrize('value', ['#REF!', '1,00', True, '1.5', float('nan'), 1.5])
def test_reject_invalid_amount(value):
    with pytest.raises(Issue):
        number(value)

