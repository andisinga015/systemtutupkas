"""Delivered V4 destination reader, offline differential fixture only."""
from app.engine.types import Cell,Grid,Issue
from app.config import settings
from app.sheets import google_cell

class V4GridReader:
    def grid(self, document_id: str, title: str) -> Grid:
            # Destination/report only. Keep every mapping and protection cell, but
            # bound both total materialization and each HTTP response.
            p = self.sheet_properties(document_id, title)
            size = p.get('gridProperties', {})
            height, width = size.get('rowCount', 0), size.get('columnCount', 0)
            cfg = settings()
            if height * width > min(cfg.max_sheet_cells, cfg.max_destination_cells):
                raise Issue('SHEET_TOO_LARGE', 'Sheet tujuan melebihi batas baca aman untuk memori VPS.',
                            'Tinjau area kosong berlebih; pemeriksaan keamanan tidak dilewati. Jangan menaikkan MemoryMax.')
            rows, merges, merges_loaded = [], [], False
            fields = 'userEnteredValue,effectiveValue,note,effectiveFormat(backgroundColor,backgroundColorStyle,numberFormat(type)),formattedValue'
            band_width = min(64, max(1, cfg.grid_chunk_cells))
            for c in range(0, width, band_width):
                last_col = min(width, c+band_width)-1
                step = max(1, min(cfg.source_chunk_rows, cfg.grid_chunk_cells // (last_col-c+1)))
                for r in range(0, height, step):
                    last_row = min(height,r+step)-1
                    raw = self.cells(document_id, [self.a1(title,r,last_row,c,last_col)], fields, not merges_loaded)
                    for sheet in raw.get('sheets', []):
                        if not merges_loaded:
                            merges = sheet.get('merges', [])
                        for band in sheet.get('data', []):
                            start, col = band.get('startRow',0), band.get('startColumn',0)
                            for i, row in enumerate(band.get('rowData', [])):
                                if not r <= start+i <= last_row or not c <= col <= last_col:
                                    raise Issue('DESTINATION_READ_FAILED','Respons tujuan berada di luar rentang yang diminta.')
                                while len(rows) <= start+i:
                                    rows.append([])
                                values = row.get('values', [])
                                if col+len(values)-1 > last_col:
                                    raise Issue('DESTINATION_READ_FAILED','Respons tujuan melebihi batas kolom yang diminta.')
                                target = rows[start+i]
                                while len(target) < col+len(values):
                                    target.append(Cell())
                                for j, value in enumerate(values):
                                    target[col+j] = google_cell(value)
                    merges_loaded = True
                    del raw
            return Grid(title, p['sheetId'], rows, merges)
