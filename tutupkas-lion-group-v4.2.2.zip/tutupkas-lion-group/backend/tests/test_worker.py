import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

from sqlalchemy import select

from app.models import Run, RunItem, TaskError, Website
from helpers import DAY


def test_worker_process_holds_interrupted_job_without_replay(db,tmp_path):
    website=Website(display_name='WORKER TEST',slug='worker-test')
    db.add(website)
    db.flush()
    run=Run(website_id=website.id,selected_date=DAY,year=2026,month=10,environment='TEST',started_by=1,
            idempotency_key='worker-process-recovery-test',status='RUNNING',config_snapshot={
                'website':'WORKER TEST','sources':[],'destination':{'id':1,'revision':1,'spreadsheet_id':'not-accessed'}})
    db.add(run)
    db.flush()
    db.add(RunItem(run_id=run.id,source_tab_name='Unavailable source',metric_type='deposit',source_date=DAY))
    db.commit()
    process_env={**os.environ,'TK_DATABASE_URL':str(db.get_bind().url),
                 'TK_CREDENTIAL_FILE':str(tmp_path/'no-credentials.json'),
                 'TK_WORKER_LOCK':str(tmp_path/'worker.lock'),'TK_WORKER_POLL_SECONDS':'0.05'}
    log=tmp_path/'worker.log'
    with log.open('w') as out:
        proc=subprocess.Popen([sys.executable,'-m','app.worker'],cwd=Path(__file__).parents[1],
                              env=process_env,stdout=out,stderr=out)
        try:
            deadline=time.monotonic()+8
            while time.monotonic()<deadline:
                db.expire_all()
                if db.get(Run,run.id).status=='FAILED':
                    break
                assert proc.poll() is None,log.read_text()
                time.sleep(.05)
            assert db.get(Run,run.id).status=='FAILED',log.read_text()
            second=subprocess.run([sys.executable,'-m','app.worker'],cwd=Path(__file__).parents[1],
                                  env=process_env,capture_output=True,text=True,timeout=5)
            assert second.returncode!=0 and 'Worker lain sudah berjalan' in second.stderr
        finally:
            proc.send_signal(signal.SIGTERM)
            proc.wait(timeout=5)
    assert proc.returncode==0
    assert 'worker_ready' in log.read_text()
    error=db.scalar(select(TaskError).where(TaskError.run_id==run.id))
    assert error.error_code=='WORKER_INTERRUPTED'

