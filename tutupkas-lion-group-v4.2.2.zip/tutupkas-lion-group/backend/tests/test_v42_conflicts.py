"""Actual old/new groups, explicit decisions, stale approvals and read-only Preview."""
from copy import deepcopy
from uuid import uuid4

import pytest
from sqlalchemy import select

from app.engine.runner import process_run
from app.models import Run,RunItem,DestinationConflict,ConflictDecision,TaskError,WriteLedger,AuditLog
from helpers import put
from test_engine import configured,start


def create_conflict(logged,db,monkeypatch,tmp_path,tab='TOTAL DEPO',preview=False,note=''):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    grid=fake.documents['destination-copy-12345'][tab]
    put(grid,2,1,'DATA LAMA' if tab.startswith('Pengeluaran') else 999,note=note)
    if tab.startswith('Pengeluaran'):put(grid,2,2,123)
    r=start(logged,w,preview=preview);run=db.get(Run,r['id']);process_run(db,run,fake)
    conflict=db.scalar(select(DestinationConflict).where(DestinationConflict.run_id==run.id,DestinationConflict.state=='OPEN'))
    assert conflict is not None,logged.get(f'/api/runs/{run.id}').json()['errors']
    return w,fake,run,conflict


def decision(logged,conflict,action,key=None):
    data=logged.post(f'/api/conflicts/{conflict.id}/refresh')
    assert data.status_code==200,data.text
    result=logged.post(f'/api/conflicts/{conflict.id}/decide',json={'action':action,'observation_hash':data.json()['observation_hash'],
        'idempotency_key':key or str(uuid4())})
    return result


def test_exact_google_values_and_provenance_are_exposed(logged,db,monkeypatch,tmp_path):
    w,fake,run,conflict=create_conflict(logged,db,monkeypatch,tmp_path)
    result=logged.post(f'/api/conflicts/{conflict.id}/refresh').json()
    assert result['current_observed'][0]['value']==999 and result['writes'][0]['value']==0
    assert result['current_observed'][0]['cell']=='B3' and result['provenance']['source_cell'].endswith('J306')
    assert result['provenance']['source_spreadsheet_id']=='depo-document-12345'
    assert result['read_at'] and result['preview'] is False


def test_new_value_requires_decision_and_clears_only_after_verified(logged,db,monkeypatch,tmp_path):
    w,fake,run,conflict=create_conflict(logged,db,monkeypatch,tmp_path)
    before=len(fake.writes)
    assert decision(logged,conflict,'NEW').status_code==202
    assert conflict.state=='WRITE_PENDING' and len(fake.writes)==before
    assert db.scalar(select(TaskError.id).where(TaskError.run_item_id==conflict.run_item_id,TaskError.is_resolved==False))
    process_run(db,run,fake)
    assert conflict.state=='RESOLVED' and fake.documents['destination-copy-12345']['TOTAL DEPO'].cell(2,1).value==0
    assert not db.scalar(select(TaskError.id).where(TaskError.run_item_id==conflict.run_item_id,TaskError.is_resolved==False))
    assert db.scalar(select(ConflictDecision)) and db.scalar(select(AuditLog.id).where(AuditLog.action=='destination_conflict_observed'))
    assert db.scalar(select(AuditLog.id).where(AuditLog.action=='conflict_decision_verified'))
    assert db.get(RunItem,conflict.run_item_id).status=='SUCCESS'


def test_keep_old_never_writes_or_forces_balance_zero(logged,db,monkeypatch,tmp_path):
    w,fake,run,conflict=create_conflict(logged,db,monkeypatch,tmp_path)
    report=fake.documents['destination-copy-12345']['Laporan deposit harian']
    report.rows[2][23].value=-999
    before=len(fake.writes)
    assert decision(logged,conflict,'KEEP').status_code==202
    process_run(db,run,fake)
    detail=logged.get(f'/api/runs/{run.id}').json()
    assert conflict.state=='RESOLVED' and len(fake.writes)==before
    assert fake.documents['destination-copy-12345']['TOTAL DEPO'].cell(2,1).value==999
    assert detail['reconciliation']['status']=='NOT_BALANCED' and detail['reconciliation']['balance']=='-999'
    assert not detail['date_status']['eligible']
    assert not any(e['run_item_id']==conflict.run_item_id for e in detail['errors'])
    assert db.scalar(select(TaskError.id).where(TaskError.run_item_id==conflict.run_item_id,TaskError.is_resolved==True))


def test_stale_approval_is_rejected_and_conflict_refreshed(logged,db,monkeypatch,tmp_path):
    w,fake,run,conflict=create_conflict(logged,db,monkeypatch,tmp_path)
    assert decision(logged,conflict,'NEW').status_code==202
    fake.documents['destination-copy-12345']['TOTAL DEPO'].rows[2][1].value=888
    before=len(fake.writes)
    process_run(db,run,fake)
    assert conflict.state=='OPEN' and conflict.observed[0]['value']==888 and len(fake.writes)==before
    assert db.scalar(select(TaskError.id).where(TaskError.error_code=='STALE_CONFLICT_APPROVAL',TaskError.is_resolved==False))
    assert decision(logged,conflict,'NEW').status_code==202
    process_run(db,run,fake)
    assert conflict.state=='RESOLVED' and fake.documents['destination-copy-12345']['TOTAL DEPO'].cell(2,1).value==0


def test_preview_cannot_write_indirectly_via_conflict(logged,db,monkeypatch,tmp_path):
    w,fake,run,conflict=create_conflict(logged,db,monkeypatch,tmp_path,preview=True)
    assert decision(logged,conflict,'NEW').status_code==409
    assert not fake.writes and not list(db.scalars(select(WriteLedger)))
    assert decision(logged,conflict,'KEEP').status_code==202
    process_run(db,run,fake)
    assert conflict.state=='RESOLVED' and not fake.writes and not list(db.scalars(select(WriteLedger)))
    assert logged.post(f'/api/runs/{run.id}/clear').status_code==409


def test_formula_cannot_be_overwritten_even_by_admin_decision(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    put(fake.documents['destination-copy-12345']['TOTAL DEPO'],2,1,999,formula='=1+998')
    r=start(logged,w);run=db.get(Run,r['id']);process_run(db,run,fake)
    conflict=db.scalar(select(DestinationConflict).where(DestinationConflict.reason=='FORMULA_CONFLICT'))
    assert conflict and decision(logged,conflict,'NEW').status_code==409
    assert fake.documents['destination-copy-12345']['TOTAL DEPO'].cell(2,1).formula=='=1+998'


def test_manual_note_is_preserved_when_only_value_is_authorized(logged,db,monkeypatch,tmp_path):
    w,fake,run,conflict=create_conflict(logged,db,monkeypatch,tmp_path,note='Catatan manual tetap')
    assert decision(logged,conflict,'NEW').status_code==202
    process_run(db,run,fake)
    actual=fake.documents['destination-copy-12345']['TOTAL DEPO'].cell(2,1)
    assert actual.value==0 and actual.note=='Catatan manual tetap' and conflict.state=='RESOLVED'


@pytest.mark.parametrize('tab',['Pengeluaran FEE QRIS DEPO','Pengeluaran FEE QRIS WD'])
def test_fee_description_and_amount_are_one_authorized_group(logged,db,monkeypatch,tmp_path,tab):
    w,fake,run,conflict=create_conflict(logged,db,monkeypatch,tmp_path,tab)
    assert len(conflict.writes)==2 and {o['cell'] for o in conflict.observed}=={'B3','C3'}
    before=len(fake.writes)
    assert decision(logged,conflict,'NEW').status_code==202
    process_run(db,run,fake)
    after=[w for w in fake.writes[before:] if w.tab==tab]
    assert len(after)==2 and conflict.state=='RESOLVED'
    assert all(l.verification_status=='VERIFIED' for l in db.scalars(select(WriteLedger).where(WriteLedger.run_item_id==conflict.run_item_id)))


def test_whole_group_remains_unresolved_when_readback_fails(logged,db,monkeypatch,tmp_path):
    w,fake,run,conflict=create_conflict(logged,db,monkeypatch,tmp_path,'Pengeluaran FEE QRIS DEPO')
    assert decision(logged,conflict,'NEW').status_code==202
    fake.corrupt_readback=True
    process_run(db,run,fake)
    assert conflict.state=='OPEN'
    assert {l.verification_status for l in db.scalars(select(WriteLedger).where(WriteLedger.run_item_id==conflict.run_item_id))}=={'PREPARED'}
    assert db.scalar(select(TaskError.id).where(TaskError.run_item_id==conflict.run_item_id,TaskError.is_resolved==False))


def test_timeout_after_google_accepts_group_is_verified_without_second_post(logged,db,monkeypatch,tmp_path):
    w,fake,run,conflict=create_conflict(logged,db,monkeypatch,tmp_path,'Pengeluaran FEE QRIS DEPO')
    assert decision(logged,conflict,'NEW').status_code==202
    calls=[];original=fake.write
    def uncertain(*args):
        calls.append(args);original(*args);raise ConnectionError('accepted, reply lost')
    fake.write=uncertain
    process_run(db,run,fake)
    assert len(calls)==1 and conflict.state=='RESOLVED'
    assert all(l.verification_status=='VERIFIED' for l in db.scalars(select(WriteLedger).where(WriteLedger.run_item_id==conflict.run_item_id)))


def test_duplicate_decision_and_csrf_cannot_create_duplicate_writes(logged,db,monkeypatch,tmp_path):
    w,fake,run,conflict=create_conflict(logged,db,monkeypatch,tmp_path)
    observed=logged.post(f'/api/conflicts/{conflict.id}/refresh').json();key=str(uuid4())
    body={'action':'NEW','observation_hash':observed['observation_hash'],'idempotency_key':key}
    assert logged.post(f'/api/conflicts/{conflict.id}/decide',json=body,headers={'x-csrf-token':'wrong'}).status_code==403
    first=logged.post(f'/api/conflicts/{conflict.id}/decide',json=body)
    second=logged.post(f'/api/conflicts/{conflict.id}/decide',json=body)
    assert first.status_code==second.status_code==202 and first.json()['id']==second.json()['id']
    assert len(list(db.scalars(select(ConflictDecision))))==1
    assert logged.post(f'/api/conflicts/{conflict.id}/decide',json={**body,'action':'KEEP'}).status_code==409
    before=len(fake.writes);process_run(db,run,fake)
    assert len(fake.writes)-before==1


@pytest.mark.parametrize('preview',[False,True])
def test_keep_never_acknowledges_foreign_or_preview_prepared_ledger(logged,db,monkeypatch,tmp_path,preview):
    from app.engine.writer import owner_key
    from app.engine.types import fingerprint
    from app.models import RetainedCell
    w,fake,run,conflict=create_conflict(logged,db,monkeypatch,tmp_path,preview=preview)
    current=db.get(RunItem,conflict.run_item_id)
    other=current if preview else db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.source_tab_name=='QRIS E-POWER',RunItem.metric_type=='deposit'))
    ledger=WriteLedger(run_item_id=other.id,destination_document_id=run.config_snapshot['destination']['id'],destination_revision=run.config_snapshot['destination']['revision'],destination_tab='TOTAL DEPO',target_range='B3',output_type='deposit',owner_key=owner_key(run,other),source_fingerprint='protected-intent',previous_managed_value={'value':None,'formula':None,'note':''},written_value={'value':999,'formula':None,'note':''},note_fingerprint=fingerprint(''),verification_status='PREPARED')
    db.add(ledger);db.commit();before=deepcopy(ledger.written_value)
    assert decision(logged,conflict,'KEEP').status_code==202
    process_run(db,run,fake)
    assert conflict.state=='RESOLVED' and ledger.verification_status=='PREPARED' and ledger.written_value==before
    assert not db.get(RetainedCell,ledger.id)
