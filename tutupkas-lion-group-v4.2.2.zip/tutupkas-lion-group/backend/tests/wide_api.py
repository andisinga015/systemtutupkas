"""Sparse wire fixtures: no dense historical/allocated cell arrays."""
import json
from app.engine.types import Cell, Grid, Issue
from app.config import settings
from range_api import RangeAPI


class LazySheet:
    def __init__(self,title='SALDO BANK',height=1000,width=1500,sheet_id=700):
        self.title,self.width,self.sheet_id = title,width,sheet_id
        self.rows = range(height)  # Count only, never row/cell objects.
        self.cells,self.merges = {},[]
        self.formatted_blanks = False

    def cell(self,r,c):
        return self.cells.get((r,c),Cell())

    def put(self,r,c,value=None,**kwargs):
        self.cells[r,c] = Cell(value,**kwargs)

    def merge(self,top,bottom,left,right):
        self.merges.append({'startRowIndex':top,'endRowIndex':bottom,
                            'startColumnIndex':left,'endColumnIndex':right})

    def dense(self):
        # Only for small differential tests, not memory benchmarks.
        assert len(self.rows)*self.width<100000
        return Grid(self.title,self.sheet_id,[[self.cell(r,c) for c in range(self.width)] for r in self.rows],list(self.merges))


class WideAPI(RangeAPI):
    def __init__(self,sheet,retain_calls=True):
        super().__init__(sheet,retain_calls=retain_calls)
        self.before=lambda method,params:None
        self.posts=[]
        self.post_requests=0
        self.corrupt=False
        self.byte_limit=settings().max_api_response_bytes
        self.rejected=0
        self.returned_sizes=[]

    def request(self,method,path,**kwargs):
        self.before(method,kwargs.get('params',{}))
        if method=='POST':
            for update in kwargs['json']['requests']:
                update=update['updateCells'];r=update['range']['startRowIndex'];c=update['range']['startColumnIndex']
                raw=update['rows'][0]['values'][0];value=raw['userEnteredValue']
                v=value.get('numberValue',value.get('stringValue'))
                old=self.fixture.cell(r,c)
                self.fixture.put(r,c,'mismatch' if self.corrupt else v,note=raw.get('note',old.note),color=old.color,date_format=old.date_format)
                self.posts.append((r,c,v,raw.get('note')))
            reply={'replies':[{} for _ in kwargs['json']['requests']]}
            size=len(json.dumps(reply,separators=(',',':')).encode())
            self.count+=1;self.post_requests+=1;self.total_bytes+=size
            self.largest=max(self.largest,size);self.returned_sizes.append(size)
            self.hook()
            return reply
        self.cancel_check();self.hook()
        params=kwargs.get('params',{})
        ranges=params.get('ranges',[])
        if not ranges:
            reply={'sheets':[{'properties':self.properties()}]}
        elif path.endswith('/values:batchGet'):
            reply={'valueRanges':[]}
            for a1 in ranges:
                top,bottom,left,right=self.decode(a1)
                values=[[self.fixture.cell(r,c).value for c in range(left,right+1)] for r in range(top,bottom+1)]
                for row in values:
                    while row and row[-1] is None:row.pop()
                while values and not values[-1]:values.pop()
                reply['valueRanges'].append({'values':values})
        else:
            fields=params.get('fields','')
            sheet={'properties':{'sheetId':self.fixture.sheet_id}}
            if 'merges' in fields:sheet['merges']=self.fixture.merges
            if 'rowData' in fields:
                sheet['data']=[]
                for a1 in ranges:
                    top,bottom,left,right=self.decode(a1)
                    band={'startRow':top,'startColumn':left}
                    found={pos:cell for pos,cell in self.fixture.cells.items() if top<=pos[0]<=bottom and left<=pos[1]<=right}
                    if found or self.fixture.formatted_blanks:
                        end=bottom if self.fixture.formatted_blanks else max(r for r,c in found)
                        rows=[]
                        for r in range(top,end+1):
                            cols=[c for rr,c in found if rr==r]
                            last=right if self.fixture.formatted_blanks else max(cols,default=left-1)
                            values=[self.raw(self.fixture.cell(r,c),fields) for c in range(left,last+1)]
                            if self.fixture.formatted_blanks and 'backgroundColor' in fields:
                                for value in values:value.setdefault('effectiveFormat',{}).setdefault('backgroundColor',{'red':1,'green':1,'blue':1})
                            rows.append({'values':values})
                        band['rowData']=rows
                    sheet['data'].append(band)
            reply={'sheets':[sheet]}
        size=len(json.dumps(reply,separators=(',',':')).encode())
        self.count+=1;self.total_bytes+=min(size,self.byte_limit)
        if self.retain_calls:self.calls.append((path,params))
        if size>self.byte_limit:
            self.rejected+=1
            raise Issue('RESPONSE_TOO_LARGE','Synthetic streamed byte cap')
        self.largest=max(self.largest,size);self.returned_sizes.append(size)
        return reply


def wide_regular(width=1500,height=1000,websites=40,title='SALDO BANK',target=1420,date_row=74):
    sheet=LazySheet(title,height,width)
    names=[]
    for i in range(websites):
        c=i*8;name=f'WEB {i:02}'
        names.append(name);sheet.put(0,c,name);sheet.put(date_row,c,'18-Oct-2026')
        sheet.put(1,c+1,'FATMAWATI');sheet.put(1,c+2,'TOTAL');sheet.put(date_row,c+2,0,formula='=SUM(B2:B8)')
    names.append('VELBETT')
    sheet.put(0,target,'VELBETT');sheet.put(1,target+1,'FATMAWATI')
    sheet.put(1,target+2,'TOTAL');sheet.put(date_row,target,'18-Oct-2026')
    sheet.put(date_row,target+2,0,formula='=SUM(A1:A2)')
    return sheet,names
