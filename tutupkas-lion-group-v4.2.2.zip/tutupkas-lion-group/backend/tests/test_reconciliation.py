from copy import deepcopy
from decimal import Decimal
from uuid import uuid4

import pytest
from sqlalchemy import select

from app.batches import process_batch
from app.engine.report import REPORT, decimal_balance, resolve_balance
from app.engine.runner import process_run
from app.engine.types import Cell, Issue, Write
from app.engine.writer import execute
from app.models import BatchEntry, CrawlBatch, Run, RunItem, SourceDocument, SourceSheet, TaskError, WriteLedger
from app.reconciliation import fresh_balance
from helpers import DAY, DEPO_NAME, FakeSheets, blank, put, report
from test_engine import configured, start

NAMES=['VELBETT','FANTASI','BBTOTO']

@pytest.mark.parametrize('value',[0,0.0,'0','0.00','0,00','-0.000000'])
def test_exact_zero(value):
    assert decimal_balance(value)==0

@pytest.mark.parametrize('value',[None,'',True,'#REF!','#VALUE!','NaN','Infinity','bukan angka'])
def test_invalid_balance_not_zero(value):
    with pytest.raises(Issue): decimal_balance(value)

@pytest.mark.parametrize('value',['0.000000000001','-0.00000000001',1,-1])
def test_small_unrounded_difference(value):
    g=report(balances={'VELBETT':value})
    assert Decimal(resolve_balance(g,DAY,'VELBETT',NAMES)['balance'])!=0

@pytest.mark.parametrize('label',['velbett',' VELBETT ','V\nE\nL\nB\nE\nT\nT'])
def test_rotated_or_multiline_marker_with_shifted_columns(label):
    g=report(balances={'VELBETT':-55,'FANTASI':90})
    put(g,0,13,label)
    result=resolve_balance(g,DAY,'VELBETT',NAMES)
    assert result['cell']=='X3' and result['balance']=='-55'
    assert resolve_balance(g,DAY,None,NAMES)['cell']=='K3'
    assert resolve_balance(g,DAY,'FANTASI',NAMES)['balance']=='90'


def test_separate_vertical_letters_and_merged_label():
    g=report()
    put(g,0,13,None)
    for r,v in enumerate('VELBETT'): put(g,r,13,v)
    assert resolve_balance(g,DAY,'VELBETT',NAMES)['balance']=='0'
    g=report();g.merges.append(dict(startRowIndex=0,endRowIndex=1,startColumnIndex=13,endColumnIndex=24))
    assert resolve_balance(g,DAY,'VELBETT',NAMES)['cell']=='X3'


def test_stacked_tables_do_not_share_markers():
    g=blank(REPORT,12,12)
    for r,name,value in [(0,'VELBETT',0),(6,'FANTASI',7)]:
        put(g,r,0,name);put(g,r+1,1,'Tanggal');put(g,r+1,5,'BALANCE')
        put(g,r+2,1,'15/10/2026');put(g,r+2,5,value)
    assert resolve_balance(g,DAY,'VELBETT',NAMES)['cell']=='F3'
    assert resolve_balance(g,DAY,'FANTASI',NAMES)['balance']=='7'

@pytest.mark.parametrize('change,code',[
    ('missing_marker','WEBSITE_BLOCK_MISSING'),('duplicate_block','AMBIGUOUS_REPORT_BLOCK'),
    ('duplicate_date','DUPLICATE_REPORT_DATE'),('missing_date','REPORT_DATE_MISSING'),
    ('missing_balance','REPORT_BALANCE_HEADER_MISSING'),('duplicate_balance','REPORT_BALANCE_HEADER_MISSING')])
def test_ambiguous_structure_stops(change,code):
    g=report()
    if change=='missing_marker': put(g,0,13,None)
    if change=='duplicate_block': put(g,0,26,'VELBETT')
    if change=='duplicate_date': put(g,3,14,'15-Oct-2026')
    if change=='missing_date': put(g,2,14,'16-Oct-2026')
    if change=='missing_balance': put(g,1,23,None)
    if change=='duplicate_balance': put(g,1,22,'BALANCE')
    with pytest.raises(Issue) as err: resolve_balance(g,DAY,'VELBETT',NAMES)
    assert err.value.code==code


def test_consolidation_requires_all_headers_and_unique_table():
    g=report();put(g,1,11,None)
    with pytest.raises(Issue) as err: resolve_balance(g,DAY,None,NAMES)
    assert err.value.code=='CONSOLIDATED_BLOCK_MISSING'
    g=report();put(g,0,13,None);put(g,1,24,'STATUS');put(g,1,25,'KETERANGAN')
    with pytest.raises(Issue) as err: resolve_balance(g,DAY,None,NAMES)
    assert err.value.code=='AMBIGUOUS_REPORT_BLOCK'


def test_stale_formula_requires_consecutive_fresh_zero():
    class Changing:
        def __init__(self,values): self.values=iter(values);self.calls=0
        def grid(self,*args): self.calls+=1;return report(balances={'VELBETT':next(self.values)})
    client=Changing([99,0,0])
    assert fresh_balance(client,{'spreadsheet_id':'id'},DAY,'VELBETT',NAMES)['balance']=='0'
    assert client.calls==3
    with pytest.raises(Issue) as err: fresh_balance(Changing([99,99,0]),{'spreadsheet_id':'id'},DAY,'VELBETT',NAMES)
    assert err.value.code=='REPORT_NOT_STABLE'


def test_nonzero_is_processing_success_and_read_only(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    g=fake.documents['destination-copy-12345'][REPORT]
    put(g,2,23,'0.000000001',formula='=A1-A2',note='Note tetap')
    before=deepcopy(g)
    run=start(logged,w);process_run(db,db.get(Run,run['id']),fake)
    detail=logged.get(f"/api/runs/{run['id']}").json()
    assert detail['status']=='SUCCESS' and detail['reconciliation']['status']=='NOT_BALANCED'
    assert detail['date_status']['consolidated']['status']=='BALANCED'
    assert detail['date_status']['status']=='NOT_BALANCED'
    error=next(e for e in detail['errors'] if e['error_code']=='WEBSITE_NOT_BALANCED')
    assert error['human_message']=='Kas Velbett tidak klop Bagian Laporan deposit harian'
    assert error['technical_details']['actual_balance']=='1E-9'
    assert error['technical_details']['cell']=='X3'
    assert logged.post(f"/api/runs/{run['id']}/clear").status_code==409
    assert g==before and all(w.tab!=REPORT for w in fake.writes)
    assert not list(db.scalars(select(WriteLedger).where(WriteLedger.destination_tab==REPORT)))
    # A recheck cannot replay any source read, transfer, Note, or output write.
    put(g,2,23,0,formula='=A1-A2',note='Note tetap')
    write_count=len(fake.writes);read_count=len(fake.reads)
    result=logged.post(f"/api/runs/{run['id']}/reconcile",json={}).json()
    process_batch(db,db.get(CrawlBatch,result['id']),fake)
    assert len(fake.writes)==write_count and all(title==REPORT for _,title in fake.reads[read_count:])
    assert logged.get(f"/api/runs/{run['id']}").json()['errors']==[]
    assert logged.post(f"/api/runs/{run['id']}/clear").status_code==200


def test_write_guard_refuses_report_before_any_client_call(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);r=start(logged,w)
    run=db.get(Run,r['id']);item=db.scalar(select(RunItem).where(RunItem.run_id==run.id))
    reads=len(fake.reads)
    with pytest.raises(Issue) as err: execute(db,fake,run,item,report(),[Write(REPORT,2,23,0)])
    assert err.value.code=='READ_ONLY_REPORT' and len(fake.reads)==reads and fake.writes==[]


def test_zero_report_cannot_hide_incomplete_source(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);fake.fail_tabs.add(DEPO_NAME)
    r=start(logged,w);process_run(db,db.get(Run,r['id']),fake)
    detail=logged.get(f"/api/runs/{r['id']}").json()
    assert detail['status']=='PARTIAL' and detail['reconciliation']['status']=='INCOMPLETE'
    assert not any(title==REPORT for _,title in fake.reads)
    assert not detail['date_status']['eligible']
    assert logged.post(f"/api/runs/{r['id']}/reconcile",json={}).status_code==409


def add_second(logged,fake):
    existing=logged.get('/api/websites/fantasi')
    w=existing.json() if existing.status_code==200 else logged.post('/api/websites',json={'display_name':'FANTASI','slug':'fantasi'}).json()
    doc=logged.put(f"/api/websites/{w['id']}/sources",json={'year':2026,'month':10,'document_type':'DEPO','source_period':'FIRST_HALF','spreadsheet_url':'https://docs.google.com/spreadsheets/d/depo-document-12345/edit'}).json()
    logged.post(f"/api/sources/{doc['id']}/validate")
    tabs=logged.get(f"/api/sources/{doc['id']}/tabs").json()
    logged.post(f"/api/sources/{doc['id']}/tabs",json={'ids':[t['id'] for t in tabs],'is_active':True})
    # Complete the FANTASI block in each existing synthetic destination.
    for title,g in fake.documents['destination-copy-12345'].items():
        if title in (REPORT,'KET PENGIRIMAN'): continue
        left=next(c for c,cell in enumerate(g.rows[0]) if cell.value=='FANTASI')
        for row in g.rows: row.extend(Cell() for _ in range(7))
        put(g,2,left+1,None)
        for c in range(1,left-1):
            g.rows[1][left+c]=deepcopy(g.cell(1,c))
    g=fake.documents['destination-copy-12345']['KET PENGIRIMAN']
    original=FakeSheets().documents['destination-copy-12345']['KET PENGIRIMAN']
    g.rows.extend([deepcopy(row) for row in original.rows[1:]])
    put(g,8,0,'FANTASI')
    for m in original.merges[1:]: g.merges.append({**m,'startRowIndex':m['startRowIndex']+7,'endRowIndex':m['endRowIndex']+7})
    fake.rebuild_mapping()  # This fixture deliberately restructures the month.
    fake.reads.clear()
    return w


def test_durable_batch_sequential_progress_idempotency_and_global_clear(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);second=add_second(logged,fake)
    inactive=logged.post('/api/websites',json={'display_name':'NONAKTIF','slug':'nonaktif'}).json()
    logged.patch(f"/api/websites/{inactive['id']}",json={'is_active':False})
    body={'selected_date':str(DAY),'idempotency_key':str(uuid4())}
    first=logged.post('/api/batches',json=body);assert first.status_code==202,first.text
    batch=first.json();assert batch['total']==2
    assert logged.post('/api/batches',json=body).json()['id']==batch['id']
    assert logged.post('/api/batches',json={**body,'idempotency_key':str(uuid4())}).status_code==409
    assert logged.post('/api/runs',json={**body,'website_id':w['id'],'idempotency_key':str(uuid4())}).status_code==409
    # Stop between websites, then resume from persistent entries.
    calls=[0]
    def stop_after_first(): calls[0]+=1;return calls[0]>1
    b=db.get(CrawlBatch,batch['id']);process_batch(db,b,fake,stop_after_first)
    p=logged.get(f"/api/batches/{b.id}").json()
    assert p['processed']==1 and p['status']=='RUNNING'
    assert not p['date_status']['eligible'] and p['date_status']['pending_websites']==['FANTASI']
    writes=len(fake.writes)
    process_batch(db,b,fake)
    p=logged.get(f"/api/batches/{b.id}").json()
    assert p['status']=='SUCCESS',p
    assert p['processed']==2 and p['success']==2 and p['date_status']['eligible']
    assert len(fake.writes)>writes
    assert logged.post('/api/reconciliations/clear',json={'selected_date':str(DAY)}).status_code==200
    # Backend guards repeated single and batch starts after global Clear.
    assert logged.post('/api/batches',json={**body,'idempotency_key':str(uuid4())}).status_code==409


def test_batch_records_unconfigured_active_web_and_retries_only_it(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    missing=logged.post('/api/websites',json={'display_name':'FANTASI','slug':'fantasi'}).json()
    result=logged.post('/api/batches',json={'selected_date':str(DAY),'idempotency_key':str(uuid4())}).json()
    b=db.get(CrawlBatch,result['id']);process_batch(db,b,fake)
    p=logged.get(f"/api/batches/{b.id}").json()
    assert p['status']=='PARTIAL' and p['failed']==1 and not p['date_status']['eligible']
    bad=next(e for e in p['entries'] if e['website_id']==missing['id'])
    error=db.scalar(select(TaskError).where(TaskError.run_id==bad['run_id']))
    assert error.error_code=='CONFIGURATION_NOT_READY'
    assert logged.post(f"/api/batches/{b.id}/retry",json={'website_id':missing['id']}).status_code==409
    assert db.get(Run,bad['run_id']).status=='FAILED'
    writes=len(fake.writes)
    add_second(logged,fake)
    response=logged.post(f"/api/batches/{b.id}/retry",json={'website_id':missing['id']})
    assert response.status_code==202,response.text
    process_batch(db,b,fake)
    state=logged.get(f"/api/batches/{b.id}").json()
    assert state['status']=='SUCCESS' and state['date_status']['eligible'],state
    assert db.get(Run,bad['run_id']).status=='FAILED'  # original failure retained
    assert all(write.col>4 or write.tab=='KET PENGIRIMAN' for write in fake.writes[writes:])


def test_url_change_preserves_history_requires_explicit_resync(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    r=start(logged,w);process_run(db,db.get(Run,r['id']),fake)
    old=deepcopy(fake.documents['destination-copy-12345'])
    fake.documents['new-copy-123456']=FakeSheets().documents['destination-copy-12345']
    body={'year':2026,'month':10,'spreadsheet_url':'https://docs.google.com/spreadsheets/d/new-copy-123456/edit'}
    changed=logged.put('/api/destinations',json=body).json()
    assert changed['revision']==2 and changed['validation_status']=='UNVALIDATED'
    assert len(logged.get('/api/runs').json())==1
    assert not logged.get(f"/api/runs/{r['id']}").json()['current_revision']
    assert logged.post(f"/api/runs/{r['id']}/retry",json={}).status_code==409
    logged.post(f"/api/destinations/{changed['id']}/validate")
    state=logged.get('/api/reconciliations/date',params={'selected_date':str(DAY)}).json()
    assert state['websites'][0]['processing_status']=='SYNC_REQUIRED' and not state['eligible']
    result=logged.post(f"/api/runs/{r['id']}/resync",json={'selected_dates':[str(DAY)],'idempotency_key':str(uuid4())})
    assert result.status_code==202,result.text
    new=result.json()['runs'][0];process_run(db,db.get(Run,new['id']),fake)
    assert db.get(Run,new['id']).status=='SUCCESS'
    assert fake.documents['destination-copy-12345']==old
    assert db.get(Run,r['id']).config_snapshot['destination']['revision']==1
    assert logged.get(f"/api/destinations/{changed['id']}/history").json()[0]['revision_number']==2


def test_source_url_change_resets_tabs_and_old_completion(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    r=start(logged,w);process_run(db,db.get(Run,r['id']),fake)
    source=db.scalar(select(SourceDocument).where(SourceDocument.document_type=='DEPO'))
    fake.documents['replacement-source-12345']=deepcopy(fake.documents[source.spreadsheet_id])
    changed=logged.put(f"/api/websites/{w['id']}/sources",json={'year':2026,'month':10,'document_type':'DEPO','source_period':'FIRST_HALF','spreadsheet_url':'https://docs.google.com/spreadsheets/d/replacement-source-12345/edit'}).json()
    assert changed['validation_status']=='UNVALIDATED'
    assert logged.get(f"/api/sources/{source.id}/tabs").json()==[]
    assert len(logged.get('/api/runs').json())==1
    logged.post(f"/api/sources/{source.id}/validate")
    assert all(not t['is_active'] for t in logged.get(f"/api/sources/{source.id}/tabs").json())
    assert not logged.get(f"/api/runs/{r['id']}").json()['current_revision']


@pytest.mark.parametrize('balance',[1,-30278535,'0.00001'])
def test_nonzero_consolidated_prevents_clear(logged,db,monkeypatch,tmp_path,balance):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    put(fake.documents['destination-copy-12345'][REPORT],2,10,balance)
    r=start(logged,w);process_run(db,db.get(Run,r['id']),fake)
    detail=logged.get(f"/api/runs/{r['id']}").json()
    assert detail['reconciliation']['status']=='BALANCED'
    assert detail['date_status']['consolidated']['status']=='NOT_BALANCED'
    assert not detail['date_status']['eligible']
    assert logged.post(f"/api/runs/{r['id']}/clear").status_code==409

@pytest.mark.parametrize('change',['missing_web','missing_consolidated','formula_error'])
def test_report_error_never_manufactures_zero(logged,db,monkeypatch,tmp_path,change):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    g=fake.documents['destination-copy-12345'][REPORT]
    if change=='missing_web': put(g,0,13,None)
    if change=='missing_consolidated': put(g,1,12,None)
    if change=='formula_error': put(g,2,23,'#REF!')
    r=start(logged,w);process_run(db,db.get(Run,r['id']),fake)
    state=logged.get(f"/api/runs/{r['id']}").json()
    assert state['status']=='SUCCESS' and not state['date_status']['eligible']
    failed=state['date_status']['consolidated'] if change=='missing_consolidated' else state['reconciliation']
    assert failed['status']=='ERROR' and failed['balance'] is None


def test_batch_restart_requires_manual_retry_and_reuses_verified_entries(logged,db,monkeypatch,tmp_path):
    from app.worker import recover_jobs
    w,fake=configured(logged,db,monkeypatch,tmp_path);add_second(logged,fake)
    result=logged.post('/api/batches',json={'selected_date':str(DAY),'idempotency_key':str(uuid4())}).json()
    b=db.get(CrawlBatch,result['id'])
    calls=[0]
    def stop_after_one(): calls[0]+=1;return calls[0]>1
    process_batch(db,b,fake,stop_after_one)
    entries=list(db.scalars(select(BatchEntry).where(BatchEntry.batch_id==b.id).order_by(BatchEntry.position)))
    writes=len(fake.writes)
    entries[1].status='RUNNING';db.get(Run,entries[1].run_id).status='RUNNING';db.commit()
    recover_jobs(db)
    assert b.status=='PARTIAL' and entries[1].status=='FAILED'
    process_batch(db,b,fake)
    assert len(fake.writes)==writes  # Restart alone cannot replay the job.
    assert logged.post(f'/api/batches/{b.id}/retry',json={'website_id':entries[1].website_id}).status_code==202
    process_batch(db,b,fake)
    assert b.status=='SUCCESS' and entries[0].status=='SUCCESS'
    assert all(w.col>4 or w.tab=='KET PENGIRIMAN' for w in fake.writes[writes:])


def test_simultaneous_single_and_batch_starts_are_serialized(logged,db,monkeypatch,tmp_path):
    from concurrent.futures import ThreadPoolExecutor
    from fastapi import HTTPException
    from sqlalchemy.orm import Session
    from app.batches import enqueue_batch
    from app.workflow import lock_date,assert_available,make_snapshot,create_run
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    engine=db.get_bind()
    def submit(all_web):
        with Session(engine) as other:
            try:
                if all_web: enqueue_batch(other,DAY,False,str(uuid4()),1)
                else:
                    lock_date(other,DAY);assert_available(other,DAY,w['id'])
                    create_run(other,w['id'],DAY,False,str(uuid4()),1,make_snapshot(other,w['id'],DAY))
                other.commit();return 202
            except HTTPException as error:
                other.rollback();return error.status_code
    with ThreadPoolExecutor(2) as pool: results=list(pool.map(submit,[True,False]))
    assert sorted(results)==[202,409]



def test_source_resync_adopts_unchanged_owned_slots_without_duplicates(logged,db,monkeypatch,tmp_path):
    from app.models import TransferOwnership
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    r=start(logged,w);process_run(db,db.get(Run,r['id']),fake)
    old_count=len(list(db.scalars(select(TransferOwnership))))
    old_grid=deepcopy(fake.documents['destination-copy-12345']['KET PENGIRIMAN'])
    source=db.scalar(select(SourceDocument).where(SourceDocument.document_type=='DEPO'))
    fake.documents['replacement-source-12345']=deepcopy(fake.documents[source.spreadsheet_id])
    logged.put(f"/api/websites/{w['id']}/sources",json={'year':2026,'month':10,'document_type':'DEPO','source_period':'FIRST_HALF','spreadsheet_url':'https://docs.google.com/spreadsheets/d/replacement-source-12345/edit'})
    logged.post(f"/api/sources/{source.id}/validate")
    tabs=logged.get(f"/api/sources/{source.id}/tabs").json()
    logged.post(f"/api/sources/{source.id}/tabs",json={'ids':[t['id'] for t in tabs],'is_active':True})
    response=logged.post(f"/api/runs/{r['id']}/resync",json={'idempotency_key':str(uuid4())})
    assert response.status_code==202,response.text
    new=response.json()['runs'][0];process_run(db,db.get(Run,new['id']),fake)
    detail=logged.get(f"/api/runs/{new['id']}").json()
    assert detail['status']=='PARTIAL'
    from test_v42_conflicts import decision
    from app.models import DestinationConflict
    conflicts=list(db.scalars(select(DestinationConflict).where(DestinationConflict.run_id==new['id'],DestinationConflict.state=='OPEN')))
    assert len(conflicts)==1 and conflicts[0].reason=='TRANSFER_IDENTITY_CHANGED'
    assert decision(logged,conflicts[0],'NEW').status_code==202
    process_run(db,db.get(Run,new['id']),fake)
    assert db.get(Run,new['id']).status=='SUCCESS'
    assert len(list(db.scalars(select(TransferOwnership))))==old_count
    assert fake.documents['destination-copy-12345']['KET PENGIRIMAN']==old_grid



def test_unverified_ledger_prevents_reconciliation_and_clear(logged,db,monkeypatch,tmp_path):
    from app.workflow import processing_complete
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    r=start(logged,w);run=db.get(Run,r['id']);process_run(db,run,fake)
    assert processing_complete(db,run)
    ledger=db.scalar(select(WriteLedger));ledger.verification_status='PREPARED';db.commit()
    assert not processing_complete(db,run)
    state=logged.get('/api/reconciliations/date',params={'selected_date':str(DAY)}).json()
    assert not state['eligible']
    assert logged.post(f"/api/runs/{run.id}/clear").status_code==409


def test_legacy_destinations_require_selection_and_leave_other_months(logged,db):
    from app.models import Destination, MonthlyDestination
    for mode,sid in [('TEST','first-document-12345'),('PRODUCTION','second-document-12345')]:
        db.add(Destination(year=2026,month=10,environment=mode,spreadsheet_url=f'https://docs.google.com/spreadsheets/d/{sid}/edit',spreadsheet_id=sid))
    db.commit()
    state=logged.get('/api/reconciliations/date',params={'selected_date':str(DAY)}).json()
    assert state['destination'] is None and not state['eligible']
    options=logged.get('/api/destinations').json()
    assert not any(d['is_current'] for d in options)
    chosen=logged.put('/api/destinations',json={'year':2026,'month':10,'spreadsheet_url':options[1]['spreadsheet_url']}).json()
    assert chosen['id']==options[1]['id'] and chosen['is_current']
    next_month=logged.put('/api/destinations',json={'year':2026,'month':11,'spreadsheet_url':options[0]['spreadsheet_url']}).json()
    assert next_month['id']!=chosen['id']
    assert db.scalar(select(MonthlyDestination).where(MonthlyDestination.month==10)).destination_document_id==chosen['id']
    assert db.get(Destination,options[0]['id']).spreadsheet_url==options[0]['spreadsheet_url']



def test_explicit_resync_range_adopts_each_dates_own_history(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    from test_engine import add_second_depo
    add_second_depo(logged,db,fake,w)
    for title,g in fake.documents['destination-copy-12345'].items():
        if title==REPORT:
            for offset in [0,13,26,39]:
                put(g,3,offset+1,'16-Oct-2026');put(g,3,offset+10,0)
        elif title=='KET PENGIRIMAN':
            before=deepcopy(g);g.rows.extend(deepcopy(before.rows))
            for merge in before.merges: g.merges.append({**merge,'startRowIndex':merge['startRowIndex']+8,'endRowIndex':merge['endRowIndex']+8})
            put(g,8,0,'16-Oct-2026')
        else:
            put(g,3,0,'16-Oct-2026')
    fake.rebuild_mapping()
    first=start(logged,w);process_run(db,db.get(Run,first['id']),fake)
    second=start(logged,w,selected_date='2026-10-16');process_run(db,db.get(Run,second['id']),fake)
    assert db.get(Run,second['id']).status=='SUCCESS'
    source=db.scalar(select(SourceDocument).where(SourceDocument.document_type=='DEPO'))
    fake.documents['replacement-source-12345']=deepcopy(fake.documents[source.spreadsheet_id])
    logged.put(f"/api/websites/{w['id']}/sources",json={'year':2026,'month':10,'document_type':'DEPO','source_period':'FIRST_HALF','spreadsheet_url':'https://docs.google.com/spreadsheets/d/replacement-source-12345/edit'})
    logged.post(f"/api/sources/{source.id}/validate")
    tabs=logged.get(f"/api/sources/{source.id}/tabs").json()
    logged.post(f"/api/sources/{source.id}/tabs",json={'ids':[t['id'] for t in tabs],'is_active':True})
    response=logged.post(f"/api/runs/{first['id']}/resync",json={'selected_dates':[str(DAY),'2026-10-16'],'idempotency_key':str(uuid4())})
    assert response.status_code==202,response.text
    runs=response.json()['runs']
    assert [r['config_snapshot']['authorized_previous_run_id'] for r in runs]==[first['id'],second['id']]
    for new in runs:
        process_run(db,db.get(Run,new['id']),fake)
        detail=logged.get(f"/api/runs/{new['id']}").json()
        if detail['conflicts']:
            from app.models import DestinationConflict
            from test_v42_conflicts import decision
            for conflict in detail['conflicts']:
                assert conflict['reason']=='TRANSFER_IDENTITY_CHANGED'
                assert decision(logged,db.get(DestinationConflict,conflict['id']),'NEW').status_code==202
            process_run(db,db.get(Run,new['id']),fake)
        assert db.get(Run,new['id']).status=='SUCCESS',detail['errors']
