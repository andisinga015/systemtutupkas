"""Eight source tabs / 43 logical plans, with a dense BIAYA wire response.

All Google traffic is isolated. Reuses registration, fixed-column data, account
resolution and approved mapping, rather than adding hardcoded engine addresses.
"""
from copy import deepcopy
from datetime import date
import json

from app.sheets import SheetsClient
from app.engine.types import Cell,Grid
from helpers import (FakeSheets,DEPO_NAME,BROWN,blank,marker,put,regular_destination)
from wide_api import LazySheet,WideAPI

SELECTED=date(2026,10,18)


class FormattedExpense(LazySheet):
    def cell(self,r,c):
        if (r,c) in self.cells:return self.cells[r,c]
        # Large ordinary Notes outside every selected target. V4.2 asks for
        # them during its global checks even though the predicates discard them.
        return Cell(note='kept historical note '+('x'*850),color=(1.,1.,1.)) if r>=128 else Cell()


def configure_writer(logged,db,monkeypatch,tmp_path,heavy=True,batch=False,token=True):
    from test_engine import configured
    from app.config import settings
    from app.models import SourceDocument
    from sqlalchemy import select
    w,fake=configured(logged,db,monkeypatch,tmp_path,source_period='SECOND_HALF')
    names=[DEPO_NAME,*[f'WD BCA / ACCOUNT {n}' for n in range(2,7)]]
    original=fake.documents['depo-document-12345'][DEPO_NAME]
    for i,title in enumerate(names[1:],2):
        g=deepcopy(original);g.title=title;g.sheet_id=i;put(g,1,3,title)
        fake.documents['depo-document-12345'][title]=g
    source=db.scalar(select(SourceDocument).where(SourceDocument.document_type=='DEPO'))
    assert logged.post(f'/api/sources/{source.id}/tabs/refresh').status_code==200
    tabs=logged.get(f'/api/sources/{source.id}/tabs').json()
    assert logged.post(f'/api/sources/{source.id}/tabs',json={'ids':[t['id'] for t in tabs],'is_active':True}).status_code==200
    labels=['IVAN RAKHMANDA',*[f'ACCOUNT {n}' for n in range(2,7)],'QRIS E-POWER','QRIS QRIZZ']
    for title in ('TOTAL DEPO','TOTAL WD','SALDO BANK'):
        g=regular_destination(title,labels);g.sheet_id=fake.documents['destination-copy-12345'][title].sheet_id
        fake.documents['destination-copy-12345'][title]=g
    old=fake.documents['destination-copy-12345']['KET PENGIRIMAN']
    g=blank(old.title,30,8,old.sheet_id)
    for r in range(3):g.rows[r]=deepcopy(old.rows[r])
    g.merges=deepcopy(old.merges)
    for c in (0,2,4,6):put(g,27,c,'TOTAL');put(g,27,c+1,0,formula='=SUM(B4:B27)')
    fake.documents['destination-copy-12345'][g.title]=g
    for doc in ('depo-document-12345','qris-document-12345'):
        for g in fake.documents[doc].values():
            for r,d in ([(290,18),(306,19),(307,20)] if doc.startswith('depo') else [(83,18),(88,19),(89,20)]):marker(g,r,date(2026,10,d))
    for g in fake.documents['destination-copy-12345'].values():
        for row in g.rows:
            for cell in row:
                if cell.value=='15-Oct-2026':cell.value='18-Oct-2026'
    apis={}
    for title,g in fake.documents['destination-copy-12345'].items():
        sheet=(FormattedExpense if title=='BIAYA' and heavy else LazySheet)(title,height=256 if title=='BIAYA' and heavy else 40,width=64,sheet_id=g.sheet_id)
        sheet.formatted_blanks=bool(title=='BIAYA' and heavy)
        for r,row in enumerate(g.rows):
            for c,cell in enumerate(row):
                if not cell.empty or cell.color is not None or cell.date_format:sheet.cells[r,c]=deepcopy(cell)
        sheet.merges=deepcopy(g.merges);apis[title]=WideAPI(sheet,retain_calls=False)
    fake.versions={'destination-copy-12345':1}
    if token:fake.content_revision=lambda doc:str(fake.versions.get(doc,1))
    fake.destination_grid=lambda doc,title,registered=():apis[title].destination_grid(doc,title,registered)
    def request(method,path,**kwargs):
        if method=='POST':
            updates=kwargs['json']['requests'];by_id={api.fixture.sheet_id:api for api in apis.values()}
            # Google batchUpdate validates the entire request then applies it;
            # one POST may contain several sheet IDs without splitting groups.
            for update in updates:
                u=update['updateCells'];assert u['range']['sheetId'] in by_id
                assert set(u['fields'].split(','))<= {'userEnteredValue','note'}
            for update in updates:
                u=update['updateCells'];api=by_id[u['range']['sheetId']]
                r,c=u['range']['startRowIndex'],u['range']['startColumnIndex']
                raw=u['rows'][0]['values'][0];value=raw['userEnteredValue']
                value=value.get('numberValue',value.get('stringValue'))
                old=api.fixture.cell(r,c)
                api.fixture.put(r,c,value,note=raw.get('note',old.note),color=old.color,date_format=old.date_format)
                api.posts.append((r,c,value,raw.get('note')))
            fake.versions['destination-copy-12345']+=1;fake._verified_revisions={}
            return {'replies':[{} for _ in updates]}
        import re
        if not kwargs.get('params',{}).get('ranges'):
            return {'sheets':[{'properties':api.properties(),'merges':api.fixture.merges} for api in apis.values()]}
        title=re.match(r"'((?:[^']|'')*)'!",kwargs['params']['ranges'][0])[1].replace("''", "'")
        return apis[title].request(method,path,**kwargs)
    fake.request=request
    fake.values=lambda doc,ranges:SheetsClient.values(fake,doc,ranges)
    fake.sheet_properties=lambda doc,title:SheetsClient.sheet_properties(fake,doc,title)
    def write(doc,grid,writes):
        fake.writes.extend(deepcopy(writes));apis[grid.title].write(doc,grid,writes)
        fake.versions['destination-copy-12345']+=1;fake._verified_revisions={}
    fake.write=write
    if batch:
        fake._write_requests=SheetsClient._write_requests
        def write_batch(doc,groups):
            fake.writes.extend(deepcopy([w for grid,writes in groups for w in writes]))
            return SheetsClient.write_batch(fake,doc,groups)
        fake.write_batch=write_batch
    fake.rebuild_mapping();fake.reads.clear();fake.writes.clear()
    return w,fake,apis
