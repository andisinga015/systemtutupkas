"""API terautentikasi tujuan tunggal, batch, rekonsiliasi dan Clear."""
import json
from datetime import date
from pathlib import Path
from uuid import uuid4
from typing import Literal

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import api as core
from .auth import admin
from .batches import batch_progress, enqueue_batch
from .config import settings
from .engine.types import Issue
from .db import get_db, utcnow
from .job_control import request_run_cancel, request_batch_cancel
from .models import (BatchEntry, Clearance, CrawlBatch, Destination, DestinationRevision, FinalClearance,
                     MonthlyDestination, Reconciliation, Run, RunItem, TaskError, Website)
from .reconciliation import date_overview, last_reconciliation
from .sheets import spreadsheet_id
from .workflow import (ACTIVE, assert_available, context_signature, create_run, current_source_signature,
    destination_snapshot, is_clear, is_current_run, lock_date, make_snapshot, monthly_destination,
    run_source_signature)

router = APIRouter(dependencies=[Depends(admin)])


class BatchStart(BaseModel):
    selected_date: date
    preview: bool = False
    idempotency_key: str = Field(min_length=16, max_length=100)


class CheckRequest(BaseModel):
    idempotency_key: str = Field(default_factory=lambda: str(uuid4()), min_length=16, max_length=100)


class DateCheck(CheckRequest):
    selected_date: date


class Resync(CheckRequest):
    selected_dates: list[date] = Field(default_factory=list, max_length=31)


@router.get('/destinations')
def destinations(db: Session = Depends(get_db)):
    from .destination_registry import status
    bindings = {m.destination_document_id for m in db.scalars(select(MonthlyDestination))}
    docs = list(db.scalars(select(Destination).order_by(Destination.year.desc(), Destination.month.desc(), Destination.id)))
    # A single legacy URL can be shown as active before its lazy adoption.
    for doc in docs:
        same = [d for d in docs if (d.year, d.month) == (doc.year, doc.month)]
        if len(same) == 1:
            bindings.add(doc.id)
    return [{**core.serialize(d), 'is_current': d.id in bindings,'mapping':status(db,d)} for d in docs]


@router.put('/destinations')
def save_destination(body: core.DestinationSave, background_tasks: BackgroundTasks, db: Session = Depends(get_db), user=Depends(admin)):
    from .destination_registry import background_mapping,queue_mapping,status
    sid = spreadsheet_id(body.spreadsheet_url)
    binding = db.scalar(select(MonthlyDestination).where(MonthlyDestination.year == body.year, MonthlyDestination.month == body.month))
    obj = db.get(Destination, binding.destination_document_id) if binding else None
    if obj and obj.spreadsheet_url == body.spreadsheet_url:
        return {**core.serialize(obj), 'is_current': True,'mapping':status(db,obj)}
    if not obj:
        options = list(db.scalars(select(Destination).where(Destination.year == body.year, Destination.month == body.month,
                                                           Destination.spreadsheet_url == body.spreadsheet_url)))
        obj = options[0] if len(options) == 1 else None
    if obj:
        obj.revision += 1
        obj.spreadsheet_url, obj.spreadsheet_id = body.spreadsheet_url, sid
    else:
        obj = Destination(year=body.year, month=body.month, environment='WORKING', spreadsheet_url=body.spreadsheet_url,
                          spreadsheet_id=sid, revision=1)
        db.add(obj)
        db.flush()
    if not binding:
        binding = MonthlyDestination(year=body.year, month=body.month, destination_document_id=obj.id)
        db.add(binding)
    else:
        binding.destination_document_id = obj.id
    obj.validation_status, obj.validated_at, obj.spreadsheet_title = 'UNVALIDATED', None, None
    obj.production_authorized_by, obj.authorized_at = None, None
    db.add(DestinationRevision(destination_document_id=obj.id, revision_number=obj.revision,
                               spreadsheet_url=body.spreadsheet_url, changed_by=user.id))
    core.audit(db, user, 'save_monthly_destination', obj, {'revision': obj.revision})
    mapping=queue_mapping(db,obj,user.id)
    core.save(db)
    background_tasks.add_task(background_mapping,db.get_bind(),mapping.id,core.SheetsClient)
    return {**core.serialize(obj), 'is_current': True,'mapping':status(db,obj)}


@router.post('/destinations/{id}/validate')
def validate_destination(id: int, background_tasks: BackgroundTasks, db: Session = Depends(get_db), user=Depends(admin)):
    from .destination_registry import background_mapping,queue_mapping,status
    dest=core.require(db,Destination,id)
    mapping=queue_mapping(db,dest,user.id)
    core.audit(db,user,'revalidate_destination_mapping',mapping,{'destination_revision':dest.revision})
    core.save(db)
    background_tasks.add_task(background_mapping,db.get_bind(),mapping.id,core.SheetsClient)
    return {'document':core.serialize(dest),'mapping':status(db,dest),'message':'Pemetaan absolut tujuan diantrikan. Tunggu status Siap sebelum menjalankan penarikan.','error_code':None}


@router.get('/destinations/{id}/history')
def destination_history(id: int, db: Session = Depends(get_db)):
    core.require(db, Destination, id)
    return [core.serialize(o) for o in db.scalars(select(DestinationRevision).where(
        DestinationRevision.destination_document_id == id).order_by(DestinationRevision.revision_number.desc()))]


@router.get('/destinations/{id}/revision-status')
def revision_status(id: int, selected_date: date, db: Session = Depends(get_db)):
    core.require(db, Destination, id)
    return date_overview(db, selected_date)


@router.post('/destinations/{id}/authorize')
def deprecated_authorize(id: int):
    raise HTTPException(409, 'Tujuan bulanan kini satu salinan kerja. Otorisasi TEST/produksi terpisah tidak digunakan; jalankan penarikan secara manual.')


@router.post('/runs', status_code=202)
def start_run(body: core.RunStart, db: Session = Depends(get_db), user=Depends(admin)):
    lock_date(db, body.selected_date)
    old = db.scalar(select(Run).where(Run.idempotency_key == body.idempotency_key))
    if old:
        if (old.website_id, old.selected_date, old.preview) != (body.website_id, body.selected_date, body.preview):
            raise HTTPException(409, 'Kunci permintaan dipakai untuk operasi lain.')
        return core.serialize(old)
    assert_available(db, body.selected_date, body.website_id)
    snapshot = make_snapshot(db, body.website_id, body.selected_date)
    run = create_run(db, body.website_id, body.selected_date, body.preview, body.idempotency_key, user.id, snapshot)
    core.audit(db, user, 'preview' if body.preview else 'start', run)
    core.save(db)
    return core.serialize(run)


@router.get('/runs')
def runs(limit: int = Query(default=100, ge=1, le=500), before_id: int = None, db: Session = Depends(get_db)):
    query = select(Run).order_by(Run.id.desc()).limit(limit)
    if before_id:
        query = query.where(Run.id < before_id)
    return [{**core.serialize(r), 'reconciliation': core.serialize(c) if (c := last_reconciliation(db, run_id=r.id)) else None}
            for r in db.scalars(query)]


@router.get('/runs/{id}')
def run_detail(id: int, db: Session = Depends(get_db)):
    from .models import DestinationConflict,RetryRequest,SourceSnapshot,MappedResult
    from sqlalchemy import func
    run = core.require(db, Run, id)
    reco = last_reconciliation(db, run_id=id)
    overview = date_overview(db, run.selected_date)
    row = next((r for r in overview['websites'] if r['website_id'] == run.website_id), None)
    dest = db.get(Destination, overview['destination']['id']) if overview['destination'] else None
    from .destination_registry import current_mapping
    mapping=current_mapping(db,dest) if dest else None
    pinned=run.config_snapshot.get('destination',{})
    retry_allowed=bool(dest and mapping and mapping.state=='READY' and mapping.id==run.config_snapshot.get('mapping_id') and
                       (dest.id,dest.revision,dest.spreadsheet_id)==(pinned.get('id'),pinned.get('revision'),pinned.get('spreadsheet_id')))
    return {**core.serialize(run), 'reconciliation': core.serialize(reco) if reco else None,
        'retry_allowed':retry_allowed,
        'pipeline':{'snapshots':dict(db.execute(select(SourceSnapshot.state,func.count()).where(SourceSnapshot.run_id==id).group_by(SourceSnapshot.state)).all()),
            'mapped_results':db.scalar(select(func.count()).select_from(MappedResult).join(RunItem,MappedResult.run_item_id==RunItem.id).where(RunItem.run_id==id))},
        'conflicts':[core.serialize(c) for c in db.scalars(select(DestinationConflict).where(DestinationConflict.run_id==id,
            DestinationConflict.state.in_(['OPEN','WRITE_PENDING','KEEP_PENDING'])))],
        'retry_requests':[core.serialize(r) for r in db.scalars(select(RetryRequest).where(RetryRequest.run_id==id).order_by(RetryRequest.id.desc()).limit(100))],
        'current_revision': bool(dest and is_current_run(db, run, dest)),
        'is_latest_current': bool(row and row['run_id'] == id), 'date_status': overview,
        'items': [core.serialize(i) for i in db.scalars(select(RunItem).where(RunItem.run_id == id))],
        'errors': [core.serialize(e) for e in db.scalars(select(TaskError).where(TaskError.run_id == id, TaskError.is_resolved == False))]}


def queue_retry(db, run, body, user):
    from .models import RetryRequest
    from .retry_queue import enqueue
    lock_date(db,run.selected_date)
    db.refresh(run)
    if body.idempotency_key:
        previous=db.scalar(select(RetryRequest).where(RetryRequest.idempotency_key==body.idempotency_key))
        if previous:
            if previous.run_id!=run.id or body.item_ids and body.item_ids!=[previous.run_item_id]:
                raise HTTPException(409,'Kunci retry dipakai untuk item lain.')
            return run
    assert_available(db,run.selected_date,run.website_id,allow_run=run.id,allow_batch=run.batch_id)
    if run.status=='CANCEL_REQUESTED':
        raise HTTPException(409,'Tunggu pembatalan selesai sebelum meminta retry.')
    dest=monthly_destination(db,run.selected_date,validated=True)
    if is_clear(db,run.selected_date,dest):raise HTTPException(409,'Tanggal sudah Clear. Buka kembali sebelum koreksi.')
    from .destination_registry import assert_current
    try:assert_current(db,run)  # Destination and mapping never follow a source edit.
    except Issue as error:raise HTTPException(409,error.message)
    from sqlalchemy import or_
    stale=select(TaskError.run_item_id).where(TaskError.run_id==run.id,TaskError.error_code=='DEPENDENCY_STALE',TaskError.is_resolved==False)
    allowed=or_(RunItem.status.in_(['FAILED','CANCELED']),RunItem.id.in_(stale)) if body.item_ids else RunItem.status.in_(['FAILED','CANCELED'])
    query=select(RunItem).where(RunItem.run_id==run.id,allowed,
                              RunItem.metric_type.notin_(['reconciliation','configuration']))
    if body.source_document_id is not None:query=query.where(RunItem.source_document_id==body.source_document_id)
    if body.item_ids is not None:query=query.where(RunItem.id.in_(body.item_ids))
    if body.metric_types is not None:query=query.where(RunItem.metric_type.in_(body.metric_types))
    items=list(db.scalars(query))
    # The legacy explicit DOC-wide action may include a FAILED dependent total.
    # A specific item request never adds another logical item.
    if body.item_ids is None and body.metric_types is None and any(i.metric_type=='expense_input' for i in items):
        total=db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type=='expense_total',RunItem.status.in_(['FAILED','CANCELED'])))
        if total and total not in items:items.append(total)
    if not items and body.source_document_id is None and body.metric_types is None:
        report_item=db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type=='reconciliation',RunItem.status=='FAILED'))
        if report_item and (body.item_ids is None or body.item_ids==[report_item.id]):items=[report_item]
    if not items:raise HTTPException(409,'Tidak ada item gagal dalam pilihan ini. Item berhasil tidak diulang.')
    if body.source_tab_name is not None and len({(i.source_document_id,i.source_tab_name) for i in items})>1:
        raise HTTPException(409,'Pilih sheet sumber baru hanya untuk satu item/sheet logis.')
    for item in items:
        active_request=db.scalar(select(RetryRequest).where(RetryRequest.run_item_id==item.id,RetryRequest.state.in_(['QUEUED','CLAIMED'])))
        if active_request:
            chosen=active_request.details.get('source_override',{}).get('tab')
            if body.source_tab_name is not None and body.source_tab_name!=chosen:
                raise HTTPException(409,'Retry item sudah diantrikan dengan sumber berbeda. Tunggu hasil sebelum mengubah otorisasi.')
            continue
        key=body.idempotency_key if len(items)==1 else None
        from .source_authorization import authorize_retry_source
        authorization=authorize_retry_source(db,run,item,body.source_tab_name) if item.metric_type!='reconciliation' else None
        if authorization:authorization['requested_by']=user.id
        details={'requested_item_ids':[i.id for i in items]}
        if authorization:details['source_override']=authorization
        enqueue(db,run,item,user.id,key=key,kind='RECONCILE' if item.metric_type=='reconciliation' else 'SOURCE_RETRY',details=details)
        if authorization:
            snapshot=dict(run.config_snapshot)
            snapshot['item_source_authorizations']={**snapshot.get('item_source_authorizations',{}),str(item.id):authorization}
            run.config_snapshot=snapshot
    path=Path(settings().transfer_palette_file)
    snapshot=dict(run.config_snapshot)
    if path.is_file():
        try:snapshot['palette']=json.loads(path.read_text())
        except (ValueError,OSError):raise HTTPException(409,'Palet kiriman tidak dapat dibaca.')
    from .engine.types import fingerprint
    snapshot['engine_revision']=fingerprint({p.name:p.read_text() for p in sorted((Path(__file__).parent/'engine').glob('*.py'))})
    run.config_snapshot=snapshot
    from .source_authorization import refresh_context_signature
    refresh_context_signature(db,run)
    if run.status not in ('RUNNING','QUEUED'):
        run.status,run.finished_at,run.current_phase='QUEUED',None,'RETRY_QUEUED'
        run.cancel_requested_at,run.cancel_requested_by=None,None
    if run.batch_id:
        batch=db.get(CrawlBatch,run.batch_id)
        if batch.status not in ('RUNNING','QUEUED'):
            batch.status,batch.finished_at,batch.current_phase='QUEUED',None,'RETRY_QUEUED'
            batch.cancel_requested_at,batch.cancel_requested_by=None,None
            entry=db.scalar(select(BatchEntry).where(BatchEntry.batch_id==batch.id,BatchEntry.run_id==run.id))
            if entry:entry.status='WAITING'
    core.audit(db,user,'queue_item_retry',run,{'items':[i.id for i in items]})
    return run


@router.post('/runs/{id}/retry', status_code=202)
def retry(id: int, body: core.Retry, db: Session = Depends(get_db), user=Depends(admin)):
    run = queue_retry(db, core.require(db, Run, id), body, user)
    core.save(db)
    return core.serialize(run)


@router.get('/runs/{id}/items/{item_id}/retry-options')
def retry_options(id:int,item_id:int,db:Session=Depends(get_db)):
    from .workflow import source_configuration
    from .source_authorization import document_for
    run=core.require(db,Run,id);item=core.require(db,RunItem,item_id)
    if item.run_id!=run.id:raise HTTPException(404,'Item tidak ditemukan pada Run ini.')
    if item.source_document_id is None:return {'tabs':[],'suggested':None,'requires_selection':False}
    docs,_=source_configuration(db,run.website_id,run.selected_date)
    doc=next((d for d in docs if d['id']==item.source_document_id and d['validation_status']=='VALID'),None)
    tabs=doc['tabs'] if doc else []
    prior=(document_for(run,item) or {}).get('identities',{}).get(item.source_tab_name,{})
    proven=[t for t in tabs if doc.get('identities',{}).get(t,{}).get('lineage')==prior.get('lineage') and prior.get('lineage')]
    suggested=item.source_tab_name if item.source_tab_name in tabs else proven[0] if len(proven)==1 else None
    return {'tabs':tabs,'suggested':suggested,'requires_selection':suggested is None,
            'source_revision':doc['revision'] if doc else None}


class ConflictAction(BaseModel):
    action: Literal['NEW','KEEP']
    observation_hash: str = Field(pattern=r'^[a-f0-9]{64}$')
    idempotency_key: str = Field(min_length=16,max_length=100)


@router.post('/conflicts/{id}/refresh')
def refresh_conflict(id:int,db:Session=Depends(get_db),user=Depends(admin)):
    from .conflicts import observe,observation_hash
    from .destination_registry import RegistryView
    from .destination_reader import close_view
    from .engine.types import Write
    from .models import DestinationConflict
    conflict=core.require(db,DestinationConflict,id)
    run=core.require(db,Run,conflict.run_id)
    writes=[Write(**w) for w in conflict.writes]
    client=core.SheetsClient();view=RegistryView(db,client,run,writes[0].tab)
    try:actual=observe(db,client,run,view,writes)
    finally:close_view(view)
    if conflict.state=='OPEN':
        conflict.observed=actual
        conflict.observation_hash=observation_hash(run,conflict.writes,actual)
        conflict.provenance={**conflict.provenance,'observed_at':utcnow().isoformat()}
        core.save(db)
    return {**core.serialize(conflict),'current_observed':actual,'read_at':utcnow().isoformat(),'preview':run.preview,
            'website':run.config_snapshot['website'],'selected_date':str(run.selected_date),'module':db.get(RunItem,conflict.run_item_id).metric_type}


@router.post('/conflicts/{id}/decide',status_code=202)
def decide_conflict(id:int,body:ConflictAction,db:Session=Depends(get_db),user=Depends(admin)):
    from .models import DestinationConflict
    from .conflicts import queue_decision
    decision=queue_decision(db,core.require(db,DestinationConflict,id),user,body.action,body.observation_hash,body.idempotency_key)
    core.save(db)
    return core.serialize(decision)


class LegacyLineageConfirmation(BaseModel):
    prior_run_item_id: int
    reviewed_history_and_google_identity: Literal[True]


@router.post('/source-identities/{id}/confirm-legacy')
def confirm_legacy_lineage(id:int,body:LegacyLineageConfirmation,db:Session=Depends(get_db),user=Depends(admin)):
    from .models import LegacySourceLink,SourceIdentity,SourceSheet,SourceBinding
    identity=core.require(db,SourceIdentity,id)
    item=core.require(db,RunItem,body.prior_run_item_id)
    prior=core.require(db,Run,item.run_id)
    doc=next((d for d in prior.config_snapshot['sources'] if d['id']==item.source_document_id),None)
    if not doc or (doc['id'],doc['spreadsheet_id'])!=(identity.source_document_id,identity.spreadsheet_id):
        raise HTTPException(409,'Dokumen/revisi historis tidak sesuai identitas sumber yang dikonfirmasi.')
    recorded=doc.get('identities',{}).get(item.source_tab_name)
    if recorded and recorded['lineage']!=identity.lineage:
        raise HTTPException(409,'Histori membuktikan identitas berbeda. Konfirmasi lineage tidak boleh mengalihkan ownership antar-tab.')
    names=list(db.scalars(select(SourceSheet.tab_name).join(SourceBinding,SourceBinding.source_sheet_state_id==SourceSheet.id).where(
        SourceBinding.identity_id==identity.id,SourceBinding.status=='VERIFIED',SourceSheet.is_available==True)))
    if len(names)!=1:raise HTTPException(409,'Identitas tab saat ini tidak unik.')
    client=core.SheetsClient()
    metadata=client.metadata(identity.spreadsheet_id)
    actual=[p['properties'] for p in metadata.get('sheets',[]) if p['properties']['title']==names[0]]
    if len(actual)!=1 or actual[0]['sheetId']!=identity.google_sheet_id:
        raise HTTPException(409,'Identitas Google saat ini berbeda; konfirmasi ditolak.')
    old=db.get(LegacySourceLink,item.id)
    if old:
        if old.identity_id!=identity.id:raise HTTPException(409,'Item historis sudah terikat pada identitas lain.')
        return core.serialize(old)
    link=LegacySourceLink(prior_run_item_id=item.id,identity_id=identity.id,confirmed_by=user.id,
        evidence={'current_tab':names[0],'google_sheet_id':identity.google_sheet_id,'prior_tab':item.source_tab_name,
                  'prior_revision':doc['revision'],'current_revision':identity.source_revision_id,'explicit_admin_confirmation':True})
    db.add(link)
    if item.source_tab_name not in identity.names:identity.names=[item.source_tab_name,*identity.names]
    core.audit(db,user,'confirm_legacy_source_lineage',identity,link.evidence)
    core.save(db)
    return core.serialize(link)


@router.post('/runs/{id}/resync', status_code=202)
def resync(id: int, body: Resync, db: Session = Depends(get_db), user=Depends(admin)):
    original = core.require(db, Run, id)
    dates = sorted(set(body.selected_dates or [original.selected_date]))
    result = []
    for selected in dates:
        if (selected.year, selected.month) != (original.year, original.month):
            raise HTTPException(409, 'Sinkronisasi harus tetap dalam bulan proses asal. Pilih periode lain dari halaman utama.')
        lock_date(db, selected)
        key = f"resync:{body.idempotency_key}:{selected.isoformat()}"
        old = db.scalar(select(Run).where(Run.idempotency_key == key))
        if old:
            result.append(core.serialize(old))
            continue
        assert_available(db, selected, original.website_id)
        snapshot = make_snapshot(db, original.website_id, selected)
        def same_source_documents(candidate):
            prior=candidate.config_snapshot.get('sources',[])
            current={d['id']:d for d in snapshot['sources']}
            # An explicitly requested range can cross day 15/16. Associate
            # each date only with history from its own exact document records;
            # never compare DOC B history to DOC A's signature or adopt by name.
            return (len(prior)==len(current) and all(d['id'] in current and
                d['type']==current[d['id']]['type'] and
                d.get('source_period') in (None,current[d['id']].get('source_period')) for d in prior))
        prior = original if selected == original.selected_date else next((candidate for candidate in db.scalars(
            select(Run).where(Run.website_id == original.website_id, Run.selected_date == selected,
                              Run.preview == False).order_by(Run.id.desc()))
            if same_source_documents(candidate)
            and candidate.config_snapshot.get('destination') == original.config_snapshot.get('destination')), None)
        if prior:
            snapshot['authorized_previous_run_id'] = prior.id
        new = create_run(db, original.website_id, selected, False, key, user.id, snapshot)
        core.audit(db, user, 'manual_resync_new_url', new, {'original_run_id': original.id, 'selected_date': str(selected)})
        result.append(core.serialize(new))
    core.save(db)
    return {'runs': result}


@router.post('/batches', status_code=202)
def start_batch(body: BatchStart, db: Session = Depends(get_db), user=Depends(admin)):
    batch = enqueue_batch(db, body.selected_date, body.preview, body.idempotency_key, user.id)
    core.audit(db, user, 'start_all_websites', batch, {'preview': body.preview})
    core.save(db)
    return batch_progress(db, batch)


@router.get('/batches')
def batches(db: Session = Depends(get_db)):
    return [batch_progress(db, b) for b in db.scalars(select(CrawlBatch).order_by(CrawlBatch.id.desc()).limit(100))]


@router.get('/batches/{id}')
def batch_detail(id: int, db: Session = Depends(get_db)):
    batch = core.require(db, CrawlBatch, id)
    return {**batch_progress(db, batch), 'date_status': date_overview(db, batch.selected_date)}


class BatchRetry(BaseModel):
    website_id: int


@router.post('/batches/{id}/retry', status_code=202)
def retry_batch_website(id: int, body: BatchRetry, db: Session = Depends(get_db), user=Depends(admin)):
    batch = core.require(db, CrawlBatch, id)
    entry = db.scalar(select(BatchEntry).where(BatchEntry.batch_id == id, BatchEntry.website_id == body.website_id))
    if not entry:
        raise HTTPException(404, 'WEB tidak termasuk dalam kelompok ini.')
    run = db.get(Run, entry.run_id)
    configuration = db.scalar(select(RunItem).where(RunItem.run_id == run.id, RunItem.metric_type == 'configuration'))
    if configuration:
        lock_date(db, run.selected_date)
        assert_available(db, run.selected_date)
        dest = monthly_destination(db, run.selected_date, validated=True)
        original = run.config_snapshot['destination']
        if (dest.id, dest.revision) != (original['id'], original['revision']):
            raise HTTPException(409, 'Tujuan berubah. Gunakan Crawl Ulang ke URL Baru pada hasil proses asal.')
        snapshot = make_snapshot(db, run.website_id, run.selected_date, dest)
        child = create_run(db, run.website_id, run.selected_date, batch.preview, str(uuid4()), user.id, snapshot, batch.id)
        entry.run_id, entry.status = child.id, 'WAITING'
        batch.status, batch.finished_at = 'QUEUED', None
        batch.cancel_requested_at,batch.cancel_requested_by,batch.current_phase=None,None,'QUEUED'
        core.audit(db, user, 'retry_website_configuration', child, {'original_run_id': run.id})
    else:
        queue_retry(db, run, core.Retry(), user)
    core.save(db)
    return batch_progress(db, batch)


@router.get('/reconciliations/date')
def reconciliation_date(selected_date: date, db: Session = Depends(get_db)):
    return date_overview(db, selected_date)


@router.get('/reconciliations/history')
def reconciliation_history(selected_date: date = None, website_id: int = None, db: Session = Depends(get_db)):
    query = select(Reconciliation).order_by(Reconciliation.id.desc()).limit(500)
    if selected_date:
        query = query.where(Reconciliation.selected_date == selected_date)
    if website_id:
        query = query.where(Reconciliation.website_id == website_id)
    return [core.serialize(r) for r in db.scalars(query)]


@router.post('/runs/{id}/reconcile', status_code=202)
def recheck_run(id: int, body: CheckRequest, db: Session = Depends(get_db), user=Depends(admin)):
    run = core.require(db, Run, id)
    dest = monthly_destination(db, run.selected_date, validated=True)
    if not is_current_run(db, run, dest):
        raise HTTPException(409, 'Proses ini memakai konfigurasi lama. Gunakan Crawl Ulang ke URL Baru.')
    batch = enqueue_batch(db, run.selected_date, False, body.idempotency_key, user.id, True, run)
    core.audit(db, user, 'recheck_website_read_only', batch, {'run_id': id})
    core.save(db)
    return batch_progress(db, batch)


@router.post('/reconciliations/recheck', status_code=202)
def recheck_date(body: DateCheck, db: Session = Depends(get_db), user=Depends(admin)):
    batch = enqueue_batch(db, body.selected_date, False, body.idempotency_key, user.id, True)
    core.audit(db, user, 'recheck_all_read_only', batch)
    core.save(db)
    return batch_progress(db, batch)


def clear_date(db, selected, user):
    lock_date(db, selected)
    assert_available(db, selected)
    dest = monthly_destination(db, selected, validated=True)
    state = date_overview(db, selected)
    if not state['eligible']:
        raise HTTPException(409, 'Belum dapat Clear: seluruh WEB harus selesai, tanpa kesalahan, BALANCE setiap WEB dan konsolidasi harus nol.')
    obj = db.scalar(select(FinalClearance).where(FinalClearance.selected_date == selected,
        FinalClearance.destination_document_id == dest.id, FinalClearance.destination_revision == dest.revision,
        FinalClearance.context_signature == state['context_signature']))
    if not obj:
        obj = FinalClearance(selected_date=selected, destination_document_id=dest.id, destination_revision=dest.revision,
            context_signature=state['context_signature'], confirmed_by=user.id)
        db.add(obj)
        db.flush()
    obj.is_clear, obj.confirmed_by, obj.confirmed_at = True, user.id, utcnow()
    core.audit(db, user, 'final_clear_all_websites', obj)
    return obj


@router.post('/runs/{id}/clear')
def clear_run(id: int, db: Session = Depends(get_db), user=Depends(admin)):
    run = core.require(db, Run, id)
    dest = monthly_destination(db, run.selected_date)
    if run.preview or not is_current_run(db, run, dest):
        raise HTTPException(409, 'Pratinjau atau hasil revisi lama tidak dapat ditandai Clear.')
    obj = clear_date(db, run.selected_date, user)
    core.save(db)
    return core.serialize(obj)


@router.post('/reconciliations/clear')
def clear_all(body: DateCheck, db: Session = Depends(get_db), user=Depends(admin)):
    obj = clear_date(db, body.selected_date, user)
    core.save(db)
    return core.serialize(obj)


@router.get('/clearances')
def clearances(db: Session = Depends(get_db)):
    return [{**core.serialize(c), 'website_id': None, 'environment': 'WORKING', 'scope': 'ALL'} for c in db.scalars(
        select(FinalClearance).order_by(FinalClearance.id.desc()).limit(500))]


@router.get('/clearances/legacy')
def legacy_clearances(db: Session = Depends(get_db)):
    return [core.serialize(c) for c in db.scalars(select(Clearance).order_by(Clearance.id.desc()).limit(500))]


@router.post('/clearances/{id}/reopen')
def reopen(id: int, body: core.Reopen, db: Session = Depends(get_db), user=Depends(admin)):
    obj = core.require(db, FinalClearance, id)
    lock_date(db, obj.selected_date)
    assert_available(db, obj.selected_date)
    obj.is_clear, obj.reopened_at, obj.reopen_reason = False, utcnow(), body.reason
    core.audit(db, user, 'reopen_all_websites', obj, body.model_dump())
    core.save(db)
    return core.serialize(obj)



@router.post('/runs/{id}/cancel')
def cancel_run(id:int,db:Session=Depends(get_db),user=Depends(admin)):
    run=core.require(db,Run,id)
    lock_date(db,run.selected_date)
    request_run_cancel(db,run,user.id)
    core.audit(db,user,'cancel_run',run,{'status':run.status})
    core.save(db)
    return core.serialize(run)


@router.post('/batches/{id}/cancel')
def cancel_batch(id:int,db:Session=Depends(get_db),user=Depends(admin)):
    batch=core.require(db,CrawlBatch,id)
    lock_date(db,batch.selected_date)
    request_batch_cancel(db,batch,user.id)
    core.audit(db,user,'cancel_batch',batch,{'status':batch.status})
    core.save(db)
    return batch_progress(db,batch)
