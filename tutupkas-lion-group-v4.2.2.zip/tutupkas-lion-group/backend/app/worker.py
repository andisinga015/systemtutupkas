import fcntl
import json
import logging
import signal
import time
from pathlib import Path

from sqlalchemy import select

from .config import settings
from .diagnostics import configure_worker_log
from .db import SessionLocal
from .engine.runner import process_run
from .batches import process_batch, fail_batch
from .models import Run, CrawlBatch
from .job_control import finalize_cancel,finalize_batch_cancel,fail_run

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger('tutupkas.worker')
stopping = False


def stop(*_):
    global stopping
    stopping = True


def recover_jobs(db):
    from .retry_queue import interrupted
    from .destination_registry import recover_mappings
    recover_mappings(db)
    for run in list(db.scalars(select(Run).where(Run.status.in_(['RUNNING','CANCEL_REQUESTED'])))):
        interrupted(db,run)
        db.refresh(run)
        if run.cancel_requested_at or run.status=='CANCEL_REQUESTED':
            finalize_cancel(db,run)
        else:
            fail_run(db,run,code='WORKER_INTERRUPTED')
    for batch in list(db.scalars(select(CrawlBatch).where(CrawlBatch.status.in_(['RUNNING','CANCEL_REQUESTED'])))):
        db.refresh(batch)
        if batch.cancel_requested_at or batch.status=='CANCEL_REQUESTED':
            finalize_batch_cancel(db,batch)
            continue
        fail_batch(db,batch,code='WORKER_INTERRUPTED')
    db.commit()


def main():
    lockpath = Path(settings().worker_lock)
    lockpath.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with lockpath.open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise SystemExit('Worker lain sudah berjalan.')
        configure_worker_log(lockpath)
        signal.signal(signal.SIGTERM, stop)
        signal.signal(signal.SIGINT, stop)
        # An abrupt termination is never an automatic financial replay. Mark
        # interrupted jobs failed, preserving intents and verified results.
        # Only an explicit admin retry can reconcile and resume them.
        with SessionLocal() as db:
            recover_jobs(db)
        logger.info(json.dumps({"event": "worker_ready"}))
        while not stopping:
            with SessionLocal() as db:
                from .models import DestinationMapping
                from .destination_registry import build_mapping
                from .sheets import SheetsClient
                mapping=db.scalar(select(DestinationMapping).where(DestinationMapping.state=='QUEUED').order_by(DestinationMapping.id).limit(1))
                if mapping:
                    try:build_mapping(db,mapping,SheetsClient())
                    except Exception:
                        db.rollback();db.refresh(mapping)
                        mapping.state,mapping.error='FAILED',{'code':'MAPPING_FAILED','message':'Pemetaan belum selesai; validasi ulang dan periksa log.'}
                        db.commit()
                batch = db.scalar(select(CrawlBatch).where(CrawlBatch.status == 'QUEUED').order_by(CrawlBatch.id).limit(1))
                run = None if batch else db.scalar(select(Run).where(Run.status == 'QUEUED', Run.batch_id == None).order_by(Run.id).limit(1))
                if run or batch:
                    try:
                        if batch:
                            process_batch(db, batch, should_stop=lambda: stopping)
                        else:
                            process_run(db, run)
                    except Exception as e:
                        db.rollback()
                        logger.error(json.dumps({"event": "worker_error", "run_id": run.id if run else None,
                                                 "batch_id": batch.id if batch else None, "type": type(e).__name__}))
                        if batch:
                            fail_batch(db,batch)
                        else:
                            fail_run(db,run)
            if not run and not batch:
                time.sleep(settings().worker_poll_seconds)
        logger.info(json.dumps({"event": "worker_stopped"}))


if __name__ == '__main__':
    main()

