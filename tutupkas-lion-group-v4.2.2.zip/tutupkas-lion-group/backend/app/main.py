import json
import logging
import time

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from sqlalchemy import text

from . import auth, api, operations
from .db import SessionLocal
from .engine.types import Issue

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger('tutupkas')
app = FastAPI(title='Tutup Kas Lion Group', docs_url=None, redoc_url=None, openapi_url=None)
app.include_router(auth.router, prefix='/api')
app.include_router(api.router, prefix='/api')
app.include_router(operations.router, prefix='/api')


@app.exception_handler(Issue)
async def issue_handler(request: Request, error: Issue):
    return JSONResponse(status_code=422, content={"detail": error.message, "code": error.code,
                                                 "suggested_fix": error.fix, "context": error.context})


@app.middleware('http')
async def security_headers(request: Request, call_next):
    started = time.monotonic()
    try:
        response = await call_next(request)
    except Exception:
        # No raw request bodies, credentials, or Google exception text in logs.
        logger.error(json.dumps({"event": "request_error", "path": request.url.path}))
        response = JSONResponse({"detail": "Terjadi kesalahan layanan. Periksa log status dan konfigurasi."}, status_code=500)
    response.headers['Cache-Control'] = 'no-store'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['Referrer-Policy'] = 'same-origin'
    logger.info(json.dumps({"event": "request", "method": request.method, "path": request.url.path,
                            "status": response.status_code, "ms": round((time.monotonic()-started)*1000)}))
    return response


@app.get('/api/health')
def health():
    with SessionLocal() as db:
        db.execute(text('SELECT version_num FROM alembic_version'))
    return {"status": "ok", "service": "tutupkas-api"}

