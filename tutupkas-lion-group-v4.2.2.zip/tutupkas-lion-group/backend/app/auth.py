import hashlib
import secrets
from datetime import timedelta

from argon2 import PasswordHasher
from argon2.exceptions import VerificationError
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field
from sqlalchemy import func, select, delete
from sqlalchemy.orm import Session

from .config import settings
from .db import get_db, utcnow
from .models import AuthSession, LoginAttempt, User

router = APIRouter(prefix="/auth", tags=["auth"])
hasher = PasswordHasher(time_cost=3, memory_cost=19456, parallelism=1)
DUMMY_HASH = hasher.hash(secrets.token_urlsafe(32))


def digest(v):
    return hashlib.sha256(v.encode()).hexdigest()


def check_origin(request: Request):
    origin = request.headers.get("origin")
    if origin and origin.rstrip("/") != settings().app_origin.rstrip("/"):
        raise HTTPException(403, "Asal permintaan tidak diizinkan.")


def csrf_check(request: Request, expected: str):
    check_origin(request)
    token = request.headers.get("x-csrf-token", "")
    if not expected or not secrets.compare_digest(token, expected):
        raise HTTPException(403, "Token keamanan kedaluwarsa. Muat ulang halaman.")


def admin(request: Request, db: Session = Depends(get_db)) -> User:
    token = request.cookies.get("tk_session", "")
    session = db.get(AuthSession, digest(token)) if token else None
    if not session or session.expires_at <= utcnow():
        raise HTTPException(401, "Silakan masuk kembali.")
    user = db.get(User, session.user_id)
    if not user or not user.is_active or user.role != "admin":
        raise HTTPException(403, "Akses administrator diperlukan.")
    if request.method not in ("GET", "HEAD", "OPTIONS"):
        csrf_check(request, session.csrf_token)
    request.state.auth_session = session
    return user


class Login(BaseModel):
    username: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=1, max_length=1024)


@router.get("/csrf")
def csrf(response: Response):
    token = secrets.token_urlsafe(32)
    response.set_cookie("tk_pre_csrf", token, httponly=True, secure=settings().cookie_secure,
                        samesite="strict", max_age=900, path="/api/auth")
    return {"csrf_token": token}


@router.post("/login")
def login(body: Login, request: Request, response: Response, db: Session = Depends(get_db)):
    csrf_check(request, request.cookies.get("tk_pre_csrf", ""))
    # Trust only the direct peer. Nginx sets this header and binds the API to loopback.
    ip = request.client.host if request.client else "unknown"
    identities = [digest("ip:" + ip), digest("user:" + body.username.casefold())]
    cutoff = utcnow() - timedelta(minutes=15)
    db.execute(delete(LoginAttempt).where(LoginAttempt.created_at < cutoff))
    for identity in identities:
        count = db.scalar(select(func.count()).select_from(LoginAttempt).where(LoginAttempt.identity == identity,
                                                        LoginAttempt.created_at > cutoff))
        if count >= 8:
            db.commit()
            raise HTTPException(429, "Terlalu banyak percobaan. Coba lagi dalam 15 menit.")
    user = db.scalar(select(User).where(User.username == body.username))
    try:
        valid = hasher.verify(user.password_hash if user else DUMMY_HASH, body.password)
    except VerificationError:
        valid = False
    if not valid or not user or not user.is_active:
        for identity in identities:
            db.add(LoginAttempt(identity=identity))
        db.commit()
        raise HTTPException(401, "Nama pengguna atau kata sandi salah.")
    if hasher.check_needs_rehash(user.password_hash):
        user.password_hash = hasher.hash(body.password)
    token, csrf = secrets.token_urlsafe(48), secrets.token_urlsafe(32)
    db.add(AuthSession(token_hash=digest(token), user_id=user.id, csrf_token=csrf,
                       expires_at=utcnow() + timedelta(hours=settings().session_hours)))
    user.last_login_at = utcnow()
    db.commit()
    response.set_cookie("tk_session", token, httponly=True, secure=settings().cookie_secure, samesite="strict",
                        max_age=settings().session_hours * 3600, path="/api")
    response.delete_cookie("tk_pre_csrf", path="/api/auth")
    return {"id": user.id, "username": user.username, "role": user.role, "csrf_token": csrf}


@router.get("/me")
def me(request: Request, user=Depends(admin)):
    return {"id": user.id, "username": user.username, "role": user.role,
            "csrf_token": request.state.auth_session.csrf_token}


@router.post("/logout")
def logout(request: Request, response: Response, user=Depends(admin), db: Session = Depends(get_db)):
    db.delete(request.state.auth_session)
    db.commit()
    response.delete_cookie("tk_session", path="/api")
    return {"ok": True}

