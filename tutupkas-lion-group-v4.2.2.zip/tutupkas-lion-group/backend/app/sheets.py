import json
import logging
import re
import time
import random
from urllib.parse import urlparse

import requests
from google.auth.exceptions import GoogleAuthError
from google.auth.transport.requests import AuthorizedSession
from google.oauth2 import service_account

from .diagnostics import memory
from .config import settings
from .engine.types import Cell, Grid, Issue, Write, column

logger = logging.getLogger('tutupkas.worker')

SCOPES = ["https://www.googleapis.com/auth/spreadsheets", "https://www.googleapis.com/auth/drive.metadata.readonly"]


def spreadsheet_id(url: str) -> str:
    parsed = urlparse(url)
    match = re.fullmatch(r"/spreadsheets/d/([A-Za-z0-9_-]{15,150})(?:/.*)?", parsed.path)
    if parsed.scheme != "https" or parsed.netloc != "docs.google.com" or not match or parsed.username:
        raise Issue("INVALID_URL", "Gunakan URL Google Spreadsheet https://docs.google.com/spreadsheets/d/…")
    return match[1]


def google_cell(raw: dict) -> Cell:
    user = raw.get("userEnteredValue", {})
    effective = raw.get("effectiveValue", {})
    if "errorValue" in effective:
        value = raw.get("formattedValue", "#ERROR!")
    else:
        value = next((effective[k] for k in ("numberValue", "stringValue", "boolValue") if k in effective), None)
    fmt = raw.get("effectiveFormat", {})
    rgb = fmt.get("backgroundColorStyle", {}).get("rgbColor", fmt.get("backgroundColor"))
    color = tuple(float(rgb.get(k, 0)) for k in ("red", "green", "blue")) if rgb is not None else None
    return Cell(value, user.get("formulaValue"), raw.get("note", ""), color,
                fmt.get("numberFormat", {}).get("type") in ("DATE", "DATE_TIME"))


class SheetsClient:
    @staticmethod
    def request_info(method,service,path,kwargs):
        params=kwargs.get('params',{});fields=params.get('fields','');ranges=params.get('ranges',[])
        if isinstance(ranges,str):ranges=[ranges]
        cells=0
        def col(value):
            total=0
            for letter in value:total=total*26+ord(letter)-64
            return total
        for address in ranges:
            match=re.search(r'!([A-Z]+)(\d+):([A-Z]+)(\d+)$',address)
            if match:cells+=(col(match[3])-col(match[1])+1)*(int(match[4])-int(match[2])+1)
        kind=('drive_version' if service=='drive' else 'financial_batch' if method!='GET' else
            'values' if '/values:' in path else 'target_cells' if 'rowData' in fields and cells<=len(ranges) else
            ('global_invariants' if 'note' not in fields and 'backgroundColor' not in fields else 'global_cells') if 'rowData' in fields else
            'merged_geometry' if 'merges' in fields else 'properties')
        return {'read_kind':kind,'range_count':len(ranges),'requested_cells':cells}

    def __init__(self, cancel_check=lambda:None):
        self.cancel_check=cancel_check
        try:
            credentials = service_account.Credentials.from_service_account_file(settings().credential_file, scopes=SCOPES)
        except (OSError, ValueError):
            raise Issue("CREDENTIALS_UNAVAILABLE", "File Service Account belum tersedia atau tidak dapat dibaca oleh layanan.",
                        "Atur TK_CREDENTIAL_FILE ke file yang sudah ada dan beri akses baca hanya untuk pengguna layanan.")
        self.session = AuthorizedSession(credentials)
        self.last_request = 0.0

    def request(self, method: str, path: str, **kwargs):
        cfg = settings()
        service = kwargs.pop('_service','sheets')
        request_info=self.request_info(method,service,path,kwargs)
        if method!='GET':self._verified_revisions={}
        headers = dict(kwargs.pop('headers', {}))
        # Avoid an oversized decompressor buffer before the streamed byte cap.
        headers['Accept-Encoding'] = 'identity'
        # Keep TLS verification, including the platform's configured CA bundle.
        for attempt in range(cfg.api_retries + 1):
            if method == 'GET':
                self.cancel_check()
            from .quota import acquire
            acquire(self.cancel_check if method=='GET' else lambda:None)
            self.last_request = time.monotonic()
            from .telemetry import api_attempt,response_bytes
            api_attempt(method,attempt)
            started, response, code, received = time.monotonic(), None, 'GOOGLE_TIMEOUT',0
            try:
                base = 'https://www.googleapis.com/drive/v3/files/' if service=='drive' else 'https://sheets.googleapis.com/v4/spreadsheets/'
                response = self.session.request(method, base + path,
                    timeout=cfg.request_timeout, stream=True, headers=headers, **kwargs)
                if response.ok:
                    body = bytearray()
                    for chunk in response.iter_content(chunk_size=65536):
                        received+=len(chunk)
                        if time.monotonic()-started > cfg.request_timeout:
                            raise requests.Timeout()
                        if len(body)+len(chunk) > cfg.max_api_response_bytes:
                            logger.info(json.dumps({'event':'sheets_response_limit','method':method,**getattr(self,'diagnostic_context',{}),
                                **request_info,'received_bytes':received,'response_limit_bytes':cfg.max_api_response_bytes}))
                            raise Issue('RESPONSE_TOO_LARGE', 'Respons Google melebihi batas memori aman.',
                                        'Periksa ukuran sel/rentang pada log VPS; jangan menaikkan MemoryMax.')
                        body.extend(chunk)
                    size = len(body)
                    try:
                        result = json.loads(body)
                    except ValueError:
                        raise Issue('GOOGLE_INVALID_RESPONSE','Respons Google tidak berupa JSON yang dapat dibaca.')
                    del body
                    logger.info(json.dumps({'event':'sheets_request','method':method,
                        **getattr(self,'diagnostic_context',{}),
                        **request_info,
                        'duration_ms':round((time.monotonic()-started)*1000),'attempt':attempt+1,
                        'response_bytes':size, **memory()}))
                    return result
                if response.status_code not in (429,500,502,503,504):
                    code = {403:'ACCESS_DENIED',404:'SPREADSHEET_MISSING'}.get(response.status_code,'GOOGLE_REQUEST_FAILED')
                    raise Issue(code,f'Google menolak permintaan spreadsheet (HTTP {response.status_code}).',
                                'Periksa URL, izin Editor untuk Service Account, serta akses API.')
                code = 'GOOGLE_RATE_LIMIT' if response.status_code==429 else 'GOOGLE_TIMEOUT'
            except GoogleAuthError:
                raise Issue('GOOGLE_AUTH_FAILED','Google tidak menerima autentikasi Service Account.',
                            'Periksa kunci, waktu sistem, API Sheets aktif, serta koneksi ke oauth2.googleapis.com.')
            except requests.RequestException:
                pass
            finally:
                response_bytes(received)
                if response is not None:
                    response.close()
                # Release partial bodies too when a streamed attempt disconnects.
                body = None
            if method!='GET':
                raise Issue('GOOGLE_WRITE_UNCERTAIN','Respons tulis Google belum pasti; tujuan harus diperiksa sebelum pengiriman ulang.')
            if attempt == cfg.api_retries:
                raise Issue(code,'Google belum dapat memproses permintaan setelah beberapa percobaan.')
            logger.info(json.dumps({'event':'sheets_retry','method':method,'attempt':attempt+1,'error_code':code,
                **getattr(self,'diagnostic_context',{}),
                'duration_ms':round((time.monotonic()-started)*1000), **memory()}))
            time.sleep(min(2 ** attempt + random.random(),16))

    def metadata(self, document_id: str):
        return self.request("GET", document_id, params={"fields": "spreadsheetId,properties(title),sheets(properties),namedRanges"})

    def sheet_properties(self, document_id, title):
        meta = self.request('GET', document_id, params={'fields':'sheets(properties(sheetId,title,gridProperties(rowCount,columnCount)))'})
        matches = [s['properties'] for s in meta.get('sheets', [])
                   if s['properties']['title'] == title]
        if len(matches) != 1:
            raise Issue('TAB_MISSING', f'Sheet {title} tidak tersedia. Refresh Daftar Sheet untuk memeriksa nama terbaru.')
        return matches[0]

    @staticmethod
    def a1(title, first_row, last_row, first_col, last_col):
        return "'" + title.replace("'", "''") + "'!" + f'{column(first_col)}{first_row+1}:{column(last_col)}{last_row+1}'

    def values(self, document_id, ranges):
        return self.request('GET', document_id + '/values:batchGet', params={
            'ranges':ranges, 'valueRenderOption':'UNFORMATTED_VALUE',
            'dateTimeRenderOption':'SERIAL_NUMBER', 'majorDimension':'ROWS'}).get('valueRanges', [])

    def cells(self, document_id, ranges, fields, merges=False):
        mask = 'sheets(data(startRow,startColumn,rowData(values(' + fields + ')))'
        if merges:
            mask += ',merges'
        return self.request('GET', document_id, params={'ranges':ranges,
            'includeGridData':'true', 'fields':mask + ')'})

    def source_day(self, document_id, title, selected, document_type):
        from .source_reader import SourceReader
        return SourceReader(self, document_id, title, selected, document_type).read()

    def indexed_source_day(self,db,doc,title,selected,identity):
        from .source_index import indexed_source_day
        return indexed_source_day(db,self,doc,title,selected,identity)

    def content_revision(self,document_id):
        # Metadata only, same Service Account/key. Missing Drive API permission
        # disables the fast path; it must never manufacture a stable token.
        if getattr(self,'_revision_unavailable',False) or not isinstance(getattr(self,'session',None),AuthorizedSession):
            return None
        try:
            raw=self.request('GET',document_id,_service='drive',params={'fields':'id,version,modifiedTime','supportsAllDrives':'true'})
        except Issue as error:
            if error.code in ('ACCESS_DENIED','SPREADSHEET_MISSING','GOOGLE_REQUEST_FAILED'):
                self._revision_unavailable=True
                return None
            raise
        return str(raw['version']) if raw.get('id')==document_id and raw.get('version') is not None else None

    def destination_grid(self, document_id, title, registered=()):
        from .destination_reader import DestinationReader
        return DestinationReader(self,document_id,title,registered)

    def grid(self, document_id: str, title: str):
        # All legacy destination/report consumers also get bounded access.
        return self.destination_grid(document_id,title)

    def write(self, document_id: str, grid: Grid, writes: list[Write]):
        return self.write_batch(document_id,[(grid,writes)])

    def write_batch(self,document_id,groups):
        """One atomic batchUpdate for disjoint complete logical groups."""
        requests_,seen=[],set()
        for grid,writes in groups:
            for request in self._write_requests(grid,writes):
                coordinates=request['updateCells']['range']
                key=(coordinates['sheetId'],coordinates['startRowIndex'],coordinates['startColumnIndex'])
                if key in seen:raise Issue('DUPLICATE_DESTINATION','Batch berisi lebih dari satu intent untuk sel yang sama.')
                seen.add(key);requests_.append(request)
                if len(requests_)>settings().grid_chunk_cells:
                    raise Issue('WRITE_BATCH_RESOURCE_LIMIT','Batch melebihi batas jumlah sel aman; tidak ada bagian dikirim.')
        if requests_:
            if len(json.dumps({'requests':requests_},ensure_ascii=False).encode())>settings().max_api_response_bytes:
                raise Issue('WRITE_BATCH_RESOURCE_LIMIT','Payload batch melebihi batas aman; tidak ada kelompok dipotong atau dikirim.')
            self.request('POST',document_id+':batchUpdate',json={'requests':requests_})

    @staticmethod
    def _write_requests(grid,writes):
        if grid.title.strip().casefold() == 'laporan deposit harian' or any(
                w.tab.strip().casefold() == 'laporan deposit harian' for w in writes):
            raise Issue('READ_ONLY_REPORT', 'Laporan deposit harian hanya boleh dibaca; semua penulisan ditolak.')
        if any(w.tab != grid.title for w in writes):
            raise Issue('WRITE_TAB_MISMATCH', 'Sheet rencana tulis berbeda dari grid yang diperiksa.')
        requests_ = []
        for w in writes:
            value = {} if w.value is None else {"numberValue": w.value} if isinstance(w.value, (float, int)) else {"stringValue": str(w.value)}
            cell = {"userEnteredValue": value}
            fields = "userEnteredValue"
            if w.note is not None:
                cell['note'] = w.note
                fields += ",note"
            requests_.append({"updateCells": {"range": {"sheetId": grid.sheet_id,
                "startRowIndex": w.row, "endRowIndex": w.row + 1, "startColumnIndex": w.col, "endColumnIndex": w.col + 1},
                "rows": [{"values": [cell]}], "fields": fields}})
        return requests_

