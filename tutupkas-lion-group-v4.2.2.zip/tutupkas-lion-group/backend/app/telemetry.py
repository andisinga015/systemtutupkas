"""Bounded attempt telemetry. Durations include local work and request pacing.

Exclusive coordinator time includes calculation, SQLite and scheduling overhead;
network stages are measured separately. No financial payload is recorded.
"""
from contextvars import ContextVar
from contextlib import contextmanager
from functools import wraps
import time

from .diagnostics import memory

_active=ContextVar('tutupkas_attempt_metrics',default=None)


class Capture:
    def __enter__(self):
        self.state={'stages_ms':{},'exclusive_ms':{},'api_reads':0,'api_writes':0,'api_retries':0,'response_bytes':0,'largest_response_bytes':0}
        self.stack=[];self.started=time.monotonic();self.token=_active.set(self);return self
    def __exit__(self,*args):
        self.result={**self.state,'duration_ms':round((time.monotonic()-self.started)*1000,3),**memory()}
        _active.reset(self.token)


@contextmanager
def stage(name):
    capture=_active.get()
    if capture is None:yield;return
    nested_same=any(frame[2]==name for frame in capture.stack)
    frame=[time.monotonic(),0.0,name];capture.stack.append(frame)
    try:yield
    finally:
        duration=(time.monotonic()-frame[0])*1000;capture.stack.pop()
        for key,value in [('stages_ms',duration),('exclusive_ms',max(0,duration-frame[1]))]:
            if key=='stages_ms' and nested_same:continue
            capture.state[key][name]=round(capture.state[key].get(name,0)+value,3)
        if capture.stack:capture.stack[-1][1]+=duration


def measured(name):
    def decorator(func):
        @wraps(func)
        def wrapped(*args,**kwargs):
            with stage(name):return func(*args,**kwargs)
        return wrapped
    return decorator


def api_attempt(method,attempt=0):
    capture=_active.get()
    if capture:
        capture.state['api_reads' if method=='GET' else 'api_writes']+=1
        if attempt:capture.state['api_retries']+=1


def response_bytes(size):
    capture=_active.get()
    if capture:
        capture.state['response_bytes']+=size
        capture.state['largest_response_bytes']=max(capture.state['largest_response_bytes'],size)
