"""One bounded pacing gate shared by API and coordinator processes."""
import fcntl
import json
from pathlib import Path
import time

from .config import settings


def acquire(cancel_check=lambda:None):
    interval=settings().google_min_interval
    if interval<=0:return
    parent=Path(settings().worker_lock).parent
    parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    path=parent/'google-quota.lock'
    boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    while True:
        cancel_check()
        with path.open('a+') as stream:
            path.chmod(0o600)
            fcntl.flock(stream,fcntl.LOCK_EX)
            stream.seek(0)
            try:state=json.loads(stream.read(1024))
            except (ValueError,OSError):state={}
            now=time.monotonic()
            previous=state.get('at',0) if state.get('boot')==boot else 0
            wait=max(0,interval-(now-previous))
            if wait==0:
                stream.seek(0);stream.truncate()
                stream.write(json.dumps({'boot':boot,'at':now}));stream.flush()
                return
        # Never hold the process lock during waiting or network IO.
        time.sleep(min(wait,.2))
