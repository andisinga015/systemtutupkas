"""Source continuity follows current Google sheet identity, never its title alone."""
from sqlalchemy import select

from .db import utcnow
from .engine.types import fingerprint
from .models import SourceBinding, SourceIdentity, SourceSheet


def refresh_bindings(db, doc, metadata, accept_recreated=False):
    current = list(db.scalars(select(SourceSheet).where(SourceSheet.source_revision_id == doc.active_revision_id)))
    properties = [s['properties'] for s in metadata.get('sheets', [])]
    names = {p['title']:p for p in properties}
    existing = {s.tab_name:s for s in current}
    for tab in current:
        tab.is_available = tab.tab_name in names
        if not tab.is_available:
            tab.is_active = False
    mismatched = []
    for name,p in names.items():
        tab = existing.get(name)
        if tab is None:
            tab = SourceSheet(source_document_id=doc.id,source_revision_id=doc.active_revision_id,tab_name=name,is_active=False)
            db.add(tab);db.flush()
        tab.last_seen_at = utcnow()
        binding = db.get(SourceBinding,tab.id)
        identity = db.scalar(select(SourceIdentity).where(SourceIdentity.source_revision_id==doc.active_revision_id,
                                                         SourceIdentity.google_sheet_id==p['sheetId']))
        if binding and db.get(SourceIdentity,binding.identity_id).google_sheet_id != p['sheetId']:
            tab.is_active = False
            binding.status = 'IDENTITY_CHANGED'
            if not accept_recreated:
                mismatched.append(name)
                continue
        if identity is None:
            lineage=fingerprint([doc.id,doc.spreadsheet_id,p['sheetId']])
            prior=db.scalar(select(SourceIdentity).where(SourceIdentity.lineage==lineage).order_by(SourceIdentity.id))
            identity = SourceIdentity(source_document_id=doc.id,source_revision_id=doc.active_revision_id,
                spreadsheet_id=doc.spreadsheet_id,google_sheet_id=p['sheetId'],names=list(dict.fromkeys([*(prior.names if prior else []),name])),
                lineage=lineage)
            db.add(identity);db.flush()
        elif name not in identity.names:
            identity.names = [*identity.names,name]
        if binding is None:
            db.add(SourceBinding(source_sheet_state_id=tab.id,identity_id=identity.id))
        else:
            binding.identity_id,binding.status,binding.verified_at = identity.id,'VERIFIED',utcnow()
    return mismatched


def configured_identities(db, revision):
    result = {}
    for tab,binding,identity in db.execute(select(SourceSheet,SourceBinding,SourceIdentity).join(
            SourceBinding,SourceBinding.source_sheet_state_id==SourceSheet.id).join(
            SourceIdentity,SourceIdentity.id==SourceBinding.identity_id).where(
            SourceSheet.source_revision_id==revision,SourceBinding.status=='VERIFIED')):
        result[tab.tab_name] = {'id':identity.id,'sheet_id':identity.google_sheet_id,
                               'lineage':identity.lineage,'names':identity.names}
    return result
