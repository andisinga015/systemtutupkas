"""Source calendar identity; never inferred from workbook contents or names."""
FIRST_HALF='FIRST_HALF'
SECOND_HALF='SECOND_HALF'
MONTHLY='MONTHLY'
UNASSIGNED='UNASSIGNED'
VALID_COMBINATIONS={('DEPO',FIRST_HALF),('DEPO',SECOND_HALF),('QRIS',MONTHLY),('DEPO',UNASSIGNED)}


def depo_period(selected):
    return FIRST_HALF if selected.day<=15 else SECOND_HALF


def source_label(kind,period):
    return {('DEPO',FIRST_HALF):'DOC A — DEPO/WD (tanggal 1–15)',
            ('DEPO',SECOND_HALF):'DOC B — DEPO/WD (tanggal 16–akhir bulan)',
            ('DEPO',UNASSIGNED):'DOC DEPO lama — belum ditetapkan',
            ('QRIS',MONTHLY):'DOC QRIS — bulanan'}.get((kind,period),'Dokumen sumber tidak valid')


def applies(kind,period,selected):
    return (kind,period) in (('DEPO',depo_period(selected)),('QRIS',MONTHLY))
