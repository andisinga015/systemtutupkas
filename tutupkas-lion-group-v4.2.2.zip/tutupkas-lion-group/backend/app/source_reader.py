"""Bounded source access; financial extraction remains in the V3 Day parser.

No cross-run row cache: Sheets has no content revision token. Global uniqueness
of separators must still be proved, so discovery visits narrow values-only
bands, discards them immediately, and retains only verified date markers.
"""
from collections.abc import Sequence
from datetime import datetime, timedelta
import logging
import time
import json

from .config import settings
from .diagnostics import memory
from .engine.parser import Day, LAYOUTS, eligible_description, parse_date
from .engine.types import Cell, Grid, Issue
from .sheets import google_cell

logger = logging.getLogger('tutupkas.worker')


class SparseRows(Sequence):
    """Absolute row indices without allocating historical empty row objects."""
    def __init__(self, size, rows):
        self.size, self.rows = size, rows

    def __len__(self):
        return self.size

    def __getitem__(self, index):
        if isinstance(index, slice):
            return [self[i] for i in range(*index.indices(self.size))]
        if index < 0:
            index += self.size
        if not 0 <= index < self.size:
            raise IndexError(index)
        return self.rows.get(index, ())


class SourceReader:
    def __init__(self, client, document, title, selected, kind):
        self.client, self.document, self.title = client, document, title
        self.selected, self.kind = selected, kind
        self.cfg = settings()
        self.chunk = self.cfg.source_chunk_rows
        self.scan_width = self.cfg.source_scan_columns
        self.target_dates = {selected,selected+timedelta(days=1)}
        serial = (selected-datetime(1899,12,30).date()).days
        self.target_serials = {serial,serial+1}
        if not 1 <= self.chunk <= 250 or not 1 <= self.scan_width <= 32:
            raise Issue('READ_LIMIT_INVALID', 'Ukuran chunk sumber harus 1–250 baris dan 1–32 kolom.')

    def values(self, first, last, left, right, columns=None):
        columns = list(range(left,right+1)) if columns is None else columns
        ranges = [self.client.a1(self.title, first, last, c, c) for c in columns]
        bands = self.client.values(self.document, ranges)
        if len(bands) != len(ranges):
            raise Issue('SOURCE_READ_FAILED', 'Jumlah rentang respons sumber tidak sesuai permintaan.')
        for c, band in zip(columns, bands):
            values = band.get('values', [])
            if len(values) > last-first+1 or any(len(row)>1 for row in values):
                raise Issue('SOURCE_READ_FAILED', 'Respons sumber berada di luar rentang yang diminta.')
            for offset, row in enumerate(values):
                if row:
                    yield first+offset, c, row[0]

    def formatted(self, positions, fields, with_merges=False):
        # Single-cell ranges: never request a whole formatted transaction row.
        for i in range(0, len(positions), 32):
            chunk = positions[i:i+32]
            allowed = set(chunk)
            ranges = [self.client.a1(self.title,r,r,c,c) for r,c in chunk]
            raw = self.client.cells(self.document, ranges, fields, with_merges)
            cells, merges = {}, []
            for sheet in raw.get('sheets', []):
                merges = sheet.get('merges', [])
                for band in sheet.get('data', []):
                    r, c = band.get('startRow',0), band.get('startColumn',0)
                    for dr, row in enumerate(band.get('rowData', [])):
                        for dc, value in enumerate(row.get('values', [])):
                            if (r+dr,c+dc) not in allowed:
                                raise Issue('SOURCE_READ_FAILED', 'Metadata sumber melampaui rentang yang diminta.')
                            cells[r+dr,c+dc] = google_cell(value)
            del raw
            yield chunk, cells, merges

    @staticmethod
    def candidate(value):
        if isinstance(value, (int,float)):
            # All representable Sheets date serials; money is never classified
            # as a date until its actual numberFormat has been checked.
            return -693593 <= value < 2958466
        return parse_date(Cell(value)) is not None

    def discover(self, height, width, first=0, all_numeric=False):
        found = {}
        fields = 'effectiveValue,formattedValue,effectiveFormat(backgroundColor,backgroundColorStyle,numberFormat(type))'
        for r in range(first,height,self.chunk):
            for c in range(0,width,self.scan_width):
                candidates = [(rr,cc) for rr,cc,v in self.values(r,min(height,r+self.chunk)-1,c,min(width,c+self.scan_width)-1)
                              if self.candidate(v) and (all_numeric or
                                  (int(v) in self.target_serials if isinstance(v,(int,float))
                                   else parse_date(Cell(v)) in self.target_dates))]
                for positions, cells, merges in self.formatted(candidates,fields,True):
                    anchors = {(m['startRowIndex'],m['startColumnIndex']) for m in merges
                               if m['endColumnIndex']-m['startColumnIndex'] >= 3}
                    for pos in positions:
                        cell = cells.get(pos,Cell())
                        d = parse_date(cell)
                        if d and (pos in anchors or cell.color is not None and max(cell.color)<.15):
                            # Only two duplicates are needed to reject ambiguity.
                            if len(found.setdefault(d,{})) < 2 or pos[0] in found[d]:
                                found[d][pos[0]] = (pos[1],cell,pos in anchors)
                            if len(found) > 400:
                                raise Issue('SOURCE_RESOURCE_LIMIT','Pemisah tanggal sumber melebihi batas baca aman.')
        return found

    def read(self):
        started = time.monotonic()
        p = self.client.sheet_properties(self.document,self.title)
        shape = p.get('gridProperties',{})
        height, width = shape.get('rowCount',0),shape.get('columnCount',0)
        if self.kind not in LAYOUTS or width <= LAYOUTS[self.kind]['balance']:
            raise Issue('SOURCE_LAYOUT_INVALID','Jumlah kolom sumber tidak sesuai tata letak DOC DEPO/QRIS yang dikonfirmasi.')
        if height*width > self.cfg.max_source_scan_cells:
            raise Issue('SOURCE_RESOURCE_LIMIT','Area penelusuran tanggal sumber melebihi batas baca aman.',
                        'Periksa baris/kolom kosong berlebih pada sumber; transaksi tidak dilewati.')
        found = self.discover(height,width)
        following = self.selected + timedelta(days=1)
        for d in (self.selected,following):
            if len(found.get(d,{})) != 1:
                raise Issue('DATE_NOT_FOUND',f'Pemisah tanggal {d.isoformat()} tidak ditemukan secara unik.',
                            'Pastikan pemisah tanggal terpilih dan hari berikutnya tersedia di sumber.',expected_date=str(d))
        start, stop = next(iter(found[self.selected])),next(iter(found[following]))
        if stop <= start or any(start<r<stop for d,rr in found.items() if d not in (self.selected,following) for r in rr):
            raise Issue('AMBIGUOUS_DATE','Urutan pemisah tanggal tidak konsisten.')
        last_col = LAYOUTS[self.kind]['balance']
        if (stop-start+1)*max(last_col+1,width) > self.cfg.max_source_day_cells:
            raise Issue('SOURCE_RESOURCE_LIMIT','Data satu tanggal melebihi batas konteks memori aman.',
                        'Tinjau sumber dan batas TK_MAX_SOURCE_DAY_CELLS; tidak ada transaksi yang dipotong.')
        # Numeric dates outside this interval cannot affect Day.resolve. Check
        # all numeric candidates inside it, including dates on unusual columns.
        within = self.discover(stop, width, start+1, all_numeric=True)
        if any(d not in (self.selected,following) for d in within):
            raise Issue('AMBIGUOUS_DATE','Urutan pemisah tanggal tidak konsisten.')
        rows = {}
        def row_at(r):
            if r not in rows:
                rows[r] = [Cell() for _ in range(last_col+1)]
            return rows[r]
        # B..L / B..K are exactly the payload and fixed totals required by V3.
        # A is not transaction payload. CEK SALDO is omitted for DOC DEPO.
        columns = sorted({1,2,3,4,5,*LAYOUTS[self.kind].values()})
        for first in range(start,stop,self.chunk):
            last = min(stop,first+self.chunk)-1
            for r,cc,v in self.values(first,last,0,0,columns):
                row_at(r)[cc] = Cell(v)
        row_at(stop-1)  # Enforce the confirmed width even for a blank day.
        merges = []
        positions = []
        for d,r in ((self.selected,start),(following,stop)):
            c,cell,merged = found[d][r]
            while len(row_at(r)) <= c:
                rows[r].append(Cell())
            rows[r][c] = cell
            positions.append((r,c))
            if merged:
                merges.append({'startRowIndex':r,'endRowIndex':r+1,'startColumnIndex':c,'endColumnIndex':c+3})
        grid = Grid(self.title,p['sheetId'],SparseRows(stop+1,rows),merges)
        day = Day.resolve(grid,self.selected,self.kind)
        if not day.transaction_rows and all(grid.cell(r,last_col).value in (None,'') for r in range(day.end,day.start-1,-1)):
            for end in range(start-1,-1,-self.chunk):
                begin = max(0,end-self.chunk+1)
                values = list(self.values(begin,end,last_col,last_col))
                previous = next(((r,v) for r,c,v in reversed(values) if v not in (None,'')),None)
                if previous:
                    r,v = previous
                    row_at(r)[last_col] = Cell(v)
                    break
        transfers = [(r,3) for r in day.transaction_rows if eligible_description(str(grid.cell(r,3).value or ''))]
        fields = 'effectiveFormat(backgroundColor,backgroundColorStyle)'
        for positions_,cells,_ in self.formatted(transfers,fields):
            for r,c in positions_:
                rows[r][c].color = cells.get((r,c),Cell()).color
        # Validate the anchors again after chunk reads: no stale row cache is
        # authoritative, and inserted/moved date boundaries fail closed.
        fields = 'effectiveValue,formattedValue,effectiveFormat(backgroundColor,backgroundColorStyle,numberFormat(type))'
        for positions_,cells,actual_merges in self.formatted(positions,fields,True):
            anchors = {(m['startRowIndex'],m['startColumnIndex']) for m in actual_merges
                       if m['endColumnIndex']-m['startColumnIndex'] >= 3}
            for r,c in positions_:
                old,now = grid.cell(r,c),cells.get((r,c),Cell())
                if parse_date(old) != parse_date(now) or not ((r,c) in anchors or now.color is not None and max(now.color)<.15):
                    raise Issue('SOURCE_CHANGED','Pemisah tanggal sumber berubah selama pembacaan. Ulangi pratinjau.')
        logger.info(json.dumps({'event':'source_read','source_tab':self.title,'selected_date':str(self.selected),
            **getattr(self.client,'diagnostic_context',{}),
            'duration_ms':round((time.monotonic()-started)*1000),'retained_rows':len(rows), **memory()}))
        return day
