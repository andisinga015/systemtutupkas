from ..telemetry import measured,stage
from sqlalchemy import select
from dataclasses import dataclass

from ..destination_reader import close_view, formula_signature
from ..db import utcnow
from ..models import WriteLedger, TransferOwnership
from .parser import parse_date
from .types import Grid, Issue, Write, fingerprint, norm


def structural(grid: Grid):
    if hasattr(grid,'structural_signature'):
        return grid.structural_signature
    labels = []
    for r, row in enumerate(grid.rows):
        for c, cell in enumerate(row):
            if r < 2 or parse_date(cell) or norm(cell.value) in ('BCA', 'MANDIRI', 'BRI', 'BNI', 'TOTAL'):
                labels.append((r, c, cell.value, cell.formula))
    return fingerprint([labels, grid.merges])


def formula_map(grid: Grid):
    if hasattr(grid,'formula_signature'):
        return grid.formula_signature
    return formula_signature(grid.iter_cells())


def owner_key(run, item):
    # Stable across retries and later explicit runs for the same date/source revision.
    from ..source_authorization import document_for
    doc = document_for(run,item) or {}
    identity=doc.get('identities',{}).get(item.source_tab_name)
    if identity:
        return fingerprint(['source-lineage',run.website_id,str(run.selected_date),identity['lineage'],item.metric_type])
    return fingerprint([run.website_id, str(run.selected_date), item.source_document_id,
                        doc.get('revision'), item.source_tab_name, item.metric_type])


def get_ledger(db, run, write):
    dest = run.config_snapshot['destination']
    return db.scalar(select(WriteLedger).where(WriteLedger.destination_document_id == dest['id'],
        WriteLedger.destination_revision == dest['revision'], WriteLedger.destination_tab == write.tab,
        WriteLedger.target_range == write.address))


def check_write(db, run, item, grid, write, approval=None):
    cell = grid.cell(write.row, write.col)
    merged = (grid.merges.at(write.row,write.col) is not None) if hasattr(grid.merges,'at') else any(
        m['startRowIndex'] <= write.row < m['endRowIndex'] and
        m['startColumnIndex'] <= write.col < m['endColumnIndex'] for m in grid.merges)
    if merged:
        raise Issue('MERGED_CELL_CONFLICT', f'Sel {write.tab}!{write.address} termasuk area gabungan yang dilindungi.')
    if cell.formula is not None:
        raise Issue('FORMULA_CONFLICT', f'Sel {write.tab}!{write.address} berisi formula dan dilindungi.')
    authorized=False
    if approval is not None:
        from dataclasses import asdict
        if approval.run_item_id!=item.id or approval.mapping_id!=run.config_snapshot.get('mapping_id') or approval.state!='WRITE_PENDING':
            raise Issue('INVALID_CONFLICT_APPROVAL','Persetujuan konflik tidak sesuai item/mapping.')
        observed=next((v for v in approval.observed if (v['tab'],v['row'],v['col'])==(write.tab,write.row,write.col)),None)
        proposed=next((v for v in approval.writes if (v['tab'],v['row'],v['col'])==(write.tab,write.row,write.col)),None)
        if not observed or not proposed or proposed!=asdict(write) or cell.snapshot!={k:observed[k] for k in ('value','formula','note')}:
            raise Issue('STALE_CONFLICT_APPROVAL','Tujuan/rencana berubah setelah persetujuan; baca ulang konflik.')
        authorized=True
    ledger = get_ledger(db, run, write)
    owns_source=bool(ledger and ledger.owner_key==owner_key(run,item))
    if ledger:
        if ledger.owner_key != owner_key(run, item):
            from ..models import Run, RunItem
            previous_item = db.get(RunItem, ledger.run_item_id)
            previous_run = db.get(Run, previous_item.run_id) if previous_item else None
            authorized = (run.config_snapshot.get('authorized_previous_run_id') == (previous_run.id if previous_run else None)
                and previous_run is not None and previous_run.website_id == run.website_id
                and previous_run.selected_date == run.selected_date
                and previous_item.source_document_id == item.source_document_id
                and previous_item.source_tab_name == item.source_tab_name and previous_item.metric_type == item.metric_type)
            from ..models import LegacySourceLink,SourceIdentity
            from ..source_authorization import document_for
            current_doc=document_for(run,item) or {}
            prior_doc=document_for(previous_run,previous_item) if previous_run and previous_item else {}
            current_identity=current_doc.get('identities',{}).get(item.source_tab_name)
            prior_identity=(prior_doc or {}).get('identities',{}).get(previous_item.source_tab_name) if previous_item else None
            same_source=(previous_item.source_document_id==item.source_document_id and
                (previous_item.source_tab_name==item.source_tab_name or current_identity and prior_identity and current_identity['lineage']==prior_identity['lineage'])) if previous_item else False
            same_logical_group=bool(previous_run and previous_run.website_id==run.website_id and previous_run.selected_date==run.selected_date
                and previous_item.metric_type==item.metric_type and same_source)
            link=db.get(LegacySourceLink,previous_item.id) if previous_item else None
            identity=current_doc.get('identities',{}).get(item.source_tab_name)
            linked_identity=db.get(SourceIdentity,link.identity_id) if link else None
            linked=bool(linked_identity and identity and linked_identity.lineage==identity['lineage'] and same_logical_group)
            owns_source=bool(linked or authorized or approval is not None and same_logical_group)
            if not authorized and not linked and not (approval is not None and same_logical_group):
                raise Issue('DUPLICATE_DESTINATION', f'Sel {write.tab}!{write.address} sudah dimiliki item sumber lain.')
        allowed = [ledger.written_value]
        if ledger.verification_status=='RETAINED':
            from ..conflicts import retained_snapshot
            kept=retained_snapshot(db,ledger)
            if kept is not None:allowed.append(kept)
        if ledger.verification_status == 'PREPARED':
            allowed.append(ledger.previous_managed_value)
        if cell.snapshot not in allowed and approval is None:
            raise Issue('EXISTING_VALUE_CONFLICT', f'Sel {write.tab}!{write.address} telah diubah di luar robot.',
                        'Tinjau perubahan manual. Robot tidak akan menimpanya secara otomatis.')
        # First reconcile an uncertain old write before changing its desired output.
        if ledger.verification_status == 'PREPARED' and write.proposed != ledger.written_value and approval is None:
            raise Issue('UNCERTAIN_WRITE', 'Nilai sumber berubah saat hasil tulis sebelumnya belum pasti.',
                        'Pulihkan hasil sumber awal dan Crawl Ulang untuk rekonsiliasi sebelum melakukan koreksi baru.')
        desired={**write.proposed,'note':cell.note if write.note is None else write.note}
        if (run.config_snapshot.get('mapping_id') and ledger.verification_status in ('VERIFIED','RETAINED') and
            not cell.empty and desired!=cell.snapshot and approval is None):
            raise Issue('EXISTING_VALUE_CONFLICT','Data tujuan lama berbeda dari hasil sumber baru; diperlukan keputusan administrator.')
    elif not cell.empty and approval is None:
        raise Issue('EXISTING_VALUE_CONFLICT', f'Sel {write.tab}!{write.address} berisi data atau Note yang bukan milik robot.',
                    'Gunakan salinan kerja dan pastikan sel output tersedia; formula dan entri manual tetap dilindungi.')
    if approval is not None:
        if write.note is not None and write.note!=cell.note and cell.note and (not ledger or fingerprint(cell.note)!=ledger.note_fingerprint):
            raise Issue('NOTE_CONFLICT','Note yang bukan milik robot tetap dilindungi meskipun nilai baru disetujui.')
        if write.value is None and item.metric_type=='qris_fee' and not owns_source:
            raise Issue('FEE_CLEAR_NOT_OWNED','Penghapusan fee hanya diizinkan untuk sel fee yang terbukti milik robot.')
    if write.note is None:
        # Never clear unrelated Notes through a value-only update.
        write.note = cell.note
    return ledger


def validate_group(grid,writes):
    import json
    from dataclasses import asdict
    from ..config import settings
    if len({(w.tab,w.row,w.col) for w in writes})!=len(writes) or any(w.tab!=grid.title for w in writes):
        raise Issue('WRITE_GROUP_INVALID','Kelompok tulis harus unik dan berada pada satu tab.')
    if len(writes)>settings().grid_chunk_cells or len(json.dumps([asdict(w) for w in writes],ensure_ascii=False,default=str).encode())>settings().max_api_response_bytes:
        raise Issue('WRITE_GROUP_RESOURCE_LIMIT','Kelompok finansial melampaui batas atomik aman; tidak ada bagian yang dipotong.')
    if grid.title.strip().casefold() == 'laporan deposit harian' or any(
            w.tab.strip().casefold() == 'laporan deposit harian' for w in writes):
        raise Issue('READ_ONLY_REPORT', 'Laporan deposit harian hanya boleh dibaca; penulisan ditolak sebelum API.')


@dataclass
class PendingSubmission:
    item: object
    grid: object
    fresh: object
    writes: list
    formulas: object
    plan: list


def execute(db, client, run, item, grid, writes, cancel_check=lambda:None, on_phase=lambda value:None, approval=None):
    cancel_check()
    on_phase("CHECKING_DESTINATION")
    validate_group(grid,writes)
    dest = run.config_snapshot['destination']
    fresh = grid.refresh() if hasattr(grid,'refresh') else client.grid(dest['spreadsheet_id'], grid.title)
    try:
        if hasattr(fresh,'prefetch'):
            fresh.prefetch([(w.row,w.col) for w in writes])
        return _execute_checked(db,client,run,item,grid,fresh,writes,cancel_check,on_phase,approval)
    finally:
        close_view(fresh)


def inspect_preview(db,run,item,grid,fresh,writes):
    if not run.preview:raise Issue('PREVIEW_REQUIRED','Pembacaan gabungan hanya tersedia untuk Pratinjau.')
    if structural(fresh)!=structural(grid):raise Issue('DESTINATION_CHANGED','Struktur tujuan berubah selama Pratinjau.')
    plan=[]
    for w in writes:
        check_write(db,run,item,fresh,w)
        plan.append({'tab':w.tab,'cell':w.address,'existing':fresh.cell(w.row,w.col).snapshot,'proposed':w.proposed,
                     'bank':w.bank,'source_transaction':w.transaction})
    return {'plan':plan,'formula_cells_checked':len(formula_map(fresh)),'verified':False}


def _execute_checked(db,client,run,item,grid,fresh,writes,cancel_check,on_phase,approval=None,defer_submit=False):
    dest = run.config_snapshot['destination']
    if structural(fresh) != structural(grid):
        raise Issue('DESTINATION_CHANGED', 'Header atau batas tanggal tujuan berubah selama penyusunan rencana. Ulangi pratinjau.')
    formulas = formula_map(fresh)
    plan = []
    for w in writes:
        ledger = check_write(db, run, item, fresh, w, approval)
        plan.append({"tab": w.tab, "cell": w.address, "existing": fresh.cell(w.row, w.col).snapshot,
                     "proposed": w.proposed, "bank": w.bank, "source_transaction": w.transaction})
    cancel_check()
    if run.preview:
        return {"plan": plan, "formula_cells_checked": len(formulas), "verified": False}
    if run.config_snapshot.get('mapping_id') and item.source_document_id is not None:
        from ..source_authorization import authorized_source_is_current
        if not authorized_source_is_current(db,run,item):
            raise Issue('SOURCE_REVISION_CHANGED','Konfigurasi sumber berubah setelah otorisasi item. Retry akan meminta data mentah pada revisi baru secara eksplisit.')
    transfer_changes=[]
    actor_id=run.config_snapshot.get('item_source_authorizations',{}).get(str(item.id),{}).get('requested_by',run.started_by)
    if approval is not None:
        from ..models import ConflictDecision
        decision=db.scalar(select(ConflictDecision).where(ConflictDecision.conflict_id==approval.id).order_by(ConflictDecision.id.desc()))
        if decision:actor_id=decision.actor_id
    if item.metric_type=='transfers':
        from ..models import MappedResult
        mapped=db.scalar(select(MappedResult).where(MappedResult.run_item_id==item.id).order_by(MappedResult.id.desc()))
        transfer_changes=(approval.provenance if approval is not None else mapped.provenance if mapped else {}).get('transfer_changes',[])
        from ..transfer_intents import prepare,recoverable
        if transfer_changes and approval is None and not recoverable(db,run,item,writes,transfer_changes):
            raise Issue('TRANSFER_IDENTITY_CHANGED','Perubahan kiriman memerlukan keputusan administrator untuk seluruh kelompok.')
    def already_present(w):
        ledger=get_ledger(db,run,w)
        if not ledger or fresh.cell(w.row,w.col).snapshot!=w.proposed:return False
        if ledger.verification_status in ('VERIFIED','PREPARED'):return ledger.written_value==w.proposed
        if ledger.verification_status=='RETAINED':
            from ..conflicts import retained_snapshot
            return retained_snapshot(db,ledger)==w.proposed
        return False
    if writes and all(already_present(w) for w in writes):
        if item.metric_type=='transfers':
            from ..transfer_intents import verified
            prepare(db,run,item,writes,transfer_changes,actor_id);verified(db,run,item,writes)
        retained=any(get_ledger(db,run,w).verification_status=='RETAINED' for w in writes)
        for w in writes:
            ledger=get_ledger(db,run,w)
            if ledger.verification_status!='RETAINED':ledger.verification_status='VERIFIED'
        db.commit()
        return {'plan':plan,'formula_cells_checked':len(formulas),'verified':True,'idempotent':True,'retained_existing':retained}
    if run.config_snapshot.get('mapping_id'):
        from ..destination_registry import assert_current
        assert_current(db,run)
    # Persist intent before contacting Google: restart recovery can recognize
    # both pre-write and intended post-write values, never append blindly.
    for w in writes:
        ledger = get_ledger(db, run, w)
        if not ledger:
            ledger = WriteLedger(run_item_id=item.id, destination_document_id=dest['id'], destination_revision=dest['revision'],
                destination_tab=w.tab, target_range=w.address, output_type=item.metric_type,
                owner_key=owner_key(run, item), source_fingerprint=fingerprint([item.result, w.value, w.transaction]),
                previous_managed_value=fresh.cell(w.row, w.col).snapshot, written_value=w.proposed,
                note_fingerprint=fingerprint(w.note), verification_status='PREPARED')
            db.add(ledger)
        else:
            ledger.previous_managed_value = fresh.cell(w.row, w.col).snapshot
            ledger.written_value, ledger.run_item_id = w.proposed, item.id
            ledger.verification_status, ledger.last_written_at = 'PREPARED', utcnow()
            ledger.note_fingerprint = fingerprint(w.note)
            ledger.owner_key = owner_key(run, item)
        if w.transaction and w.bank and not run.config_snapshot.get('mapping_id'):
            owned = db.scalar(select(TransferOwnership).where(TransferOwnership.destination_document_id == dest['id'],
                  TransferOwnership.destination_revision == dest['revision'],
                  TransferOwnership.source_transaction_fingerprint == w.transaction))
            if not owned and w.previous_transaction and run.config_snapshot.get('authorized_previous_run_id'):
                owned = db.scalar(select(TransferOwnership).where(TransferOwnership.destination_document_id == dest['id'],
                    TransferOwnership.destination_revision == dest['revision'],
                    TransferOwnership.source_transaction_fingerprint == w.previous_transaction))
                if owned:
                    owned.source_transaction_fingerprint, owned.run_item_id = w.transaction, item.id
            if not owned:
                db.add(TransferOwnership(run_item_id=item.id, source_transaction_fingerprint=w.transaction,
                     destination_document_id=dest['id'], destination_revision=dest['revision'], destination_tab=w.tab,
                     destination_bank=w.bank, description_cell=w.address,
                     amount_cell=next(x.address for x in writes if x.row == w.row and x.col == w.col + 1),
                     note_cell=w.address))
    if item.metric_type=='transfers' and run.config_snapshot.get('mapping_id'):
        from ..transfer_intents import prepare
        prepare(db,run,item,writes,transfer_changes,actor_id)
    db.commit()
    # Google batchUpdate is atomic within this item. Retrying writes sets the same
    # exact cells; no append, insertion, formatting or formula updates are used.
    cancel_check()
    if run.config_snapshot.get('mapping_id'):
        assert_current(db,run)
    if defer_submit:
        return PendingSubmission(item,grid,fresh,writes,formulas,plan)
    previous_check=getattr(client,'cancel_check',None)
    if previous_check is not None:
        client.cancel_check=lambda:None
    try:
        return _submit_and_verify(db,client,run,grid,fresh,writes,formulas,plan,on_phase)
    finally:
        if previous_check is not None:
            client.cancel_check=previous_check


@measured('write_and_readback')
def _submit_and_verify(db,client,run,grid,fresh,writes,formulas,plan,on_phase):
    dest=run.config_snapshot['destination']
    on_phase('WRITING')
    try:
        with stage('actual_write'):
            client.write(dest['spreadsheet_id'], fresh, writes)
    except Issue as error:
        if error.code not in ('GOOGLE_WRITE_UNCERTAIN','GOOGLE_INVALID_RESPONSE','GOOGLE_TIMEOUT'):raise
        # No second POST: inspect the complete intended group after uncertainty.
    except ConnectionError:
        pass
    # An already submitted write must be verified even if Stop arrives now.
    on_phase('VERIFYING')
    return _verify_submission(db,client,run,grid,fresh,writes,formulas,plan)


@measured('readback_verification')
def _verify_submission(db,client,run,grid,fresh,writes,formulas,plan):
    dest=run.config_snapshot['destination']
    verified = grid.after_write(writes,fresh) if hasattr(grid,'after_write') else grid.refresh() if hasattr(grid,'refresh') else client.grid(dest['spreadsheet_id'], grid.title)
    try:
        if hasattr(verified,'prefetch'):
            verified.prefetch([(w.row,w.col) for w in writes])
        if formula_map(verified) != formulas:
            raise Issue('FORMULA_CHANGED', 'Formula tujuan berubah saat verifikasi. Periksa spreadsheet sebelum mencoba lagi.')
        for w in writes:
            if verified.cell(w.row, w.col).snapshot != w.proposed:
                raise Issue('READBACK_FAILED', f'Pembacaan ulang {w.tab}!{w.address} tidak sesuai rencana.',
                            'Periksa izin dan perubahan manual. Crawl Ulang akan merekonsiliasi sel milik robot.')
        for w in writes:
            ledger = get_ledger(db, run, w)
            ledger.verification_status, ledger.last_written_at = 'VERIFIED', utcnow()
        if hasattr(grid,'accept_verified'):grid.accept_verified(writes,verified)
        from ..models import RunItem
        item=db.get(RunItem,get_ledger(db,run,writes[0]).run_item_id) if writes else None
        if item and item.metric_type=='transfers':
            from ..transfer_intents import verified as verify_transfers
            verify_transfers(db,run,item,writes)
    finally:
        close_view(verified)
    db.commit()
    return {"plan": plan, "formula_cells_checked": len(formulas), "verified": True}

