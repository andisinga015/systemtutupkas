"""Bounded submission windows sharing the existing V4.2 safety checks.

No global invariant is discarded: one preflight and one post-write global proof
per affected tab replace repeated per-item passes. Mutable target observations
exist only for this window, and every logical group is verified independently.
"""
from collections import defaultdict
from contextlib import ExitStack
from dataclasses import asdict
import json
import logging
import time

from sqlalchemy import select

from ..config import settings
from ..destination_reader import close_view
from ..destination_registry import assert_current,DestinationProof
from ..source_index import revision
from ..job_control import JobCanceled,check_cancel,phase,log_phase
from ..models import MappedResult,SourceSnapshot,RunItem
from ..source_authorization import document_for,authorized_source_is_current
from ..telemetry import stage
from ..transfer_intents import allocate,recoverable
from .types import Issue,Write,fingerprint
from .writer import (_execute_checked,_verify_submission,PendingSubmission,validate_group)
logger=logging.getLogger('tutupkas.worker')


class ObservedTargets:
    """An explicit, bounded, single-window GET snapshot, never a value cache."""
    def __init__(self,view,positions,budget,initial=None,use_cache=False):
        self.view,self.cells,self.allowed,self.order,self.budget=view,{},set(positions),list(positions),budget
        wanted=self.order if initial is None else list(initial)
        if use_cache:
            self.cells.update((p,view.cache[p]) for p in wanted if p in view.cache)
            budget[0]+=sum(self._size(cell) for cell in self.cells.values())
            if budget[0]>64*1048576:
                raise Issue('WRITE_BATCH_RESOURCE_LIMIT','Observasi batch tujuan melebihi batas memori aman; kelompok tidak dipotong.')
        self._load([p for p in wanted if p not in self.cells])
    @staticmethod
    def _size(cell):return len(json.dumps(cell.snapshot,ensure_ascii=False,default=str).encode())+512
    def _load(self,positions):
        if not set(positions)<=self.allowed:raise Issue('WRITE_BATCH_UNOBSERVED_CELL','Sel berada di luar domain registry batch.')
        for first in range(0,len(positions),32):
            cells=self.view.read_cells(positions[first:first+32])
            for pos,cell in cells.items():
                self.budget[0]+=self._size(cell)
                if self.budget[0]>64*1048576:
                    raise Issue('WRITE_BATCH_RESOURCE_LIMIT','Observasi batch tujuan melebihi batas memori aman; kelompok tidak dipotong.')
                self.cells[pos]=cell
    def __getattr__(self,name):return getattr(self.view,name)
    def cell(self,row,col):
        if (row,col) not in self.cells:
            if (row,col) not in self.allowed:raise Issue('WRITE_BATCH_UNOBSERVED_CELL','Target tidak termasuk observasi eksplisit batch.')
            index=self.order.index((row,col))
            self._load([p for p in self.order[index:index+32] if p not in self.cells])
        return self.cells[row,col]
    def prefetch(self,positions):
        if not set(positions)<=self.cells.keys():raise Issue('WRITE_BATCH_UNOBSERVED_CELL','Verifikasi meminta sel di luar observasi batch.')
    def close(self):pass  # The owner closes the underlying view once per window.


class AuditedGrid:
    """Use the shared global proof without repeating it for each item."""
    def __init__(self,original,verified):self.original,self.verified=original,verified
    def __getattr__(self,name):return getattr(self.original,name)
    def after_write(self,*args):return self.verified
    def accept_verified(self,*args):pass  # Shared structure accepted atomically below.


def validate_mapped(db,run,item,retry_id=None):
    stored=db.scalar(select(MappedResult).where(MappedResult.run_item_id==item.id,
        MappedResult.retry_request_id==retry_id).order_by(MappedResult.id.desc()).execution_options(populate_existing=True))
    if not stored or stored.mapping_id!=run.config_snapshot.get('mapping_id') or fingerprint([stored.writes,stored.provenance])!=stored.checksum:
        raise Issue('MAPPED_RESULT_CORRUPT','Hasil mapping lengkap/integritasnya tidak sesuai. Tidak ada tulisan dikirim.')
    if stored.snapshot_id:
        snapshot=db.get(SourceSnapshot,stored.snapshot_id,populate_existing=True)
        if not snapshot or snapshot.state not in ('SNAPSHOT_READY','MAPPED') or fingerprint(snapshot.payload)!=snapshot.checksum:
            raise Issue('SNAPSHOT_CORRUPT','Snapshot belum lengkap atau integritasnya berubah. Tidak ada tulisan dikirim.')
    if item.metric_type=='expense_total':
        inputs=list(db.scalars(select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type=='expense_input').execution_options(populate_existing=True)))
        if (not inputs or any(i.status!='SUCCESS' for i in inputs) or len(stored.writes)!=1 or
            stored.writes[0]['value']!=abs(sum(i.result['signed_value'] for i in inputs))):
            raise Issue('DEPENDENCY_STALE','Input BIAYA berubah setelah planning; total memerlukan retry eksplisit, tanpa menulis rencana lama.')
        for dependency in inputs:
            snapshot_id=dependency.result.get('snapshot_id')
            snapshot=db.get(SourceSnapshot,snapshot_id,populate_existing=True) if snapshot_id else None
            if snapshot_id and (not snapshot or snapshot.state not in ('SNAPSHOT_READY','MAPPED') or fingerprint(snapshot.payload)!=snapshot.checksum):
                raise Issue('SNAPSHOT_CORRUPT','Snapshot input BIAYA tidak lengkap atau integritasnya berubah.')
    return stored


def _positions(db,run,intents):
    found=defaultdict(dict)
    for intent in intents:
        found[intent['grid'].title].update(((w.row,w.col),None) for w in intent['writes'])
    if any(i['item'].metric_type=='transfers' for i in intents):
        from ..destination_registry import target
        entry=target(db,run,'KET PENGIRIMAN','SLOTS')
        for slots in entry.coordinates['slots'].values():
            for r,dc,ac in slots:found['KET PENGIRIMAN'].update({(r,dc):None,(r,ac):None})
    if sum(map(len,found.values()))>settings().grid_chunk_cells:
        raise Issue('WRITE_BATCH_RESOURCE_LIMIT','Observasi slot/target batch melebihi batas jumlah sel aman.')
    return {title:list(values) for title,values in found.items()}


def submit_window(db,run,client,intents,on_outcome,on_phase,retry_id=None):
    """Persist all disjoint intents before one POST; no retry of that POST."""
    cancel=lambda:check_cancel(db,run=run)
    client.diagnostic_context.update({'module':'batch','batch_item_ids':[i['item'].id for i in intents]})
    on_phase('CHECKING_DESTINATION')
    with ExitStack() as cleanup:
        budget=[0]
        positions=_positions(db,run,intents)
        grids={i['grid'].title:i['grid'] for i in intents}
        fresh,failures={},{}
        for title,grid in grids.items():
            cancel()
            try:
                # Registry refresh retains V4.2's complete global invariant
                # proof when a version token cannot prove the file unchanged.
                initial=list(dict.fromkeys((w.row,w.col) for i in intents if i['grid'].title==title for w in i['writes']))
                view=grid.refresh(positions=initial[:128]);cleanup.callback(close_view,view)
                fresh[title]=ObservedTargets(view,positions[title],budget,initial=initial,use_cache=True)
            except Issue as problem:failures[title]=problem
        reservations=set();eligible=[]
        for intent in intents:
            cancel();item,grid=intent['item'],intent['grid']
            try:
                if grid.title in failures:raise failures[grid.title]
                stored=validate_mapped(db,run,item,retry_id)
                intent['writes']=[Write(**raw) for raw in stored.writes]
                if item.metric_type=='transfers':
                    from ..destination_registry import target
                    entry=target(db,run,'KET PENGIRIMAN','SLOTS')
                    writes,changes,changed=allocate(db,run,item,document_for(run,item),fresh[grid.title],entry.coordinates['slots'],
                        stored.provenance.get('transfer_intents',[]),reservations)
                    intent['writes']=writes;intent['context']={**intent['context'],'transfer_changes':changes}
                    raw=[asdict(w) for w in writes]
                    db.add(MappedResult(run_item_id=item.id,snapshot_id=stored.snapshot_id,retry_request_id=stored.retry_request_id,
                        mapping_id=stored.mapping_id,writes=raw,provenance=intent['context'],checksum=fingerprint([raw,intent['context']])))
                    db.commit()
                    if changed and not recoverable(db,run,item,writes,changes):
                        raise Issue('TRANSFER_IDENTITY_CHANGED','Kiriman berubah; tinjau seluruh kelompok sebelum koreksi.')
                validate_group(grid,intent['writes']);eligible.append(intent)
            except Issue as problem:on_outcome(intent,problem)
        owners=defaultdict(set)
        for intent in eligible:
            for w in intent['writes']:owners[w.tab,w.row,w.col].add(intent['item'].id)
        duplicates=set().union(*(ids for ids in owners.values() if len(ids)>1)) if owners else set()
        pending=[]
        for intent in eligible:
            cancel();item,grid=intent['item'],intent['grid']
            try:
                if item.id in duplicates:raise Issue('DUPLICATE_DESTINATION','Beberapa intent batch memilih sel yang sama; tidak ada yang dikirim untuk sel tersebut.')
                result=_execute_checked(db,client,run,item,grid,fresh[grid.title],intent['writes'],cancel,on_phase,defer_submit=True)
                if isinstance(result,PendingSubmission):pending.append((intent,result))
                else:on_outcome(intent,result)
            except Issue as problem:on_outcome(intent,problem)
        if not pending:return
        # Revalidate source authorization and durable plans at the final safe
        # boundary. Preparing another item must not make earlier intent stale.
        ready=[]
        # Target values are mutable: re-read the complete groups after all
        # SQLite preparation, before the POST. An epoch check also covers any
        # structural change while other tabs were being examined.
        boundary_epoch=revision(client,run.config_snapshot['destination']['spreadsheet_id'])
        latest={};boundary_errors={}
        for title,view in fresh.items():
            try:latest[title]=ObservedTargets(view.view,sorted({(w.row,w.col) for i,p in pending if p.grid.title==title for w in p.writes}),budget)
            except Issue as problem:boundary_errors[title]=problem
        final_epoch=revision(client,run.config_snapshot['destination']['spreadsheet_id'])
        for intent,submission in pending:
            cancel()
            try:
                validate_mapped(db,run,submission.item,retry_id)
                if submission.grid.title in boundary_errors:raise boundary_errors[submission.grid.title]
                expected=getattr(submission.fresh,'validated_content_revision',None)
                if expected is not None and (expected!=boundary_epoch or final_epoch!=boundary_epoch):
                    raise Issue('DESTINATION_CHANGED','Versi tujuan berubah sejak validasi batch; koordinat lama tidak ditulis.')
                if any(submission.fresh.cell(w.row,w.col).snapshot!=latest[submission.grid.title].cell(w.row,w.col).snapshot for w in submission.writes):
                    raise Issue('EXISTING_VALUE_CONFLICT','Target berubah selama persiapan batch. Baca ulang kelompok sebelum koreksi.')
                if submission.item.source_document_id is not None and not authorized_source_is_current(db,run,submission.item):
                    raise Issue('SOURCE_REVISION_CHANGED','Konfigurasi sumber berubah sebelum batch dikirim; otorisasi ulang item secara eksplisit.')
                ready.append((intent,submission))
            except Issue as problem:on_outcome(intent,problem)
        if not ready:return
        assert_current(db,run);cancel()
        previous_check=getattr(client,'cancel_check',None)
        if previous_check is not None:client.cancel_check=lambda:None
        try:
            on_phase('WRITING')
            assert_current(db,run);cancel()
            try:
                with stage('actual_write'):
                    client.write_batch(run.config_snapshot['destination']['spreadsheet_id'],[(p.grid,p.writes) for _,p in ready])
            except Issue as problem:
                if problem.code not in ('GOOGLE_WRITE_UNCERTAIN','GOOGLE_INVALID_RESPONSE','GOOGLE_TIMEOUT'):
                    for intent,_ in ready:on_outcome(intent,problem)
                    return
            except ConnectionError:pass
            # Once submitted, complete all readback groups even if Stop arrives.
            on_phase('VERIFYING')
            by_tab=defaultdict(list)
            for intent,submission in ready:by_tab[submission.grid.title].append((intent,submission))
            proof=DestinationProof(client,run.config_snapshot['destination']['spreadsheet_id'],by_tab)
            audits={};audit_errors={}
            for title,groups in by_tab.items():
                grid=grids[title];all_writes=[w for _,p in groups for w in p.writes]
                try:
                    with stage('readback_verification'):
                        verified=grid.after_write(all_writes,fresh[title],proof=proof);cleanup.callback(close_view,verified)
                        observed=ObservedTargets(verified,sorted({(w.row,w.col) for w in all_writes}),budget)
                        audits[title]=(all_writes,observed)
                except Issue as problem:audit_errors[title]=problem
            # No financial/mapping acknowledgement may precede closure of the
            # shared revision epoch. This is why cached metadata is sufficient.
            try:proof.finish()
            except Issue as problem:
                for intent,_ in ready:on_outcome(intent,problem)
                return
            for title,groups in by_tab.items():
                grid=grids[title]
                try:
                    if title in audit_errors:raise audit_errors[title]
                    all_writes,observed=audits[title]
                    with stage('readback_verification'):
                        # This acknowledges the global structural proof only.
                        # Item financial state stays PREPARED until its complete
                        # values/amounts/Notes match in _verify_submission().
                        grid.accept_verified(all_writes,observed);db.commit()
                    proxy=AuditedGrid(grid,observed)
                    for intent,submission in groups:
                        try:
                            result=_verify_submission(db,client,run,proxy,submission.fresh,submission.writes,submission.formulas,submission.plan)
                            on_outcome(intent,result)
                        except Issue as problem:on_outcome(intent,problem)
                except Issue as problem:
                    for intent,_ in groups:on_outcome(intent,problem)
        finally:
            if previous_check is not None:client.cancel_check=previous_check


def process_plans(db,run,client,ordered,planned,conflicting,service_retries,retry_id=None):
    """Bound each window, preserving logical group and DEPO-before-QRIS order."""
    from .runner import error,success
    from ..conflicts import open_conflict
    def change_phase(value):
        client.diagnostic_context['phase']=value;phase(db,run,value)
    def outcome(intent,value):
        item,grid,writes,context=intent['item'],intent['grid'],intent['writes'],intent['context']
        if isinstance(value,Issue):
            value=Issue(value.code,value.message,value.fix,**{**context,'phase':run.current_phase,**value.context})
            if value.code in ('EXISTING_VALUE_CONFLICT','DUPLICATE_DESTINATION','UNCERTAIN_WRITE','READBACK_FAILED','TRANSFER_IDENTITY_CHANGED'):
                try:
                    conflict=open_conflict(db,client,run,item,grid,writes,value,context)
                    if conflict:value.context['conflict_id']=conflict.id
                except Issue as observation:value=Issue(observation.code,observation.message,observation.fix,**context,conflict_observation_failed=True)
            error(db,run,item,value)
        else:success(db,item,{**value,**context},False)
        log_phase(run,item,'FAILED' if isinstance(value,Issue) else 'VERIFIED',intent['started'],value.code if isinstance(value,Issue) else None)
    queue=[i for i in ordered if i.id in planned]
    while queue:
        service_retries();check_cancel(db,run=run)
        token=revision(client,run.config_snapshot['destination']['spreadsheet_id'])
        window=[];cells=size=0
        if token is None:
            # Unknown revisions cannot justify sharing stale metadata across
            # tabs. Keep the original full proof around each single-tab batch.
            first_title=planned[queue[0].id][0].title
            queue=[i for i in queue if planned[i.id][0].title==first_title]+[i for i in queue if planned[i.id][0].title!=first_title]
        while queue and len(window)<64:
            item=queue[0];grid,writes,context=planned[item.id]
            if token is None and window and grid.title!=window[0]['grid'].title:break
            weight=len(json.dumps([asdict(w) for w in writes],ensure_ascii=False,default=str).encode())
            if window and (cells+len(writes)>settings().grid_chunk_cells or size+weight>settings().max_api_response_bytes):break
            queue.pop(0);planned.pop(item.id)
            intent={'item':item,'grid':grid,'writes':writes,'context':context,'started':time.monotonic()}
            if item.id in conflicting:outcome(intent,Issue('DUPLICATE_DESTINATION','Beberapa sumber memetakan sel tujuan yang sama.'));continue
            if item.status!='PENDING':continue  # A priority retry already finished it.
            window.append(intent);cells+=len(writes);size+=weight
        try:submit_window(db,run,client,window,outcome,change_phase,retry_id)
        except JobCanceled:raise
        except Issue as problem:
            for intent in window:
                if intent['item'].status=='PENDING':outcome(intent,problem)
        except Exception as error:
            logger.error(json.dumps({'event':'batch_write_error','run_id':run.id,'phase':run.current_phase,'type':type(error).__name__}))
            db.rollback()
            for intent in window:
                if intent['item'].status=='PENDING':outcome(intent,Issue('WRITE_FAILURE','Penulisan batch belum dapat diverifikasi. Gunakan retry eksplisit untuk rekonsiliasi.'))
