import re
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Optional

from .types import Cell, Grid, Issue, norm, number

MONTHS = {
    "JANUARY": 1, "JANUARI": 1, "JAN": 1, "FEBRUARY": 2, "FEBRUARI": 2, "FEB": 2,
    "MARCH": 3, "MARET": 3, "MAR": 3, "APRIL": 4, "APR": 4, "MAY": 5, "MEI": 5,
    "JUNE": 6, "JUNI": 6, "JUN": 6, "JULY": 7, "JULI": 7, "JUL": 7,
    "AUGUST": 8, "AGUSTUS": 8, "AUG": 8, "AGU": 8, "SEPTEMBER": 9, "SEP": 9,
    "OCTOBER": 10, "OKTOBER": 10, "OCT": 10, "OKT": 10, "NOVEMBER": 11, "NOV": 11,
    "DECEMBER": 12, "DESEMBER": 12, "DEC": 12, "DES": 12,
}


def parse_date(cell: Cell) -> Optional[date]:
    v = cell.value
    if isinstance(v, (float, int)) and cell.date_format:
        return (datetime(1899, 12, 30) + timedelta(days=v)).date()
    s = norm(v)
    iso = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", s)
    try:
        if iso:
            return date(*map(int, iso.groups()))
        m = re.search(r"\b(\d{1,2})[\s-]+([A-Z]+)[\s-]+(\d{4})\b", s)
        if m and m[2] in MONTHS:
            return date(int(m[3]), MONTHS[m[2]], int(m[1]))
    except ValueError:
        return None
    return None


def separator_dates(grid: Grid) -> dict[date, list[int]]:
    markers: dict[date, list[int]] = {}
    for r, row in enumerate(grid.rows):
        for c, cell in enumerate(row):
            d = parse_date(cell)
            if not d:
                continue
            black = cell.color is not None and max(cell.color) < 0.15
            merged = any(m['startRowIndex'] == r and m['startColumnIndex'] == c
                         and m['endColumnIndex'] - c >= 3 for m in grid.merges)
            if black or merged:
                if r not in markers.setdefault(d, []):
                    markers[d].append(r)
    return markers


def header(grid: Grid, label: str) -> int:
    candidates = {(r, c) for r, row in enumerate(grid.rows[:12]) for c, cell in enumerate(row)
                  if norm(cell.value) == norm(label)}
    if len(candidates) != 1:
        raise Issue("DUPLICATE_HEADER" if candidates else "HEADER_MISSING",
                    f"Header {label} harus ditemukan tepat satu kali.", header=label)
    return next(iter(candidates))[1]


# Confirmed SOURCE layouts. Destination mapping remains dynamic in resolver.py.
LAYOUTS = {
    'DEPO': {'deposit': 9, 'withdrawal': 10, 'balance': 11, 'expense': 7, 'transfer': 8},
    'QRIS': {'deposit': 8, 'withdrawal': 9, 'balance': 10, 'expense': 6, 'transfer': 7},
}


@dataclass
class Day:
    grid: Grid
    selected: date
    start: int
    end: int
    transaction_rows: list[int]
    document_type: str = "DEPO"
    last_metric_row: Optional[int] = None

    @classmethod
    def resolve(cls, grid: Grid, selected: date, document_type: str = "DEPO"):
        if document_type not in LAYOUTS or grid.width <= LAYOUTS[document_type]["balance"]:
            raise Issue("SOURCE_LAYOUT_INVALID", "Jumlah kolom sumber tidak sesuai tata letak DOC DEPO/QRIS yang dikonfirmasi.")
        markers = separator_dates(grid)
        following = selected + timedelta(days=1)
        for d in (selected, following):
            if len(markers.get(d, [])) != 1:
                raise Issue("DATE_NOT_FOUND", f"Pemisah tanggal {d.isoformat()} tidak ditemukan secara unik.",
                            "Pastikan pemisah tanggal terpilih dan hari berikutnya tersedia di sumber.", expected_date=str(d))
        start, next_row = markers[selected][0], markers[following][0]
        if next_row <= start or any(start < r < next_row for d, rr in markers.items()
                                   if d not in (selected, following) for r in rr):
            raise Issue("AMBIGUOUS_DATE", "Urutan pemisah tanggal tidak konsisten.")
        layout = LAYOUTS[document_type]
        payload_columns = {1, 2, 3, 4, 5, layout['expense'], layout['transfer']}
        money_columns = {4, 5, layout['expense'], layout['transfer']}
        # Cumulative totals, SALDO, CEK SALDO and decorative cells are not
        # transactions. Blank formula results and template numeric zeroes are
        # not activity; malformed/nonzero inputs still count and remain errors.
        def activity(r):
            return any(grid.cell(r,c).value not in (None, '') and
                       (c not in money_columns or grid.cell(r,c).value != 0 or isinstance(grid.cell(r,c).value, bool))
                       for c in payload_columns)
        rows = [r for r in range(start+1, next_row) if activity(r)]
        return cls(grid, selected, start, next_row-1, rows, document_type)

    def metric_column(self, label: str) -> int:
        key = {'TOTAL': 'deposit', 'TOTAL DEPO': 'deposit', 'TOTAL WD': 'withdrawal', 'SALDO': 'balance'}.get(norm(label))
        if not key:
            raise Issue('SOURCE_METRIC_UNKNOWN', 'Metrik sumber tidak dikenali.')
        return LAYOUTS[self.document_type][key]

    def metric(self, label: str) -> int:
        c = self.metric_column(label)
        self.last_metric_row = self.end
        if not self.transaction_rows:
            if norm(label) != 'SALDO':
                closing = self.grid.cell(self.end, c).value
                if closing not in (None, ''):
                    number(closing)  # A formula error is never an empty-day zero.
                return 0
            for r in range(self.end, -1, -1):
                cell = self.grid.cell(r, c)
                if cell.value not in (None, ''):
                    self.last_metric_row = r
                    return number(cell.value)
            raise Issue('INVALID_BALANCE', 'Saldo sebelumnya tidak ditemukan untuk hari tanpa transaksi.')
        return number(self.grid.cell(self.end, c).value)

    def signed_sum(self, col: int) -> int:
        return sum(number(self.grid.cell(r, col).value, blank_zero=True) for r in self.transaction_rows)

    def fees(self, prefix: str, amount_col: int = 7) -> tuple[str, int]:
        entries = [(str(self.grid.cell(r, 3).value), number(self.grid.cell(r, amount_col).value))
                   for r in self.transaction_rows if norm(self.grid.cell(r, 3).value).startswith(norm(prefix))]
        desc = "\n".join(text for text, _ in entries)
        if prefix == "FEE WD AUTO":
            desc = prefix if entries else ""
        return desc, abs(sum(v for _, v in entries))


def eligible_description(text: str) -> bool:
    return bool(re.match(r"^(KIRIM KE\b|PENGIRIMAN DARI\b|DARI (?:NL )?KAS\b)", norm(text)))


def transfer_rows(day: Day, document_type: str, palette: dict) -> list[dict]:
    out = []
    kiriman = LAYOUTS[document_type]["transfer"]
    approved = {tuple(v) for v in palette.get("approved_brown", [])}
    excluded = {tuple(v) for v in palette.get("excluded_blue", [])}
    for r in day.transaction_rows:
        desc = day.grid.cell(r, 3)
        if not eligible_description(str(desc.value or "")):
            continue
        rgb = tuple(round(v, 4) for v in desc.color) if desc.color is not None else None
        if rgb in excluded:
            continue
        if rgb not in approved:
            raise Issue("UNRECOGNIZED_TRANSFER_FORMAT", "Warna transaksi kiriman belum disetujui atau tidak dikenali.",
                        "Periksa warna aktual melalui pratinjau; setujui palet melalui perintah CLI setelah verifikasi.",
                        source_row=r + 1, observed_rgb=rgb)
        banks = re.findall(r"\b(BCA|MANDIRI|BRI|BNI)\b", norm(day.grid.title))
        if document_type == "DEPO" and len(set(banks)) != 1:
            raise Issue("BANK_AMBIGUOUS", "Bank pada nama sheet sumber tidak ditemukan secara unik.")
        amount = number(day.grid.cell(r, kiriman).value)
        note = f"{day.grid.title} ( {desc.value} ) {amount:,}".replace(",", ".") if document_type == "QRIS" else None
        out.append({"description": str(desc.value), "amount": amount, "row": r,
                    "bank": banks[0] if document_type == "DEPO" else None, "note": note})
    return out

