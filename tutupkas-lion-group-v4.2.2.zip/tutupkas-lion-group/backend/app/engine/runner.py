import logging
import time
from pathlib import Path
from contextlib import ExitStack
from dataclasses import asdict

from sqlalchemy import select, update

from ..destination_reader import read_destination, close_view
from ..db import utcnow
from ..models import RunItem, TaskError, TransferOwnership, Run, Destination, MappedResult, AuditLog
from ..sheets import SheetsClient
from ..job_control import JobCanceled, check_cancel, claim, finalize_cancel, fail_run, phase, log_phase
from ..telemetry import Capture,measured
from . import resolver
from .parser import Day, transfer_rows
from .types import Issue, Write, column, fingerprint, norm
from .writer import check_write, execute

logger = logging.getLogger('tutupkas.worker')


def error(db, run, item, issue):
    item.status, item.processed_at = 'FAILED', utcnow()
    existing = db.scalar(select(TaskError).where(TaskError.run_item_id == item.id, TaskError.is_resolved == False))
    if not existing:
        existing = TaskError(run_id=run.id, run_item_id=item.id, source_document_id=item.source_document_id,
                             source_tab_name=item.source_tab_name, error_code=issue.code,
                             human_message=issue.message, suggested_fix=issue.fix, technical_details=issue.context)
        db.add(existing)
    else:
        db.add(AuditLog(actor_id=run.started_by,action='historical_item_error_retained',entity_type='task_errors',entity_id=str(existing.id),
            details={'code':existing.error_code,'message':existing.human_message,'details':existing.technical_details}))
        existing.error_code, existing.human_message = issue.code, issue.message
        existing.suggested_fix, existing.technical_details = issue.fix, issue.context
    db.add(AuditLog(actor_id=run.started_by,action='item_error_observed',entity_type='task_run_items',entity_id=str(item.id),
                    details={'code':issue.code,'message':issue.message,'context':issue.context}))
    db.commit()


def success(db, item, result, preview):
    item.status, item.result, item.processed_at = 'PREVIEWED' if preview else 'SUCCESS', result, utcnow()
    for err in db.scalars(select(TaskError).where(TaskError.run_item_id == item.id, TaskError.is_resolved == False)):
        err.is_resolved, err.resolved_at = True, utcnow()
    db.commit()


def process_run(db, run: Run, client=None):
    if not claim(db,run):
        return
    if client is not None:client._verified_revisions={}
    run_started=time.monotonic()
    try:
        with Capture() as metrics:
            with ExitStack() as cleanup:
                _process_run(db,run,client,cleanup)
    except JobCanceled:
        finalize_cancel(db,run)
    except Exception as exc:
        logger.error('{"event":"run_error","run_id":%s,"type":"%s","phase":"%s","elapsed_ms":%s}',run.id,type(exc).__name__,run.current_phase,round((time.monotonic()-run_started)*1000))
        fail_run(db,run)
    finally:
        if 'metrics' in locals() and hasattr(metrics,'result'):
            db.refresh(run)
            snapshot=dict(run.config_snapshot)
            snapshot['performance_attempts']=[*snapshot.get('performance_attempts',[])[-19:],metrics.result]
            run.config_snapshot=snapshot
            db.add(AuditLog(actor_id=run.started_by,action='run_performance_measured',entity_type='task_runs',entity_id=str(run.id),details=metrics.result))
            db.commit()


@measured('financial_calculation_and_coordinator')
def _process_run(db, run: Run, client=None, cleanup=None, selected_item=None, retry_request=None, finalize=True):
    query=select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type!='reconciliation').order_by(RunItem.id)
    if selected_item is not None:query=query.where(RunItem.id==selected_item)
    items=list(db.scalars(query))
    snap = run.config_snapshot
    source_cache, destination_cache = {}, {}
    planned: dict[int, tuple] = {}
    reservations = set()
    doc_by_id = {d['id']: d for d in snap['sources']}
    if selected_item is not None:
        from ..source_authorization import document_for
        selected_row=db.get(RunItem,selected_item)
        override=document_for(run,selected_row)
        if override:doc_by_id[override['id']]=override
    current_revision = fingerprint({p.name: p.read_text() for p in sorted(Path(__file__).parent.glob('*.py'))})
    if snap.get('engine_revision') and snap['engine_revision'] != current_revision:
        for item in items:
            if item.status == 'PENDING':
                error(db, run, item, Issue('ENGINE_CHANGED', 'Versi engine berubah setelah pekerjaan diantrikan.',
                      'Jalankan pratinjau dan penarikan baru sebelum menulis dengan versi aplikasi ini.'))
        if finalize:finish(db, run, items)
        return
    try:
        client = client or SheetsClient(cancel_check=lambda:check_cancel(db,run=run))
    except Issue as issue:
        for item in items:
            if item.status == 'PENDING':
                error(db, run, item, issue)
        if finalize:finish(db, run, items)
        return

    client.diagnostic_context = {'run_id':run.id,'website':snap['website'],'selected_date':str(run.selected_date)}
    snapshot_record=None

    def service_retries(limit=3):
        if not finalize:return
        from ..retry_queue import claim_next,complete,flag_dependents
        from ..conflicts import apply_decision
        for _ in range(limit):
            check_cancel(db,run=run)
            # A priority QRIS retry must not take still-unwritten DEPO slots.
            # Leave that dependent request QUEUED; other retries remain eligible.
            depo_ids=[d['id'] for d in snap['sources'] if d['type']=='DEPO']
            qris_ids=[d['id'] for d in snap['sources'] if d['type']=='QRIS']
            blocked=[]
            if db.scalar(select(RunItem.id).where(RunItem.run_id==run.id,RunItem.metric_type=='transfers',
                    RunItem.status=='PENDING',RunItem.source_document_id.in_(depo_ids)).limit(1)):
                blocked=list(db.scalars(select(RunItem.id).where(RunItem.run_id==run.id,
                    RunItem.metric_type=='transfers',RunItem.source_document_id.in_(qris_ids))))
            request=claim_next(db,run,blocked)
            if request is None:break
            db.refresh(run)  # API may have committed item-specific authority.
            selected=db.get(RunItem,request.run_item_id)
            db.refresh(selected)
            try:
                if request.kind.startswith('CONFLICT_'):
                    apply_decision(db,client,run,request)
                elif request.kind=='RECONCILE':
                    from ..reconciliation import reconcile_website
                    reconcile_website(db,run,client,allow_running=True,cancel_check=lambda:check_cancel(db,run=run))
                else:
                    authorized=request.details.get('source_override')
                    if authorized and hasattr(client,'_verified_revisions'):
                        client._verified_revisions.pop(authorized['document']['spreadsheet_id'],None)
                    selected.status='PENDING';db.commit()
                    _process_run(db,run,client,cleanup,selected.id,request,False)
                    if selected.status in ('SUCCESS','PREVIEWED'):flag_dependents(db,run,selected)
            except Issue as issue:error(db,run,selected,issue)
            complete(db,request)

    def source(doc, tab):
        nonlocal snapshot_record
        key = (doc['id'], tab)
        if key not in source_cache:
            # Metrics are contiguous per tab. Retain only the current source
            # grid instead of accumulating every active sheet in RAM.
            source_cache.clear()
            try:
                check_cancel(db,run=run)
                phase(db,run,'SOURCE_READING')
                client.diagnostic_context['phase'] = 'SOURCE_READING'
                log_phase(run,item,'SOURCE_READING',item_started)
                from ..snapshots import source_snapshot
                source_cache[key] = source_snapshot(db,client,run,doc,doc.get('actual_tab_override',tab),retry_request)
            except JobCanceled:
                raise
            except Issue as e:
                # Cache diagnostics without a traceback that could retain raw
                # HTTP bodies or the failed reader's calculation buffers.
                source_cache[key] = Issue(e.code,e.message,e.fix,**e.context)
            except Exception as exc:
                logger.error('{"event":"source_error","run_id":%s,"type":"%s"}',run.id,type(exc).__name__)
                source_cache[key]=Issue('SOURCE_READ_FAILED','Data sumber tidak dapat dibaca atau diproses; periksa log layanan dan struktur sumber.')
        v = source_cache[key]
        if isinstance(v, Issue):
            raise Issue(v.code,v.message,v.fix,**v.context)
        snapshot_record,day=v
        return day

    def target(tab):
        if tab not in destination_cache:
            check_cancel(db,run=run)
            try:
                if snap.get('mapping_id'):
                    from ..destination_registry import RegistryView
                    destination_cache[tab]=RegistryView(db,client,run,tab)
                else:
                    destination_cache[tab] = read_destination(client,snap['destination']['spreadsheet_id'],tab,snap['registered'])
                cleanup.callback(close_view,destination_cache[tab])
            except Issue as issue:
                destination_cache[tab]=Issue(issue.code,issue.message,issue.fix,**issue.context)
        result=destination_cache[tab]
        if isinstance(result,Issue):
            raise Issue(result.code,result.message,result.fix,**result.context)
        return result

    def regular(tab, item, value):
        grid = target(tab)
        doc=doc_by_id[item.source_document_id]
        canonical=doc.get('identities',{}).get(item.source_tab_name,{}).get('names',[item.source_tab_name])[0]
        from ..source_authorization import alias_for
        alias=alias_for(run,item,doc)
        if snap.get('mapping_id'):
            from ..destination_registry import target as mapped_target
            found=mapped_target(db,run,tab,'',regular=True,source=canonical,alias=alias)
            grid.require_coordinates(found.coordinates)
            p=found.coordinates
            return grid,[Write(tab,p['row'],p['col'],value)]
        return grid, [resolver.regular(grid, snap['website'], snap['registered'], run.selected_date,
                                      canonical, value, alias)]

    def labeled(grid,label,value):
        if snap.get('mapping_id'):
            from ..destination_registry import target as mapped_target
            found=mapped_target(db,run,grid.title,label)
            grid.require_coordinates(found.coordinates)
            p=found.coordinates
            return Write(grid.title,p['row'],p['col'],value)
        return resolver.labeled(grid,snap['website'],snap['registered'],run.selected_date,label,value)

    def remember(item,writes,context):
        raw=[asdict(w) for w in writes]
        db.add(MappedResult(run_item_id=item.id,snapshot_id=snapshot_record.id if snapshot_record else None,
            retry_request_id=retry_request.id if retry_request else None,mapping_id=snap.get('mapping_id'),
            writes=raw,provenance=context,checksum=fingerprint([raw,context])))
        if snapshot_record:snapshot_record.state='MAPPED'
        db.commit()

    # Process DEPO ahead of QRIS, then the dependent aggregate. Successful inputs
    # remain in the DB and are reused on retries without a new source read.
    ordered = sorted(items, key=lambda i: (i.metric_type == 'expense_total',
                                          doc_by_id.get(i.source_document_id, {}).get('type') == 'QRIS', i.id))
    static_conflicts=set()
    if snap.get('mapping_id'):
        from ..destination_registry import target as mapped_target
        static={}
        all_items=list(db.scalars(select(RunItem).where(RunItem.run_id==run.id)))
        for candidate in all_items:
            try:
                from ..source_authorization import document_for,alias_for
                candidate_doc=document_for(run,candidate) or {}
                metric=candidate.metric_type
                if metric in ('deposit','withdrawal','balance'):
                    title={'deposit':'TOTAL DEPO','withdrawal':'TOTAL WD','balance':'SALDO BANK'}[metric]
                    source_doc=candidate_doc
                    canonical=source_doc.get('identities',{}).get(candidate.source_tab_name,{}).get('names',[candidate.source_tab_name])[0]
                    entry=mapped_target(db,run,title,'',regular=True,source=canonical,
                        alias=alias_for(run,candidate,source_doc))
                elif metric=='expense_total':entry=mapped_target(db,run,'BIAYA','BIAYA')
                elif metric=='qris_expense':
                    source_doc=candidate_doc
                    canonical=source_doc.get('identities',{}).get(candidate.source_tab_name,{}).get('names',[candidate.source_tab_name])[0]
                    entry=mapped_target(db,run,'BIAYA','BIAYA TARIK QRIS' if norm(canonical)=='QRIS QRIZZ' else 'BIAYA AUTO WD')
                else:continue
                pos=entry.coordinates
                static.setdefault((entry.module,pos['row'],pos['col']),set()).add(candidate.id)
            except Issue:continue  # The selected item reports its precise error.
        static_conflicts=set().union(*(ids for ids in static.values() if len(ids)>1)) if static else set()
        positions={}
        for (title,row,col),ids in static.items():
            if selected_item is None or selected_item in ids:positions.setdefault(title,[]).append((row,col))
        for title,cells in positions.items():
            check_cancel(db,run=run)
            try:target(title).prefetch(cells)
            except Issue:pass  # Individual items still report accurate failures.
    for item in ordered:
        service_retries()
        if item.status != 'PENDING':
            continue
        check_cancel(db,run=run)
        phase(db,run,'PLANNING')
        item_started=time.monotonic()
        client.diagnostic_context.update({'source_tab':item.source_tab_name,'module':item.metric_type,'phase':'PLANNING'})
        log_phase(run,item,'PLANNING',item_started)
        context = {"run_id": run.id, "phase": 'PLANNING', "selected_date": str(run.selected_date), "website": snap['website'],
                   "source_tab": item.source_tab_name, "module": item.metric_type,
                   "destination_title": snap['destination'].get('title')}
        try:
            writes,grid,snapshot_record=[],None,None
            if item.id in static_conflicts:
                raise Issue('DUPLICATE_DESTINATION','Beberapa sumber aktif memetakan sel yang sama. Perbaiki account/alias; tidak ada tulisan parsial.')
            if item.metric_type == 'expense_total':
                inputs = list(db.scalars(select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type=='expense_input')))
                if not inputs or any(i.status not in ('SUCCESS', 'PREVIEWED') for i in inputs):
                    raise Issue('AGGREGATE_INCOMPLETE', 'Total BIAYA menunggu seluruh input DOC DEPO berhasil.',
                                'Perbaiki item biaya sumber yang gagal; total akan dihitung ulang dari input tersimpan.')
                value = abs(sum(i.result['signed_value'] for i in inputs))
                grid = target('BIAYA')
                writes = [labeled(grid,'BIAYA',value)]
            else:
                doc = doc_by_id[item.source_document_id]
                context.update({"source_title": doc['title'], "document_type": doc['type'],
                                'source_spreadsheet_id':doc['spreadsheet_id'],'source_revision':doc['revision'],
                                "expected_date": str(run.selected_date)})
                day = None
                day = source(doc, item.source_tab_name)
                context['closing_row'] = day.end + 1
                context['snapshot_id']=snapshot_record.id
                context['source_read_at']=snapshot_record.created_at.isoformat()
                context['source_identity']=doc.get('identities',{}).get(item.source_tab_name)
                context['source_tab']=day.grid.title
                if item.metric_type in ('deposit', 'withdrawal', 'balance'):
                    labels = {'deposit': 'Total' if doc['type'] == 'DEPO' else 'Total Depo',
                              'withdrawal': 'Total WD', 'balance': 'SALDO'}
                    label = labels[item.metric_type]
                    value = day.metric(label)
                    context['source_cell'] = f'{day.grid.title}!{column(day.metric_column(label))}{day.last_metric_row + 1}'
                    tabs = {'deposit': 'TOTAL DEPO', 'withdrawal': 'TOTAL WD', 'balance': 'SALDO BANK'}
                    grid, writes = regular(tabs[item.metric_type], item, value)
                elif item.metric_type == 'expense_input':
                    remember(item,[],{**context,'signed_value':day.signed_sum(7)})
                    success(db, item, {"signed_value": day.signed_sum(7), **context}, run.preview)
                    continue
                elif item.metric_type == 'qris_expense':
                    value = abs(day.signed_sum(6))
                    grid = target('BIAYA')
                    canonical=doc.get('identities',{}).get(item.source_tab_name,{}).get('names',[item.source_tab_name])[0]
                    label = 'BIAYA TARIK QRIS' if norm(canonical) == 'QRIS QRIZZ' else 'BIAYA AUTO WD'
                    writes = [labeled(grid,label,value)]
                elif item.metric_type == 'qris_fee':
                    canonical=doc.get('identities',{}).get(item.source_tab_name,{}).get('names',[item.source_tab_name])[0]
                    is_depo = norm(canonical) == 'QRIS QRIZZ'
                    description, value = day.fees('FEE QRIS PERIODE' if is_depo else 'FEE WD AUTO')
                    title='Pengeluaran FEE QRIS DEPO' if is_depo else 'Pengeluaran FEE QRIS WD'
                    label='FEE QRIS DEPO' if is_depo else 'FEE QRIS WD'
                    if snap.get('mapping_id'):
                        from ..destination_registry import target as mapped_target
                        try:entry=mapped_target(db,run,title,label)
                        except Issue:
                            if description:raise
                            from ..destination_registry import inspect_no_fee
                            inspection=mapped_target(db,run,title,'__FEE_OCCUPANCY__')
                            grid=target(title);grid.require_coordinates(inspection.coordinates)
                            writes=inspect_no_fee(db,run,item,grid,inspection.coordinates)
                            if not writes:
                                remember(item,[],context);success(db,item,{'no_fee':True,'verified':not run.preview,**context},run.preview);continue
                            context['no_fee']=True
                            raise Issue('NO_FEE_EXISTING_DATA','Sumber tanpa fee, tetapi blok tanggal tujuan mempunyai data lama. Tinjau kelompok sebelum koreksi.')
                        grid=target(title);grid.require_coordinates(entry.coordinates)
                        writes=[Write(title,p['row'],p['col'],v) for p,v in zip(entry.coordinates['cells'],[description,value])]
                    else:
                        grid=target(title)
                        writes=resolver.fees(grid,snap['website'],snap['registered'],run.selected_date,label,description,value)
                    if not description:
                        from .writer import get_ledger
                        owned=[get_ledger(db,run,w) for w in writes]
                        empty=all(grid.cell(w.row,w.col).empty for w in writes)
                        pending=any(o and o.verification_status=='PREPARED' and o.written_value.get('value') is None for o in owned)
                        mismatch=any(o and grid.cell(w.row,w.col).snapshot!=o.written_value for o,w in zip(owned,writes))
                        if empty and not pending and not mismatch:
                            remember(item,[],context);success(db,item,{'no_fee':True,'verified':not run.preview,**context},run.preview);continue
                        for w,ledger in zip(writes,owned):
                            w.value=None
                            if pending and ledger:w.note=ledger.written_value.get('note','')
                        context['no_fee']=True
                        from ..conflicts import retained_decision
                        retained=retained_decision(db,client,run,item,grid,writes)
                        if retained:
                            remember(item,[],context);success(db,item,{**retained,**context},run.preview);continue
                        if not (empty and pending):
                            raise Issue('NO_FEE_EXISTING_DATA','Sumber valid tanpa fee, tetapi fee lama ada di tujuan. Pilih data baru atau tetapkan data lama.')
                elif item.metric_type == 'transfers':
                    from ..transfer_intents import normalize,history,allocate,recoverable
                    transactions=normalize(db,run,item,doc,transfer_rows(day,doc['type'],snap.get('palette',{})))
                    context['transfer_intents']=transactions
                    identity,prior=history(db,run,item,doc)
                    if not transactions and not prior:
                        remember(item,[],context)
                        success(db,item,{'transfers':0,'verified':not run.preview,**context},run.preview)
                        continue
                    grid=target('KET PENGIRIMAN')
                    if snap.get('mapping_id'):
                        from ..destination_registry import target as mapped_target
                        entry=mapped_target(db,run,'KET PENGIRIMAN','SLOTS')
                        slots=entry.coordinates['slots'];grid.require_coordinates(entry.coordinates)
                        if callable(getattr(client,'write_batch',None)) and not getattr(grid,'_planning_slots_prefetched',False):
                            # Planning may reserve these observations; Stage C
                            # still re-reads actual occupancy before any POST.
                            positions=[pos for bank in resolver.BANKS for r,dc,ac in slots[bank] for pos in ((r,dc),(r,ac))]
                            grid.prefetch(positions[:128]);grid._planning_slots_prefetched=True
                    else:slots=resolver.transfer_slots(grid,snap['website'],snap['registered'],run.selected_date)
                    writes,changes,changed=allocate(db,run,item,doc,grid,slots,transactions,reservations)
                    context['transfer_changes']=changes
                    if changed and not recoverable(db,run,item,writes,changes):
                        remember(item,writes,context)
                        from ..conflicts import retained_decision
                        retained=retained_decision(db,client,run,item,grid,writes)
                        if retained:
                            success(db,item,{**retained,**context},run.preview);continue
                        raise Issue('TRANSFER_IDENTITY_CHANGED','Kiriman sumber berubah/hilang; tinjau seluruh slot lama dan hasil sumber baru sebelum koreksi.')
                else:
                    raise Issue('MODULE_UNSUPPORTED', 'Modul pemrosesan tidak dikenal.')
            from ..conflicts import retained_decision
            retained=retained_decision(db,client,run,item,grid,writes)
            if retained:
                remember(item,[],context);success(db,item,{**retained,**context},run.preview);continue
            for w in writes:
                check_write(db, run, item, grid, w)
            remember(item,writes,context)
            planned[item.id] = (grid, writes, context)
        except JobCanceled:
            raise
        except Issue as e:
            log_phase(run,item,'FAILED',item_started,e.code)
            e.context = {**context, 'phase':run.current_phase, **e.context}
            if grid is not None and writes and e.code in ('EXISTING_VALUE_CONFLICT','DUPLICATE_DESTINATION','UNCERTAIN_WRITE','NO_FEE_EXISTING_DATA','TRANSFER_IDENTITY_CHANGED','FORMULA_CONFLICT','MERGED_CELL_CONFLICT','NOTE_CONFLICT'):
                from ..conflicts import open_conflict
                try:
                    conflict=open_conflict(db,client,run,item,grid,writes,e,context)
                    if conflict:e.context['conflict_id']=conflict.id
                except Issue as observation:
                    e=Issue(observation.code,observation.message,observation.fix,**context,conflict_observation_failed=True)
            error(db, run, item, e)
        except Exception as e:
            log_phase(run,item,'FAILED',item_started,'INTERNAL_ERROR')
            logger.error('{"event":"planning_error","run_id":%s,"type":"%s"}', run.id, type(e).__name__)
            error(db, run, item, Issue('INTERNAL_ERROR', 'Pemrosesan item terhenti. Periksa konfigurasi dan log layanan.', **context))

    source_cache.clear()
    day = None  # Last loop-local source reference must not survive into writing.
    collisions = {}
    for item_id, (_, writes, _) in planned.items():
        for w in writes:
            collisions.setdefault((w.tab, w.row, w.col), set()).add(item_id)
    conflicting = set().union(*(v for v in collisions.values() if len(v) > 1)) if collisions else set()
    preview_views={}
    if run.preview and snap.get('mapping_id'):
        for grid,writes,context in planned.values():
            if grid.title in preview_views:continue
            positions=[(w.row,w.col) for g,group,c in planned.values() if g.title==grid.title for w in group]
            try:
                view=grid.refresh(positions=positions)
                preview_views[grid.title]=view
                cleanup.callback(close_view,view)
            except Issue as problem:preview_views[grid.title]=problem
    if not run.preview and snap.get('mapping_id') and callable(getattr(client,'write_batch',None)):
        from .batch_writer import process_plans
        process_plans(db,run,client,ordered,planned,conflicting,service_retries,retry_request.id if retry_request else None)
    for item in ordered:
        service_retries()
        if item.id not in planned:
            continue
        check_cancel(db,run=run)
        grid, writes, context = planned.pop(item.id)
        item_started=time.monotonic()
        if item.id in conflicting:
            error(db, run, item, Issue('DUPLICATE_DESTINATION', 'Beberapa sumber memetakan sel tujuan yang sama.', **context))
            continue
        try:
            stored=db.scalar(select(MappedResult).where(MappedResult.run_item_id==item.id,
                MappedResult.retry_request_id==(retry_request.id if retry_request else None)).order_by(MappedResult.id.desc()))
            if stored and fingerprint([stored.writes,stored.provenance])!=stored.checksum:
                raise Issue('MAPPED_RESULT_CORRUPT','Integritas hasil mapping tidak sesuai. Tidak ada tulisan yang dikirim.')
            if stored and stored.snapshot_id:
                from ..models import SourceSnapshot
                snapshot=db.get(SourceSnapshot,stored.snapshot_id)
                if not snapshot or snapshot.state not in ('SNAPSHOT_READY','MAPPED') or fingerprint(snapshot.payload)!=snapshot.checksum:
                    raise Issue('SNAPSHOT_CORRUPT','Snapshot belum lengkap atau integritasnya berubah. Tidak ada tulisan dikirim.')
            if stored:writes=[Write(**raw) for raw in stored.writes]
            if item.metric_type=='transfers' and not run.preview and snap.get('mapping_id') and stored:
                from ..source_authorization import document_for
                from ..transfer_intents import allocate,recoverable
                from ..destination_registry import target as mapped_target
                entry=mapped_target(db,run,'KET PENGIRIMAN','SLOTS')
                allocation_view=grid.refresh()
                try:
                    writes,changes,changed=allocate(db,run,item,document_for(run,item),allocation_view,entry.coordinates['slots'],
                        stored.provenance.get('transfer_intents',[]))
                finally:close_view(allocation_view)
                context={**context,'transfer_changes':changes}
                raw=[asdict(w) for w in writes]
                db.add(MappedResult(run_item_id=item.id,snapshot_id=stored.snapshot_id,retry_request_id=stored.retry_request_id,
                    mapping_id=stored.mapping_id,writes=raw,provenance=context,checksum=fingerprint([raw,context])))
                db.commit()
                if changed and not recoverable(db,run,item,writes,changes):
                    raise Issue('TRANSFER_IDENTITY_CHANGED','Kiriman berubah sejak planning; diperlukan keputusan kelompok, bukan penambahan slot lain.')
            def record_phase(value):
                client.diagnostic_context['phase'] = value
                phase(db,run,value)
                log_phase(run,item,value,item_started)
            if run.preview and grid.title in preview_views:
                from .writer import inspect_preview
                view=preview_views[grid.title]
                if isinstance(view,Issue):raise view
                result=inspect_preview(db,run,item,grid,view,writes)
            else:
                result = execute(db, client, run, item, grid, writes,
                    cancel_check=lambda:check_cancel(db,run=run),
                    on_phase=record_phase)
            success(db, item, {**result, **context}, run.preview)
            log_phase(run,item,'VERIFIED' if not run.preview else 'PREVIEWED',item_started)
        except JobCanceled:
            raise
        except Issue as e:
            log_phase(run,item,'FAILED',item_started,e.code)
            e.context = {**context, 'phase':run.current_phase, **e.context}
            if e.code in ('EXISTING_VALUE_CONFLICT','DUPLICATE_DESTINATION','UNCERTAIN_WRITE','READBACK_FAILED'):
                from ..conflicts import open_conflict
                try:
                    conflict=open_conflict(db,client,run,item,grid,writes,e,context)
                    if conflict:e.context['conflict_id']=conflict.id
                except Issue as observation:
                    e=Issue(observation.code,observation.message,observation.fix,**context,conflict_observation_failed=True)
            error(db, run, item, e)
        except Exception as e:
            db.rollback()
            log_phase(run,item,'FAILED',item_started,'WRITE_FAILURE')
            logger.error('{"event":"write_error","run_id":%s,"type":"%s"}', run.id, type(e).__name__)
            error(db, run, item, Issue('WRITE_FAILURE', 'Penulisan belum dapat diverifikasi. Gunakan Crawl Ulang untuk rekonsiliasi.', **context))
    destination_cache.clear()
    planned.clear()
    grid = None
    client.diagnostic_context.update({'source_tab':None,'module':'reconciliation','phase':'RECONCILING'})
    if finalize:
        from ..retry_queue import pending
        while pending(db,run):service_retries()
        finish(db, run, items, client)


def finish(db, run, items, client=None):
    from ..retry_queue import pending
    from ..workflow import lock_date
    check_cancel(db,run=run)
    for item in items:
        if item.status == 'PENDING':
            error(db,run,item,Issue('ITEM_NOT_FINISHED','Item belum selesai diproses; ulangi setelah memeriksa kesalahan layanan.'))
    failed = sum(i.status == 'FAILED' for i in items)
    if db.scalar(select(TaskError.id).join(RunItem,TaskError.run_item_id==RunItem.id).where(
            TaskError.run_id==run.id,TaskError.is_resolved==False,RunItem.metric_type!='reconciliation')):
        failed=max(1,failed)
    successful = sum(i.status in ('SUCCESS', 'PREVIEWED') for i in items)
    result_status = ('PARTIAL' if successful else 'FAILED') if failed else ('PREVIEWED' if run.preview else 'SUCCESS')
    if not items:
        result_status = 'FAILED'
    if result_status == 'SUCCESS' and db.get(Destination, run.config_snapshot.get('destination',{}).get('id')):
        from ..reconciliation import reconcile_website, reconcile_consolidated
        from fastapi import HTTPException
        phase(db,run,'RECONCILING')
        cancel=lambda:check_cancel(db,run=run)
        reconcile_website(db,run,client,allow_running=True,cancel_check=cancel)
        cancel()
        try:
            reconcile_consolidated(db,run.selected_date,client,run.batch_id,completing_run_id=run.id,cancel_check=cancel)
        except HTTPException:
            pass  # Legacy ambiguous monthly destination still requires selection.
    check_cancel(db,run=run)
    db.refresh(run)
    # A cancellation committed after the last read still wins finalization.
    if run.cancel_requested_at or run.status == 'CANCEL_REQUESTED':
        raise JobCanceled()
    lock_date(db,run.selected_date)
    if pending(db,run):
        # A request committed just before finalization wins the same date gate.
        db.commit()
        with ExitStack() as cleanup:_process_run(db,run,client,cleanup)
        return
    changed=db.execute(update(Run).where(Run.id==run.id,Run.cancel_requested_at==None,Run.status=='RUNNING')
        .values(status=result_status,current_phase='DONE',finished_at=utcnow()))
    if not changed.rowcount:
        db.rollback();raise JobCanceled()
    db.commit();db.refresh(run)
    if result_status in ('PARTIAL','FAILED') and not run.preview and db.get(Destination,run.config_snapshot.get('destination',{}).get('id')):
        from ..reconciliation import reconcile_website,reconcile_consolidated
        from fastapi import HTTPException
        reconcile_website(db,run,client)
        try:
            reconcile_consolidated(db,run.selected_date,client,run.batch_id)
        except HTTPException:
            pass
