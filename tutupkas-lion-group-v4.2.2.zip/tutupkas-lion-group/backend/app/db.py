from datetime import datetime, timezone

from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from .config import ensure_data_dir, settings


def utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    pass


ensure_data_dir()
engine = create_engine(settings().database_url, connect_args={"check_same_thread": False, "timeout": 30}
                       if settings().database_url.startswith("sqlite") else {})


@event.listens_for(engine, "connect")
def sqlite_pragmas(connection, _):
    if settings().database_url.startswith("sqlite"):
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA busy_timeout=30000")


SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)


def get_db():
    with SessionLocal() as db:
        yield db

