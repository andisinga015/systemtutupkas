"""Small, VPS-only diagnostics. Never include cell payloads or credentials."""
import resource
from pathlib import Path
import logging
from logging.handlers import RotatingFileHandler


def memory():
    high = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
    try:
        # Linux resident pages; reading this does not allocate a process snapshot.
        import os
        rss = int(Path('/proc/self/statm').read_text().split()[1]) * os.sysconf('SC_PAGE_SIZE') / 1048576
    except (OSError, ValueError, IndexError):
        rss = high
    return {'rss_mb': round(rss, 2), 'peak_rss_mb': round(high, 2)}


def configure_worker_log(lock_path):
    """20 MiB maximum retained worker diagnostics; no transaction payloads."""
    path = Path(lock_path).parent / 'worker-performance.log'
    path.touch(mode=0o600, exist_ok=True)
    path.chmod(0o600)
    handler = RotatingFileHandler(path,maxBytes=5*1024*1024,backupCount=3,encoding='utf-8')
    handler.setFormatter(logging.Formatter('%(message)s'))
    logging.getLogger('tutupkas.worker').addHandler(handler)
