from .telemetry import measured
"""Durable complete date snapshots; only explicit retry fetches a replacement."""
import json
from datetime import date

from sqlalchemy import func,select

from .config import settings
from .engine.parser import Day, LAYOUTS
from .engine.types import Cell, Grid, Issue, fingerprint
from .models import SourceSnapshot
from .source_reader import SparseRows


def pack(day):
    grid = day.grid
    stored = getattr(grid.rows,'rows',None)
    indices = set(stored) if isinstance(stored,dict) else set(range(day.start,day.end+2))
    # Carry-forward provenance is part of the snapshot even when it precedes
    # the selected separator. No historical grid is persisted.
    col = LAYOUTS[day.document_type]['balance']
    if not day.transaction_rows:
        for r in range(day.start-1,-1,-1):
            if grid.cell(r,col).value not in (None,''):
                indices.add(r);break
    rows = []
    for r in sorted(indices):
        for c,cell in enumerate(grid.rows[r]):
            if not cell.empty or cell.color is not None or cell.date_format:
                rows.append([r,c,cell.value,cell.formula,cell.note,cell.color,cell.date_format])
    return {'title':grid.title,'sheet_id':grid.sheet_id,'selected':str(day.selected),'kind':day.document_type,
        'start':day.start,'end':day.end,'rows':rows,'merges':grid.merges,
        'width':grid.width,'height':len(grid.rows)}


def unpack(payload):
    rows = {}
    for r,c,value,formula,note,color,formatted in payload['rows']:
        row = rows.setdefault(r,[])
        while len(row)<=c:row.append(Cell())
        row[c] = Cell(value,formula,note,tuple(color) if color is not None else None,formatted)
    # Preserve the fixed source width even if the closing row is blank.
    row = rows.setdefault(payload['end'],[])
    while len(row)<max(payload['width'],LAYOUTS[payload['kind']]['balance']+1):row.append(Cell())
    grid = Grid(payload['title'],payload['sheet_id'],SparseRows(payload['height'],rows),payload['merges'])
    return Day.resolve(grid,date.fromisoformat(payload['selected']),payload['kind'])


@measured('source_reading')
def source_snapshot(db,client,run,doc,tab,retry=None):
    query = select(SourceSnapshot).where(SourceSnapshot.run_id==run.id,SourceSnapshot.source_document_id==doc['id'],
        SourceSnapshot.tab_name==tab,SourceSnapshot.retry_request_id==(retry.id if retry else None))
    old = db.scalar(query.order_by(SourceSnapshot.id.desc()))
    if old and old.state in ('SNAPSHOT_READY','MAPPED'):
        if fingerprint(old.payload)!=old.checksum:
            raise Issue('SNAPSHOT_CORRUPT','Integritas snapshot sumber tidak sesuai; lakukan retry item dengan data baru.')
        return old,unpack(old.payload)
    if old and old.state=='FAILED' and not retry:
        problem = old.provenance['error']
        raise Issue(problem['code'],problem['message'],problem['fix'],**problem.get('context',{}))
    identity = doc.get('identities',{}).get(tab)
    snapshot = SourceSnapshot(run_id=run.id,source_document_id=doc['id'],identity_id=identity['id'] if identity else None,
        retry_request_id=retry.id if retry else None,tab_name=tab,selected_date=run.selected_date,state='SCANNING',
        provenance={'spreadsheet_id':doc['spreadsheet_id'],'source_revision':doc['revision'],
                    'source_period':doc.get('source_period'),'identity':identity})
    db.add(snapshot);db.commit()
    try:
        actual_tab=tab
        if identity:
            from .models import SourceBinding,SourceSheet
            available=list(db.scalars(select(SourceSheet.tab_name).join(SourceBinding,SourceBinding.source_sheet_state_id==SourceSheet.id).where(
                SourceBinding.identity_id==identity['id'],SourceBinding.status=='VERIFIED',
                SourceSheet.is_available==True,SourceSheet.is_active==True)))
            if len(available)!=1:raise Issue('SOURCE_IDENTITY_UNAVAILABLE','Tab sumber tidak aktif/unik pada identitas yang diotorisasi.')
            actual_tab=available[0]
        if identity and hasattr(client,'indexed_source_day'):
            day = client.indexed_source_day(db,doc,actual_tab,run.selected_date,identity)
        else:
            day = client.source_day(doc['spreadsheet_id'],actual_tab,run.selected_date,doc['type'])
        if identity and day.grid.sheet_id!=identity['sheet_id']:
            raise Issue('SOURCE_IDENTITY_CHANGED','Sheet sumber berbeda dari identitas yang diotorisasi. Validasi ulang sumber.')
        payload = pack(day)
        size=len(json.dumps(payload,ensure_ascii=False,default=str).encode())
        if size>settings().source_snapshot_bytes:
            raise Issue('SNAPSHOT_RESOURCE_LIMIT','Snapshot satu tanggal melebihi batas penyimpanan aman; data tidak dipotong.')
        retained=db.scalar(select(func.coalesce(func.sum(SourceSnapshot.provenance['bytes'].as_integer()),0)).where(SourceSnapshot.run_id==run.id))
        if size+retained>settings().source_snapshot_run_bytes:
            raise Issue('SNAPSHOT_RESOURCE_LIMIT','Snapshot aktif Run melampaui batas penyimpanan aman; tidak ada ledger atau intent dihapus.')
        snapshot.payload,snapshot.checksum,snapshot.state = payload,fingerprint(payload),'SNAPSHOT_READY'
        snapshot.provenance = {**snapshot.provenance,'bytes':size,'actual_tab_name':actual_tab,'separator_row':day.start,'following_row':day.end+1}
        db.commit()
        return snapshot,day
    except Issue as error:
        snapshot.state = 'FAILED'
        snapshot.provenance = {**snapshot.provenance,'error':{'code':error.code,'message':error.message,'fix':error.fix,'context':error.context}}
        db.commit();raise
