"""Durable item scheduling; a single coordinator claims work at safe boundaries."""
from uuid import uuid4

from fastapi import HTTPException
from sqlalchemy import select, update

from .db import utcnow
from .models import RetryRequest, Run, RunItem, TaskError

OPEN=('QUEUED','CLAIMED')


def enqueue(db,run,item,user_id,kind='SOURCE_RETRY',key=None,details=None):
    old=db.scalar(select(RetryRequest).where(RetryRequest.run_item_id==item.id,RetryRequest.state.in_(OPEN)))
    if old:return old
    if key:
        old=db.scalar(select(RetryRequest).where(RetryRequest.idempotency_key==key))
        if old:
            if (old.run_id,old.run_item_id,old.kind)!=(run.id,item.id,kind):
                raise HTTPException(409,'Kunci permintaan sudah dipakai untuk tindakan lain.')
            return old
    request=RetryRequest(run_id=run.id,run_item_id=item.id,requested_by=user_id,kind=kind,
                         idempotency_key=key or str(uuid4()),details=details or {})
    db.add(request);db.flush()
    return request


def claim_next(db,run,blocked_item_ids=()):
    from .workflow import lock_date
    lock_date(db,run.selected_date)
    query=select(RetryRequest).where(RetryRequest.run_id==run.id,RetryRequest.state=='QUEUED')
    if blocked_item_ids:query=query.where(RetryRequest.run_item_id.notin_(blocked_item_ids))
    request=db.scalar(query.order_by(RetryRequest.id).limit(1))
    if not request:
        db.commit();return None
    changed=db.execute(update(RetryRequest).where(RetryRequest.id==request.id,RetryRequest.state=='QUEUED')
                       .values(state='CLAIMED',claimed_at=utcnow()))
    db.commit()
    if not changed.rowcount:return None
    db.refresh(request)
    return request


def complete(db,request):
    item=db.get(RunItem,request.run_item_id)
    request.state='SUCCEEDED' if item.status in ('SUCCESS','PREVIEWED') else 'FAILED'
    request.finished_at=utcnow();db.commit()


def cancel_open(db,run):
    from .models import DestinationConflict
    for request in db.scalars(select(RetryRequest).where(RetryRequest.run_id==run.id,RetryRequest.state.in_(OPEN))):
        if request.kind.startswith('CONFLICT_'):
            conflict=db.get(DestinationConflict,request.details.get('conflict_id'))
            if conflict and conflict.state in ('WRITE_PENDING','KEEP_PENDING'):conflict.state='OPEN'
    db.execute(update(RetryRequest).where(RetryRequest.run_id==run.id,RetryRequest.state.in_(OPEN))
               .values(state='CANCELED',finished_at=utcnow()))


def pending(db,run):
    return db.scalar(select(RetryRequest.id).where(RetryRequest.run_id==run.id,RetryRequest.state=='QUEUED')) is not None


def interrupted(db,run):
    # A claimed attempt may have reached Google. Do not auto-replay it. Other
    # explicitly requested QUEUED attempts survive for an operator-held Run.
    from .models import DestinationConflict
    for request in db.scalars(select(RetryRequest).where(RetryRequest.run_id==run.id,RetryRequest.state=='CLAIMED')):
        if request.kind.startswith('CONFLICT_'):
            conflict=db.get(DestinationConflict,request.details.get('conflict_id'))
            if conflict and conflict.state in ('WRITE_PENDING','KEEP_PENDING'):conflict.state='OPEN'
    db.execute(update(RetryRequest).where(RetryRequest.run_id==run.id,RetryRequest.state=='CLAIMED')
               .values(state='INTERRUPTED',finished_at=utcnow()))


def flag_dependents(db,run,item):
    from .models import AuditLog,SourceSnapshot
    snapshot_id=(item.result or {}).get('snapshot_id')
    current=db.get(SourceSnapshot,snapshot_id) if snapshot_id else None
    if current:
        related=[]
        for sibling in db.scalars(select(RunItem).where(RunItem.run_id==run.id,RunItem.id!=item.id,
                RunItem.source_document_id==item.source_document_id,RunItem.source_tab_name==item.source_tab_name,
                RunItem.status.in_(['SUCCESS','PREVIEWED']))):
            prior_id=(sibling.result or {}).get('snapshot_id')
            prior=db.get(SourceSnapshot,prior_id) if prior_id else None
            if prior and prior.checksum!=current.checksum:related.append(sibling.id)
        if related:
            notice={'retried_item_id':item.id,'successful_items_unchanged':related,'snapshot_id':current.id,
                    'message':'Sumber berubah saat retry. Item berhasil tetap menggunakan snapshot semula; tinjau perbedaan secara terpisah.'}
            snap=dict(run.config_snapshot)
            snap['source_retry_notices']=[*snap.get('source_retry_notices',[]),notice]
            run.config_snapshot=snap
            db.add(AuditLog(actor_id=run.started_by,action='retry_source_dependency_notice',entity_type='task_run_items',entity_id=str(item.id),details=notice))
    if item.metric_type!='expense_input':return
    total=db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type=='expense_total'))
    if total and total.status in ('SUCCESS','PREVIEWED') and not db.scalar(select(TaskError.id).where(
            TaskError.run_item_id==total.id,TaskError.error_code=='DEPENDENCY_STALE',TaskError.is_resolved==False)):
        db.add(TaskError(run_id=run.id,run_item_id=total.id,source_tab_name=total.source_tab_name,
            error_code='DEPENDENCY_STALE',human_message='Input BIAYA diperbarui; total yang sudah berhasil tidak dihitung ulang otomatis.',
            suggested_fix='Tinjau dan otorisasi retry total BIAYA secara terpisah.',
            technical_details={'changed_input_item_id':item.id}))
