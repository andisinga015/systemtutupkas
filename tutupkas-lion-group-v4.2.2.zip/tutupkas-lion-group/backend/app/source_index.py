from .telemetry import measured
"""A revision-bound date navigation index, never a financial value cache."""
from calendar import monthrange
from datetime import date, timedelta

from sqlalchemy import delete, select

from .engine.types import Cell, Issue
from .models import SourceDateIndex
from .source_reader import SourceReader


def revision(client, document, use_previous=False):
    if use_previous and document in getattr(client,'_verified_revisions',{}):
        return client._verified_revisions[document]
    method = getattr(client,'content_revision',None)
    return method(document) if method else None


def verified_revision(client,document,token):
    if token is not None:
        if not hasattr(client,'_verified_revisions'):client._verified_revisions={}
        client._verified_revisions[document]=token


class IndexedReader(SourceReader):
    def __init__(self,db,client,doc,title,selected,identity,token):
        super().__init__(client,doc['spreadsheet_id'],title,selected,doc['type'])
        self.db,self.identity,self.token = db,identity,token
        self.first_discovery = True
        self.indexed = None
        self.value_cache = {}

    def values(self,first,last,left,right,columns=None):
        if columns is not None or last-first+1 != self.chunk:
            yield from super().values(first,last,left,right,columns)
            return
        # Two nearby discovery bands fit at most 32 column ranges. The original
        # per-range boundary and scalar coordinate semantics are unchanged.
        key = first,last,left,right
        if key not in self.value_cache:
            self.value_cache.clear()
            width = right-left+1
            count = max(1,min(2,32//width))
            height = self.shape[0]
            tiles = [(r,min(height,r+self.chunk)-1,c) for r in range(first,min(height,first+count*self.chunk),self.chunk)
                     for c in range(left,right+1)]
            pending = [tiles]
            while pending:
                batch = pending.pop()
                try:
                    bands = self.client.values(self.document,[self.client.a1(self.title,r,end,c,c) for r,end,c in batch])
                except Issue as error:
                    if error.code!='RESPONSE_TOO_LARGE' or len(batch)==1:raise
                    half=len(batch)//2;pending.extend([batch[half:],batch[:half]]);continue
                if len(bands)!=len(batch):raise Issue('SOURCE_READ_FAILED','Rentang discovery sumber tidak lengkap.')
                for (r,end,c),band in zip(batch,bands):
                    rows=band.get('values',[])
                    if len(rows)>end-r+1 or any(len(row)>1 for row in rows):
                        raise Issue('SOURCE_READ_FAILED','Respons sumber melampaui rentang yang diminta.')
                    self.value_cache.setdefault((r,end,left,right),[]).extend(
                        (r+dr,c,row[0]) for dr,row in enumerate(rows) if row)
        yield from self.value_cache.get(key,[])

    @measured('source_date_discovery')
    def discover(self,height,width,first=0,all_numeric=False):
        if not self.first_discovery:
            return super().discover(height,width,first,all_numeric)
        self.first_discovery = False
        self.shape = height,width
        cached = list(self.db.scalars(select(SourceDateIndex).where(SourceDateIndex.identity_id==self.identity['id'],
                      SourceDateIndex.content_revision==self.token))) if self.token else []
        by_date = {row.selected_date:row for row in cached}
        wanted = (self.selected,self.selected+timedelta(days=1))
        if all(d in by_date and by_date[d].evidence.get('shape')==[height,width] for d in wanted):
            found = {}
            for d in wanted:
                row=by_date[d]
                raw=row.evidence['cell']
                cell=Cell(raw[0],raw[1],raw[2],tuple(raw[3]) if raw[3] is not None else None,raw[4])
                found[d]={row.separator_row:(row.separator_col,cell,row.evidence['merged'])}
            # SourceReader re-fetches both actual separators after payload reads.
            self.indexed = 'WARM'
            return found
        # Prove uniqueness for every calendar date in the selected monthly
        # source in one cold discovery, allowing forward/backward navigation.
        begin=date(self.selected.year,self.selected.month,1)-timedelta(days=1)
        dates={begin+timedelta(days=i) for i in range(monthrange(self.selected.year,self.selected.month)[1]+2)}
        self.target_dates=dates
        self.target_serials={(d-date(1899,12,30)).days for d in dates}
        found=super().discover(height,width,first,all_numeric)
        self.indexed='COLD'
        if self.token:
            self.db.execute(delete(SourceDateIndex).where(SourceDateIndex.identity_id==self.identity['id'],
                                                          SourceDateIndex.content_revision!=self.token))
            for d,positions in found.items():
                if len(positions)!=1:continue  # Never cache an ambiguous date.
                r,(c,cell,merged)=next(iter(positions.items()))
                following=found.get(d+timedelta(days=1),{})
                next_row,next_col=(next(iter(following)),next(iter(following.values()))[0]) if len(following)==1 else (None,None)
                if d in by_date:continue
                self.db.add(SourceDateIndex(identity_id=self.identity['id'],content_revision=self.token,selected_date=d,
                    separator_row=r,separator_col=c,following_row=next_row,following_col=next_col,
                    evidence={'shape':[height,width],'tab_name':self.title,'cell':[cell.value,cell.formula,cell.note,cell.color,cell.date_format],'merged':merged}))
            self.db.commit()
        return found


def indexed_source_day(db,client,doc,title,selected,identity):
    before=revision(client,doc['spreadsheet_id'],use_previous=True)
    reader=IndexedReader(db,client,doc,title,selected,identity,before)
    try:day=reader.read()
    except Issue:
        if hasattr(client,'_verified_revisions'):client._verified_revisions.pop(doc['spreadsheet_id'],None)
        if reader.indexed=='WARM':
            db.execute(delete(SourceDateIndex).where(SourceDateIndex.identity_id==identity['id']));db.commit()
        raise
    after=revision(client,doc['spreadsheet_id'])
    if before is not None and before!=after:
        if hasattr(client,'_verified_revisions'):client._verified_revisions.pop(doc['spreadsheet_id'],None)
        db.execute(delete(SourceDateIndex).where(SourceDateIndex.identity_id==identity['id']));db.commit()
        raise Issue('SOURCE_CHANGED','Dokumen sumber berubah selama snapshot; snapshot belum dianggap lengkap.')
    if day.grid.sheet_id!=identity['sheet_id']:
        raise Issue('SOURCE_IDENTITY_CHANGED','Identitas tab sumber berubah. Refresh dan validasi ulang sumber.')
    verified_revision(client,doc['spreadsheet_id'],after)
    return day
