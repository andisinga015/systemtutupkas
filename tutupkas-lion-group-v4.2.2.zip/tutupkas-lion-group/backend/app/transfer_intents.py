"""Source lineage and dynamic approved-slot allocation; no append API is used."""
import re
from sqlalchemy import select

from .db import utcnow
from .engine.resolver import BANKS
from .engine.types import Issue,Write,fingerprint
from .models import (AuditLog,LegacySourceLink,Run,RunItem,SourceIdentity,TransferLineage,TransferOwnership,WriteLedger)
from .source_authorization import document_for
from .config import settings


def coordinates(address):
    match=re.fullmatch(r'([A-Z]+)([1-9]\d*)',address)
    if not match:raise Issue('TRANSFER_OWNERSHIP_INVALID','Alamat slot historis tidak valid.')
    col=0
    for letter in match[1]:col=col*26+ord(letter)-64
    return int(match[2])-1,col-1


def identity_for(db,doc,tab):
    identity=doc.get('identities',{}).get(tab)
    if not identity:return None
    record=db.get(SourceIdentity,identity['id'])
    if not record or record.lineage!=identity['lineage']:
        raise Issue('SOURCE_IDENTITY_CHANGED','Identitas sumber tidak sesuai otorisasi item.')
    db.refresh(record)
    return {**identity,'names':record.names}


def history(db,run,item,doc):
    identity=identity_for(db,doc,item.source_tab_name)
    dest=run.config_snapshot['destination']
    records=[];creators={}
    query=select(TransferOwnership).join(RunItem,TransferOwnership.run_item_id==RunItem.id).join(Run,RunItem.run_id==Run.id).join(
        TransferLineage,TransferLineage.ownership_id==TransferOwnership.id,isouter=True).where(
        TransferOwnership.destination_document_id==dest['id'],TransferOwnership.destination_revision==dest['revision'],
        Run.website_id==run.website_id,Run.selected_date==run.selected_date,RunItem.source_document_id==item.source_document_id,
        (TransferLineage.state==None)|(TransferLineage.state!='RETIRED')).limit(settings().grid_chunk_cells//2+1)
    for n,owned in enumerate(db.scalars(query)):
        if n>=settings().grid_chunk_cells//2:
            raise Issue('TRANSFER_OWNERSHIP_RESOURCE_LIMIT','Ownership aktif satu item melebihi batas kelompok aman; tidak ada transaksi dilewati.')
        if owned.run_item_id not in creators:
            prior_item=db.get(RunItem,owned.run_item_id);prior_run=db.get(Run,prior_item.run_id)
            source=document_for(prior_run,prior_item) or {}
            prior_doc={key:source.get(key) for key in ('id','revision','spreadsheet_id','type')}
            prior_doc['identities']={prior_item.source_tab_name:source.get('identities',{}).get(prior_item.source_tab_name)}
            creators[owned.run_item_id]=(prior_item.source_tab_name,prior_doc,prior_run.id)
        prior_name,prior_doc,prior_run_id=creators[owned.run_item_id]
        state=db.get(TransferLineage,owned.id)
        if state and state.state=='RETIRED':continue
        prior_identity=prior_doc.get('identities',{}).get(prior_name)
        if state and state.source_identity_id:
            actual=db.get(SourceIdentity,state.source_identity_id)
            prior_lineage=actual.lineage if actual else None
        else:prior_lineage=prior_identity.get('lineage') if prior_identity else None
        link=db.get(LegacySourceLink,owned.run_item_id)
        linked=bool(link and identity and db.get(SourceIdentity,link.identity_id).lineage==identity['lineage'])
        same=bool(identity and prior_lineage==identity['lineage']) or linked
        # An explicit retry/resync may propose a correction across revisions,
        # but it must become a conflict, never an automatically appended row.
        explicit=bool(run.config_snapshot.get('authorized_previous_run_id')==prior_run_id or
                      run.config_snapshot.get('item_source_authorizations',{}).get(str(item.id)))
        if identity and not prior_lineage and not linked:
            raise Issue('LEGACY_LINEAGE_UNVERIFIED','Kiriman historis belum mempunyai bukti identitas tab.',
                'Tinjau histori dan konfirmasi lineage sumber secara eksplisit; robot tidak mengadopsi atau menggandakan transaksi lama.',prior_run_item_id=owned.run_item_id,source_identity_id=identity['id'])
        if not same:
            if (prior_name in (identity['names'] if identity else [item.source_tab_name]) or prior_name==item.source_tab_name) and explicit:
                same=True  # Corrective proposal only; allocate() forces a conflict.
            elif prior_name in (identity['names'] if identity else [item.source_tab_name]):
                raise Issue('SOURCE_IDENTITY_CHANGED','Nama rekening sama mempunyai identitas tab berbeda; ownership tidak dipindahkan otomatis.')
            else:continue
        if not identity and prior_name!=item.source_tab_name:continue
        records.append((owned,state,prior_doc,not (identity and prior_lineage==identity['lineage'] or linked)))
    return identity,records


def normalize(db,run,item,doc,transactions):
    identity=identity_for(db,doc,item.source_tab_name)
    canonical=identity['names'][0] if identity else item.source_tab_name
    rev=doc['revision']
    if identity:
        first=db.scalar(select(SourceIdentity).where(SourceIdentity.lineage==identity['lineage']).order_by(SourceIdentity.id))
        rev=first.source_revision_id
    other=bool(identity and any(i.lineage!=identity['lineage'] and set(i.names).intersection(identity['names'])
        for i in db.scalars(select(SourceIdentity).where(SourceIdentity.source_document_id==doc['id']))))
    normalized=[]
    _,previous=history(db,run,item,doc)
    proven={((state.pending_fingerprint or state.current_fingerprint) if state else owned.source_transaction_fingerprint):owned
            for owned,state,pdoc,changed in previous if not changed}
    variants={(pdoc.get('revision'),name) for owned,state,pdoc,changed in previous if not changed
              for name in (identity['names'] if identity else [item.source_tab_name])}
    if len(variants)>128:raise Issue('SOURCE_LINEAGE_RESOURCE_LIMIT','Variasi lineage historis melebihi batas pembuktian aman; diperlukan pemeriksaan administratif.')
    for n,tx in enumerate(transactions):
        if n%32==0:
            from .job_control import check_cancel
            check_cancel(db,run=run)
        row=dict(tx)
        row['note']=(f"{canonical} ( {row['description']} ) {row['amount']:,}".replace(',','.')) if doc['type']=='QRIS' else None
        fields=[run.website_id,str(run.selected_date),doc['id'],rev,canonical,row['row'],row['description'],row['amount']]
        row['fingerprint']=fingerprint(['source-lineage',identity['lineage'],*fields]) if other else fingerprint(fields)
        # Retain historical transaction tokens only after continuity was proved.
        # This also handles a same-file URL revision without re-owning a slot.
        candidates=[row['fingerprint']]
        for old_rev,name in variants:
            old_fields=[run.website_id,str(run.selected_date),doc['id'],old_rev,name,row['row'],row['description'],row['amount']]
            candidates.append(fingerprint(old_fields))
            if identity:candidates.append(fingerprint(['source-lineage',identity['lineage'],*old_fields]))
        for current in candidates:
            if current in proven:
                owned=proven[current];row['fingerprint']=current
                ledger=db.scalar(select(WriteLedger).where(WriteLedger.destination_document_id==run.config_snapshot['destination']['id'],
                    WriteLedger.destination_revision==run.config_snapshot['destination']['revision'],WriteLedger.destination_tab==owned.destination_tab,
                    WriteLedger.target_range==owned.description_cell))
                if ledger and doc['type']=='QRIS':row['note']=ledger.written_value.get('note','')
                break
        normalized.append(row)
    return normalized


def allocate(db,run,item,doc,grid,slots,transactions,reservations=None):
    """Return complete financial group and any required explicit replacements."""
    from .engine.writer import check_write
    identity,records=history(db,run,item,doc)
    reservations=reservations if reservations is not None else set()
    mapped={(bank,r,dc,ac) for bank in BANKS for r,dc,ac in slots[bank]}
    by_key={}
    for owned,state,prior_doc,changed_identity in records:
        key=state.pending_fingerprint or state.current_fingerprint if state else owned.source_transaction_fingerprint
        if key in by_key:raise Issue('TRANSFER_OWNERSHIP_AMBIGUOUS','Beberapa ownership mempunyai identitas transaksi yang sama.')
        by_key[key]=(owned,state,changed_identity)
    matches={};used=set()
    for n,tx in enumerate(transactions):
        found=by_key.get(tx['fingerprint'])
        if found and not found[2]:matches[n]=found[0];used.add(found[0].id)
    removed=[owned for owned,state,pdoc,changed in records if owned.id not in used]
    changed=bool(removed)
    writes,changes=[],[]
    occupied_this_group=set()
    def owned_slot(owned):
        r,dc=coordinates(owned.description_cell);ar,ac=coordinates(owned.amount_cell)
        if ar!=r or (owned.destination_bank,r,dc,ac) not in mapped:
            raise Issue('TRANSFER_OWNERSHIP_INVALID','Slot historis tidak termasuk registry yang disetujui; tidak dipindahkan otomatis.')
        return owned.destination_bank,r,dc,ac
    remaining=list(removed)
    for n,tx in enumerate(transactions):
        owned=matches.get(n)
        choices=[tx['bank']] if doc['type']=='DEPO' else list(BANKS)
        replacement=None
        if owned:
            bank,r,dc,ac=owned_slot(owned)
            if bank not in choices:raise Issue('TRANSFER_BANK_CHANGED','Bank sumber berubah; ownership lama tidak dialokasikan ke bank lain otomatis.')
            slot=(bank,r,dc,ac)
        else:
            replacement=next((o for bank in choices for o in remaining if o.destination_bank==bank),None)
            slot=owned_slot(replacement) if replacement else None
            if replacement:remaining.remove(replacement)
            if slot is None:
                dest=run.config_snapshot['destination']
                retired=db.scalar(select(TransferOwnership).join(TransferLineage,TransferLineage.ownership_id==TransferOwnership.id).where(
                    TransferOwnership.destination_document_id==dest['id'],TransferOwnership.destination_revision==dest['revision'],
                    TransferOwnership.source_transaction_fingerprint==tx['fingerprint'],TransferLineage.state=='RETIRED'))
                if retired:
                    state=db.get(TransferLineage,retired.id)
                    prior=db.get(SourceIdentity,state.source_identity_id) if state.source_identity_id else None
                    if not prior or not identity or prior.lineage!=identity['lineage']:
                        raise Issue('SOURCE_IDENTITY_CHANGED','Token kiriman lama tidak mempunyai lineage yang sama.')
                    occupied=db.scalar(select(TransferOwnership.id).join(TransferLineage,TransferLineage.ownership_id==TransferOwnership.id,isouter=True).where(
                        TransferOwnership.destination_document_id==dest['id'],TransferOwnership.destination_revision==dest['revision'],
                        TransferOwnership.destination_tab==retired.destination_tab,TransferOwnership.description_cell==retired.description_cell,
                        TransferOwnership.id!=retired.id,(TransferLineage.state==None)|(TransferLineage.state!='RETIRED')))
                    if occupied:raise Issue('TRANSFER_RETIRED_SLOT_REUSED','Slot historis telah dipakai ownership lain; tidak dibuat slot duplikat atau ditimpa otomatis.')
                    slot=owned_slot(retired);replacement=retired;changed=True
            if slot is None:
                for bank in choices:
                    for r,dc,ac in slots[bank]:
                        if (grid.title,r,dc) in reservations or (r,dc) in occupied_this_group:continue
                        dw=Write(grid.title,r,dc,tx['description'],tx['note'],bank,tx['fingerprint'])
                        aw=Write(grid.title,r,ac,tx['amount'])
                        try:check_write(db,run,item,grid,dw);check_write(db,run,item,grid,aw)
                        except Issue:continue
                        slot=(bank,r,dc,ac);break
                    if slot:break
                if slot is None:raise Issue('TRANSFER_SLOTS_FULL','Slot kiriman yang aman tidak tersedia pada bank yang diizinkan.')
        bank,r,dc,ac=slot
        if (r,dc) in occupied_this_group:raise Issue('TRANSFER_OWNERSHIP_AMBIGUOUS','Satu kelompok tidak boleh memilih slot yang sama dua kali.')
        occupied_this_group.add((r,dc));reservations.add((grid.title,r,dc))
        dw=Write(grid.title,r,dc,tx['description'],tx['note'],bank,tx['fingerprint'])
        if owned and doc['type']=='QRIS':
            # A proven rename retains the original already-approved Note.
            ledger=db.scalar(select(WriteLedger).where(WriteLedger.destination_document_id==run.config_snapshot['destination']['id'],
                WriteLedger.destination_revision==run.config_snapshot['destination']['revision'],WriteLedger.destination_tab==grid.title,
                WriteLedger.target_range==owned.description_cell))
            if ledger:dw.note=ledger.written_value.get('note','')
        writes.extend([dw,Write(grid.title,r,ac,tx['amount'])])
        if replacement:changes.append({'ownership_id':replacement.id,'new_fingerprint':tx['fingerprint'],'retire':False})
    for owned in remaining:
        bank,r,dc,ac=owned_slot(owned)
        writes.extend([Write(grid.title,r,dc,None,'',bank),Write(grid.title,r,ac,None)])
        changes.append({'ownership_id':owned.id,'new_fingerprint':None,'retire':True})
    return writes,changes,changed


def recoverable(db,run,item,writes,changes):
    from .engine.writer import get_ledger,owner_key
    if not changes:return False
    for change in changes:
        state=db.get(TransferLineage,change['ownership_id'])
        if (not state or state.state!='PREPARED_REPLACEMENT' or state.pending_fingerprint!=change['new_fingerprint'] or
            state.provenance.get('retire')!=change['retire']):return False
    for w in writes:
        ledger=get_ledger(db,run,w)
        if not ledger or ledger.verification_status!='PREPARED' or ledger.written_value!=w.proposed or ledger.owner_key!=owner_key(run,item):return False
    return True


def prepare(db,run,item,writes,changes=(),actor_id=None):
    """Persist lineage intent alongside PREPARED cell ledgers before POST."""
    dest=run.config_snapshot['destination'];doc=document_for(run,item) or {}
    identity=doc.get('identities',{}).get(item.source_tab_name)
    changed_by_key={change['new_fingerprint']:change for change in changes if not change['retire']}
    for change in changes:
        owned=db.get(TransferOwnership,change['ownership_id'])
        state=db.get(TransferLineage,owned.id)
        if state is None:
            state=TransferLineage(ownership_id=owned.id,current_fingerprint=owned.source_transaction_fingerprint)
            db.add(state)
        state.pending_fingerprint=change['new_fingerprint'];state.state='PREPARED_REPLACEMENT'
        state.provenance={**state.provenance,'pending_identity_id':identity['id'] if identity else None,
            'retire':change['retire'],'authorized_item_id':item.id,'actor_id':actor_id or run.started_by}
    for w in writes:
        if not w.transaction or not w.bank or w.transaction in changed_by_key:continue
        owned=db.scalar(select(TransferOwnership).join(TransferLineage,TransferLineage.ownership_id==TransferOwnership.id).where(
            TransferOwnership.destination_document_id==dest['id'],TransferOwnership.destination_revision==dest['revision'],
            TransferOwnership.destination_tab==w.tab,TransferOwnership.description_cell==w.address,TransferLineage.state!='RETIRED',
            (TransferLineage.current_fingerprint==w.transaction)|(TransferLineage.pending_fingerprint==w.transaction)))
        if owned is None:
            owned=db.scalar(select(TransferOwnership).where(TransferOwnership.destination_document_id==dest['id'],
                TransferOwnership.destination_revision==dest['revision'],TransferOwnership.source_transaction_fingerprint==w.transaction,
                TransferOwnership.destination_tab==w.tab,TransferOwnership.description_cell==w.address))
        if not owned:
            owned=TransferOwnership(run_item_id=item.id,source_transaction_fingerprint=w.transaction,destination_document_id=dest['id'],
                destination_revision=dest['revision'],destination_tab=w.tab,destination_bank=w.bank,description_cell=w.address,
                amount_cell=next(x.address for x in writes if x.row==w.row and x.col==w.col+1),note_cell=w.address)
            db.add(owned);db.flush()
        state=db.get(TransferLineage,owned.id)
        if state is None:
            db.add(TransferLineage(ownership_id=owned.id,current_fingerprint=None,pending_fingerprint=w.transaction,state='PREPARED_NEW',
                source_identity_id=identity['id'] if identity else None,provenance={'authorized_item_id':item.id,
                    'pending_identity_id':identity['id'] if identity else None,'retire':False,'actor_id':actor_id or run.started_by}))
        elif state.state=='RETIRED':
            state.pending_fingerprint=w.transaction;state.state='PREPARED_REPLACEMENT'
            state.provenance={**state.provenance,'pending_identity_id':identity['id'] if identity else None,'retire':False,'authorized_item_id':item.id,'actor_id':actor_id or run.started_by}
        elif state.state in ('PREPARED_NEW','PREPARED_REPLACEMENT') and state.pending_fingerprint==w.transaction:
            state.provenance={**state.provenance,'authorized_item_id':item.id,'actor_id':actor_id or run.started_by}


def verified(db,run,item,writes):
    dest=run.config_snapshot['destination']
    addresses={w.address for w in writes}
    rows=db.execute(select(TransferOwnership,TransferLineage).join(TransferLineage,TransferLineage.ownership_id==TransferOwnership.id).where(
        TransferOwnership.destination_document_id==dest['id'],TransferOwnership.destination_revision==dest['revision'],
        TransferLineage.state.in_(['PREPARED_NEW','PREPARED_REPLACEMENT'])))
    for owned,state in rows:
        if owned.description_cell not in addresses or state.provenance.get('authorized_item_id')!=item.id:continue
        before=state.current_fingerprint
        state.current_fingerprint=state.pending_fingerprint
        state.source_identity_id=state.provenance.get('pending_identity_id')
        state.pending_fingerprint=None;state.state='RETIRED' if state.provenance.get('retire') else 'ACTIVE'
        db.add(AuditLog(actor_id=state.provenance.get('actor_id',run.started_by),action='transfer_lineage_verified',
            entity_type='transfer_slot_ownership',entity_id=str(owned.id),details={'previous':before,'current':state.current_fingerprint,'state':state.state,'run_item_id':item.id}))


def retain(db,run,item,writes,observed):
    addresses={w.address for w in writes};actual={o['cell']:{k:o[k] for k in ('value','formula','note')} for o in observed}
    dest=run.config_snapshot['destination']
    rows=db.execute(select(TransferOwnership,TransferLineage).join(TransferLineage,TransferLineage.ownership_id==TransferOwnership.id).where(
        TransferOwnership.destination_document_id==dest['id'],TransferOwnership.destination_revision==dest['revision'],
        TransferLineage.state.in_(['PREPARED_NEW','PREPARED_REPLACEMENT'])))
    for owned,state in rows:
        if owned.description_cell not in addresses or state.provenance.get('authorized_item_id')!=item.id:continue
        ledgers=[db.scalar(select(WriteLedger).where(WriteLedger.destination_document_id==dest['id'],WriteLedger.destination_revision==dest['revision'],
                    WriteLedger.destination_tab==owned.destination_tab,WriteLedger.target_range==address)) for address in (owned.description_cell,owned.amount_cell)]
        exact=all(l and actual.get(l.target_range)==l.written_value for l in ledgers)
        if exact:
            state.current_fingerprint=state.pending_fingerprint
            state.source_identity_id=state.provenance.get('pending_identity_id')
            state.state='RETIRED' if state.provenance.get('retire') else 'ACTIVE'
        else:
            state.state='RETIRED' if state.current_fingerprint is None else 'RETAINED'
        state.pending_fingerprint=None
        state.provenance={**state.provenance,'retained_observed':[o for o in observed if o['cell'] in (owned.description_cell,owned.amount_cell)],'retained_by_item_id':item.id}
