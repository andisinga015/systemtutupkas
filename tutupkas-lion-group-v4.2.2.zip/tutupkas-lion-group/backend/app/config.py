from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="TK_", env_file=".env", extra="ignore")
    database_url: str = "sqlite:///./data/tutupkas.sqlite3"
    credential_file: str = "/home/aksesfinancebot/spreadsheet-robot/credentials/robot-key.json"
    app_origin: str = "https://tutupkasliongroup.com"
    cookie_secure: bool = True
    session_hours: int = 8
    request_timeout: int = 45
    api_retries: int = 4
    google_min_interval: float = 1.2
    worker_poll_seconds: float = 2
    worker_lock: str = "./data/worker.lock"
    transfer_palette_file: str = "./data/transfer-palette.json"
    max_sheet_cells: int = 2_000_000
    source_chunk_rows: int = Field(200, ge=1, le=250)
    source_scan_columns: int = Field(16, ge=1, le=32)
    max_source_scan_cells: int = Field(2_000_000, ge=1, le=10_000_000)
    max_source_day_cells: int = Field(100_000, ge=1, le=250_000)
    max_destination_cells: int = Field(250_000, ge=1, le=250_000)
    grid_chunk_cells: int = Field(8_000, ge=1, le=16_000)
    max_api_response_bytes: int = Field(8_388_608, ge=65536, le=8_388_608)
    destination_batch_cells: int = Field(64_000, ge=16_000, le=64_000)
    destination_index_bytes: int = Field(67_108_864, ge=1_048_576, le=134_217_728)
    source_snapshot_bytes: int = Field(8_388_608, ge=65_536, le=8_388_608)
    source_snapshot_run_bytes: int = Field(67_108_864,ge=8_388_608,le=67_108_864)
    destination_mapping_targets: int = Field(250_000, ge=100, le=250_000)
    reconciliation_attempts: int = 3
    reconciliation_delay: float = 1


@lru_cache
def settings() -> Settings:
    return Settings()


def ensure_data_dir():
    url = settings().database_url
    if url.startswith("sqlite:///") and url != "sqlite:///:memory:":
        Path(url[10:]).parent.mkdir(parents=True, exist_ok=True, mode=0o700)

