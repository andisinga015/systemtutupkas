"""Whole-group administrator decisions, queued for the sole financial writer."""
from dataclasses import asdict

from fastapi import HTTPException
from sqlalchemy import select

from .db import utcnow
from .destination_reader import close_view
from .engine.types import Issue, Write, fingerprint
from .job_control import check_cancel
from .models import AuditLog, ConflictDecision, DestinationConflict, Run, RunItem, TaskError, WriteLedger


def retained_snapshot(db,ledger):
    from .models import RetainedCell
    record=db.get(RetainedCell,ledger.id)
    if not record:return None
    choice=db.get(ConflictDecision,record.decision_id);conflict=db.get(DestinationConflict,record.conflict_id)
    if (not choice or choice.action!='KEEP' or not conflict or conflict.state!='RESOLVED' or
        fingerprint(record.snapshot)!=record.checksum):return None
    return record.snapshot


def retained_decision(db,client,run,item,grid,writes):
    """A verified KEEP remains effective for the same unchanged logical intent."""
    candidates=(select(DestinationConflict).join(RunItem,DestinationConflict.run_item_id==RunItem.id)
        .join(Run,DestinationConflict.run_id==Run.id).where(Run.website_id==run.website_id,Run.selected_date==run.selected_date,
            RunItem.source_document_id==item.source_document_id,RunItem.metric_type==item.metric_type,
            DestinationConflict.mapping_id==run.config_snapshot.get('mapping_id'),DestinationConflict.state=='RESOLVED')
        .order_by(DestinationConflict.id.desc()))
    last=None
    while True:
        old=db.scalar(candidates.where(DestinationConflict.id<last) .limit(1) if last else candidates.limit(1))
        if old is None:break
        last=old.id
        choice=db.scalar(select(ConflictDecision).where(ConflictDecision.conflict_id==old.id).order_by(ConflictDecision.id.desc()))
        if not choice or choice.action!='KEEP':continue
        previous=db.get(RunItem,old.run_item_id)
        from .source_authorization import document_for
        identity=(document_for(run,item) or {}).get('identities',{}).get(item.source_tab_name)
        prior_identity=old.provenance.get('source_identity')
        if identity and prior_identity:
            if identity['lineage']!=prior_identity['lineage']:continue
        elif previous.source_tab_name!=item.source_tab_name:continue
        if len(writes)!=len(old.writes):continue
        candidate=[asdict(w) for w in writes]
        for raw,prior in zip(candidate,old.writes):
            if raw['note'] is None:raw['note']=prior['note']
        if candidate!=old.writes:continue
        actual=observe(db,client,run,grid,writes)
        if [{k:v for k,v in row.items() if k!='ledger'} for row in actual]!=[{k:v for k,v in row.items() if k!='ledger'} for row in old.observed]:continue
        return {'verified':not run.preview,'retained_existing':True,'retained_decision_id':choice.id,
                'plan':[{'tab':w.tab,'cell':w.address,'existing':{k:a[k] for k in ('value','formula','note')},
                         'proposed':{k:a[k] for k in ('value','formula','note')},'bank':w.bank}
                        for w,a in zip(writes,actual)]}
    return None


def observe(db,client,run,grid,writes):
    from .engine.writer import get_ledger
    fresh=grid.refresh() if hasattr(grid,'refresh') else client.grid(run.config_snapshot['destination']['spreadsheet_id'],grid.title)
    try:
        import json
        from .config import settings
        rows=[];size=0
        for first in range(0,len(writes),32):
            chunk=writes[first:first+32]
            if hasattr(fresh,'prefetch'):fresh.prefetch([(w.row,w.col) for w in chunk])
            for w in chunk:
                ledger=get_ledger(db,run,w)
                prior_item=db.get(RunItem,ledger.run_item_id) if ledger else None
                observed={'tab':w.tab,'row':w.row,'col':w.col,'cell':w.address,**fresh.cell(w.row,w.col).snapshot,
                    'ledger':({'id':ledger.id,'owner_key':ledger.owner_key,'status':ledger.verification_status,
                        'written_value':ledger.written_value,'previous_managed_value':ledger.previous_managed_value,
                        'run_item_id':ledger.run_item_id,'source_tab':prior_item.source_tab_name if prior_item else None,
                        'source_document_id':prior_item.source_document_id if prior_item else None} if ledger else None)}
                size+=len(json.dumps(observed,ensure_ascii=False,default=str).encode())
                if size>settings().max_api_response_bytes:raise Issue('CONFLICT_RESOURCE_LIMIT','Data konflik aktual melampaui batas kelompok aman; tidak ada nilai dilewati atau ditimpa.')
                rows.append(observed)
        return rows
    finally:close_view(fresh)


def observation_hash(run,writes,observed):
    return fingerprint([run.config_snapshot['destination'],run.config_snapshot.get('mapping_id'),writes,observed])


def open_conflict(db,client,run,item,grid,writes,issue,provenance):
    if not writes:return None
    observed=observe(db,client,run,grid,writes)
    # Value-only corrections retain unrelated Notes. Explicit QRIS Note changes
    # remain visible and are checked again by the writer.
    for w,old in zip(writes,observed):
        if w.note is None:w.note=old['note']
    encoded=[asdict(w) for w in writes]
    from .models import MappedResult,SourceSnapshot
    snapshot=db.get(SourceSnapshot,provenance.get('snapshot_id')) if provenance.get('snapshot_id') else None
    if snapshot and (snapshot.state not in ('SNAPSHOT_READY','MAPPED') or fingerprint(snapshot.payload)!=snapshot.checksum):
        raise Issue('SNAPSHOT_CORRUPT','Snapshot konflik belum lengkap atau integritasnya berubah.')
    if snapshot:snapshot.state='MAPPED'
    db.add(MappedResult(run_item_id=item.id,snapshot_id=snapshot.id if snapshot else None,
        retry_request_id=snapshot.retry_request_id if snapshot else None,mapping_id=run.config_snapshot.get('mapping_id'),
        writes=encoded,provenance=provenance,checksum=fingerprint([encoded,provenance])))
    previous=db.scalar(select(DestinationConflict).where(DestinationConflict.run_item_id==item.id,
                        DestinationConflict.state.in_(['OPEN','WRITE_PENDING','KEEP_PENDING'])))
    if previous:
        if previous.state!='OPEN':raise Issue('CONFLICT_DECISION_PENDING','Keputusan konflik sedang diantrikan; jangan membuat koreksi lain.')
        previous.state='SUPERSEDED';db.flush()
    conflict=DestinationConflict(run_id=run.id,run_item_id=item.id,mapping_id=run.config_snapshot.get('mapping_id'),
        reason=issue.code,writes=encoded,observed=observed,observation_hash=observation_hash(run,encoded,observed),
        provenance={**provenance,'website':run.config_snapshot['website'],'selected_date':str(run.selected_date),
                    'destination':run.config_snapshot['destination'],'preview':run.preview,'observed_at':utcnow().isoformat()})
    db.add(conflict);db.flush()
    db.add(AuditLog(actor_id=run.started_by,action='destination_conflict_observed',entity_type=conflict.__tablename__,
                    entity_id=str(conflict.id),details={'reason':issue.code,'writes':encoded,'observed':observed}))
    db.commit()
    return conflict


def queue_decision(db,conflict,user,action,expected_hash,key):
    from .destination_registry import assert_current
    from .retry_queue import enqueue
    from .workflow import assert_available,is_clear,is_current_run,lock_date,monthly_destination
    run=db.get(Run,conflict.run_id)
    lock_date(db,run.selected_date);db.refresh(conflict);db.refresh(run)
    old=db.scalar(select(ConflictDecision).where(ConflictDecision.idempotency_key==key))
    if old:
        if (old.conflict_id,old.action,old.observation_hash)!=(conflict.id,action,expected_hash):
            raise HTTPException(409,'Kunci keputusan dipakai untuk pilihan lain.')
        return old
    if conflict.state!='OPEN':raise HTTPException(409,'Konflik sudah diputuskan atau keputusan masih diproses.')
    if expected_hash!=conflict.observation_hash:raise HTTPException(409,'Tampilan konflik sudah berubah. Baca ulang nilai Google.')
    if action not in ('NEW','KEEP'):raise HTTPException(422,'Tindakan konflik tidak dikenal.')
    if action=='NEW' and run.preview:raise HTTPException(409,'Pratinjau tidak mengotorisasi penulisan. Buat penarikan mode tulis secara eksplisit.')
    if action=='NEW' and any(cell['formula'] is not None for cell in conflict.observed):
        raise HTTPException(409,'Formula dilindungi dan tidak dapat diganti melalui keputusan konflik.')
    if action=='NEW' and conflict.reason=='MERGED_CELL_CONFLICT':
        raise HTTPException(409,'Area merged dilindungi; keputusan tidak mengizinkan perubahan struktur.')
    assert_available(db,run.selected_date,run.website_id,allow_run=run.id,allow_batch=run.batch_id)
    if run.status=='CANCEL_REQUESTED':raise HTTPException(409,'Tunggu pembatalan selesai.')
    dest=monthly_destination(db,run.selected_date,validated=True)
    if is_clear(db,run.selected_date,dest):raise HTTPException(409,'Buka kembali tanggal Clear sebelum koreksi.')
    from .source_authorization import authorized_source_is_current
    if action=='NEW' and not (is_current_run(db,run,dest) or authorized_source_is_current(db,run,db.get(RunItem,conflict.run_item_id))):
        raise HTTPException(409,'Konfigurasi sumber berubah. Buat otorisasi baru; persetujuan lama tidak dipindahkan.')
    assert_current(db,run)
    item=db.get(RunItem,conflict.run_item_id)
    request=enqueue(db,run,item,user.id,kind='CONFLICT_'+action,key=key,details={'conflict_id':conflict.id,'observation_hash':expected_hash})
    if request.kind!='CONFLICT_'+action or request.details.get('conflict_id')!=conflict.id:
        raise HTTPException(409,'Item mempunyai retry lain yang belum selesai.')
    decision=ConflictDecision(conflict_id=conflict.id,retry_request_id=request.id,actor_id=user.id,action=action,
                              observation_hash=expected_hash,idempotency_key=key)
    db.add(decision)
    conflict.state='WRITE_PENDING' if action=='NEW' else 'KEEP_PENDING'
    if run.status not in ('RUNNING','QUEUED'):
        run.status,run.current_phase,run.finished_at='QUEUED','DECISION_QUEUED',None
        run.cancel_requested_at,run.cancel_requested_by=None,None
    db.flush()
    db.add(AuditLog(actor_id=user.id,action='conflict_decision_authorized',entity_type=decision.__tablename__,
                    entity_id=str(decision.id),details={'action':action,'observation_hash':expected_hash,'conflict_id':conflict.id}))
    return decision


def apply_decision(db,client,run,request):
    from .destination_registry import RegistryView,assert_current
    from .engine.runner import error,success
    from .engine.writer import execute
    conflict=db.get(DestinationConflict,request.details['conflict_id'])
    item=db.get(RunItem,request.run_item_id)
    decision=db.scalar(select(ConflictDecision).where(ConflictDecision.retry_request_id==request.id))
    if conflict:db.refresh(conflict)
    db.refresh(item)
    if not conflict or not decision or conflict.state not in ('WRITE_PENDING','KEEP_PENDING'):
        raise Issue('CONFLICT_NOT_ACTIONABLE','Keputusan konflik tidak lagi aktif.')
    writes=[Write(**w) for w in conflict.writes]
    view=RegistryView(db,client,run,writes[0].tab)
    try:
        assert_current(db,run)
        if conflict.provenance.get('snapshot_id'):
            from .models import SourceSnapshot
            snapshot=db.get(SourceSnapshot,conflict.provenance['snapshot_id'])
            if not snapshot or snapshot.state not in ('SNAPSHOT_READY','MAPPED') or fingerprint(snapshot.payload)!=snapshot.checksum:
                raise Issue('SNAPSHOT_CORRUPT','Integritas sumber keputusan tidak sesuai. Buat retry item dengan data mentah baru.')
        actual=observe(db,client,run,view,writes)
        if actual!=conflict.observed or observation_hash(run,conflict.writes,actual)!=decision.observation_hash:
            conflict.state,conflict.observed='OPEN',actual
            conflict.observation_hash=observation_hash(run,conflict.writes,actual)
            conflict.provenance={**conflict.provenance,'observed_at':utcnow().isoformat()}
            db.commit()
            raise Issue('STALE_CONFLICT_APPROVAL','Nilai tujuan berubah setelah ditampilkan; persetujuan lama ditolak. Tinjau konflik terbaru.')
        if decision.action=='NEW':
            if run.preview:raise Issue('PREVIEW_WRITE_FORBIDDEN','Pratinjau tidak boleh menulis melalui keputusan konflik.')
            result=execute(db,client,run,item,view,writes,approval=conflict,
                           cancel_check=lambda:check_cancel(db,run=run))
        else:
            result={'verified':True,'retained_existing':True,'conflict_id':conflict.id,
                'plan':[{'tab':w.tab,'cell':w.address,'existing':{'value':a['value'],'formula':a['formula'],'note':a['note']},
                         'proposed':{'value':a['value'],'formula':a['formula'],'note':a['note']},'bank':w.bank}
                        for w,a in zip(writes,actual)]}
            from .engine.writer import get_ledger,owner_key
            for w,a in zip(writes,actual):
                ledger=get_ledger(db,run,w)
                if ledger and not run.preview and ledger.owner_key==owner_key(run,item):
                    current={key:a[key] for key in ('value','formula','note')}
                    ledger.verification_status='VERIFIED' if current==ledger.written_value else 'RETAINED'
                    from .models import RetainedCell
                    record=db.get(RetainedCell,ledger.id)
                    if record is None:
                        db.add(RetainedCell(ledger_id=ledger.id,decision_id=decision.id,conflict_id=conflict.id,snapshot=current,checksum=fingerprint(current)))
                    else:
                        record.decision_id,record.conflict_id,record.snapshot,record.checksum,record.recorded_at=decision.id,conflict.id,current,fingerprint(current),utcnow()
            if item.metric_type=='transfers' and not run.preview:
                from .transfer_intents import retain
                retain(db,run,item,writes,actual)
        conflict.state,conflict.resolved_at='RESOLVED',utcnow()
        db.add(AuditLog(actor_id=decision.actor_id,action='conflict_decision_verified' if decision.action=='NEW' else 'conflict_keep_verified',
            entity_type=decision.__tablename__,entity_id=str(decision.id),details={'conflict_id':conflict.id,'action':decision.action,'observed':actual,'result':result}))
        success(db,item,{**conflict.provenance,**result,'conflict_id':conflict.id},run.preview)
        from .retry_queue import flag_dependents
        flag_dependents(db,run,item)
        db.commit()
        return result
    except Issue as issue:
        db.refresh(conflict)
        if conflict.state in ('WRITE_PENDING','KEEP_PENDING'):conflict.state='OPEN'
        error(db,run,item,issue);raise
    finally:close_view(view)
