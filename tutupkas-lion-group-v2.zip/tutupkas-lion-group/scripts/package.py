"""Make a source + prebuilt asset ZIP, explicitly excluding all runtime state."""
from pathlib import Path
import hashlib
import zipfile

root = Path(__file__).resolve().parents[1]
target = root.parent / 'tutupkas-lion-group-v2.zip'
excluded = {'.git', '.venv', 'node_modules', '__pycache__', '.pytest_cache', 'data', 'dist',
            'test-results', 'playwright-report', 'coverage'}
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as package:
    for path in sorted(root.rglob('*')):
        rel = path.relative_to(root)
        if not path.is_file() or any(p in excluded for p in rel.parts) or path.name in ('tsconfig.tsbuildinfo', 'robot-key.json', 'credentials.json') or path.name.startswith('.env'):
            continue
        if path.suffix in ('.sqlite', '.sqlite3', '.db', '.log', '.pid', '.zip', '.pyc', '.pem', '.key', '.p12', '.pfx'):
            continue
        package.write(path, 'tutupkas-lion-group/' + rel.as_posix())
    for path in sorted((root / 'frontend/dist').rglob('*')):
        if path.is_file():
            package.write(path, 'tutupkas-lion-group/public/' + path.relative_to(root / 'frontend/dist').as_posix())
digest = hashlib.sha256(target.read_bytes()).hexdigest()
target.with_suffix('.zip.sha256').write_text(f'{digest}  {target.name}\n')
print(f'{target} ({target.stat().st_size:,} bytes)')
print(f'SHA256: {digest}')

