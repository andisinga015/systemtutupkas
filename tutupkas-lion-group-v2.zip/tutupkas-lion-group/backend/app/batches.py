"""Penarikan semua WEB dan pemeriksaan ulang, satu website setiap saat."""
from fastapi import HTTPException
from sqlalchemy import select

from .db import utcnow
from .engine.runner import process_run
from .models import BatchEntry, CrawlBatch, Reconciliation, Run, Website
from .reconciliation import last_reconciliation, reconcile_consolidated, reconcile_website
from .workflow import (assert_available, context_signature, create_run, current_source_signature, destination_snapshot,
                       is_clear, latest_current_run, lock_date, make_snapshot, monthly_destination,
                       processing_complete, required_websites, website_context)


def enqueue_batch(db, selected, preview, key, user_id, recheck=False, run=None):
    lock_date(db, selected)
    old = db.scalar(select(CrawlBatch).where(CrawlBatch.idempotency_key == key))
    if old:
        if old.selected_date != selected or old.preview != preview or old.recheck_only != recheck or (run is not None and old.required_websites != [{'id': run.website_id, 'name': run.config_snapshot['website']}]):
            raise HTTPException(409, 'Kunci permintaan dipakai untuk operasi lain.')
        return old
    assert_available(db, selected)
    dest = monthly_destination(db, selected, validated=True)
    if is_clear(db, selected, dest):
        raise HTTPException(409, 'Tanggal sudah Clear. Buka kembali sebelum menjalankan koreksi.')
    websites = [db.get(Website, run.website_id)] if run else required_websites(db)
    if not websites and not recheck:
        raise HTTPException(409, 'Tidak ada WEB aktif untuk diproses.')
    batch = CrawlBatch(selected_date=selected, preview=preview, recheck_only=recheck, idempotency_key=key,
        started_by=user_id, required_websites=[{'id': w.id, 'name': w.display_name} for w in websites],
        destination_snapshot=destination_snapshot(dest))
    db.add(batch)
    db.flush()
    for position, website in enumerate(websites):
        current = run if run and run.website_id == website.id else latest_current_run(db, website.id, selected, dest)
        if recheck:
            if not current or not processing_complete(db, current):
                if run:
                    raise HTTPException(409, 'Selesaikan pemrosesan sumber sebelum memeriksa ulang saldo.')
                continue
            chosen, reused = current, True
            db.add(Reconciliation(selected_date=selected, website_id=website.id, run_id=current.id,
                batch_id=batch.id, destination_document_id=dest.id, destination_revision=dest.revision,
                context_signature=website_context(db, current), kind='WEBSITE', status='IN_PROGRESS',
                human_message='Pemeriksaan ulang saldo sedang diantrikan.', details={}))
        else:
            reused = False
            try:
                snapshot = make_snapshot(db, website.id, selected, dest)
                chosen = create_run(db, website.id, selected, preview, f'batch:{batch.id}:{website.id}', user_id, snapshot, batch.id)
            except HTTPException as e:
                snapshot = {'website': website.display_name, 'registered': [w.display_name for w in websites],
                    'sources': [], 'aliases': {}, 'destination': destination_snapshot(dest), 'palette': {}}
                chosen = create_run(db, website.id, selected, preview, f'batch:{batch.id}:{website.id}', user_id,
                                    snapshot, batch.id, str(e.detail))
        db.add(BatchEntry(batch_id=batch.id, website_id=website.id, position=position, run_id=chosen.id, reused=reused))
    return batch


def process_batch(db, batch, client=None, should_stop=lambda: False):
    batch.status = 'RUNNING'
    db.commit()
    entries = list(db.scalars(select(BatchEntry).where(BatchEntry.batch_id == batch.id).order_by(BatchEntry.position)))
    for entry in entries:
        if should_stop():
            return
        if entry.status not in ('WAITING', 'RUNNING'):
            continue
        entry.status = 'RUNNING'
        db.commit()
        run = db.get(Run, entry.run_id)
        if batch.recheck_only:
            dest = monthly_destination(db, batch.selected_date)
            from .workflow import is_current_run
            if not is_current_run(db, run, dest):
                entry.status = 'FAILED'
                db.add(Reconciliation(selected_date=run.selected_date, website_id=run.website_id, run_id=run.id,
                    batch_id=batch.id, destination_document_id=batch.destination_snapshot['id'],
                    destination_revision=batch.destination_snapshot['revision'], context_signature=website_context(db, run),
                    kind='WEBSITE', status='ERROR', error_code='CONFIGURATION_CHANGED',
                    human_message='Konfigurasi berubah. Jalankan Crawl Ulang ke URL Baru atau penarikan baru.', details={}))
                db.commit()
                continue
            reconcile_website(db, run, client)
        elif run.status in ('QUEUED', 'RUNNING'):
            process_run(db, run, client)
        elif processing_complete(db, run) and not last_reconciliation(db, run_id=run.id):
            # Crash after a verified write but before the report read: no replay.
            reconcile_website(db, run, client)
        entry.status = run.status if not batch.recheck_only else 'SUCCESS'
        db.commit()
    if not batch.preview:
        reconcile_consolidated(db, batch.selected_date, client, batch.id)
    states = [e.status for e in entries]
    failed = any(s in ('FAILED', 'PARTIAL') for s in states)
    batch.status = ('PARTIAL' if any(s in ('SUCCESS', 'PREVIEWED') for s in states) else 'FAILED') if failed else (
                   'PREVIEWED' if batch.preview else 'SUCCESS')
    batch.finished_at = utcnow()
    db.commit()


def batch_progress(db, batch):
    entries = list(db.scalars(select(BatchEntry).where(BatchEntry.batch_id == batch.id).order_by(BatchEntry.position)))
    result = []
    for entry in entries:
        run = db.get(Run, entry.run_id)
        reco = last_reconciliation(db, run_id=run.id)
        result.append({'website_id': entry.website_id, 'website': db.get(Website, entry.website_id).display_name,
            'run_id': run.id, 'status': entry.status, 'processing_status': run.status,
            'reconciliation_status': reco.status if reco else 'WAITING', 'balance': reco.balance if reco else None,
            'reused': entry.reused})
    return {'id': batch.id, 'selected_date': batch.selected_date, 'preview': batch.preview,
        'recheck_only': batch.recheck_only, 'status': batch.status, 'destination': batch.destination_snapshot,
        'total': len(entries), 'processed': sum(e.status not in ('WAITING','RUNNING') for e in entries),
        'current_website': next((r['website'] for r in result if r['status'] == 'RUNNING'), None),
        'success': sum(r['reconciliation_status'] == 'BALANCED' and r['status'] == 'SUCCESS' for r in result),
        'written': sum(r['processing_status'] == 'SUCCESS' for r in result),
        'not_balanced': sum(r['reconciliation_status'] == 'NOT_BALANCED' for r in result),
        'failed': sum(r['status'] in ('FAILED','PARTIAL') for r in result),
        'waiting': sum(r['status'] == 'WAITING' for r in result), 'entries': result}
