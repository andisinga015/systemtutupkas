"""Konfigurasi bulanan, snapshot dan antrean Tutup Kas All Web."""
import json
from pathlib import Path

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.dialects.sqlite import insert

from .config import settings
from .db import utcnow
from .engine.types import fingerprint
from .models import (AccountAlias, BatchEntry, CrawlBatch, DayGate, Destination, FinalClearance,
                     MonthlyDestination, Run, RunItem, SourceDocument, SourceSheet, TaskError, Website, WriteLedger)

ACTIVE = ('QUEUED', 'RUNNING')


def lock_date(db, selected):
    # Every start/batch/retry takes the same SQLite write gate BEFORE checking
    # conflicts. This closes the cross-table individual-vs-batch race.
    db.execute(insert(DayGate).values(selected_date=selected, version=1).on_conflict_do_update(
        index_elements=['selected_date'], set_={'version': DayGate.version + 1}))


def monthly_destination(db, selected, validated=False):
    binding = db.scalar(select(MonthlyDestination).where(MonthlyDestination.year == selected.year,
                                                        MonthlyDestination.month == selected.month))
    if not binding:
        legacy = list(db.scalars(select(Destination).where(Destination.year == selected.year,
                                                          Destination.month == selected.month)))
        if len(legacy) == 1:
            # Supports databases created by model metadata as well as migrations.
            binding = MonthlyDestination(year=selected.year, month=selected.month, destination_document_id=legacy[0].id)
            db.add(binding)
            db.flush()
        else:
            raise HTTPException(409, 'Pilih dan simpan satu URL Kas Semua Web untuk bulan terpilih, lalu validasi. Konfigurasi lama tetap tersimpan.')
    dest = db.get(Destination, binding.destination_document_id)
    if validated and dest.validation_status != 'VALID':
        raise HTTPException(409, 'Tujuan bulan terpilih belum dikonfigurasi dan divalidasi.')
    return dest


def destination_snapshot(dest):
    return {'id': dest.id, 'revision': dest.revision, 'spreadsheet_id': dest.spreadsheet_id,
            'title': dest.spreadsheet_title}


def source_configuration(db, website_id, selected):
    result = []
    docs = db.scalars(select(SourceDocument).where(SourceDocument.website_id == website_id,
        SourceDocument.year == selected.year, SourceDocument.month == selected.month).order_by(SourceDocument.document_type))
    for doc in docs:
        tabs = list(db.scalars(select(SourceSheet.tab_name).where(SourceSheet.source_revision_id == doc.active_revision_id,
            SourceSheet.is_active == True, SourceSheet.is_available == True).order_by(SourceSheet.tab_name)))
        result.append({'id': doc.id, 'type': doc.document_type, 'revision': doc.active_revision_id,
                       'spreadsheet_id': doc.spreadsheet_id, 'title': doc.spreadsheet_title,
                       'tabs': tabs, 'validation_status': doc.validation_status})
    aliases = {a.source_name: a.destination_header for a in db.scalars(select(AccountAlias).where(AccountAlias.website_id == website_id))}
    return result, aliases


def source_signature(sources, aliases):
    return fingerprint({'sources': sorted([{'id': d['id'], 'type': d['type'], 'revision': d['revision'],
        'spreadsheet_id': d['spreadsheet_id'], 'tabs': sorted(d['tabs'])} for d in sources], key=lambda d: d['id']),
        'aliases': aliases})


def current_source_signature(db, website_id, selected):
    return source_signature(*source_configuration(db, website_id, selected))


def run_source_signature(run):
    return source_signature(run.config_snapshot.get('sources', []), run.config_snapshot.get('aliases', {}))


def required_websites(db):
    return list(db.scalars(select(Website).where(Website.is_active == True, Website.is_archived == False).order_by(Website.id)))


def context_signature(db, selected, dest):
    return fingerprint({'destination': [dest.id, dest.revision], 'websites': [
        [w.id, w.display_name, current_source_signature(db, w.id, selected)] for w in required_websites(db)]})


def website_context(db, run):
    return fingerprint([run.website_id, run.config_snapshot.get('website'), str(run.selected_date),
                        run.config_snapshot['destination'], run_source_signature(run)])


def is_current_run(db, run, dest):
    d = run.config_snapshot.get('destination', {})
    website = db.get(Website, run.website_id)
    return (d.get('id') == dest.id and d.get('revision') == dest.revision
            and d.get('spreadsheet_id') == dest.spreadsheet_id
            and run_source_signature(run) == current_source_signature(db, run.website_id, run.selected_date)
            and website is not None and run.config_snapshot.get('website') == website.display_name)


def latest_current_run(db, website_id, selected, dest):
    runs = db.scalars(select(Run).where(Run.website_id == website_id, Run.selected_date == selected,
                                      Run.preview == False).order_by(Run.id.desc()))
    return next((r for r in runs if is_current_run(db, r, dest)), None)


def is_clear(db, selected, dest):
    return db.scalar(select(FinalClearance).where(FinalClearance.selected_date == selected,
        FinalClearance.destination_document_id == dest.id, FinalClearance.destination_revision == dest.revision,
        FinalClearance.context_signature == context_signature(db, selected, dest), FinalClearance.is_clear == True))


def assert_available(db, selected, website_id=None, allow_batch=None, allow_run=None):
    batch = db.scalar(select(CrawlBatch).where(CrawlBatch.selected_date == selected, CrawlBatch.status.in_(ACTIVE),
                                            CrawlBatch.id != (allow_batch or -1)))
    if batch:
        raise HTTPException(409, 'Penarikan Semua WEB pada tanggal ini masih berjalan.')
    query = select(Run.id).where(Run.selected_date == selected, Run.status.in_(ACTIVE), Run.id != (allow_run or -1))
    if website_id is not None:
        query = query.where(Run.website_id == website_id)
    if db.scalar(query):
        raise HTTPException(409, 'Pekerjaan yang bertabrakan pada tanggal ini masih berjalan.')


def make_snapshot(db, website_id, selected, dest=None, check_clear=True):
    website = db.get(Website, website_id)
    if not website or not website.is_active or website.is_archived:
        raise HTTPException(409, 'WEB tidak aktif.')
    dest = dest or monthly_destination(db, selected, validated=True)
    if dest.validation_status != 'VALID':
        raise HTTPException(409, 'Tujuan bulan terpilih belum divalidasi.')
    if check_clear and is_clear(db, selected, dest):
        raise HTTPException(409, 'Tanggal sudah Selesai & Clear. Buka kembali dengan alasan untuk melakukan koreksi.')
    sources, aliases = source_configuration(db, website_id, selected)
    if not sources:
        raise HTTPException(409, 'URL sumber bulan terpilih belum dikonfigurasi.')
    for doc in sources:
        if doc['validation_status'] != 'VALID':
            raise HTTPException(409, f"DOC {doc['type']} belum divalidasi.")
    if not any(d['tabs'] for d in sources):
        raise HTTPException(409, 'Tidak ada sheet aktif untuk diproses.')
    path = Path(settings().transfer_palette_file)
    try:
        palette = json.loads(path.read_text()) if path.is_file() else {}
    except (OSError, ValueError):
        raise HTTPException(409, 'Palet kiriman tidak dapat dibaca.')
    return {'website': website.display_name, 'registered': list(db.scalars(select(Website.display_name).order_by(Website.id))),
            'sources': sources, 'destination': destination_snapshot(dest), 'aliases': aliases, 'palette': palette,
            'source_signature': source_signature(sources, aliases),
            'engine_revision': fingerprint({p.name: p.read_text() for p in sorted((Path(__file__).parent/'engine').glob('*.py'))})}


def create_run(db, website_id, selected, preview, key, user_id, snapshot, batch_id=None, readiness_error=None):
    run = Run(website_id=website_id, selected_date=selected, year=selected.year, month=selected.month,
              environment='WORKING', preview=preview, idempotency_key=key, started_by=user_id,
              config_snapshot=snapshot, batch_id=batch_id, status='FAILED' if readiness_error else 'QUEUED')
    db.add(run)
    db.flush()
    if readiness_error:
        item = RunItem(run_id=run.id, source_tab_name='Konfigurasi WEB', metric_type='configuration',
                       source_date=selected, status='FAILED')
        db.add(item)
        db.flush()
        db.add(TaskError(run_id=run.id, run_item_id=item.id, source_tab_name=item.source_tab_name,
                        error_code='CONFIGURATION_NOT_READY', human_message=readiness_error,
                        technical_details={'website': snapshot['website'], 'selected_date': str(selected)},
                        suggested_fix='Periksa sumber, validasi URL dan aktifkan sheet, lalu gunakan Ulangi WEB Gagal.'))
        run.finished_at = utcnow()
        return run
    for doc in snapshot['sources']:
        for tab in doc['tabs']:
            metrics = ['deposit', 'withdrawal', 'balance', 'transfers']
            if doc['type'] == 'DEPO':
                metrics.append('expense_input')
            elif tab.strip().upper() in ('QRIS QRIZZ', 'QRIS E-POWER'):
                metrics += ['qris_expense', 'qris_fee']
            for metric in metrics:
                db.add(RunItem(run_id=run.id, source_document_id=doc['id'], source_tab_name=tab,
                               metric_type=metric, source_date=selected))
    if any(d['type'] == 'DEPO' and d['tabs'] for d in snapshot['sources']):
        db.add(RunItem(run_id=run.id, source_tab_name='Semua DOC DEPO', metric_type='expense_total', source_date=selected))
    return run


def processing_complete(db, run):
    if run.preview or run.status != 'SUCCESS':
        return False
    items = list(db.scalars(select(RunItem).where(RunItem.run_id == run.id, RunItem.metric_type != 'reconciliation')))
    if not items or any(i.status != 'SUCCESS' for i in items):
        return False
    if any(i.result and 'plan' in i.result and not i.result.get('verified') for i in items):
        return False
    if db.scalar(select(WriteLedger.id).join(RunItem, WriteLedger.run_item_id == RunItem.id).where(
            RunItem.run_id == run.id, WriteLedger.verification_status != 'VERIFIED')):
        return False
    return not db.scalar(select(TaskError.id).join(RunItem, TaskError.run_item_id == RunItem.id).where(
        TaskError.run_id == run.id, TaskError.is_resolved == False, RunItem.metric_type != 'reconciliation'))
