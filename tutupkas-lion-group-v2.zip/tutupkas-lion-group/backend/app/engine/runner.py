import logging
from pathlib import Path

from sqlalchemy import select

from ..db import utcnow
from ..models import RunItem, TaskError, TransferOwnership, Run, Destination
from ..sheets import SheetsClient
from . import resolver
from .parser import Day, header, transfer_rows
from .types import Issue, Write, column, fingerprint, norm
from .writer import check_write, execute

logger = logging.getLogger('tutupkas.worker')


def error(db, run, item, issue):
    item.status, item.processed_at = 'FAILED', utcnow()
    existing = db.scalar(select(TaskError).where(TaskError.run_item_id == item.id, TaskError.is_resolved == False))
    if not existing:
        existing = TaskError(run_id=run.id, run_item_id=item.id, source_document_id=item.source_document_id,
                             source_tab_name=item.source_tab_name, error_code=issue.code,
                             human_message=issue.message, suggested_fix=issue.fix, technical_details=issue.context)
        db.add(existing)
    else:
        existing.error_code, existing.human_message = issue.code, issue.message
        existing.suggested_fix, existing.technical_details = issue.fix, issue.context
    db.commit()


def success(db, item, result, preview):
    item.status, item.result, item.processed_at = 'PREVIEWED' if preview else 'SUCCESS', result, utcnow()
    for err in db.scalars(select(TaskError).where(TaskError.run_item_id == item.id, TaskError.is_resolved == False)):
        err.is_resolved, err.resolved_at = True, utcnow()
    db.commit()


def process_run(db, run: Run, client=None):
    run.status = 'RUNNING'
    db.commit()
    items = list(db.scalars(select(RunItem).where(RunItem.run_id == run.id,
                                                RunItem.metric_type != 'reconciliation').order_by(RunItem.id)))
    snap = run.config_snapshot
    source_cache, destination_cache = {}, {}
    planned: dict[int, tuple] = {}
    reservations = set()
    doc_by_id = {d['id']: d for d in snap['sources']}
    current_revision = fingerprint({p.name: p.read_text() for p in sorted(Path(__file__).parent.glob('*.py'))})
    if snap.get('engine_revision') and snap['engine_revision'] != current_revision:
        for item in items:
            if item.status == 'PENDING':
                error(db, run, item, Issue('ENGINE_CHANGED', 'Versi engine berubah setelah pekerjaan diantrikan.',
                      'Jalankan pratinjau dan penarikan baru sebelum menulis dengan versi aplikasi ini.'))
        finish(db, run, items)
        return
    try:
        client = client or SheetsClient()
    except Issue as issue:
        for item in items:
            if item.status == 'PENDING':
                error(db, run, item, issue)
        finish(db, run, items)
        return

    def source(doc, tab):
        key = (doc['id'], tab)
        if key not in source_cache:
            # Metrics are contiguous per tab. Retain only the current source
            # grid instead of accumulating every active sheet in RAM.
            source_cache.clear()
            try:
                source_cache[key] = Day.resolve(client.grid(doc['spreadsheet_id'], tab), run.selected_date)
            except Issue as e:
                source_cache[key] = e
        v = source_cache[key]
        if isinstance(v, Issue):
            raise v
        return v

    def target(tab):
        if tab not in destination_cache:
            destination_cache[tab] = client.grid(snap['destination']['spreadsheet_id'], tab)
        return destination_cache[tab]

    def regular(tab, item, value):
        grid = target(tab)
        return grid, [resolver.regular(grid, snap['website'], snap['registered'], run.selected_date,
                                      item.source_tab_name, value, snap['aliases'].get(item.source_tab_name, ''))]

    # Process DEPO ahead of QRIS, then the dependent aggregate. Successful inputs
    # remain in the DB and are reused on retries without a new source read.
    ordered = sorted(items, key=lambda i: (i.metric_type == 'expense_total',
                                          doc_by_id.get(i.source_document_id, {}).get('type') == 'QRIS', i.id))
    for item in ordered:
        if item.status != 'PENDING':
            continue
        context = {"selected_date": str(run.selected_date), "website": snap['website'],
                   "source_tab": item.source_tab_name, "module": item.metric_type,
                   "destination_title": snap['destination'].get('title')}
        try:
            if item.metric_type == 'expense_total':
                inputs = [i for i in items if i.metric_type == 'expense_input']
                if not inputs or any(i.status not in ('SUCCESS', 'PREVIEWED') for i in inputs):
                    raise Issue('AGGREGATE_INCOMPLETE', 'Total BIAYA menunggu seluruh input DOC DEPO berhasil.',
                                'Perbaiki item biaya sumber yang gagal; total akan dihitung ulang dari input tersimpan.')
                value = abs(sum(i.result['signed_value'] for i in inputs))
                grid = target('BIAYA')
                writes = [resolver.labeled(grid, snap['website'], snap['registered'], run.selected_date, 'BIAYA', value)]
            else:
                doc = doc_by_id[item.source_document_id]
                context.update({"source_title": doc['title'], "document_type": doc['type'],
                                "expected_date": str(run.selected_date)})
                day = source(doc, item.source_tab_name)
                context['closing_row'] = day.end + 1
                if item.metric_type in ('deposit', 'withdrawal', 'balance'):
                    labels = {'deposit': 'Total' if doc['type'] == 'DEPO' else 'Total Depo',
                              'withdrawal': 'Total WD', 'balance': 'SALDO'}
                    label = labels[item.metric_type]
                    value = day.metric(label)
                    context['source_cell'] = f'{item.source_tab_name}!{column(header(day.grid, label))}{day.end + 1}'
                    tabs = {'deposit': 'TOTAL DEPO', 'withdrawal': 'TOTAL WD', 'balance': 'SALDO BANK'}
                    grid, writes = regular(tabs[item.metric_type], item, value)
                elif item.metric_type == 'expense_input':
                    if header(day.grid, 'DLL') != 7:
                        raise Issue('HEADER_MISMATCH', 'Kolom biaya DOC DEPO harus H (DLL); struktur berbeda.')
                    success(db, item, {"signed_value": day.signed_sum(7), **context}, run.preview)
                    continue
                elif item.metric_type == 'qris_expense':
                    if header(day.grid, 'DLL') != 6:
                        raise Issue('HEADER_MISMATCH', 'Kolom biaya DOC QRIS harus G (DLL); struktur berbeda.')
                    value = abs(day.signed_sum(6))
                    grid = target('BIAYA')
                    label = 'BIAYA TARIK QRIS' if norm(item.source_tab_name) == 'QRIS QRIZZ' else 'BIAYA AUTO WD'
                    writes = [resolver.labeled(grid, snap['website'], snap['registered'], run.selected_date, label, value)]
                elif item.metric_type == 'qris_fee':
                    is_depo = norm(item.source_tab_name) == 'QRIS QRIZZ'
                    description, value = day.fees('FEE QRIS PERIODE' if is_depo else 'FEE WD AUTO')
                    grid = target('Pengeluaran FEE QRIS DEPO' if is_depo else 'Pengeluaran FEE QRIS WD')
                    writes = resolver.fees(grid, snap['website'], snap['registered'], run.selected_date,
                                           'FEE QRIS DEPO' if is_depo else 'FEE QRIS WD', description, value)
                elif item.metric_type == 'transfers':
                    transactions = transfer_rows(day, doc['type'], snap.get('palette', {}))
                    if not transactions:
                        previous = db.scalar(select(TransferOwnership.id).join(RunItem, TransferOwnership.run_item_id == RunItem.id)
                            .join(Run, RunItem.run_id == Run.id).where(
                                TransferOwnership.destination_document_id == snap['destination']['id'],
                                TransferOwnership.destination_revision == snap['destination']['revision'],
                                Run.website_id == run.website_id, Run.selected_date == run.selected_date,
                                RunItem.source_document_id == item.source_document_id,
                                RunItem.source_tab_name == item.source_tab_name))
                        if previous:
                            raise Issue('TRANSFER_IDENTITY_CHANGED', 'Kiriman lama milik robot tidak lagi ditemukan pada sumber.',
                                        'Tinjau sumber dan kepemilikan slot. Robot tidak menghapus transaksi lama secara otomatis.')
                        success(db, item, {"transfers": 0, "verified": not run.preview, **context}, run.preview)
                        continue
                    grid = target('KET PENGIRIMAN')
                    slots = resolver.transfer_slots(grid, snap['website'], snap['registered'], run.selected_date)
                    writes = []
                    transaction_ids = []
                    for tx in transactions:
                        tf = fingerprint([run.website_id, str(run.selected_date), doc['id'], doc['revision'],
                                          item.source_tab_name, tx['row'], tx['description'], tx['amount']])
                        transaction_ids.append(tf)
                        owned = db.scalar(select(TransferOwnership).where(
                            TransferOwnership.destination_document_id == snap['destination']['id'],
                            TransferOwnership.destination_revision == snap['destination']['revision'],
                            TransferOwnership.source_transaction_fingerprint == tf))
                        previous_tf = ''
                        previous_run = db.get(Run, snap.get('authorized_previous_run_id')) if snap.get('authorized_previous_run_id') else None
                        if not owned and previous_run and previous_run.website_id == run.website_id and previous_run.selected_date == run.selected_date:
                            prior_doc = next((d for d in previous_run.config_snapshot.get('sources', []) if d['id'] == doc['id']), None)
                            if prior_doc:
                                # Explicit source resync can adopt the exact same transaction
                                # in its verified old slot. Changed row/description/amount is
                                # still a conflict, never an append or deletion.
                                prior_tf = fingerprint([run.website_id, str(run.selected_date), prior_doc['id'], prior_doc['revision'],
                                                        item.source_tab_name, tx['row'], tx['description'], tx['amount']])
                                owned = db.scalar(select(TransferOwnership).where(
                                    TransferOwnership.destination_document_id == snap['destination']['id'],
                                    TransferOwnership.destination_revision == snap['destination']['revision'],
                                    TransferOwnership.source_transaction_fingerprint == prior_tf))
                                if owned:
                                    previous_tf = prior_tf
                                    transaction_ids.append(prior_tf)
                        choices = [tx['bank']] if doc['type'] == 'DEPO' else list(resolver.BANKS)
                        slot = None
                        for bank in choices:
                            for r, dc, ac in slots[bank]:
                                desc_write = Write(grid.title, r, dc, tx['description'], tx['note'], bank, tf, previous_tf)
                                nominal_write = Write(grid.title, r, ac, tx['amount'])
                                if owned and desc_write.address != owned.description_cell:
                                    continue
                                if (grid.title, r, dc) in reservations:
                                    continue
                                try:
                                    check_write(db, run, item, grid, desc_write)
                                    check_write(db, run, item, grid, nominal_write)
                                except Issue:
                                    if owned:
                                        raise
                                    continue
                                slot = [desc_write, nominal_write]
                                break
                            if slot:
                                break
                        if not slot:
                            raise Issue('TRANSFER_SLOTS_FULL', 'Slot kiriman yang aman tidak tersedia pada bank yang diizinkan.')
                        reservations.add((grid.title, slot[0].row, slot[0].col))
                        writes.extend(slot)
                    # Changed/removed source transactions cannot be silently duplicated.
                    old_ids = list(db.scalars(select(TransferOwnership.source_transaction_fingerprint).join(
                        RunItem, TransferOwnership.run_item_id == RunItem.id).join(Run, RunItem.run_id == Run.id).where(
                        TransferOwnership.destination_document_id == snap['destination']['id'],
                        TransferOwnership.destination_revision == snap['destination']['revision'],
                        Run.website_id == run.website_id, Run.selected_date == run.selected_date,
                        RunItem.source_document_id == item.source_document_id,
                        RunItem.source_tab_name == item.source_tab_name)))
                    if set(old_ids) - set(transaction_ids):
                        raise Issue('TRANSFER_IDENTITY_CHANGED', 'Transaksi kiriman milik robot berubah atau berpindah baris.',
                                    'Tinjau sumber dan slot lama. Identitas yang berubah perlu direkonsiliasi; robot tidak menambahkan duplikat.')
                else:
                    raise Issue('MODULE_UNSUPPORTED', 'Modul pemrosesan tidak dikenal.')
            for w in writes:
                check_write(db, run, item, grid, w)
            planned[item.id] = (grid, writes, context)
        except Issue as e:
            e.context = {**context, **e.context}
            error(db, run, item, e)
        except Exception as e:
            logger.error('{"event":"planning_error","run_id":%s,"type":"%s"}', run.id, type(e).__name__)
            error(db, run, item, Issue('INTERNAL_ERROR', 'Pemrosesan item terhenti. Periksa konfigurasi dan log layanan.', **context))

    collisions = {}
    for item_id, (_, writes, _) in planned.items():
        for w in writes:
            collisions.setdefault((w.tab, w.row, w.col), set()).add(item_id)
    conflicting = set().union(*(v for v in collisions.values() if len(v) > 1)) if collisions else set()
    for item in ordered:
        if item.id not in planned:
            continue
        grid, writes, context = planned[item.id]
        if item.id in conflicting:
            error(db, run, item, Issue('DUPLICATE_DESTINATION', 'Beberapa sumber memetakan sel tujuan yang sama.', **context))
            continue
        try:
            result = execute(db, client, run, item, grid, writes)
            success(db, item, {**result, **context}, run.preview)
        except Issue as e:
            e.context = {**context, **e.context}
            error(db, run, item, e)
        except Exception as e:
            db.rollback()
            logger.error('{"event":"write_error","run_id":%s,"type":"%s"}', run.id, type(e).__name__)
            error(db, run, item, Issue('WRITE_FAILURE', 'Penulisan belum dapat diverifikasi. Gunakan Crawl Ulang untuk rekonsiliasi.', **context))
    finish(db, run, items, client)


def finish(db, run, items, client=None):
    failed = sum(i.status == 'FAILED' for i in items)
    successful = sum(i.status in ('SUCCESS', 'PREVIEWED') for i in items)
    run.status = ('PARTIAL' if successful else 'FAILED') if failed else ('PREVIEWED' if run.preview else 'SUCCESS')
    if not items:
        run.status = 'FAILED'
    run.finished_at = utcnow()
    db.commit()
    if not run.preview and db.get(Destination,
                                  run.config_snapshot.get('destination', {}).get('id')):
        from ..reconciliation import reconcile_website, reconcile_consolidated
        from fastapi import HTTPException
        reconcile_website(db, run, client)
        try:
            reconcile_consolidated(db, run.selected_date, client, run.batch_id)
        except HTTPException:
            # An ambiguous legacy monthly destination still requires an admin
            # selection. The completed run and original destination are retained.
            pass

