"""Rekonsiliasi persisten; laporan Google hanya dibaca dengan GET."""
import time
from decimal import Decimal

from fastapi import HTTPException
from sqlalchemy import select

from .config import settings
from .db import utcnow
from .engine.report import REPORT, resolve_balance
from .engine.types import Issue
from .models import Reconciliation, Run, RunItem, TaskError, Website
from .sheets import SheetsClient
from .workflow import (context_signature, is_current_run, latest_current_run, monthly_destination,
                       processing_complete, required_websites, website_context)


def last_reconciliation(db, *, run_id=None, signature=None, kind='WEBSITE', selected=None):
    query = select(Reconciliation).where(Reconciliation.kind == kind)
    if run_id is not None:
        query = query.where(Reconciliation.run_id == run_id)
    if signature is not None:
        query = query.where(Reconciliation.context_signature == signature)
    if selected is not None:
        query = query.where(Reconciliation.selected_date == selected)
    return db.scalar(query.order_by(Reconciliation.id.desc()))


def fresh_balance(client, destination, selected, website, registered):
    attempts = max(2, min(settings().reconciliation_attempts, 5))
    previous_zero = False
    last_issue, result = None, None
    for attempt in range(attempts):
        try:
            # No grid cache: each observation is a fresh Google calculated value.
            grid = client.grid(destination['spreadsheet_id'], REPORT)
            result = resolve_balance(grid, selected, website, registered)
            zero = Decimal(result['balance']) == 0
            if zero and previous_zero:
                return result
            previous_zero, last_issue = zero, None
        except Issue as issue:
            previous_zero, last_issue = False, issue
        if attempt+1 < attempts:
            time.sleep(settings().reconciliation_delay)
    if last_issue:
        raise last_issue
    if result and Decimal(result['balance']) == 0:
        raise Issue('REPORT_NOT_STABLE', 'Hasil BALANCE belum stabil dalam batas pembacaan ulang.',
                    'Tunggu formula spreadsheet selesai diperbarui, lalu Periksa Ulang Rekonsiliasi.')
    return result


def record_error(db, run, issue, result=None):
    item = db.scalar(select(RunItem).where(RunItem.run_id == run.id, RunItem.metric_type == 'reconciliation'))
    if not item:
        item = RunItem(run_id=run.id, source_tab_name=REPORT, metric_type='reconciliation', source_date=run.selected_date)
        db.add(item)
        db.flush()
    errors = list(db.scalars(select(TaskError).where(TaskError.run_item_id == item.id, TaskError.is_resolved == False)))
    if not issue:
        item.status, item.result = 'SUCCESS', result
        for e in errors:
            e.is_resolved, e.resolved_at = True, utcnow()
    else:
        item.status = 'FAILED'
        context = {'website': run.config_snapshot['website'], 'selected_date': str(run.selected_date),
            'destination_title': run.config_snapshot['destination'].get('title'), 'destination_tab': REPORT,
            'run_id': run.id, 'expected': '0', **issue.context}
        if errors:
            error = errors[0]
            error.error_code, error.human_message, error.technical_details = issue.code, issue.message, context
            error.suggested_fix = issue.fix
        else:
            db.add(TaskError(run_id=run.id, run_item_id=item.id, source_tab_name=REPORT, error_code=issue.code,
                human_message=issue.message, suggested_fix=issue.fix, technical_details=context))
    item.processed_at = utcnow()


def reconcile_website(db, run, client=None):
    dest = run.config_snapshot['destination']
    status, result, issue = 'INCOMPLETE', None, None
    if processing_complete(db, run):
        try:
            client = client or SheetsClient()
            result = fresh_balance(client, dest, run.selected_date, run.config_snapshot['website'], run.config_snapshot['registered'])
            status = 'BALANCED' if Decimal(result['balance']) == 0 else 'NOT_BALANCED'
            if status == 'NOT_BALANCED':
                issue = Issue('WEBSITE_NOT_BALANCED', f"Kas {run.config_snapshot['website'].title()} tidak klop Bagian {REPORT}",
                              'Periksa selisih pada laporan dan sumber. Jangan mengubah formula untuk memaksa nol; setelah koreksi, Periksa Ulang Rekonsiliasi.',
                              actual_balance=result['balance'], difference=result['balance'], cell=result['cell'])
        except Issue as e:
            status, issue = 'ERROR', e
        record_error(db, run, issue, result)
    elif not run.preview:
        # Clear previous green reconciliation when a later selective retry fails.
        status = 'INCOMPLETE'
    record = Reconciliation(selected_date=run.selected_date, website_id=run.website_id, run_id=run.id,
        batch_id=run.batch_id, destination_document_id=dest['id'], destination_revision=dest['revision'],
        context_signature=website_context(db, run), kind='WEBSITE', status=status,
        balance=result['balance'] if result else None, cell=result['cell'] if result else None,
        error_code=issue.code if issue else None, human_message=issue.message if issue else
            ('KLOP' if status == 'BALANCED' else 'Pemrosesan sumber dan verifikasi tulisan belum lengkap.'),
        details=result or {})
    db.add(record)
    db.commit()
    return record


def date_overview(db, selected):
    try:
        dest = monthly_destination(db, selected)
    except HTTPException as e:
        return {'selected_date': selected, 'destination': None, 'websites': [], 'consolidated': None,
                'status': 'WAITING', 'pending_websites': [], 'eligible': False, 'message': e.detail, 'is_clear': False}
    signature = context_signature(db, selected, dest)
    rows, pending = [], []
    for w in required_websites(db):
        run = latest_current_run(db, w.id, selected, dest)
        historical = db.scalar(select(Run).where(Run.website_id == w.id, Run.selected_date == selected,
                                               Run.preview == False).order_by(Run.id.desc()))
        reconciliation = last_reconciliation(db, run_id=run.id, signature=website_context(db, run)) if run else None
        complete = bool(run and processing_complete(db, run))
        sync = historical is not None and run is None
        if not complete:
            pending.append(w.display_name)
        rows.append({'website_id': w.id, 'website': w.display_name, 'run_id': run.id if run else None,
            'historical_run_id': historical.id if historical else None,
            'processing_status': run.status if run else ('SYNC_REQUIRED' if sync else 'WAITING'),
            'reconciliation_status': reconciliation.status if reconciliation and complete else 'WAITING',
            'balance': reconciliation.balance if reconciliation and complete else None,
            'cell': reconciliation.cell if reconciliation and complete else None,
            'requires_sync': sync, 'complete': complete,
            'error_count': len(list(db.scalars(select(TaskError.id).where(TaskError.run_id == run.id,
                TaskError.is_resolved == False)))) if run else 0})
    consolidated = last_reconciliation(db, signature=signature, kind='CONSOLIDATED', selected=selected)
    if pending or not rows:
        status = 'IN_PROGRESS' if any(r['processing_status'] in ('QUEUED','RUNNING') for r in rows) else 'WAITING'
    elif any(r['reconciliation_status'] == 'ERROR' for r in rows):
        status = 'ERROR'
    elif any(r['reconciliation_status'] == 'NOT_BALANCED' for r in rows):
        status = 'NOT_BALANCED'
    elif any(r['reconciliation_status'] != 'BALANCED' for r in rows):
        status = 'IN_PROGRESS' if any(r['reconciliation_status'] == 'IN_PROGRESS' for r in rows) else 'WAITING'
    else:
        status = consolidated.status if consolidated else 'WAITING'
    all_zero = bool(rows) and all(r['complete'] and r['reconciliation_status'] == 'BALANCED' and r['error_count'] == 0 for r in rows)
    from .workflow import is_clear
    eligible = all_zero and not pending and consolidated is not None and consolidated.status == 'BALANCED'
    return {'selected_date': selected, 'destination': {'id': dest.id, 'revision': dest.revision, 'title': dest.spreadsheet_title},
        'websites': rows, 'consolidated': ({'id': consolidated.id, 'status': consolidated.status, 'balance': consolidated.balance,
            'cell': consolidated.cell, 'message': consolidated.human_message} if consolidated else None),
        'status': status, 'pending_websites': pending, 'eligible': eligible, 'context_signature': signature,
        'is_clear': bool(is_clear(db, selected, dest)), 'message': 'Menunggu website lain: '+', '.join(pending) if pending else ''}


def reconcile_consolidated(db, selected, client=None, batch_id=None):
    dest = monthly_destination(db, selected)
    overview = date_overview(db, selected)
    snapshot = {'id': dest.id, 'revision': dest.revision, 'spreadsheet_id': dest.spreadsheet_id}
    status, result, issue = 'WAITING', None, None
    if overview['websites'] and not overview['pending_websites']:
        try:
            client = client or SheetsClient()
            result = fresh_balance(client, snapshot, selected, None, list(db.scalars(select(Website.display_name))))
            status = 'BALANCED' if Decimal(result['balance']) == 0 else 'NOT_BALANCED'
            if status == 'NOT_BALANCED':
                issue = Issue('CONSOLIDATED_NOT_BALANCED', f'Kas seluruh website tidak klop Bagian {REPORT}',
                              actual_balance=result['balance'], difference=result['balance'], cell=result['cell'])
        except Issue as e:
            status, issue = 'ERROR', e
    record = Reconciliation(selected_date=selected, batch_id=batch_id,
        destination_document_id=dest.id, destination_revision=dest.revision,
        context_signature=overview['context_signature'], kind='CONSOLIDATED', status=status,
        balance=result['balance'] if result else None, cell=result['cell'] if result else None,
        error_code=issue.code if issue else None, human_message=issue.message if issue else
            ('KLOP' if status == 'BALANCED' else overview['message'] or 'Menunggu seluruh website selesai.'),
        details={**(result or {}), 'pending_websites': overview['pending_websites']})
    db.add(record)
    db.commit()
    return record

