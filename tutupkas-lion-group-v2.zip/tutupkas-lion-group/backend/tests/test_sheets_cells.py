import pytest

from app.engine.types import Cell, Issue, Write
from app.sheets import google_cell, spreadsheet_id


def test_empty_string_roundtrip_is_equivalent_but_formula_stays_protected():
    assert google_cell({}).snapshot == Write('fee',1,1,'').proposed
    cell=google_cell({'userEnteredValue':{'formulaValue':'=""'},'effectiveValue':{'stringValue':''}})
    assert not cell.empty
    assert cell.formula=='=""'


def test_real_cell_metadata_keeps_zero_note_date_and_resolved_color():
    cell=google_cell({'effectiveValue':{'numberValue':0},'note':'manual',
                     'effectiveFormat':{'numberFormat':{'type':'DATE'},'backgroundColorStyle':{'rgbColor':{'red':1,'green':.6}}}})
    assert cell.value==0 and not cell.empty
    assert cell.color==(1.,.6,0.) and cell.date_format and cell.note=='manual'


@pytest.mark.parametrize('url',[
    'http://docs.google.com/spreadsheets/d/abc123456789012345/edit',
    'https://docs.google.com.evil.example/spreadsheets/d/abc123456789012345/edit',
    'https://user:password@docs.google.com/spreadsheets/d/abc123456789012345/edit',
    'https://docs.google.com/not-a-sheet',
])
def test_url_cannot_redirect_credentialed_requests(url):
    with pytest.raises(Issue):
        spreadsheet_id(url)



def test_report_write_rejected_before_http():
    import pytest
    from app.sheets import SheetsClient
    from app.engine.types import Grid, Write, Issue
    client=object.__new__(SheetsClient)
    calls=[]
    client.request=lambda *args,**kwargs:calls.append(args)
    with pytest.raises(Issue) as error:
        client.write('destination',Grid('Laporan deposit harian',1,[]),[Write('Laporan deposit harian',2,3,0)])
    assert error.value.code=='READ_ONLY_REPORT' and calls==[]
