import fcntl
import json
import logging
import signal
import time
from pathlib import Path

from sqlalchemy import select

from .config import settings
from .db import SessionLocal
from .engine.runner import process_run
from .models import Run

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger('tutupkas.worker')
stopping = False


def stop(*_):
    global stopping
    stopping = True


def main():
    lockpath = Path(settings().worker_lock)
    lockpath.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with lockpath.open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise SystemExit('Worker lain sudah berjalan.')
        signal.signal(signal.SIGTERM, stop)
        signal.signal(signal.SIGINT, stop)
        # Running jobs were already manually authorized. Resume only unfinished
        # items using their immutable config and persisted write intents.
        with SessionLocal() as db:
            for run in db.scalars(select(Run).where(Run.status == 'RUNNING')):
                run.status = 'QUEUED'
            db.commit()
        logger.info(json.dumps({"event": "worker_ready"}))
        while not stopping:
            with SessionLocal() as db:
                run = db.scalar(select(Run).where(Run.status == 'QUEUED').order_by(Run.id).limit(1))
                if run:
                    try:
                        process_run(db, run)
                    except Exception as e:
                        db.rollback()
                        logger.error(json.dumps({"event": "worker_error", "run_id": run.id, "type": type(e).__name__}))
                        # Keep uncertain work recoverable without a hot retry loop.
                        raise
            if not run:
                time.sleep(settings().worker_poll_seconds)
        logger.info(json.dumps({"event": "worker_stopped"}))


if __name__ == '__main__':
    main()

