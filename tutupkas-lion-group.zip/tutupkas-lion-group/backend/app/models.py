from datetime import date, datetime
from typing import Optional

from sqlalchemy import JSON, Boolean, Date, DateTime, ForeignKey, Index, Integer, String, Text, UniqueConstraint, text
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base, utcnow


class Stamp:
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


class User(Stamp, Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(80), unique=True)
    password_hash: Mapped[str] = mapped_column(Text)
    role: Mapped[str] = mapped_column(String(30), default="admin")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    last_login_at: Mapped[Optional[datetime]] = mapped_column(DateTime)


class AuthSession(Base):
    __tablename__ = "auth_sessions"
    token_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    csrf_token: Mapped[str] = mapped_column(String(100))
    expires_at: Mapped[datetime] = mapped_column(DateTime, index=True)


class LoginAttempt(Base):
    __tablename__ = "login_attempts"
    id: Mapped[int] = mapped_column(primary_key=True)
    identity: Mapped[str] = mapped_column(String(64), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)


class Website(Stamp, Base):
    __tablename__ = "websites"
    id: Mapped[int] = mapped_column(primary_key=True)
    display_name: Mapped[str] = mapped_column(String(100))
    slug: Mapped[str] = mapped_column(String(100), unique=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_archived: Mapped[bool] = mapped_column(Boolean, default=False)


class SourceDocument(Stamp, Base):
    __tablename__ = "source_documents"
    __table_args__ = (UniqueConstraint("website_id", "document_type", "year", "month"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    website_id: Mapped[int] = mapped_column(ForeignKey("websites.id"), index=True)
    document_type: Mapped[str] = mapped_column(String(10))
    year: Mapped[int] = mapped_column(Integer)
    month: Mapped[int] = mapped_column(Integer)
    spreadsheet_url: Mapped[str] = mapped_column(Text)
    spreadsheet_id: Mapped[str] = mapped_column(String(150))
    spreadsheet_title: Mapped[Optional[str]] = mapped_column(Text)
    validation_status: Mapped[str] = mapped_column(String(30), default="UNVALIDATED")
    validated_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    active_revision_id: Mapped[Optional[int]] = mapped_column(Integer)


class SourceRevision(Base):
    __tablename__ = "source_document_revisions"
    __table_args__ = (UniqueConstraint("source_document_id", "revision_number"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    source_document_id: Mapped[int] = mapped_column(ForeignKey("source_documents.id"), index=True)
    revision_number: Mapped[int] = mapped_column(Integer)
    spreadsheet_url: Mapped[str] = mapped_column(Text)
    spreadsheet_id: Mapped[str] = mapped_column(String(150))
    changed_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    changed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class SourceSheet(Stamp, Base):
    __tablename__ = "source_sheet_states"
    __table_args__ = (UniqueConstraint("source_revision_id", "tab_name"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    source_document_id: Mapped[int] = mapped_column(ForeignKey("source_documents.id"), index=True)
    source_revision_id: Mapped[int] = mapped_column(ForeignKey("source_document_revisions.id"), index=True)
    tab_name: Mapped[str] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=False)
    is_available: Mapped[bool] = mapped_column(Boolean, default=True)
    discovered_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Destination(Stamp, Base):
    __tablename__ = "destination_documents"
    __table_args__ = (UniqueConstraint("year", "month", "environment"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    year: Mapped[int] = mapped_column(Integer)
    month: Mapped[int] = mapped_column(Integer)
    environment: Mapped[str] = mapped_column(String(12))
    spreadsheet_url: Mapped[str] = mapped_column(Text)
    spreadsheet_id: Mapped[str] = mapped_column(String(150))
    spreadsheet_title: Mapped[Optional[str]] = mapped_column(Text)
    validation_status: Mapped[str] = mapped_column(String(30), default="UNVALIDATED")
    validated_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    revision: Mapped[int] = mapped_column(Integer, default=1)
    test_verified_revision: Mapped[Optional[int]] = mapped_column(Integer)
    production_authorized_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))
    authorized_at: Mapped[Optional[datetime]] = mapped_column(DateTime)


class DestinationRevision(Base):
    __tablename__ = "destination_document_revisions"
    id: Mapped[int] = mapped_column(primary_key=True)
    destination_document_id: Mapped[int] = mapped_column(ForeignKey("destination_documents.id"), index=True)
    revision_number: Mapped[int] = mapped_column(Integer)
    spreadsheet_url: Mapped[str] = mapped_column(Text)
    changed_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    changed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class ValidationEvent(Base):
    __tablename__ = "validation_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    document_id: Mapped[int] = mapped_column(Integer, index=True)
    document_type: Mapped[str] = mapped_column(String(20))
    result: Mapped[str] = mapped_column(String(30))
    error_code: Mapped[Optional[str]] = mapped_column(String(60))
    human_message: Mapped[str] = mapped_column(Text)
    checked_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Run(Base):
    __tablename__ = "task_runs"
    __table_args__ = (Index("one_active_run", "website_id", "selected_date", "environment", unique=True,
                           sqlite_where=text("status IN ('QUEUED','RUNNING')"),
                           postgresql_where=text("status IN ('QUEUED','RUNNING')")),)
    id: Mapped[int] = mapped_column(primary_key=True)
    task_number: Mapped[int] = mapped_column(Integer, default=1)
    website_id: Mapped[int] = mapped_column(ForeignKey("websites.id"), index=True)
    selected_date: Mapped[date] = mapped_column(Date)
    year: Mapped[int] = mapped_column(Integer)
    month: Mapped[int] = mapped_column(Integer)
    environment: Mapped[str] = mapped_column(String(12))
    preview: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(30), default="QUEUED", index=True)
    started_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    finished_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    idempotency_key: Mapped[str] = mapped_column(String(100), unique=True)
    config_snapshot: Mapped[dict] = mapped_column(JSON)


class RunItem(Base):
    __tablename__ = "task_run_items"
    __table_args__ = (UniqueConstraint("run_id", "source_document_id", "source_tab_name", "metric_type"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("task_runs.id"), index=True)
    source_document_id: Mapped[Optional[int]] = mapped_column(ForeignKey("source_documents.id"))
    source_tab_name: Mapped[str] = mapped_column(Text)
    metric_type: Mapped[str] = mapped_column(String(50))
    status: Mapped[str] = mapped_column(String(30), default="PENDING")
    source_date: Mapped[date] = mapped_column(Date)
    result: Mapped[Optional[dict]] = mapped_column(JSON)
    processed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)


class TaskError(Base):
    __tablename__ = "task_errors"
    id: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("task_runs.id"), index=True)
    run_item_id: Mapped[int] = mapped_column(ForeignKey("task_run_items.id"), index=True)
    source_document_id: Mapped[Optional[int]] = mapped_column(ForeignKey("source_documents.id"))
    source_tab_name: Mapped[str] = mapped_column(Text)
    error_code: Mapped[str] = mapped_column(String(80))
    human_message: Mapped[str] = mapped_column(Text)
    technical_details: Mapped[dict] = mapped_column(JSON, default=dict)
    suggested_fix: Mapped[str] = mapped_column(Text)
    is_resolved: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    retry_count: Mapped[int] = mapped_column(Integer, default=0)


class Clearance(Base):
    __tablename__ = "date_clearances"
    __table_args__ = (UniqueConstraint("website_id", "selected_date", "environment", "task_number"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    website_id: Mapped[int] = mapped_column(ForeignKey("websites.id"))
    selected_date: Mapped[date] = mapped_column(Date)
    year: Mapped[int] = mapped_column(Integer)
    month: Mapped[int] = mapped_column(Integer)
    environment: Mapped[str] = mapped_column(String(12))
    task_number: Mapped[int] = mapped_column(Integer, default=1)
    is_clear: Mapped[bool] = mapped_column(Boolean, default=True)
    confirmed_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    confirmed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    reopened_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    reopen_reason: Mapped[Optional[str]] = mapped_column(Text)


class WriteLedger(Base):
    __tablename__ = "output_write_ledger"
    __table_args__ = (UniqueConstraint("destination_document_id", "destination_revision", "destination_tab", "target_range"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    run_item_id: Mapped[int] = mapped_column(ForeignKey("task_run_items.id"))
    destination_document_id: Mapped[int] = mapped_column(ForeignKey("destination_documents.id"))
    destination_revision: Mapped[int] = mapped_column(Integer)
    destination_tab: Mapped[str] = mapped_column(Text)
    target_range: Mapped[str] = mapped_column(String(50))
    output_type: Mapped[str] = mapped_column(String(50))
    owner_key: Mapped[str] = mapped_column(String(64))
    source_fingerprint: Mapped[str] = mapped_column(String(64))
    previous_managed_value: Mapped[dict] = mapped_column(JSON)
    written_value: Mapped[dict] = mapped_column(JSON)
    note_fingerprint: Mapped[str] = mapped_column(String(64))
    last_written_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    verification_status: Mapped[str] = mapped_column(String(30), default="PREPARED")


class TransferOwnership(Base):
    __tablename__ = "transfer_slot_ownership"
    __table_args__ = (UniqueConstraint("destination_document_id", "destination_revision", "source_transaction_fingerprint"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    run_item_id: Mapped[int] = mapped_column(ForeignKey("task_run_items.id"))
    source_transaction_fingerprint: Mapped[str] = mapped_column(String(64))
    destination_document_id: Mapped[int] = mapped_column(ForeignKey("destination_documents.id"))
    destination_revision: Mapped[int] = mapped_column(Integer)
    destination_tab: Mapped[str] = mapped_column(Text)
    destination_bank: Mapped[str] = mapped_column(String(20))
    description_cell: Mapped[str] = mapped_column(String(50))
    amount_cell: Mapped[str] = mapped_column(String(50))
    note_cell: Mapped[str] = mapped_column(String(50))
    last_written_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class AccountAlias(Base):
    __tablename__ = "account_aliases"
    __table_args__ = (UniqueConstraint("website_id", "source_name"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    website_id: Mapped[int] = mapped_column(ForeignKey("websites.id"))
    source_name: Mapped[str] = mapped_column(Text)
    destination_header: Mapped[str] = mapped_column(Text)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    actor_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))
    action: Mapped[str] = mapped_column(String(80), index=True)
    entity_type: Mapped[str] = mapped_column(String(50))
    entity_id: Mapped[str] = mapped_column(String(100))
    details: Mapped[dict] = mapped_column("metadata", JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

