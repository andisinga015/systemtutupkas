from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="TK_", env_file=".env", extra="ignore")
    database_url: str = "sqlite:///./data/tutupkas.sqlite3"
    credential_file: str = "/home/aksesfinancebot/spreadsheet-robot/credentials/robot-key.json"
    app_origin: str = "https://tutupkasliongroup.com"
    cookie_secure: bool = True
    session_hours: int = 8
    request_timeout: int = 45
    api_retries: int = 4
    google_min_interval: float = 1.2
    worker_poll_seconds: float = 2
    worker_lock: str = "./data/worker.lock"
    transfer_palette_file: str = "./data/transfer-palette.json"
    max_sheet_cells: int = 2_000_000


@lru_cache
def settings() -> Settings:
    return Settings()


def ensure_data_dir():
    url = settings().database_url
    if url.startswith("sqlite:///") and url != "sqlite:///:memory:":
        Path(url[10:]).parent.mkdir(parents=True, exist_ok=True, mode=0o700)

