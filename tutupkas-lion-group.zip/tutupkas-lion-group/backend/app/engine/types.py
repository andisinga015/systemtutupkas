import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, InvalidOperation
from typing import Any, Optional


class Issue(Exception):
    def __init__(self, code: str, message: str, fix: str = "Periksa data sumber/tujuan, lalu Crawl Ulang item ini.", **context):
        self.code, self.message, self.fix, self.context = code, message, fix, context
        super().__init__(message)


def norm(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").replace("\u00a0", " ")).strip().upper()


def fingerprint(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, default=str, ensure_ascii=False).encode()).hexdigest()


def number(value: Any, blank_zero: bool = False) -> int:
    if value is None or value == "":
        if blank_zero:
            return 0
        raise Issue("INVALID_BALANCE", "Nilai penutupan kosong; angka tidak dapat dipastikan.")
    if isinstance(value, bool):
        raise Issue("NON_NUMERIC", "Nilai nominal berupa boolean, bukan angka.")
    if isinstance(value, str):
        value = value.strip()
        # Financial sheets use comma or dot as grouping, never guess decimal money.
        if re.fullmatch(r"-?\d{1,3}(,\d{3})+", value):
            value = value.replace(",", "")
        elif re.fullmatch(r"-?\d{1,3}(\.\d{3})+", value):
            value = value.replace(".", "")
        elif not re.fullmatch(r"-?\d+", value):
            raise Issue("NON_NUMERIC", "Nominal tidak berupa angka rupiah yang jelas.")
    try:
        v = Decimal(str(value))
        if not v.is_finite() or v != v.to_integral_value() or abs(v) > 9_007_199_254_740_991:
            raise InvalidOperation
        return int(v)
    except (InvalidOperation, ValueError):
        raise Issue("NON_NUMERIC", "Nominal rupiah tidak valid atau melebihi batas presisi aman.")


def column(c: int) -> str:
    out = ""
    c += 1
    while c:
        c, rem = divmod(c - 1, 26)
        out = chr(65 + rem) + out
    return out


@dataclass
class Cell:
    value: Any = None
    formula: Optional[str] = None
    note: str = ""
    color: Optional[tuple] = None
    date_format: bool = False

    @property
    def empty(self):
        return self.value in (None, "") and self.formula is None and not self.note

    @property
    def snapshot(self):
        # Sheets may omit effectiveValue for an explicitly written empty string.
        return {"value": None if self.value == "" else self.value, "formula": self.formula, "note": self.note}


@dataclass
class Grid:
    title: str
    sheet_id: int
    rows: list[list[Cell]]
    merges: list[dict] = field(default_factory=list)

    def cell(self, row: int, col: int) -> Cell:
        if row < 0 or col < 0:
            return Cell()
        return self.rows[row][col] if row < len(self.rows) and col < len(self.rows[row]) else Cell()

    @property
    def width(self):
        return max((len(row) for row in self.rows), default=0)

    def inherited(self, row: int, col: int) -> Cell:
        for m in self.merges:
            if m['startRowIndex'] <= row < m['endRowIndex'] and m['startColumnIndex'] <= col < m['endColumnIndex']:
                return self.cell(m['startRowIndex'], m['startColumnIndex'])
        return self.cell(row, col)


@dataclass
class Write:
    tab: str
    row: int
    col: int
    value: Any
    note: Optional[str] = None
    bank: str = ""
    transaction: str = ""

    @property
    def address(self):
        return f"{column(self.col)}{self.row + 1}"

    @property
    def proposed(self):
        return {"value": None if self.value == "" else self.value, "formula": None, "note": self.note or ""}

