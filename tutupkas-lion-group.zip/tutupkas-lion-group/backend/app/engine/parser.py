import re
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Optional

from .types import Cell, Grid, Issue, norm, number

MONTHS = {
    "JANUARY": 1, "JANUARI": 1, "JAN": 1, "FEBRUARY": 2, "FEBRUARI": 2, "FEB": 2,
    "MARCH": 3, "MARET": 3, "MAR": 3, "APRIL": 4, "APR": 4, "MAY": 5, "MEI": 5,
    "JUNE": 6, "JUNI": 6, "JUN": 6, "JULY": 7, "JULI": 7, "JUL": 7,
    "AUGUST": 8, "AGUSTUS": 8, "AUG": 8, "AGU": 8, "SEPTEMBER": 9, "SEP": 9,
    "OCTOBER": 10, "OKTOBER": 10, "OCT": 10, "OKT": 10, "NOVEMBER": 11, "NOV": 11,
    "DECEMBER": 12, "DESEMBER": 12, "DEC": 12, "DES": 12,
}


def parse_date(cell: Cell) -> Optional[date]:
    v = cell.value
    if isinstance(v, (float, int)) and cell.date_format:
        return (datetime(1899, 12, 30) + timedelta(days=v)).date()
    s = norm(v)
    iso = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", s)
    try:
        if iso:
            return date(*map(int, iso.groups()))
        m = re.search(r"\b(\d{1,2})[\s-]+([A-Z]+)[\s-]+(\d{4})\b", s)
        if m and m[2] in MONTHS:
            return date(int(m[3]), MONTHS[m[2]], int(m[1]))
    except ValueError:
        return None
    return None


def separator_dates(grid: Grid) -> dict[date, list[int]]:
    markers: dict[date, list[int]] = {}
    for r, row in enumerate(grid.rows):
        for c, cell in enumerate(row):
            d = parse_date(cell)
            if not d:
                continue
            black = cell.color is not None and max(cell.color) < 0.15
            merged = any(m['startRowIndex'] == r and m['startColumnIndex'] == c
                         and m['endColumnIndex'] - c >= 3 for m in grid.merges)
            if black or merged:
                if r not in markers.setdefault(d, []):
                    markers[d].append(r)
    return markers


def header(grid: Grid, label: str) -> int:
    candidates = {(r, c) for r, row in enumerate(grid.rows[:12]) for c, cell in enumerate(row)
                  if norm(cell.value) == norm(label)}
    if len(candidates) != 1:
        raise Issue("DUPLICATE_HEADER" if candidates else "HEADER_MISSING",
                    f"Header {label} harus ditemukan tepat satu kali.", header=label)
    return next(iter(candidates))[1]


@dataclass
class Day:
    grid: Grid
    selected: date
    start: int
    end: int
    transaction_rows: list[int]

    @classmethod
    def resolve(cls, grid: Grid, selected: date):
        markers = separator_dates(grid)
        following = selected + timedelta(days=1)
        for d in (selected, following):
            if len(markers.get(d, [])) != 1:
                raise Issue("DATE_NOT_FOUND", f"Pemisah tanggal {d.isoformat()} tidak ditemukan secara unik.",
                            "Pastikan pemisah tanggal terpilih dan hari berikutnya tersedia di sumber.", expected_date=str(d))
        start, next_row = markers[selected][0], markers[following][0]
        if next_row <= start or any(start < r < next_row for d, rr in markers.items()
                                   if d not in (selected, following) for r in rr):
            raise Issue("AMBIGUOUS_DATE", "Urutan pemisah tanggal tidak konsisten.")
        cumulative = set()
        for label in ("Total", "Total Depo", "Total WD", "SALDO", "BALANCE", "CEK SALDO"):
            cumulative.update(c for row in grid.rows[:12] for c, v in enumerate(row) if norm(v.value) == norm(label))
        rows = [r for r in range(start + 1, next_row)
                if any(not cell.empty and c not in cumulative for c, cell in enumerate(grid.rows[r]))]
        return cls(grid, selected, start, next_row - 1, rows)

    def metric(self, label: str) -> int:
        c = header(self.grid, label)
        if not self.transaction_rows:
            if label != "SALDO":
                return 0
            # Separator rows often carry the previous balance. Search back through
            # truly blank cells only; a malformed balance is an error, not zero.
            for r in range(self.end, -1, -1):
                cell = self.grid.cell(r, c)
                if cell.value not in (None, ""):
                    return number(cell.value)
            raise Issue("INVALID_BALANCE", "Saldo sebelumnya tidak ditemukan untuk hari tanpa transaksi.")
        return number(self.grid.cell(self.end, c).value)

    def signed_sum(self, col: int) -> int:
        return sum(number(self.grid.cell(r, col).value, blank_zero=True) for r in self.transaction_rows)

    def fees(self, prefix: str, amount_col: int = 7) -> tuple[str, int]:
        entries = [(str(self.grid.cell(r, 3).value), number(self.grid.cell(r, amount_col).value))
                   for r in self.transaction_rows if norm(self.grid.cell(r, 3).value).startswith(norm(prefix))]
        desc = "\n".join(text for text, _ in entries)
        if prefix == "FEE WD AUTO":
            desc = prefix if entries else ""
        return desc, abs(sum(v for _, v in entries))


def eligible_description(text: str) -> bool:
    return bool(re.match(r"^(KIRIM KE\b|PENGIRIMAN DARI\b|DARI (?:NL )?KAS\b)", norm(text)))


def transfer_rows(day: Day, document_type: str, palette: dict) -> list[dict]:
    out = []
    kiriman = header(day.grid, "Kiriman")
    if document_type == "QRIS" and kiriman != 7:
        raise Issue("HEADER_MISMATCH", "Kolom Kiriman DOC QRIS bukan H; struktur perlu diperiksa.")
    approved = {tuple(v) for v in palette.get("approved_brown", [])}
    excluded = {tuple(v) for v in palette.get("excluded_blue", [])}
    for r in day.transaction_rows:
        desc = day.grid.cell(r, 3)
        if not eligible_description(str(desc.value or "")):
            continue
        rgb = tuple(round(v, 4) for v in desc.color) if desc.color is not None else None
        if rgb in excluded:
            continue
        if rgb not in approved:
            raise Issue("UNRECOGNIZED_TRANSFER_FORMAT", "Warna transaksi kiriman belum disetujui atau tidak dikenali.",
                        "Periksa warna aktual melalui pratinjau; setujui palet melalui perintah CLI setelah verifikasi.",
                        source_row=r + 1, observed_rgb=rgb)
        banks = re.findall(r"\b(BCA|MANDIRI|BRI|BNI)\b", norm(day.grid.title))
        if document_type == "DEPO" and len(set(banks)) != 1:
            raise Issue("BANK_AMBIGUOUS", "Bank pada nama sheet sumber tidak ditemukan secara unik.")
        amount = number(day.grid.cell(r, kiriman).value)
        note = f"{day.grid.title} ( {desc.value} ) {amount:,}".replace(",", ".") if document_type == "QRIS" else None
        out.append({"description": str(desc.value), "amount": amount, "row": r,
                    "bank": banks[0] if document_type == "DEPO" else None, "note": note})
    return out

