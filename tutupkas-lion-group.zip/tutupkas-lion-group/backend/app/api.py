import json
import re
from datetime import date
from pathlib import Path
from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import func, select, or_
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .auth import admin
from .config import settings
from .db import get_db, utcnow
from .engine.types import Issue, fingerprint
from .models import (Website, SourceDocument, SourceRevision, SourceSheet, Destination, DestinationRevision,
                     ValidationEvent, Run, RunItem, TaskError, Clearance, AccountAlias, AuditLog, WriteLedger)
from .sheets import SheetsClient, spreadsheet_id

router = APIRouter(dependencies=[Depends(admin)])


def serialize(obj):
    return {c.key: getattr(obj, c.key) for c in obj.__mapper__.column_attrs}


def require(db, model, id):
    obj = db.get(model, id)
    if obj is None:
        raise HTTPException(404, "Data tidak ditemukan.")
    return obj


def audit(db, actor, action, obj, details=None):
    db.add(AuditLog(actor_id=actor.id, action=action, entity_type=obj.__tablename__,
                    entity_id=str(obj.id), details=details or {}))


def save(db):
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Data atau pekerjaan yang sama sudah tersedia. Muat ulang halaman.")


class WebsiteCreate(BaseModel):
    display_name: str = Field(min_length=2, max_length=100)
    slug: str = Field(min_length=2, max_length=100, pattern=r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


class WebsiteEdit(BaseModel):
    display_name: Optional[str] = Field(default=None, min_length=2, max_length=100)
    is_active: Optional[bool] = None
    is_archived: Optional[bool] = None


class Period(BaseModel):
    year: int = Field(ge=2020, le=2100)
    month: int = Field(ge=1, le=12)


class SourceSave(Period):
    document_type: Literal['DEPO', 'QRIS']
    spreadsheet_url: str = Field(max_length=2000)


class DestinationSave(Period):
    environment: Literal['TEST', 'PRODUCTION']
    spreadsheet_url: str = Field(max_length=2000)


class TabsAction(BaseModel):
    ids: list[int] = Field(max_length=1000)
    is_active: bool


class RunStart(BaseModel):
    website_id: int
    selected_date: date
    environment: Literal['TEST', 'PRODUCTION'] = 'TEST'
    preview: bool = False
    idempotency_key: str = Field(min_length=16, max_length=100)


class AliasSave(BaseModel):
    source_name: str = Field(min_length=1, max_length=300)
    destination_header: str = Field(min_length=1, max_length=300)


class Authorize(BaseModel):
    test_run_id: int
    reviewed_formulas_notes_and_retry: bool


class Retry(BaseModel):
    source_document_id: int


class Reopen(BaseModel):
    reason: str = Field(min_length=10, max_length=1000)


@router.get('/dashboard')
def dashboard(db: Session = Depends(get_db)):
    count = lambda m, *conditions: db.scalar(select(func.count()).select_from(m).where(*conditions))
    return {"websites": count(Website, Website.is_archived == False),
            "active_websites": count(Website, Website.is_active == True, Website.is_archived == False),
            "inactive_websites": count(Website, Website.is_active == False, Website.is_archived == False),
            "active_tabs": count(SourceSheet, SourceSheet.is_active == True, SourceSheet.is_available == True,
                                  SourceSheet.source_revision_id == SourceDocument.active_revision_id,
                                  SourceSheet.source_document_id == SourceDocument.id),
            "inactive_tabs": count(SourceSheet, SourceSheet.is_active == False, SourceSheet.is_available == True,
                                    SourceSheet.source_revision_id == SourceDocument.active_revision_id,
                                    SourceSheet.source_document_id == SourceDocument.id),
            "validated_urls": count(SourceDocument, SourceDocument.validation_status == 'VALID') + count(Destination, Destination.validation_status == 'VALID'),
            "failed_urls": count(SourceDocument, SourceDocument.validation_status == 'FAILED') + count(Destination, Destination.validation_status == 'FAILED'),
            "success_runs": count(Run, Run.status == 'SUCCESS', Run.preview == False),
            "partial_runs": count(Run, Run.status == 'PARTIAL'), "failed_runs": count(Run, Run.status == 'FAILED'),
            "errors": count(TaskError, TaskError.is_resolved == False),
            "credentials_configured": Path(settings().credential_file).is_file(),
            "palette_configured": Path(settings().transfer_palette_file).is_file()}


@router.get('/websites')
def websites(q: str = '', status: str = 'all', db: Session = Depends(get_db)):
    query = select(Website).where(Website.display_name.ilike(f'%{q}%'))
    if status == 'archived':
        query = query.where(Website.is_archived == True)
    else:
        query = query.where(Website.is_archived == False)
    if status in ('active', 'inactive'):
        query = query.where(Website.is_active == (status == 'active'))
    return [serialize(w) for w in db.scalars(query.order_by(Website.created_at))]


@router.post('/websites', status_code=201)
def create_website(body: WebsiteCreate, db: Session = Depends(get_db), user=Depends(admin)):
    if db.scalar(select(Website.id).where(Website.slug == body.slug)):
        raise HTTPException(409, 'Slug WEB sudah digunakan.')
    if any(w.display_name.strip().casefold() == body.display_name.strip().casefold() for w in db.scalars(select(Website))):
        raise HTTPException(409, 'Nama WEB sudah digunakan; identitas tujuan harus unik.')
    obj = Website(**body.model_dump())
    db.add(obj)
    db.flush()
    audit(db, user, 'create', obj)
    save(db)
    return serialize(obj)


@router.get('/websites/{slug}')
def website(slug: str, db: Session = Depends(get_db)):
    obj = db.scalar(select(Website).where(Website.slug == slug))
    if not obj:
        raise HTTPException(404, 'WEB tidak ditemukan.')
    return serialize(obj)


@router.patch('/websites/{id}')
def edit_website(id: int, body: WebsiteEdit, db: Session = Depends(get_db), user=Depends(admin)):
    obj = require(db, Website, id)
    if db.scalar(select(Run.id).where(Run.website_id == id, Run.status.in_(['RUNNING', 'QUEUED']))):
        raise HTTPException(409, 'Tunggu proses WEB ini selesai sebelum mengubah pengaturan.')
    for k, v in body.model_dump(exclude_none=True).items():
        setattr(obj, k, v)
    if obj.is_archived:
        obj.is_active = False
    audit(db, user, 'edit', obj, body.model_dump(exclude_none=True))
    save(db)
    return serialize(obj)


@router.get('/websites/{id}/sources')
def sources(id: int, year: Optional[int] = None, month: Optional[int] = None, db: Session = Depends(get_db)):
    query = select(SourceDocument).where(SourceDocument.website_id == id)
    if year is not None:
        query = query.where(SourceDocument.year == year)
    if month is not None:
        query = query.where(SourceDocument.month == month)
    return [serialize(s) for s in db.scalars(query.order_by(SourceDocument.year.desc(), SourceDocument.month.desc()))]


@router.put('/websites/{id}/sources')
def save_source(id: int, body: SourceSave, db: Session = Depends(get_db), user=Depends(admin)):
    require(db, Website, id)
    sid = spreadsheet_id(body.spreadsheet_url)
    obj = db.scalar(select(SourceDocument).where(SourceDocument.website_id == id, SourceDocument.document_type == body.document_type,
                                                SourceDocument.year == body.year, SourceDocument.month == body.month))
    if obj and obj.spreadsheet_url == body.spreadsheet_url:
        return serialize(obj)
    if not obj:
        obj = SourceDocument(website_id=id, **body.model_dump(), spreadsheet_id=sid)
        db.add(obj)
        db.flush()
    rev = (db.scalar(select(func.max(SourceRevision.revision_number)).where(SourceRevision.source_document_id == obj.id)) or 0) + 1
    revision = SourceRevision(source_document_id=obj.id, revision_number=rev, spreadsheet_url=body.spreadsheet_url,
                              spreadsheet_id=sid, changed_by=user.id)
    db.add(revision)
    db.flush()
    obj.spreadsheet_url, obj.spreadsheet_id = body.spreadsheet_url, sid
    obj.active_revision_id = revision.id
    obj.validation_status, obj.validated_at, obj.spreadsheet_title = 'UNVALIDATED', None, None
    audit(db, user, 'save_source_revision', obj, {"revision": rev})
    save(db)
    return serialize(obj)


@router.get('/sources/{id}/history')
def source_history(id: int, db: Session = Depends(get_db)):
    require(db, SourceDocument, id)
    return [serialize(o) for o in db.scalars(select(SourceRevision).where(SourceRevision.source_document_id == id).order_by(SourceRevision.revision_number.desc()))]


def refresh_tabs(db, obj, metadata):
    current = list(db.scalars(select(SourceSheet).where(SourceSheet.source_revision_id == obj.active_revision_id)))
    names = {s['properties']['title'] for s in metadata.get('sheets', [])}
    for tab in current:
        tab.is_available = tab.tab_name in names
        if tab.is_available:
            tab.last_seen_at = utcnow()
        else:
            tab.is_active = False
    existing = {s.tab_name for s in current}
    for name in names - existing:
        db.add(SourceSheet(source_document_id=obj.id, source_revision_id=obj.active_revision_id, tab_name=name, is_active=False))


def validate_document(db, obj, kind, user):
    try:
        metadata = SheetsClient().metadata(obj.spreadsheet_id)
        obj.spreadsheet_title = metadata['properties']['title']
        obj.validation_status = 'VALID'
        obj.validated_at = utcnow()
        if kind == 'SOURCE':
            refresh_tabs(db, obj, metadata)
        code, message = None, 'Akses baca dan metadata berhasil diverifikasi. Akses tulis belum diuji.'
    except Issue as e:
        obj.validation_status, obj.validated_at = 'FAILED', utcnow()
        code, message = e.code, e.message
    db.add(ValidationEvent(document_id=obj.id, document_type=kind, result=obj.validation_status,
                            error_code=code, human_message=message))
    audit(db, user, 'validate', obj, {"status": obj.validation_status})
    save(db)
    return {"document": serialize(obj), "message": message, "error_code": code}


@router.post('/sources/{id}/validate')
def validate_source(id: int, db: Session = Depends(get_db), user=Depends(admin)):
    return validate_document(db, require(db, SourceDocument, id), 'SOURCE', user)


@router.get('/sources/{id}/tabs')
def tabs(id: int, db: Session = Depends(get_db)):
    obj = require(db, SourceDocument, id)
    return [serialize(t) for t in db.scalars(select(SourceSheet).where(SourceSheet.source_revision_id == obj.active_revision_id).order_by(SourceSheet.tab_name))]


@router.post('/sources/{id}/tabs/refresh')
def refresh(id: int, db: Session = Depends(get_db), user=Depends(admin)):
    obj = require(db, SourceDocument, id)
    metadata = SheetsClient().metadata(obj.spreadsheet_id)
    refresh_tabs(db, obj, metadata)
    obj.spreadsheet_title, obj.validation_status, obj.validated_at = metadata['properties']['title'], 'VALID', utcnow()
    audit(db, user, 'refresh_tabs', obj)
    save(db)
    return tabs(id, db)


@router.post('/sources/{id}/tabs')
def toggle_tabs(id: int, body: TabsAction, db: Session = Depends(get_db), user=Depends(admin)):
    obj = require(db, SourceDocument, id)
    targets = list(db.scalars(select(SourceSheet).where(SourceSheet.id.in_(body.ids),
                   SourceSheet.source_revision_id == obj.active_revision_id, SourceSheet.is_available == True)))
    if len(targets) != len(set(body.ids)):
        raise HTTPException(409, 'Pilihan sheet sudah berubah. Refresh daftar terlebih dahulu.')
    for tab in targets:
        tab.is_active = body.is_active
    audit(db, user, 'toggle_tabs', obj, body.model_dump())
    save(db)
    return tabs(id, db)


@router.get('/websites/{id}/aliases')
def aliases(id: int, db: Session = Depends(get_db)):
    return [serialize(o) for o in db.scalars(select(AccountAlias).where(AccountAlias.website_id == id))]


@router.put('/websites/{id}/aliases')
def save_alias(id: int, body: AliasSave, db: Session = Depends(get_db), user=Depends(admin)):
    require(db, Website, id)
    obj = db.scalar(select(AccountAlias).where(AccountAlias.website_id == id, AccountAlias.source_name == body.source_name))
    if not obj:
        obj = AccountAlias(website_id=id, **body.model_dump())
        db.add(obj)
        db.flush()
    obj.destination_header = body.destination_header
    audit(db, user, 'save_alias', obj)
    save(db)
    return serialize(obj)


@router.get('/destinations')
def destinations(db: Session = Depends(get_db)):
    return [serialize(o) for o in db.scalars(select(Destination).order_by(Destination.year.desc(), Destination.month.desc()))]


@router.put('/destinations')
def save_destination(body: DestinationSave, db: Session = Depends(get_db), user=Depends(admin)):
    sid = spreadsheet_id(body.spreadsheet_url)
    if db.scalar(select(Destination.id).where(Destination.spreadsheet_id == sid, Destination.environment != body.environment)):
        raise HTTPException(409, 'Spreadsheet TEST dan PRODUCTION harus berbeda.')
    obj = db.scalar(select(Destination).where(Destination.year == body.year, Destination.month == body.month,
                                              Destination.environment == body.environment))
    if obj and obj.spreadsheet_url == body.spreadsheet_url:
        return serialize(obj)
    if not obj:
        obj = Destination(**body.model_dump(), spreadsheet_id=sid, revision=1)
        db.add(obj)
        db.flush()
    else:
        obj.revision += 1
        obj.spreadsheet_url, obj.spreadsheet_id = body.spreadsheet_url, sid
    obj.validation_status, obj.validated_at, obj.spreadsheet_title = 'UNVALIDATED', None, None
    obj.production_authorized_by, obj.authorized_at = None, None
    db.add(DestinationRevision(destination_document_id=obj.id, revision_number=obj.revision,
                               spreadsheet_url=body.spreadsheet_url, changed_by=user.id))
    audit(db, user, 'save_destination', obj, {"revision": obj.revision})
    save(db)
    return serialize(obj)


@router.post('/destinations/{id}/validate')
def validate_destination(id: int, db: Session = Depends(get_db), user=Depends(admin)):
    return validate_document(db, require(db, Destination, id), 'DESTINATION', user)


@router.get('/destinations/{id}/history')
def destination_history(id: int, db: Session = Depends(get_db)):
    require(db, Destination, id)
    return [serialize(o) for o in db.scalars(select(DestinationRevision).where(DestinationRevision.destination_document_id == id).order_by(DestinationRevision.revision_number.desc()))]


def preflight(db, body: RunStart):
    w = require(db, Website, body.website_id)
    if not w.is_active or w.is_archived:
        raise HTTPException(409, 'WEB tidak aktif.')
    d = body.selected_date
    dest = db.scalar(select(Destination).where(Destination.year == d.year, Destination.month == d.month,
                                               Destination.environment == body.environment))
    if not dest or dest.validation_status != 'VALID':
        raise HTTPException(409, 'Tujuan bulan terpilih belum dikonfigurasi dan divalidasi.')
    if body.environment == 'PRODUCTION' and not body.preview and not dest.production_authorized_by:
        raise HTTPException(409, 'Penulisan produksi belum diotorisasi administrator.')
    clear = db.scalar(select(Clearance).where(Clearance.website_id == w.id, Clearance.selected_date == d,
                                              Clearance.environment == body.environment, Clearance.is_clear == True))
    if clear:
        raise HTTPException(409, 'Tanggal sudah Clear. Buka kembali dengan alasan untuk melakukan koreksi.')
    docs = list(db.scalars(select(SourceDocument).where(SourceDocument.website_id == w.id,
                      SourceDocument.year == d.year, SourceDocument.month == d.month).order_by(SourceDocument.document_type)))
    if not docs:
        raise HTTPException(409, 'URL sumber bulan terpilih belum dikonfigurasi.')
    snapshot_docs = []
    for doc in docs:
        if doc.validation_status != 'VALID':
            raise HTTPException(409, f'DOC {doc.document_type} belum divalidasi.')
        active = list(db.scalars(select(SourceSheet).where(SourceSheet.source_revision_id == doc.active_revision_id,
                                                          SourceSheet.is_active == True, SourceSheet.is_available == True)))
        snapshot_docs.append({"id": doc.id, "type": doc.document_type, "revision": doc.active_revision_id,
                              "spreadsheet_id": doc.spreadsheet_id, "title": doc.spreadsheet_title,
                              "tabs": [t.tab_name for t in active]})
    if not any(doc['tabs'] for doc in snapshot_docs):
        raise HTTPException(409, 'Tidak ada sheet aktif untuk diproses.')
    palette_path = Path(settings().transfer_palette_file)
    try:
        palette = json.loads(palette_path.read_text()) if palette_path.is_file() else {}
    except (OSError, ValueError):
        raise HTTPException(409, 'Konfigurasi palet tidak dapat dibaca.')
    snap = {"website": w.display_name, "registered": list(db.scalars(select(Website.display_name))),
            "sources": snapshot_docs, "destination": {"id": dest.id, "revision": dest.revision,
                    "spreadsheet_id": dest.spreadsheet_id, "title": dest.spreadsheet_title},
            "palette": palette,
            "aliases": {a.source_name: a.destination_header for a in db.scalars(select(AccountAlias).where(AccountAlias.website_id == w.id))}}
    snap['engine_revision'] = fingerprint({p.name: p.read_text() for p in sorted((Path(__file__).parent / 'engine').glob('*.py'))})
    if body.environment == 'PRODUCTION' and not body.preview:
        tested = list(db.scalars(select(Run).where(Run.website_id == w.id, Run.selected_date == d,
                                                   Run.environment == 'TEST', Run.status == 'SUCCESS', Run.preview == False)))
        if not any(all(r.config_snapshot.get(k) == snap[k] for k in ('sources', 'palette', 'aliases', 'website', 'registered','engine_revision')) for r in tested):
            raise HTTPException(409, 'Jalankan dan verifikasi TEST untuk website, tanggal, serta konfigurasi sumber yang sama sebelum produksi.')
    return snap


@router.post('/runs', status_code=202)
def start_run(body: RunStart, db: Session = Depends(get_db), user=Depends(admin)):
    existing = db.scalar(select(Run).where(Run.idempotency_key == body.idempotency_key))
    if existing:
        if (existing.website_id, existing.selected_date, existing.environment, existing.preview) != (body.website_id, body.selected_date, body.environment, body.preview):
            raise HTTPException(409, 'Kunci permintaan sudah digunakan untuk operasi lain.')
        return serialize(existing)
    snap = preflight(db, body)
    # Reject duplicate active runs before flush; the DB unique index also closes the race.
    if db.scalar(select(Run.id).where(Run.website_id == body.website_id, Run.selected_date == body.selected_date,
                                     Run.environment == body.environment, Run.status.in_(['QUEUED', 'RUNNING']))):
        raise HTTPException(409, 'Pekerjaan untuk tanggal ini masih berjalan.')
    run = Run(**body.model_dump(), year=body.selected_date.year, month=body.selected_date.month,
              started_by=user.id, config_snapshot=snap)
    db.add(run)
    db.flush()
    for doc in snap['sources']:
        for tab in doc['tabs']:
            metrics = ['deposit', 'withdrawal', 'balance', 'transfers']
            if doc['type'] == 'DEPO':
                metrics += ['expense_input']
            if doc['type'] == 'QRIS' and tab.strip().upper() in ('QRIS QRIZZ', 'QRIS E-POWER'):
                metrics += ['qris_expense', 'qris_fee']
            for metric in metrics:
                db.add(RunItem(run_id=run.id, source_document_id=doc['id'], source_tab_name=tab,
                               metric_type=metric, source_date=body.selected_date))
    if any(s['type'] == 'DEPO' and s['tabs'] for s in snap['sources']):
        db.add(RunItem(run_id=run.id, source_tab_name='Semua DOC DEPO', metric_type='expense_total', source_date=body.selected_date))
    audit(db, user, 'preview' if body.preview else 'start', run)
    save(db)
    return serialize(run)


@router.get('/runs')
def runs(db: Session = Depends(get_db)):
    return [serialize(r) for r in db.scalars(select(Run).order_by(Run.id.desc()).limit(100))]


@router.get('/runs/{id}')
def run_detail(id: int, db: Session = Depends(get_db)):
    run = require(db, Run, id)
    return {**serialize(run), "items": [serialize(i) for i in db.scalars(select(RunItem).where(RunItem.run_id == id))],
            "errors": [serialize(e) for e in db.scalars(select(TaskError).where(TaskError.run_id == id, TaskError.is_resolved == False))]}


@router.post('/runs/{id}/retry', status_code=202)
def retry(id: int, body: Retry, db: Session = Depends(get_db), user=Depends(admin)):
    run = require(db, Run, id)
    if run.status in ('RUNNING', 'QUEUED'):
        raise HTTPException(409, 'Proses masih berjalan.')
    clear = db.scalar(select(Clearance).where(Clearance.website_id == run.website_id, Clearance.selected_date == run.selected_date,
                                              Clearance.environment == run.environment, Clearance.is_clear == True))
    if clear:
        raise HTTPException(409, 'Tanggal sudah Clear.')
    errors = list(db.scalars(select(TaskError).where(TaskError.run_id == id, TaskError.source_document_id == body.source_document_id,
                                                    TaskError.is_resolved == False)))
    if not errors:
        raise HTTPException(409, 'Tidak ada item gagal untuk dokumen ini.')
    # URL/date/revisions stay pinned. Explicitly approved aliases and palettes
    # may repair failed mapping/classification items without repeating success.
    snapshot = dict(run.config_snapshot)
    snapshot['aliases'] = {a.source_name: a.destination_header for a in db.scalars(
        select(AccountAlias).where(AccountAlias.website_id == run.website_id))}
    palette_path = Path(settings().transfer_palette_file)
    if palette_path.is_file():
        try:
            snapshot['palette'] = json.loads(palette_path.read_text())
        except (OSError, ValueError):
            raise HTTPException(409, 'Palet transaksi tidak dapat dibaca.')
    if run.environment == 'PRODUCTION' and not run.preview:
        dest = require(db, Destination, snapshot['destination']['id'])
        if not dest.production_authorized_by or dest.revision != snapshot['destination']['revision']:
            raise HTTPException(409, 'Otorisasi atau revisi tujuan produksi berubah. Tinjau konfigurasi dan jalankan TEST kembali.')
        tests = list(db.scalars(select(Run).where(Run.website_id == run.website_id, Run.selected_date == run.selected_date,
                         Run.environment == 'TEST', Run.status == 'SUCCESS', Run.preview == False)))
        current_engine = fingerprint({p.name: p.read_text() for p in sorted((Path(__file__).parent / 'engine').glob('*.py'))})
        snapshot['engine_revision'] = current_engine
        if not any(all(t.config_snapshot.get(k) == snapshot[k] for k in ('sources','aliases','palette','website','registered','engine_revision')) for t in tests):
            raise HTTPException(409, 'Perubahan pemetaan/palet memerlukan TEST terverifikasi sebelum retry produksi.')
    run.config_snapshot = snapshot
    for e in errors:
        item = db.get(RunItem, e.run_item_id)
        item.status = 'PENDING'
        e.retry_count += 1
    # Recompute an aggregate from saved verified contributions; do not re-read successful tabs.
    aggregate = db.scalar(select(RunItem).where(RunItem.run_id == id, RunItem.metric_type == 'expense_total'))
    if aggregate and aggregate.status == 'FAILED':
        aggregate.status = 'PENDING'
    run.status, run.finished_at = 'QUEUED', None
    audit(db, user, 'retry_source', run, body.model_dump())
    save(db)
    return serialize(run)


@router.get('/clearances')
def clearances(db: Session = Depends(get_db)):
    return [serialize(c) for c in db.scalars(select(Clearance).order_by(Clearance.selected_date.desc()).limit(500))]


@router.post('/runs/{id}/clear')
def clear(id: int, db: Session = Depends(get_db), user=Depends(admin)):
    run = require(db, Run, id)
    latest = db.scalar(select(Run).where(Run.website_id == run.website_id, Run.selected_date == run.selected_date,
                                        Run.environment == run.environment, Run.preview == False).order_by(Run.id.desc()))
    if run.status != 'SUCCESS' or run.preview or not latest or latest.id != run.id:
        raise HTTPException(409, 'Hanya hasil tulis terakhir yang sepenuhnya berhasil dapat ditandai Clear.')
    unresolved = db.scalar(select(TaskError.id).join(Run, TaskError.run_id == Run.id).where(
        Run.website_id == run.website_id, Run.selected_date == run.selected_date, Run.environment == run.environment,
        Run.preview == False, TaskError.is_resolved == False))
    if unresolved:
        raise HTTPException(409, 'Masih ada kesalahan tanggal ini. Perbaiki melalui Crawl Ulang pada proses asal.')
    obj = db.scalar(select(Clearance).where(Clearance.website_id == run.website_id, Clearance.selected_date == run.selected_date,
                                           Clearance.environment == run.environment))
    if not obj:
        obj = Clearance(website_id=run.website_id, selected_date=run.selected_date, year=run.year, month=run.month,
                        environment=run.environment, confirmed_by=user.id)
        db.add(obj)
        db.flush()
    obj.is_clear, obj.confirmed_by, obj.confirmed_at = True, user.id, utcnow()
    audit(db, user, 'clear_date', obj)
    save(db)
    return serialize(obj)


@router.post('/clearances/{id}/reopen')
def reopen(id: int, body: Reopen, db: Session = Depends(get_db), user=Depends(admin)):
    obj = require(db, Clearance, id)
    obj.is_clear, obj.reopened_at, obj.reopen_reason = False, utcnow(), body.reason
    audit(db, user, 'reopen_date', obj, body.model_dump())
    save(db)
    return serialize(obj)


@router.post('/destinations/{id}/authorize')
def authorize(id: int, body: Authorize, db: Session = Depends(get_db), user=Depends(admin)):
    dest = require(db, Destination, id)
    test = require(db, Run, body.test_run_id)
    if (dest.environment != 'PRODUCTION' or dest.validation_status != 'VALID' or test.preview or test.environment != 'TEST'
        or test.status != 'SUCCESS' or (test.year, test.month) != (dest.year, dest.month)
        or not body.reviewed_formulas_notes_and_retry):
        raise HTTPException(409, 'Diperlukan TEST berhasil pada periode sama dan konfirmasi formula, Note, serta retry.')
    written = list(db.scalars(select(WriteLedger).join(RunItem, WriteLedger.run_item_id == RunItem.id).where(RunItem.run_id == test.id,
                      WriteLedger.verification_status == 'VERIFIED')))
    if not written or not any(w.written_value.get('note') for w in written):
        raise HTTPException(409, 'Uji TEST harus mencakup Note kiriman QRIS yang telah dibaca kembali.')
    dest.production_authorized_by, dest.authorized_at = user.id, utcnow()
    audit(db, user, 'authorize_production', dest, body.model_dump())
    save(db)
    return serialize(dest)

