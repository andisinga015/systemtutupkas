import os
import re
import time
import random
from urllib.parse import quote, urlparse

import requests
from google.auth.exceptions import GoogleAuthError
from google.auth.transport.requests import AuthorizedSession
from google.oauth2 import service_account

from .config import settings
from .engine.types import Cell, Grid, Issue, Write

SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]


def spreadsheet_id(url: str) -> str:
    parsed = urlparse(url)
    match = re.fullmatch(r"/spreadsheets/d/([A-Za-z0-9_-]{15,150})(?:/.*)?", parsed.path)
    if parsed.scheme != "https" or parsed.netloc != "docs.google.com" or not match or parsed.username:
        raise Issue("INVALID_URL", "Gunakan URL Google Spreadsheet https://docs.google.com/spreadsheets/d/…")
    return match[1]


def google_cell(raw: dict) -> Cell:
    user = raw.get("userEnteredValue", {})
    effective = raw.get("effectiveValue", {})
    if "errorValue" in effective:
        value = raw.get("formattedValue", "#ERROR!")
    else:
        value = next((effective[k] for k in ("numberValue", "stringValue", "boolValue") if k in effective), None)
    fmt = raw.get("effectiveFormat", {})
    rgb = fmt.get("backgroundColorStyle", {}).get("rgbColor", fmt.get("backgroundColor"))
    color = tuple(float(rgb.get(k, 0)) for k in ("red", "green", "blue")) if rgb is not None else None
    return Cell(value, user.get("formulaValue"), raw.get("note", ""), color,
                fmt.get("numberFormat", {}).get("type") in ("DATE", "DATE_TIME"))


class SheetsClient:
    def __init__(self):
        try:
            credentials = service_account.Credentials.from_service_account_file(settings().credential_file, scopes=SCOPES)
        except (OSError, ValueError):
            raise Issue("CREDENTIALS_UNAVAILABLE", "File Service Account belum tersedia atau tidak dapat dibaca oleh layanan.",
                        "Atur TK_CREDENTIAL_FILE ke file yang sudah ada dan beri akses baca hanya untuk pengguna layanan.")
        self.session = AuthorizedSession(credentials)
        self.last_request = 0.0

    def request(self, method: str, path: str, **kwargs):
        cfg = settings()
        # Keep TLS verification, including the platform's configured CA bundle.
        for attempt in range(cfg.api_retries + 1):
            remaining = cfg.google_min_interval - (time.monotonic() - self.last_request)
            if remaining > 0:
                time.sleep(remaining)
            self.last_request = time.monotonic()
            try:
                response = self.session.request(method, "https://sheets.googleapis.com/v4/spreadsheets/" + path,
                                                timeout=cfg.request_timeout, **kwargs)
            except GoogleAuthError:
                raise Issue("GOOGLE_AUTH_FAILED", "Google tidak menerima autentikasi Service Account.",
                            "Periksa kunci, waktu sistem, API Sheets aktif, serta koneksi ke oauth2.googleapis.com.")
            except requests.RequestException:
                if attempt == cfg.api_retries:
                    raise Issue("GOOGLE_TIMEOUT", "Google Sheets tidak dapat dihubungi dalam batas waktu.")
            else:
                if response.ok:
                    return response.json()
                if response.status_code not in (429, 500, 502, 503, 504):
                    code = {403: "ACCESS_DENIED", 404: "SPREADSHEET_MISSING"}.get(response.status_code, "GOOGLE_REQUEST_FAILED")
                    raise Issue(code, f"Google menolak permintaan spreadsheet (HTTP {response.status_code}).",
                                "Periksa URL, izin Editor untuk Service Account, serta akses API.")
                if attempt == cfg.api_retries:
                    raise Issue("GOOGLE_RATE_LIMIT" if response.status_code == 429 else "GOOGLE_TIMEOUT",
                                "Google belum dapat memproses permintaan setelah beberapa percobaan.")
            time.sleep(min(2 ** attempt + random.random(), 16))

    def metadata(self, document_id: str):
        return self.request("GET", document_id, params={"fields": "spreadsheetId,properties(title),sheets(properties),namedRanges"})

    def grid(self, document_id: str, title: str) -> Grid:
        meta = self.metadata(document_id)
        matches = [s['properties'] for s in meta.get('sheets', []) if s['properties']['title'] == title]
        if len(matches) != 1:
            raise Issue("TAB_MISSING", f"Sheet {title} tidak tersedia. Refresh Daftar Sheet untuk memeriksa nama terbaru.")
        p = matches[0]
        size = p.get('gridProperties', {})
        if size.get('rowCount', 0) * size.get('columnCount', 0) > settings().max_sheet_cells:
            raise Issue("SHEET_TOO_LARGE", "Sheet melebihi batas baca aman untuk memori VPS.",
                        "Hapus area kosong berlebih atau naikkan batas TK_MAX_SHEET_CELLS setelah memeriksa RAM.")
        raw = self.request("GET", document_id, params={"ranges": "'" + title.replace("'", "''") + "'",
            "includeGridData": "true", "fields": "sheets(properties,merges,data(startRow,startColumn,rowData(values(userEnteredValue,effectiveValue,effectiveFormat,note,formattedValue))))"})
        sheet = raw['sheets'][0]
        rows = []
        for band in sheet.get('data', []):
            start, col = band.get('startRow', 0), band.get('startColumn', 0)
            for i, row in enumerate(band.get('rowData', [])):
                while len(rows) <= start + i:
                    rows.append([])
                rows[start+i] = [Cell() for _ in range(col)] + [google_cell(v) for v in row.get('values', [])]
        return Grid(title, p['sheetId'], rows, sheet.get('merges', []))

    def write(self, document_id: str, grid: Grid, writes: list[Write]):
        requests_ = []
        for w in writes:
            value = {"numberValue": w.value} if isinstance(w.value, (float, int)) else {"stringValue": str(w.value)}
            cell = {"userEnteredValue": value}
            fields = "userEnteredValue"
            if w.note is not None:
                cell['note'] = w.note
                fields += ",note"
            requests_.append({"updateCells": {"range": {"sheetId": grid.sheet_id,
                "startRowIndex": w.row, "endRowIndex": w.row + 1, "startColumnIndex": w.col, "endColumnIndex": w.col + 1},
                "rows": [{"values": [cell]}], "fields": fields}})
        if requests_:
            self.request("POST", document_id + ":batchUpdate", json={"requests": requests_})

