export type Website = {id:number; display_name:string; slug:string; is_active:boolean; is_archived:boolean}
export type Doc = {id:number; year:number; month:number; document_type?:string; environment?:string; spreadsheet_url:string; spreadsheet_title:string|null; validation_status:string; validated_at:string|null; revision?:number; production_authorized_by?:number|null}
export type Tab = {id:number; tab_name:string; is_active:boolean; is_available:boolean}
export type Plan = {tab:string; cell:string; existing:{value:unknown;note:string};proposed:{value:unknown;note:string};bank:string}
export type Item = {id:number;source_document_id:number|null;source_tab_name:string;metric_type:string;status:string;result:{plan?:Plan[];source_cell?:string;closing_row?:number;verified?:boolean}|null}
export type TaskError = {id:number;run_item_id:number;source_document_id:number|null;source_tab_name:string;error_code:string;human_message:string;suggested_fix:string;retry_count:number;technical_details:Record<string,unknown>}
export type Run = {id:number;website_id:number;selected_date:string;environment:string;preview:boolean;status:string;started_at:string;finished_at:string|null;config_snapshot:{website:string;sources:{id:number;title:string;type:string;tabs:string[]}[];destination:{title:string}};items?:Item[];errors?:TaskError[]}
export type Clearance = {id:number;website_id:number;selected_date:string;environment:string;is_clear:boolean;confirmed_at:string}
export type Stats = {websites:number;active_websites:number;inactive_websites:number;active_tabs:number;inactive_tabs:number;validated_urls:number;failed_urls:number;success_runs:number;partial_runs:number;failed_runs:number;errors:number;credentials_configured:boolean;palette_configured:boolean}
let csrf = ''
export function setCsrf(value:string){csrf=value}
export async function api<T>(path:string, options:RequestInit={}):Promise<T>{
 const response = await fetch('/api'+path,{credentials:'same-origin',...options,headers:{'Content-Type':'application/json',...(csrf?{'X-CSRF-Token':csrf}:{}),...options.headers}})
 const data = await response.json().catch(()=>({detail:'Layanan tidak dapat dihubungi.'}))
 if(!response.ok){
  if(response.status===401 && !path.startsWith('/auth/')) window.dispatchEvent(new Event('session-expired'))
  throw new Error(typeof data.detail==='string'?data.detail:'Periksa kembali data formulir.')
 }
 return data as T
}
export const send = <T>(path:string, body:unknown={},method='POST')=>api<T>(path,{method,body:JSON.stringify(body)})
export const months=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember']
export function today(){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Jakarta',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())}
export function dateLabel(s:string){return new Date(s.length===10?s+'T12:00:00':s+'Z').toLocaleDateString('id-ID',{day:'numeric',month:'short',year:'numeric'})}
export const statusText:Record<string,string>={VALID:'Valid',UNVALIDATED:'Belum divalidasi',FAILED:'Gagal',SUCCESS:'Berhasil',PARTIAL:'Sebagian berhasil',RUNNING:'Sedang diproses',QUEUED:'Dalam antrean',PREVIEWED:'Pratinjau selesai',PENDING:'Menunggu',TEST:'TEST',PRODUCTION:'PRODUKSI'}
