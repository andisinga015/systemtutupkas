# Laporan penyerahan dan verifikasi

Tanggal pemeriksaan: 22 Oktober 2026. Laporan ini membedakan pengujian lokal dari akses Google/VPS yang belum tersedia. Tidak ada pengujian sumber finansial asli yang diklaim berhasil.

## Hasil lokal

| Pemeriksaan | Hasil |
|---|---|
| Backend pada Python 3.10.22 | 54 test lulus; 0 gagal/skip |
| Backend pada Python 3.12.14 | 54 test lulus; 0 gagal/skip |
| Browser Chromium + React + FastAPI + SQLite nyata lokal | 2 test E2E lulus |
| TypeScript dan Vite production build | Lulus |
| Alembic upgrade head dan pemeriksaan perubahan model | Lulus; tidak ada operasi migrasi tertinggal |
| Script instalasi development diulang | Lulus; lockfile dan database tidak direkreasi |
| Startup API/worker/Vite di cloud | Lulus; API health ok, worker_ready, frontend HTML tersedia |
| API terlindungi tanpa sesi | HTTP 401 sesuai harapan |
| CLI backup SQLite dan integrity_check lokal | Lulus |
| Sintaks shell script deployment/setup | Lulus |

Suite Python mengeluarkan satu peringatan deprecation dari Starlette TestClient terkait httpx. Ini peringatan dependensi test; tidak ada assertion yang dilewati atau dinonaktifkan. Runtime produksi tidak memakai TestClient.

### Cakupan yang diuji

- Login, password salah, expiry sesi, logout, akses tanpa sesi, CSRF, Origin, pembatasan percobaan login.
- WEB dinamis, perubahan nama/status, arsip, konflik slug, dan konfigurasi sumber/tujuan berbeda periode.
- Revisi URL, reset validasi, tab baru nonaktif, aktivasi, refresh, serta nama baru setelah rename nonaktif.
- Closing minus satu, koordinat contoh 306/88 dengan nilai yang ditetapkan spesifikasi, tanggal serial/Inggris/Indonesia, hari kosong/carry saldo, tanggal berikutnya hilang, dan header ganda.
- ABS setelah sum signed H, pemisahan G/H QRIS, filter fee harian, deskripsi asli/newline, dan satu label FEE WD AUTO.
- Mapping rekening unik dalam blok website; alias tersedia; tidak memilih rekening dari website lain.
- Transfer cokelat + deskripsi, pengecualian biru, warna belum disetujui, prioritas DEPO, bank sumber, overflow QRIS ke MANDIRI, slot penuh, dan preservasi tanda.
- Resolver kiriman dengan banner tanggal lengkap serta layout header nomor hari/TOTAL samping mengikuti bentuk screenshot, dengan posisi dinamis dan blok website vertikal. Angka hari tanpa batas struktural ditolak.
- Rencana output tujuh modul, formula/Note manual, formula yang menampilkan kosong, nol bukan slot kosong, Note QRIS, ledger, dan read-back melalui transport Google terisolasi.
- Partial success, dependensi agregat, retry gagal saja, start idempotent, run diulang tanpa append, putus koneksi setelah tulis, perubahan identitas transaksi, dan mismatch read-back.
- Worker subprocess sebenarnya: pemulihan job RUNNING yang sebelumnya diotorisasi, error kredensial hilang, penghentian tertib, dan penolakan worker kedua pada lock sama.
- Otorisasi produksi setelah TEST, penolakan sebelum otorisasi, Clear, dan reopen dengan alasan.
- E2E antarmuka: login, tambah WEB, simpan URL ke database, persist setelah reload, gagal validasi tanpa credential (tidak hijau palsu), riwayat URL, daftar sheet serentak, Start ditolak tanpa tujuan, navigasi ponsel, produksi terkunci, logout.

`FakeSheets` hanya merupakan transport test di `backend/tests`; aplikasi produksi selalu menggunakan SheetsClient asli. Screenshot dokumentasi memakai database E2E sementara; nama WEB UJI E2E bukan website produksi dan tidak disimpan ke database rilis.

## Belum diuji dan prasyarat eksternal

| Pemeriksaan nyata | Status / tindakan |
|---|---|
| Autentikasi Service Account VPS melalui aplikasi baru | Belum dijalankan; file hanya ada di VPS Anda |
| Metadata serta pembacaan sumber Google Anda | Belum dijalankan; konfigurasikan URL melalui Admin setelah instalasi |
| Penulisan ke salinan TEST dan read-back Google asli | Belum dijalankan; gunakan Start TEST lalu pemeriksaan di bawah |
| Formula dan Note dalam workbook asli | Belum diverifikasi; hasil lokal tidak membuktikan perilaku workbook asli |
| RGB kiriman dan makna biaya G QRIS QRIZZ | Perlu dicocokkan ke data nyata, kemudian palet disetujui |
| Grid/merge KET PENGIRIMAN asli | Perlu verifikasi terhadap struktur yang didukung; ambiguitas menjadi error item |
| Koreksi otomatis kiriman yang berubah/pindah baris tanpa ID stabil | Tidak didukung; konflik memerlukan rekonsiliasi, tanpa overwrite buta |
| Installer root, ACL kunci, systemd, Nginx IPv4 dan HTTPS di VPS | File/panduan tersedia, belum dijalankan di VPS |
| `https://tutupkasliongroup.com` menyajikan aplikasi ini | Belum dibuktikan; tidak ada akses SSH dari lingkungan ini |
| Pemulihan/rollback pada VPS | Panduan tersedia; belum dieksekusi pada server Anda |
| PostgreSQL atau skala di atas kemampuan VPS 2 GB | Belum diuji; SQLite dan worker tunggal adalah target awal |

Aplikasi **belum dinyatakan production-ready**. Langkah berikutnya adalah memasang ZIP, membuat admin, menghubungkan Nginx yang sudah ada, lalu menjalankan TEST dengan kredensial yang tetap tersimpan di VPS. Lihat [DEPLOYMENT.md](DEPLOYMENT.md).

Setelah run TEST nyata berhasil, jalankan dari backend di VPS dengan environment layanan dimuat:

```bash
sudo -u tutupkas bash -c 'set -a; source /etc/tutupkas/app.env; set +a; cd /opt/tutupkas/current/backend; /opt/tutupkas/current/.venv/bin/python ../scripts/verify-real-run.py RUN_ID'
```

Ganti RUN_ID dengan hasil Start TEST yang Anda otorisasi. Perintah ini hanya membaca Google dan membandingkan semua sel/Note dengan ledger; tidak membuat penulisan baru. Jika ledger run lama sudah digantikan run baru, pilih run terakhir yang masih memiliki outputnya. Tinjau juga formula dan retry dari Admin sebelum otorisasi produksi.

## Konfigurasi cloud

`install_script` dan `start_skill` disimpan sebagai draf konfigurasi cloud. Custom network additions: `sheets.googleapis.com`, `oauth2.googleapis.com`; preset package manager dipertahankan. Tidak ada private key atau password yang disimpan di konfigurasi tersebut. Penyimpanan draf bukan publication dan bukan deployment VPS. Untuk mempertahankan environment cloud, tinjau dan simpan draf di Environment Settings, kemudian Publish melalui produk. Restorasi pada task baru belum diuji.

## Referensi penyerahan

- Struktur source, rute UI, dan perintah setup/build/test: [README](../README.md).
- Endpoint API, tabel, migrasi, dan kontrol akses: [IMPLEMENTATION.md](IMPLEMENTATION.md).
- Aturan tujuh modul, parser, batas pemetaan, dan write ledger: [ENGINE.md](ENGINE.md).
- SCP/SFTP, instalasi, konfigurasi Nginx, backup, restore, rollback: [DEPLOYMENT.md](DEPLOYMENT.md).
- Spesifikasi pengguna yang dipertahankan: [SPECIFICATION.md](SPECIFICATION.md).

