# COMPLETE MASTER PROMPT FOR CODEX
# TUTUP KAS LION GROUP — FULL ADMIN PANEL AND TASK 01 SPREADSHEET AUTOMATION SYSTEM

## IMPORTANT: THIS IS A COMPLETELY NEW PROJECT INSTRUCTION

You are a senior full-stack software engineer, backend architect, Google Sheets automation specialist, database engineer, DevOps engineer, QA engineer, and professional UI/UX designer.

Build a complete, operational, self-hosted business application named:

**TUTUP KAS LION GROUP**

Official domain:

**https://tutupkasliongroup.com**

This document contains the complete requirements for the project. Treat it as a standalone specification.

Do not assume any previous Codex conversation, prior implementation instructions, existing repository, or previously generated code.

You must design and implement the project from the beginning, while preserving the existing VPS infrastructure and working Google Service Account setup.

The user is not requesting an architecture proposal, demonstration interface, wireframe, or unfinished prototype.

**The user requires a working application capable of reading real Google Spreadsheet data, processing it according to the rules below, and writing verified results into the correct Google Spreadsheet destination.**

The application must also provide a premium Admin Panel to manage the entire process without editing code.

---

# PART I — PROJECT FOUNDATION

## 1. Primary Project Objective

Build a browser-based administration and automation system that manages multiple Google Spreadsheets across multiple websites.

The application must allow administrators to:

1. Register new websites.
2. Manage existing websites.
3. Configure monthly DOC DEPO URLs.
4. Configure monthly DOC QRIS URLs.
5. Configure monthly Kas Semua Web destination URLs.
6. Validate Google Spreadsheet access.
7. Discover the available source spreadsheet tabs.
8. Activate or deactivate individual source tabs.
9. Detect newly added or renamed tabs through manual refresh.
10. Select a specific transaction date.
11. Manually start data extraction for an individual website.
12. Automatically identify source values using known headers and date separators.
13. Automatically identify destination locations using website identities, account names, and dates.
14. Calculate deposits, withdrawals, balances, expenses, QRIS fees, and transfer information.
15. Write the processed values into the appropriate destination sheets.
16. Preserve formulas, existing summaries, and unrelated data.
17. Display detailed processing results.
18. Diagnose failures using a human-readable Error Center.
19. Retry only failed source items.
20. Mark fully verified dates as completed.
21. Maintain historical configuration and execution records.
22. Prepare a foundation for future Task 02 and Task 03 without activating them.

The initial workload includes approximately 38 spreadsheets and may grow.

**Never hardcode the number of websites, spreadsheets, or tabs.**

## 2. Required Deliverable

The final deliverable must contain:

- A real frontend application.
- A real backend application.
- A persistent database.
- Secure administrator authentication.
- Functional website management.
- Functional Google Spreadsheet URL management.
- Functional Google Spreadsheet validation.
- Functional spreadsheet-tab management.
- A working Task 01 crawler and writer.
- Accurate daily data calculations.
- Automatic destination mapping.
- A manual Start mechanism.
- Real Google Sheets API integration.
- A human-readable Error Center.
- Selective retry functionality.
- Duplicate-write prevention.
- Formula and Note protection.
- A secure deployment configuration.
- Automated tests.
- End-to-end integration tests.
- Clear installation instructions.
- Database backup and recovery instructions.
- An operational application accessible through the user's domain.

Do not deliver buttons that only display fake success notifications.

Do not deliver dummy data pretending to be production results.

Do not declare a feature successful without testing it appropriately.

---

# PART II — EXISTING VPS INFRASTRUCTURE

## 3. Hosting Details

The user already owns and operates the VPS.

| Component | Value |
|---|---|
| Hosting provider | IDCloudHost |
| Operating system | Ubuntu 22.04.5 LTS |
| Public IPv4 | 103.193.176.114 |
| Private IPv4 | 10.84.193.3 |
| Initial RAM | 2 GB |
| Python version | 3.10.12 |
| Web server | Nginx |
| Domain | tutupkasliongroup.com |
| HTTPS | Let's Encrypt |
| Existing Google Sheets authentication | Service Account |
| Database hosting | VPS only |

The domain already resolves to the VPS.

Nginx has already been installed and tested successfully.

HTTPS has already been configured successfully.

The domain currently displays the standard Nginx welcome page because the application has not yet been deployed.

## 4. Existing Google Spreadsheet Robot

The existing Python robot directory is:

`/home/aksesfinancebot/spreadsheet-robot/`

The existing Google Service Account credentials file is:

`/home/aksesfinancebot/spreadsheet-robot/credentials/robot-key.json`

The Service Account has already successfully accessed a Google Spreadsheet and retrieved its title and source-tab list.

Do not delete, overwrite, or corrupt the existing project or credentials.

Do not request the private key contents in chat.

Do not expose credentials to the frontend.

Do not include credentials in application logs.

If the service runs under a dedicated Linux user, configure access to the existing credential file securely instead of changing it to world-readable permissions.

## 5. Existing Nginx Limitation

The VPS previously encountered an error when Nginx attempted to bind to an IPv6 socket.

The error involved:

`socket() [::]:80 failed`

The issue was resolved by using IPv4 listeners.

When updating Nginx:

- Inspect the existing configuration.
- Back up configuration files.
- Preserve existing HTTPS.
- Do not automatically restore unsupported IPv6 listeners.
- Validate configuration with `nginx -t`.
- Reload Nginx only after successful validation.

Do not reinstall the operating system or remove the existing SSL configuration.

---

# PART III — TECHNOLOGY AND APPLICATION ARCHITECTURE

## 6. Required Technology Stack

### Backend

Use:

- Python.
- FastAPI.
- SQLAlchemy.
- Alembic.
- Pydantic.
- Google Sheets API v4.
- Google authentication libraries.
- Structured logging.
- Persistent job records.

The implementation must be compatible with Python 3.10 or clearly provision a supported newer runtime safely without disrupting the existing robot.

### Frontend

Use:

- React.
- TypeScript.
- Vite.
- Tailwind CSS.
- shadcn/ui-style components.
- Lucide icons.

### Database

Use SQLite initially.

Requirements:

- Database stored locally on the VPS.
- Foreign keys enabled.
- Appropriate indexes.
- Database migrations.
- Safe backup support.
- Transactional consistency.
- Clear schema design.
- Future PostgreSQL migration capability.

Do not use Firebase, Supabase, or another externally hosted database.

### Web Server

Use the existing Nginx deployment.

Nginx must serve the built frontend and reverse-proxy backend API requests.

### Application Services

Use systemd services.

The backend and job worker must run as restricted non-root processes.

Do not expose internal API ports directly to the internet.

## 7. Resource Efficiency

The initial VPS has 2 GB RAM.

The application should use a lightweight architecture.

Avoid unnecessary services such as Kubernetes or a large distributed message queue.

A database-backed worker queue is acceptable.

Requirements:

- Controlled Google API request concurrency.
- Efficient batched reads.
- Efficient batched writes.
- Avoid unnecessary full-spreadsheet downloads.
- Memory-efficient processing.
- Persistent job states.
- Reasonable request timeouts.
- Exponential backoff for transient Google API failures.
- Controlled retry limits.

Frontend assets must be compiled for production.

Do not run a Vite development server permanently.

## 8. No GitHub Requirement

The user explicitly does not want GitHub.

Do not require:

- GitHub repositories.
- GitHub Actions.
- GitHub authentication.
- GitHub-based deployment.
- Cloud-hosted CI/CD.

If deployment access is unavailable, produce the full project and provide secure SCP/SFTP transfer instructions.

Do not claim direct VPS deployment unless it was actually performed.

---

# PART IV — PREMIUM ADMIN INTERFACE DESIGN

## 9. Design Theme

The administrator selected a premium modern fintech dashboard appearance.

Use the following design direction:

**DARK NAVY + ELECTRIC BLUE GLOW**

The application must look professional, modern, sophisticated, and visually polished.

Required visual characteristics:

- Dark navy application background.
- Subtle blue gradients.
- Electric-blue accent colors.
- Elegant glass-inspired cards.
- Soft shadows and borders.
- Sidebar with modern icons.
- Responsive top navigation.
- Professional typography.
- Clear information hierarchy.
- Refined table styling.
- Modern date selectors.
- Premium-looking buttons.
- Smooth hover interactions.
- Light, subtle animations.
- Professional loading indicators.
- Attractive empty states.
- Responsive design.

Avoid an ordinary plain-white admin template.

Avoid excessive glow effects that reduce readability.

The visual reference is a premium SaaS analytics dashboard with a dark-blue sidebar, layered analytical cards, and refined blue highlights.

## 10. Application Language

The user interface must use **Bahasa Indonesia**.

The implementation instructions are English, but the actual website is intended for Indonesian-speaking administrators.

Examples:

- Dashboard
- Pengaturan WEB
- Tambah WEB
- Simpan Pengaturan
- Validasi URL
- Buka Spreadsheet
- Riwayat URL
- Daftar Sheet Aktif
- Daftar Sheet Nonaktif
- Refresh Daftar Sheet
- Pilih Tanggal
- Mulai Penarikan
- Sedang Diproses
- Berhasil
- Sebagian Berhasil
- Gagal
- Pusat Kesalahan
- Crawl Ulang
- Selesai & Clear

All error explanations must be understandable by nonprogrammers.

---

# PART V — LOGIN AND ADMIN SECURITY

## 11. Login Page

Route:

`/login`

Implement:

- Secure administrator login.
- Password hashing using a modern algorithm.
- Secure authentication sessions.
- HttpOnly cookies.
- Secure cookies over HTTPS.
- Appropriate SameSite settings.
- CSRF protection.
- Login rate limiting.
- Session expiration.
- Logout.
- Protection against unauthorized API access.

Do not implement public registration.

Create the first administrator through a secure CLI setup command.

Do not hardcode a default password.

## 12. Access Control

Only authenticated and authorized administrators may:

- Manage websites.
- Change URLs.
- Validate documents.
- Activate or deactivate tabs.
- Start crawling.
- Retry failed operations.
- Change production destinations.
- Mark dates as Clear.

Design the authorization layer so additional staff roles can be introduced later.

---

# PART VI — WEBSITE MANAGEMENT

## 13. Main Website Management Page

Route:

`/admin-setting`

The administrator must be able to:

- Add websites.
- Edit website display names.
- Activate websites.
- Deactivate websites.
- Archive websites.
- Search websites.
- Filter websites.
- Open website settings.

Examples of registered websites:

- VELBETT
- FANTASI
- BBTOTO
- ANGKASABET
- HUNTERTOTO

The system must support unlimited additional websites within practical infrastructure limits.

## 14. Dynamic Routes

When a website is registered, its settings page must become available automatically.

Examples:

`/admin-setting/velbett`

`/admin-setting/fantasi`

`/admin-setting/bbtoto`

If HUNTERTOTO is added:

`/admin-setting/huntertoto`

must work automatically.

No code changes should be required.

Each website needs:

- Internal unique ID.
- Display name.
- Unique stable slug.
- Active/inactive status.
- Archived status.
- Created timestamp.
- Updated timestamp.

Changing a display name must not corrupt associated spreadsheet configurations or historical records.

## 15. Website Identity

The website registered in the Admin database is the authoritative identity.

For example:

`VELBETT`

may have:

- One DOC DEPO URL.
- One DOC QRIS URL.

Both belong to VELBETT because they were configured under VELBETT.

Do not infer website ownership solely from the Google Spreadsheet document title.

The Google title is used for display, diagnosis, and validation.

---

# PART VII — MONTHLY SOURCE SPREADSHEET SETTINGS

## 16. Website Settings Page

Route:

`/admin-setting/{web_slug}`

Example:

`/admin-setting/velbett`

Required fields:

| Field | Requirement |
|---|---|
| Website | Automatically identified |
| Month | Dropdown |
| Year | Dropdown |
| DOC DEPO URL | Optional |
| DOC QRIS URL | Optional |
| Save | Functional |
| Validate DOC DEPO | Functional |
| Validate DOC QRIS | Functional |
| Open Spreadsheet | Functional |
| URL History | Separate page |
| Sheet Management | Separate page |

## 17. Monthly URL Management

Every source document belongs to:

- Website.
- Document type.
- Year.
- Month.

Example:

VELBETT / DOC DEPO / October 2026.

This configuration is independent of:

VELBETT / DOC DEPO / November 2026.

All URLs may change monthly.

The system must preserve previous months.

Do not overwrite October when adding November.

## 18. Optional Document Types

Some websites may have only DOC DEPO.

Some may have only DOC QRIS.

Some may have both.

Do not require administrators to fill a nonexistent document field.

If a source is absent, skip that document type, but do not report successful processing for metrics that require an unavailable source.

## 19. URL Replacement

If a source URL changes:

1. Record the previous URL.
2. Save the new URL.
3. Reset its validation status.
4. Require new validation.
5. Refresh the available tab list.
6. Treat the new document as a fresh monthly sheet configuration.
7. Default newly discovered tabs to inactive.
8. Preserve previous configuration history.

---

# PART VIII — URL VALIDATION

## 20. Validation Process

Each URL has its own Validate button.

When clicked:

1. Validate Google Spreadsheet URL syntax.
2. Extract the spreadsheet ID.
3. Authenticate using the existing Service Account.
4. Request spreadsheet metadata.
5. Confirm reading access.
6. Retrieve the actual spreadsheet title.
7. Retrieve available tab names.
8. Store validation results.
9. Update the UI.

## 21. Validation Status

Possible statuses:

- Belum Divalidasi.
- Sedang Divalidasi.
- Valid.
- Gagal Validasi.
- Perlu Verifikasi Izin.

When validation succeeds, display a clearly visible green indicator.

If the URL changes, immediately reset the previous validation success state.

Do not display a green status for a URL that has never actually been validated.

## 22. Spreadsheet Opening

Provide a **Buka Spreadsheet** button beside the URL.

The button opens the actual Google Spreadsheet URL.

Do not require the administrator to copy and paste the URL manually.

## 23. Validation Does Not Run Task 01

Validation may retrieve metadata.

It must not automatically read all transaction data.

It must not write transaction values.

It must not execute Task 01.

## 24. Destination Permission Validation

Read access does not guarantee write access.

For actual write testing, use an administrator-approved test spreadsheet.

Do not modify arbitrary cells in a production destination merely to verify permissions.

---

# PART IX — MONTHLY URL HISTORY

## 25. Source URL History

Route:

`/admin-setting/{web_slug}/history-url`

Example:

`/admin-setting/velbett/history-url`

Display:

- Month.
- Year.
- DOC DEPO URL.
- DOC QRIS URL.
- Actual spreadsheet title.
- Validation status.
- Validation timestamp.
- Change history.
- Open Spreadsheet button.

Historical URL configurations must remain accessible.

---

# PART X — ACTIVE AND INACTIVE SOURCE TABS

## 26. Tab Management Page

Route:

`/admin-setting/{web_slug}/sheet-aktif`

Example:

`/admin-setting/velbett/sheet-aktif`

Required controls:

- Month dropdown.
- Year dropdown.
- DOC DEPO / DOC QRIS selector.
- Refresh Daftar Sheet button.
- Action selector.
- Tab selection checkboxes.
- Apply button.

Actions:

- Aktifkan.
- Nonaktifkan.

## 27. Always-Visible Status Lists

Below the action controls, display:

**Daftar Sheet Aktif**

and

**Daftar Sheet Nonaktif**

These must always be visible simultaneously.

They are informational lists, not navigation buttons.

The administrator should not need to keep switching tabs to determine which source tabs are currently active.

## 28. Only Two States

A source tab can be:

- ACTIVE.
- INACTIVE.

Do not implement a third Pending state.

## 29. New Monthly Spreadsheet

Every tab discovered in a newly configured monthly spreadsheet must initially be INACTIVE.

The administrator explicitly activates the tabs required for that month.

Do not inherit activation statuses from the previous month.

## 30. Refresh Daftar Sheet

When clicked:

1. Read the current tab-name list from Google.
2. Compare it with the current document configuration.
3. Preserve statuses for unchanged tab names within the same unchanged document.
4. Add newly discovered names as INACTIVE.
5. Identify removed or renamed tabs.
6. Exclude removed tabs from processing.
7. Refresh both status lists.

## 31. Renamed Tabs

If:

`WD BCA 2 / ALIN HELPINA`

becomes:

`WD BCA 2 / ALIN HELPINA BARU`

then after Refresh:

- The old name is no longer available.
- The new name appears as INACTIVE.
- The administrator must activate it manually.

Do not automatically assume that a renamed tab should remain active.

## 32. No Admin Sheet ID Requirement

Administrators must work with tab names.

Do not require them to type or configure numeric sheet IDs.

Internal Google metadata IDs may be used by the software where necessary.

## 33. Inactive Tab Processing

An INACTIVE tab:

- Is not crawled for transaction data.
- Does not produce destination writes.
- Does not generate a transaction-processing error.
- Is excluded from applicable active-source aggregations.

If every relevant source tab is inactive, Start must not falsely report success.

Display:

**Tidak ada sheet aktif untuk diproses.**

---

# PART XI — KAS KECIL MONTHLY DESTINATION

## 34. Main Destination Page

Route:

`/kas-kecil`

The administrator configures the monthly destination Google Spreadsheet.

Required controls:

- Month dropdown.
- Year dropdown.
- Kas Semua Web URL.
- Save button.
- Validate button.
- Open Spreadsheet button.
- Validation status.
- Actual spreadsheet title.

The destination URL changes every month.

## 35. Destination History

Route:

`/kas-kecil/history-url`

Preserve previous destination URLs.

## 36. Source and Destination Period Consistency

When processing October 15, 2026:

Use the October 2026 source documents and the October 2026 Kas Semua Web destination.

Never accidentally write October results into November.

## 37. Test and Production Destinations

Implement explicit environments:

### TEST

Uses an administrator-approved copy of the destination spreadsheet.

Actual crawler reads and writes are allowed.

### PRODUCTION

Uses the official monthly Kas Semua Web destination.

Writing is enabled only after administrator authorization.

Test and production configurations must be clearly separated.

Never silently substitute one environment for another.

---

# PART XII — MAIN DASHBOARD

## 38. Main Dashboard Route

`/dashboard`

Display:

- Total websites.
- Active websites.
- Inactive websites.
- Active source tabs.
- Inactive source tabs.
- Validated URLs.
- Validation failures.
- Successful Task 01 runs.
- Partially successful runs.
- Failed runs.
- Outstanding errors.

## 39. Manual Execution per Website

Each website has:

- Website name.
- Status.
- Date picker.
- Start button.
- Latest processing result.
- Settings link.
- Completion status.

The administrator may select historical dates.

For example, on October 20, the administrator can process October 16.

## 40. Manual Start Only

This requirement is absolute.

**No automatic transaction crawling.**

Do not use cron to automatically extract transactions.

Do not run Task 01 when an administrator saves a URL.

Do not run Task 01 when an administrator validates a URL.

Do not start Task 02 automatically after Task 01.

A run begins only because the administrator explicitly clicks Start or the relevant selective-retry button.

A user-initiated job may continue executing on the server after the HTTP request returns.

However, no new independent transaction job may begin without a user action.

## 41. Start Validation

Before allowing Start:

- Website must be active.
- Selected date must be valid.
- Corresponding source URL must be configured.
- Applicable source URL must be validated.
- Relevant active tabs must exist.
- Destination URL must exist.
- Destination must be validated.
- Destination period must match.
- Production write authorization must be satisfied.
- No conflicting run may already be active.

## 42. Date Completion Checklist

Implement:

**Selesai & Clear**

The administrator can mark a fully successful date as reviewed and completed.

A date with unresolved processing errors cannot be marked fully Clear.

A cleared date should be protected from accidental repeated crawling.

Provide an explicit administrator action to reopen the date for corrections.

Store:

- Website.
- Date.
- Month.
- Year.
- Task.
- Reviewing administrator.
- Completion status.

---

# PART XIII — TASK 01 BUSINESS PROCESS

## 43. Complete Task 01 Scope

Task 01 must read from active DOC DEPO and DOC QRIS tabs and write into the monthly Kas Semua Web spreadsheet.

It includes these destination sheets:

1. TOTAL DEPO.
2. TOTAL WD.
3. SALDO BANK.
4. BIAYA.
5. Pengeluaran FEE QRIS DEPO.
6. Pengeluaran FEE QRIS WD.
7. KET PENGIRIMAN.

Every module must actually work, subject to validated business rules and safe destination mapping.

The modules share one manual execution workflow, but different modules require different calculation methods.

Do not attempt to process all modules using one simplistic fixed-cell extraction method.

---

# PART XIV — SOURCE DATE LOGIC

## 44. Source Spreadsheet Structure

Source spreadsheets contain black daily date-separator rows.

Daily transactions are located between date separators.

The number of transaction rows varies.

Some days have many rows.

Some days have only one row.

Some days have no transactions.

The Google Spreadsheet may contain grouped or hidden rows.

## 45. Fixed Minus-One Closing Rule

For a requested date:

1. Identify the following calendar date.
2. Find that date's separator row.
3. Subtract exactly one from the row number.
4. Read the closing metric values from that preceding row.

Formula:

`closing_row = next_date_separator_row - 1`

The offset is permanently fixed at -1.

The physical row number is dynamic.

## 46. Example — October 15

Requested date:

October 15, 2026.

Following date:

October 16, 2026.

Following-date separator row:

307.

Closing row:

306.

Read the appropriate source metric columns from row 306.

## 47. Dynamic Date Detection

Support:

- Date cells.
- Formatted date strings.
- English weekday labels.
- Different month names.
- Merged date cells.
- Grouped rows.
- Hidden rows.
- Dynamic row positions.

Do not use hardcoded date-row positions.

## 48. Final Visible Date

The administrator does not want to configure a special final date marker.

Where the next-day separator exists, use the fixed -1 method.

If the next-day separator does not yet exist, inspect the actual available source data carefully.

Do not mistake preformatted empty rows for a confirmed closing row.

Do not silently invent a closing balance.

The engine may produce a provisional result only if a reliable, tested source-boundary rule can establish that result.

Otherwise, report that the closing date is not yet verifiable.

---

# PART XV — NO-TRANSACTION DAYS

## 49. Empty Daily Transaction Sections

When there are no transactions between two consecutive daily separators:

- Total DEPO = 0.
- Total WD = 0.
- SALDO = previous valid closing balance.

Example:

Closing balance on October 15:

2,355,000.

If October 16 has no transactions:

- DEPO = 0.
- WD = 0.
- SALDO = 2,355,000.

Continue carrying the last valid balance through consecutive empty transaction days.

Do not confuse an inaccessible or malformed source with a legitimate zero-transaction day.

---

# PART XVI — SOURCE METRIC HEADERS

## 50. DOC DEPO Headers

| Source header | Metric |
|---|---|
| Total | Total Deposit |
| Total WD | Total Withdrawal |
| SALDO | Closing Balance |

## 51. DOC QRIS Headers

| Source header | Metric |
|---|---|
| Total Depo | Total Deposit |
| Total WD | Total Withdrawal |
| SALDO | Closing Balance |

Determine metric columns by reading the source header labels.

Do not hardcode metric column letters.

If a required header cannot be uniquely identified, report an error.

---

# PART XVII — VERIFIED EXAMPLE DATA

## 52. DOC DEPO Example

Website:

VELBETT.

Source tab:

`WD BCA 1 TOKEN / IVAN RAKHMANDA ( PP )`

Date:

October 15, 2026.

Closing row:

306.

| Data | Cell | Expected value |
|---|---|---:|
| Deposit | J306 | 0 |
| Withdrawal | K306 | 9,399,000 |
| Balance | L306 | 2,355,000 |

## 53. DOC QRIS Example

Website:

VELBETT.

Source tab:

`QRIS E-POWER`

Date:

October 15, 2026.

Closing row:

88.

| Data | Cell | Expected value |
|---|---|---:|
| Deposit | I88 | 75,342,988 |
| Withdrawal | J88 | 59,804,000 |
| Balance | K88 | 449,057,834 |

Use these examples in automated tests.

Do not hardcode these cell coordinates into production logic.

---

# PART XVIII — AUTOMATIC DESTINATION MAPPING

## 54. No Manual Column Configuration

The administrator does not want to enter destination letters such as E, AU, CO, or CF.

The application must determine destination locations automatically.

## 55. Destination Identification Sequence

The resolver must identify:

1. Destination spreadsheet.
2. Destination tab.
3. Website group.
4. Source-account header.
5. Requested date row.
6. Target metric cell.

## 56. Website Groups

The destination contains multiple website blocks.

Examples:

- VELBETT.
- FANTASI.
- BBTOTO.

The website name is typically displayed in a merged header region.

Each website has its own date column and account columns.

Different destination tabs may place the same website at different column positions.

Do not assume the VELBETT block always occupies the same columns on every destination tab.

## 57. Block Boundary Detection

Detect registered website labels and determine each website group's boundaries.

Example order:

VELBETT → FANTASI → BBTOTO.

The next website header marks the next group.

Do not mistake ordinary headings for website names.

Examples of non-website headings:

- BCA.
- MANDIRI.
- QRIS.
- JUMLAH.
- JUMLAH TANPA QRIS.
- DANA.
- BRI.
- BNI.

Use both the registered website identity and destination structural checks.

## 58. Source Account Matching

The source tab name identifies the corresponding destination account or QRIS.

Example:

`WD BCA 1 TOKEN / IVAN RAKHMANDA ( PP )`

The destination may contain that full name in row 2.

However, some destination examples display shortened account labels.

For example:

Source:

`WD BCA 2 / ALIN HELPINA`

Destination header:

`ALIN HELPINA`

Another example:

Source:

`QRIS E-POWER`

Destination category:

`QRIS`

Destination subheader:

`E-POWER`

Implement safe deterministic matching:

1. Prefer an exact normalized match.
2. Normalize case and harmless whitespace.
3. Recognize established prefixes such as QRIS or bank account descriptors.
4. Combine category headers and subheaders where necessary.
5. Require a unique match inside the correct website block.
6. Do not use arbitrary fuzzy matching to select a financially significant destination.
7. If more than one destination remains plausible, report an error.

If unavoidable naming exceptions exist, allow an administrator to configure an explicit **source-name to destination-header alias** without entering a column number.

The default workflow must remain automatic and require no per-column configuration.

## 59. Destination Date Mapping

For the regular destination sheets:

- The account header is generally on row 2.
- Date data generally begins on row 3.

Find the requested date in the website's own date column.

Do not search across unrelated website blocks.

## 60. Example

Website:

VELBETT.

Source:

`WD BCA 1 TOKEN / IVAN RAKHMANDA ( PP )`

Date:

October 15, 2026.

Balance:

2,355,000.

Screenshot destination example:

`SALDO BANK!E17 = 2355000`

The engine should discover that location automatically.

## 61. Duplicate Names Across Websites

The same tab name may exist under several different websites.

For example:

VELBETT may have QRIS E-POWER.

BBTOTO may also have QRIS E-POWER.

This is normal.

Use the website identity to prevent collisions.

If two active sources within the same website attempt to write different values into the same destination metric cell, report a mapping conflict.

Never silently overwrite one with the other.

---

# PART XIX — DAILY EXPENSE CALCULATION

## 62. Destination Sheet BIAYA

Each website has its own section with:

- BIAYA.
- BIAYA TARIK QRIS.
- BIAYA AUTO WD.
- JUMLAH.

Do not overwrite formulas in the JUMLAH column.

## 63. General BIAYA — DOC DEPO

Source:

DOC DEPO.

Scope:

Every active source tab belonging to that website.

Source column:

**H**

Calculation:

1. Identify all transaction rows for the selected date.
2. Read signed numeric values in column H.
3. Sum values across all applicable active DOC DEPO tabs.
4. Convert the final total into a positive number.

Formula:

`ABS(SUM(all applicable signed H values))`

Important:

**SUM FIRST, THEN APPLY ABSOLUTE VALUE.**

Do not automatically take the absolute value of every individual transaction before summing.

## 64. BIAYA TARIK QRIS

Source:

DOC QRIS.

Fixed tab:

`QRIS QRIZZ`

Destination:

`BIAYA` → `BIAYA TARIK QRIS`

The supplied screenshots suggest that ordinary fee values are recorded in column G.

Example:

`QRIS QRIZZ!G61 = -5,000`

The destination screenshot shows:

`BIAYA!C17 = 5,000`

for VELBETT on October 15.

Treat column G as the expected mapping for the initial integration test.

Validate this interpretation against the real authorized source and destination copies.

Do not confuse ordinary G-column BIAYA with H-column FEE QRIS PERIODE.

If the actual source structure contradicts the proposed G-column rule, stop only the affected metric, report the discrepancy, and do not fabricate a result.

## 65. BIAYA AUTO WD

Source:

DOC QRIS.

Fixed tab:

`QRIS E-POWER`

Source column:

**G**

Read daily signed expense values.

Sum the applicable daily entries.

Convert the final signed total to positive.

Example:

`G88 = -492,000`

Expected result:

492,000.

This value is not the same as FEE WD AUTO from column H.

## 66. Aggregated Expense Safety

General BIAYA is an aggregate calculated from multiple active DOC DEPO tabs.

If one required source tab fails, do not write an incomplete total as if it were final.

Preserve valid independent outputs.

Recompute the incomplete aggregate when the failed dependency is corrected.

---

# PART XX — PENGELUARAN FEE QRIS DEPO

## 67. Source and Destination

Source document:

DOC QRIS.

Fixed source tab:

`QRIS QRIZZ`

Destination tab:

`Pengeluaran FEE QRIS DEPO`

## 68. Matching Description

Look for transactions with descriptions beginning with or matching:

`FEE QRIS PERIODE ...`

The text after PERIODE changes according to the actual transaction.

Do not hardcode the dates inside the text.

## 69. Source Fields

- Description: source description column, shown as D.
- Amount: source column H.
- Date: determined by the source daily section.

Column H may also contain ordinary transfer transactions.

Therefore, only include H-column values on rows identified as FEE QRIS PERIODE transactions.

## 70. Amount Processing

Sum the signed fee values belonging to the selected source date.

Convert the final negative total into a positive destination amount.

## 71. Description Preservation

Copy the entire original description.

Do not change the period wording.

Do not distribute the amount across the dates mentioned in that description.

Example:

`FEE QRIS PERIODE 14 - 15 october 2026`

If recorded on October 15, the whole amount belongs to October 15.

## 72. Multiple Descriptions

If more than one FEE QRIS PERIODE description belongs to the same selected date:

- Preserve all applicable descriptions.
- Write them into one destination description cell.
- Separate them using newline characters.
- Preserve the actual source wording.
- Sum only the qualifying fee amounts actually recorded for that selected date.

Example description cell:

FEE QRIS PERIODE 15- 16 october 2026  
FEE QRIS PERIODE 14 - 15 october 2026

Do not automatically count a previous day's fee again merely because its description is present as additional explanatory text.

If source-data semantics for multiple description lines are ambiguous, preserve the raw descriptions and verify the amount independently.

## 73. October 15 Example

Source description:

`FEE QRIS PERIODE 14 - 15 october 2026`

Source value:

`H60 = -621,134`

Destination:

- Date: October 15.
- Description: exact source text.
- FEE QRIS DEPO: 621,134.

## 74. Formula Protection

Do not overwrite the destination TOTAL formula column.

---

# PART XXI — PENGELUARAN FEE QRIS WD

## 75. Source and Destination

Source document:

DOC QRIS.

Fixed source tab:

`QRIS E-POWER`

Destination tab:

`Pengeluaran FEE QRIS WD`

## 76. Matching Description

Look for:

`FEE WD AUTO`

Source description column:

D in the illustrated layout.

Source amount column:

**H — Kiriman**

## 77. Calculation

Find all FEE WD AUTO transactions recorded under the selected date.

Sum their signed values.

Convert the final negative total into a positive destination amount.

## 78. Description Rule

Write:

`FEE WD AUTO`

only once.

Even if several FEE WD AUTO transactions exist on the same date, the destination description cell must not repeat the same text unnecessarily.

## 79. Confirmed Screenshot Examples

| Date | Source cell | Expected destination amount |
|---|---|---:|
| October 14 | H82 | 883,846 |
| October 15 | H87 | 732,340 |
| October 16 | H92 | 797,053 |
| October 17 | H98 | 660,194 |

October 15 destination:

Description:

FEE WD AUTO.

Nominal:

732,340.

## 80. Critical Separation

QRIS E-POWER column G contains ordinary BIAYA.

QRIS E-POWER column H contains Kiriman transactions including FEE WD AUTO.

These are separate expense categories.

Never combine them.

---

# PART XXII — KET PENGIRIMAN

## 81. Destination

Destination tab:

`KET PENGIRIMAN`

This module has a different layout from the ordinary metric sheets.

The destination contains:

- Date-based horizontal sections.
- Website groups.
- Bank groups.
- Description cells.
- Nominal cells.
- TOTAL calculation cells.

The exact layout must be discovered and validated from the destination spreadsheet.

Do not assume a simple one-date-per-row format for this module.

## 82. Eligible Source Transactions

Only collect rows satisfying BOTH conditions:

1. The source transaction description uses the recognized brown/orange-brown transfer formatting.
2. The description identifies an actual transfer.

Examples:

- KIRIM KE.
- PENGIRIMAN DARI.
- DARI KAS.
- Other explicitly recognized transfer-related descriptions.

A brown cell without an eligible transfer description must not be included automatically.

A transfer description with another background color must not be included automatically.

Blue-format exceptions must be excluded under the current business rule.

## 83. Color Detection

Read actual Google Sheets formatting metadata.

Do not rely on screenshots for production color detection.

Determine which source cell carries the transfer background styling, normally the description cell or relevant transaction cells.

Validate the actual formatting against real spreadsheet examples.

If the color classification is ambiguous, create a reviewable processing issue instead of guessing.

## 84. Source Processing Priority

The order is mandatory:

**FIRST: DOC DEPO**

**SECOND: DOC QRIS**

DOC DEPO transfers must be allocated before DOC QRIS transfers.

DOC QRIS uses the available destination slots remaining after DOC DEPO allocation.

## 85. DOC DEPO Bank Routing

For DOC DEPO, determine the destination bank using the source tab name.

Examples:

| Source tab | Destination bank |
|---|---|
| WD BCA 2 / ALIN HELPINA | BCA |
| WD MANDIRI / MUHAMMAD AFFAN NASUTION ( PP ) | MANDIRI |
| WD BRI / ... | BRI |
| WD BNI / ... | BNI |

The source tab's bank identity is authoritative.

Do not assign a DOC DEPO transaction to a different bank merely because the transaction description mentions that bank.

## 86. DOC DEPO Transfer Amount

Read the source amount from the column identified by the **Kiriman** header.

In the shown DOC DEPO structure, Kiriman may be column I.

Do not incorrectly assume DOC DEPO's Kiriman column is H.

Column H in DOC DEPO is used for the ordinary BIAYA calculation.

Resolve Kiriman by its actual header.

Preserve the original positive or negative transfer sign.

## 87. DOC DEPO Example

Source:

`WD BCA 2 / ALIN HELPINA`

Transaction:

`KIRIM KE NL KAS BCA`

Nominal:

-1,741,000.

Destination:

- Website: VELBETT.
- Bank: BCA.
- Correct selected date section.
- One description slot.
- One nominal slot.

Another example:

`PENGIRIMAN DARI KAS BESAR BCA`

Nominal:

10,000,000.

Each transaction must remain separate.

Do not combine the two values into one row.

## 88. DOC QRIS Transfer Routing

DOC QRIS transfers do not use the DOC DEPO bank-routing rule.

Instead, DOC QRIS transactions must fill available slots in this exact order:

**BCA → MANDIRI → BRI → BNI**

Rules:

1. Fill an available BCA slot first.
2. If BCA is full, use MANDIRI.
3. If MANDIRI is full, use BRI.
4. If BRI is full, use BNI.
5. If BNI is also full, report an error.

Do not insert spreadsheet rows automatically.

Do not overwrite existing cells to create space.

## 89. DOC QRIS Transfer Amount

For DOC QRIS, read the transfer nominal from:

**Column H — Kiriman**

Include transactions from applicable active QRIS tabs.

Preserve the original sign.

A negative transfer remains negative.

A positive transfer remains positive.

Do not apply the expense absolute-value rule.

## 90. Each Transfer Must Be Separate

Every qualifying transaction must occupy its own destination description and nominal slot.

Do not sum multiple transfer descriptions into one number.

## 91. Google Sheets Note for DOC QRIS

Every DOC QRIS transfer inserted into KET PENGIRIMAN must receive an actual Google Sheets cell **Note**.

This is the Note functionality commonly accessible through Shift+F2.

It must not be a discussion comment.

The Note should be attached to the generated transaction description cell.

Required format:

`QRIS E-POWER ( ORIGINAL DESCRIPTION ) 1.xxx.xxx`

or:

`QRIS QRIZZ ( ORIGINAL DESCRIPTION ) 1.xxx.xxx`

For other active QRIS tabs, use their actual tab name.

Example:

`QRIS E-POWER ( KIRIM KE KAS BESAR BCA ) -1.741.000`

Preserve the original signed nominal.

The Note must be present regardless of whether the transaction was placed in BCA, MANDIRI, BRI, or BNI.

## 92. Destination Slot Protection

Never overwrite:

- TOTAL labels.
- TOTAL formulas.
- Existing transfer descriptions.
- Existing nominal values.
- Website headers.
- Bank headers.
- Date headers.
- Manual entries.
- Unrelated Notes.
- Protected calculation cells.

A slot is available only if both the description and nominal cells are actually available.

Do not treat a formula returning a blank string as an empty cell.

Do not assume a numeric zero automatically means an empty slot.

## 93. Transfer Slot Ownership

Record which transfer slots were written by the crawler.

Required information includes:

- Website.
- Date.
- Source document.
- Source tab.
- Source transaction fingerprint.
- Destination bank.
- Destination description cell.
- Destination nominal cell.
- Written values.
- Associated Note.
- Execution ID.

This information is necessary for safe selective retry.

## 94. Transfer Retry

During a retry:

1. Identify crawler-owned entries for that failed source.
2. Read the latest source transactions.
3. Reconcile old and new transaction identities.
4. Update only affected owned entries.
5. Update the associated Notes.
6. Avoid creating duplicate transactions.
7. Preserve all unrelated manual or crawler-generated entries.

If ownership cannot be established safely, report a conflict instead of overwriting unknown content.

---

# PART XXIII — REAL WRITE ENGINE

## 95. Safe Write Planning

Before writing data:

1. Read current destination metadata.
2. Resolve destination website.
3. Resolve destination tab.
4. Resolve destination date.
5. Resolve the account or bank block.
6. Resolve the target cell or slot.
7. Read existing target content.
8. Inspect formulas and Notes.
9. Verify that the write is permitted.
10. Construct a deterministic write plan.

## 96. Preview Mode

Provide a manual Preview or Dry Run option.

Preview displays:

- Website.
- Source document title.
- Source tab.
- Selected date.
- Source cells.
- Calculated values.
- Destination spreadsheet title.
- Destination tab.
- Destination cells.
- Existing values.
- Proposed values.
- Conflicts.

Preview does not write anything.

However, Preview must not replace the required real Start/Write functionality.

## 97. Real Write

When Start is authorized:

- Execute the validated write plan.
- Use appropriate Google Sheets API update operations.
- Preserve formulas and formatting.
- Write numeric values as numbers.
- Write descriptions as text.
- Write actual Google Sheets Notes where required.
- Avoid unrelated cell modifications.

## 98. Read-Back Verification

After writing, read the destination cells again.

Verify:

- Values match expected results.
- Descriptions match expected text.
- Notes are present.
- Formula cells remain intact.
- The correct website and date received the data.

Only mark the write successful after appropriate verification.

## 99. Duplicate Prevention

Protect against:

- Double-clicked Start buttons.
- Browser refreshes.
- Repeated HTTP requests.
- Worker restarts.
- Partial API failures.
- Selective recrawl duplication.

Use persistent run identifiers and idempotency keys.

When a server restart interrupts a job, preserve its state and reconcile uncertain writes before attempting to repeat them.

Do not blindly replay a partially completed write operation.

---

# PART XXIV — PARTIAL SUCCESS

## 100. Confirmed Partial Success Policy

The administrator selected:

**PARTIAL SUCCESS + SELECTIVE RETRY**

Example:

Six active tabs.

Four successful.

Two failed.

Expected:

- Preserve the four successful results.
- Record the two failures.
- Do not repeat the four successful tabs.
- Display overall website status as Sebagian Berhasil.
- Allow retry of only failed items.

## 101. Per-Module Failure Isolation

A single source tab may contribute to multiple destination modules.

Track processing results at an appropriate item/metric level.

For example:

- Deposit success.
- Withdrawal success.
- Balance success.
- Expense failure.

Do not erase already verified independent outputs merely because another module failed.

## 102. Aggregate Dependencies

If a daily total depends on several source tabs, it cannot be considered complete if one required input fails.

Track the dependency graph.

When the missing input is repaired, recompute the affected aggregate.

Do not double count previously successful inputs.

---

# PART XXV — ERROR CENTER

## 103. Separate Error Center Page

Route:

`/tasks/1/runs/{run_id}/errors`

The Error Center must open in a new browser tab.

It must not replace or interfere with the main dashboard.

## 104. Error Details

Every error should provide, when available:

- Website name.
- DOC DEPO or DOC QRIS.
- Actual source spreadsheet title.
- Source tab name.
- Selected date.
- Expected date marker.
- Source cell or range.
- Processing module.
- Actual destination spreadsheet title.
- Destination tab name.
- Destination account or bank.
- Error explanation.
- Human-readable correction instructions.
- Retry availability.

## 105. Error Categories

Include:

- Invalid URL.
- Spreadsheet access denied.
- Source spreadsheet missing.
- Source tab missing.
- Renamed tab.
- Date not found.
- Header missing.
- Duplicate header.
- Non-numeric amount.
- Invalid balance.
- Website block missing.
- Destination account missing.
- Destination date missing.
- Ambiguous matching.
- Formula conflict.
- Existing-value conflict.
- Duplicate destination mapping.
- Transfer slots full.
- Unrecognized transfer formatting.
- Google API timeout.
- Google API rate-limit error.
- Write failure.
- Read-back verification failure.

## 106. Human-Readable Example

Website:

VELBETT.

Error title:

**Nama Rekening Tidak Ditemukan**

Source Spreadsheet:

`DOC DEPO VELBETT OCTOBER 2026`

Source Tab:

`WD BCA 1 TOKEN / IVAN RAKHMANDA ( PP )`

Destination Spreadsheet:

`KAS SEMUA WEB OCTOBER 2026`

Destination Tab:

`SALDO BANK`

Explanation:

**Robot tidak menemukan nama rekening yang sesuai di dalam blok VELBETT pada spreadsheet tujuan.**

Suggested solution:

**Periksa nama rekening pada baris header spreadsheet tujuan. Setelah diperbaiki, tekan tombol Crawl Ulang untuk spreadsheet ini.**

Technical exception traces must not be the only visible error explanation.

---

# PART XXVI — SELECTIVE RECRAWL

## 107. Retry Buttons

Show one retry button per source spreadsheet with unresolved errors.

Examples:

- Crawl Ulang VELBETT — DOC DEPO.
- Crawl Ulang VELBETT — DOC QRIS.
- Crawl Ulang BBTOTO — DOC DEPO.
- Crawl Ulang ANGKASABET — DOC QRIS.

If four source spreadsheets have errors, display four corresponding retry buttons.

If only one has errors, display one.

Do not present a default action that blindly retries every failing spreadsheet at once.

## 108. Retry Scope

A retry must preserve:

- Original website.
- Original date.
- Original period.
- Original source document.
- Original destination period.

Within that source document, only failed source tabs or failed processing items should be retried.

Successful items must not be processed unnecessarily.

## 109. Retry Write Behavior

For corrected failed data:

- Recalculate the affected value.
- Update the appropriate destination cell.
- Overwrite only authorized crawler-owned output.
- Preserve unrelated cells.
- Reconcile dependent aggregates.
- Update Notes where required.
- Prevent duplicates.

## 110. Error Completion

When all errors are resolved, remove the active error cards and retry buttons.

Display:

**Semua Data Sukses Di-scrape. Terima kasih untuk hari ini.**

Keep minimal internal audit information required for data integrity.

---

# PART XXVII — DATABASE SCHEMA

## 111. Required Tables

Implement an appropriately normalized schema with at least the following logical entities.

### users

- id
- username
- password_hash
- role
- is_active
- created_at
- updated_at
- last_login_at

### websites

- id
- display_name
- slug
- is_active
- is_archived
- created_at
- updated_at

### source_documents

- id
- website_id
- document_type
- year
- month
- spreadsheet_url
- spreadsheet_id
- spreadsheet_title
- validation_status
- validated_at
- active_revision_id
- created_at
- updated_at

### source_document_revisions

- id
- source_document_id
- revision_number
- spreadsheet_url
- spreadsheet_id
- changed_by
- changed_at

### source_sheet_states

- id
- source_document_id
- source_revision_id
- tab_name
- is_active
- is_available
- discovered_at
- last_seen_at
- updated_at

### destination_documents

- id
- year
- month
- environment
- spreadsheet_url
- spreadsheet_id
- spreadsheet_title
- validation_status
- validated_at
- created_at
- updated_at

### destination_document_revisions

- id
- destination_document_id
- revision_number
- spreadsheet_url
- changed_at
- changed_by

### validation_events

- id
- document_id
- document_type
- result
- error_code
- human_message
- checked_at

### task_runs

- id
- task_number
- website_id
- selected_date
- year
- month
- environment
- status
- started_by
- started_at
- finished_at
- idempotency_key

### task_run_items

- id
- run_id
- source_document_id
- source_tab_name
- metric_type
- status
- source_date
- processed_at

### task_errors

- id
- run_id
- run_item_id
- source_document_id
- source_tab_name
- error_code
- human_message
- technical_details
- suggested_fix
- is_resolved
- resolved_at
- retry_count

### date_clearances

- id
- website_id
- selected_date
- year
- month
- task_number
- is_clear
- confirmed_by
- confirmed_at
- reopened_at
- reopen_reason

### output_write_ledger

- id
- run_item_id
- destination_document_id
- destination_tab
- target_range
- output_type
- source_fingerprint
- previous_managed_value
- written_value
- note_fingerprint
- last_written_at
- verification_status

### transfer_slot_ownership

- id
- run_item_id
- source_transaction_fingerprint
- destination_document_id
- destination_tab
- destination_bank
- description_cell
- amount_cell
- note_cell
- last_written_at

### audit_logs

- id
- actor_id
- action
- entity_type
- entity_id
- metadata
- created_at

Use foreign keys, indexes, uniqueness constraints, and migrations.

Never recreate the production database as part of a routine application update.

---

# PART XXVIII — BACKEND API

## 112. API Requirements

Provide actual working endpoints for:

### Authentication

- Login.
- Logout.
- Current user.

### Websites

- List.
- Create.
- Edit.
- Activate.
- Deactivate.
- Archive.

### Source Documents

- Save configuration.
- Validate URL.
- Retrieve metadata.
- Retrieve history.

### Source Tabs

- List.
- Refresh.
- Activate.
- Deactivate.

### Destination Documents

- Save monthly destination.
- Validate.
- Retrieve history.
- Manage testing destination.

### Task 01

- Preview.
- Manual Start.
- Execution status.
- Detailed results.
- Error Center.
- Selective retry.
- Mark date Clear.
- Reopen cleared date.

All endpoints must enforce authentication and authorization.

Do not provide mock success responses in production mode.

---

# PART XXIX — TESTING REQUIREMENTS

## 113. Authentication Tests

Verify:

- Login works.
- Invalid credentials are rejected.
- Sessions expire correctly.
- Logout works.
- Protected routes reject unauthenticated access.

## 114. Website Management Tests

Verify:

- New website creation.
- Dynamic route creation.
- Website updates.
- Activation/deactivation.
- Archive behavior.
- Unique slug handling.

## 115. Monthly URL Tests

Verify:

- October source URLs remain intact after saving November URLs.
- Source URL changes reset validation.
- Destination URL history remains intact.
- Source and destination periods cannot be mixed.

## 116. Sheet Management Tests

Verify:

- All new monthly tabs start inactive.
- Activation works.
- Deactivation works.
- Refresh detects new tabs.
- Renamed tabs become inactive under their new names.
- Previous month statuses do not carry forward.

## 117. Source Extraction Tests

Verify:

- Following-day separator detection.
- Minus-one closing-row rule.
- Hidden/grouped rows.
- Merged date cells.
- Dynamic row positions.
- No-transaction days.
- Last valid balance carry-forward.

## 118. Destination Mapping Tests

Verify:

- Website group detection.
- Group boundaries.
- Source account matching.
- QRIS subheader matching.
- Date-row matching.
- Conflict detection.
- No unrelated website writes.

## 119. Expense Tests

Verify:

- DOC DEPO H-column aggregation.
- Signed sum before absolute conversion.
- QRIS QRIZZ G-column candidate mapping.
- QRIS E-POWER G-column ordinary expense.
- QRIS H-column FEE WD AUTO separation.

## 120. QRIS Fee Tests

Verify:

- FEE QRIS PERIODE filtering.
- Original description preservation.
- Multiline descriptions.
- Correct daily amount.
- No fee distribution across period text.
- FEE WD AUTO description appears once.

## 121. Transfer Tests

Verify:

- Brown formatting plus transfer description.
- Blue-format exclusion.
- DOC DEPO processing priority.
- DOC DEPO routing based on source tab bank.
- DOC QRIS BCA → MANDIRI → BRI → BNI allocation.
- DOC QRIS H-column amount.
- Preservation of signed transfer amounts.
- Formula/TOTAL protection.
- Real Google Sheets Note writing and reading.
- Slot ownership.
- Overflow errors.

## 122. Partial Success Tests

Verify:

- Successful items are preserved.
- Failed items are recorded.
- Dependent aggregates remain incomplete until valid.
- Retry processes only failed items.
- Successful items are not duplicated.

## 123. Real Write Tests

Use an authorized copy of Kas Semua Web.

Verify:

- Real Google Sheets API writes.
- Correct target cells.
- Exact numeric values.
- Correct descriptions.
- Correct Notes.
- Preserved formulas.
- Correct website and selected date.
- Read-back verification.

Do not claim this test passed unless it was actually run.

---

# PART XXX — DEPLOYMENT TO THE VPS

## 124. Deployment Requirements

The final application should run at:

`https://tutupkasliongroup.com`

Preserve:

- Existing HTTPS.
- Existing Nginx functionality.
- Existing Google Service Account credentials.
- Existing robot directory.
- Existing SSH access.

## 125. Deployment Files

Provide:

- Backend source code.
- Frontend source code.
- Database models.
- Alembic migrations.
- Environment configuration template.
- Secure initial-admin setup command.
- Nginx configuration.
- systemd service definitions.
- Dependency installation commands.
- Frontend build commands.
- Deployment script.
- Health-check command.
- Database backup script.
- Restore instructions.
- Rollback instructions.
- Test commands.

## 126. No Assumed Server Access

If Codex cannot directly connect to the VPS, prepare an installable project package and exact deployment instructions.

Do not claim the domain is running the new application unless deployment is actually verified.

Do not request that the user publish credentials or passwords.

## 127. Production Activation

After successful tests on the authorized TEST destination:

1. Confirm source parsing results.
2. Confirm destination mapping.
3. Confirm formula preservation.
4. Confirm Notes.
5. Confirm retry behavior.
6. Confirm administrator approval.
7. Enable production manual Start.

The production engine must be the same tested engine.

Do not create a separate untested production implementation.

---

# PART XXXI — FUTURE TASK 02 AND TASK 03

## 128. Task Separation

Task 02 and Task 03 will be defined later.

They may depend on the results of Task 01.

However:

- They use separate task configurations.
- They may have separate source and destination URLs.
- They must be manually activated.
- They must not automatically execute after Task 01.

Do not invent their future business rules.

Focus implementation on the complete Task 01 system.

---

# PART XXXII — FINAL ACCEPTANCE CHECKLIST

## 129. Definition of Done

The delivery is accepted only when the following have been demonstrated:

- [ ] Secure administrator login works.
- [ ] Premium responsive dashboard is implemented.
- [ ] New websites can be created from Admin.
- [ ] Dynamic website routes work.
- [ ] Monthly DOC DEPO URLs are saved.
- [ ] Monthly DOC QRIS URLs are saved.
- [ ] URL validation works using actual Google API requests.
- [ ] URL change history is preserved.
- [ ] Monthly destination URLs are managed.
- [ ] New source tabs default to inactive.
- [ ] Refresh Daftar Sheet works.
- [ ] Tab activation and deactivation work.
- [ ] Manual date selection works.
- [ ] Manual Start works.
- [ ] The crawler reads actual source data.
- [ ] Closing values use the confirmed date rules.
- [ ] Empty-transaction days work correctly.
- [ ] Source headers are resolved automatically.
- [ ] Destination website blocks are resolved.
- [ ] Account headers are matched safely.
- [ ] TOTAL DEPO writes work.
- [ ] TOTAL WD writes work.
- [ ] SALDO BANK writes work.
- [ ] BIAYA calculations work.
- [ ] Pengeluaran FEE QRIS DEPO works.
- [ ] Pengeluaran FEE QRIS WD works.
- [ ] KET PENGIRIMAN works.
- [ ] DOC DEPO transfers are processed first.
- [ ] DOC QRIS transfer overflow works.
- [ ] QRIS Google Sheets Notes work.
- [ ] Formula cells are protected.
- [ ] Real writing to a TEST spreadsheet works.
- [ ] Written values are read back and verified.
- [ ] Partial success works.
- [ ] Selective retry works.
- [ ] Error Center displays human-readable errors.
- [ ] Completed dates can be marked Clear.
- [ ] Cleared dates are protected from accidental duplicate runs.
- [ ] Production mode requires explicit authorization.
- [ ] SQLite remains on the VPS.
- [ ] No GitHub is required.
- [ ] The existing Google credentials remain protected.
- [ ] The deployed application is accessible through HTTPS.
- [ ] Task 02 and Task 03 remain inactive.

---

# PART XXXIII — FINAL CODEX EXECUTION INSTRUCTIONS

## 130. Start Implementation Immediately

This prompt is the complete standalone project specification.

Do not treat it as a continuation of another discussion.

Do not ask for an earlier prompt.

Do not assume previous generated project files exist.

Implement the complete system from scratch.

If you have a filesystem workspace, create the actual project files and run available development and testing commands.

If you have secure authorized VPS access, deploy and verify the application without deleting existing working infrastructure.

If you do not have VPS access, prepare the complete deployable project and exact transfer instructions.

## 131. Implementation Approach

Proceed in a disciplined order:

1. Project structure.
2. Database schema and migrations.
3. Authentication.
4. Backend API.
5. Premium Admin frontend.
6. Google Service Account integration.
7. Monthly source/destination configuration.
8. Source-tab management.
9. Task 01 date and metric parsers.
10. Destination resolvers.
11. Expense and QRIS fee processing.
12. Transfer classification and allocation.
13. Safe write planning.
14. Google Sheets write operations.
15. Notes and formula protection.
16. Persistent execution and write ledgers.
17. Error Center.
18. Selective retries.
19. Clear-date management.
20. Automated testing.
21. Real integration testing against an approved test copy.
22. Deployment.
23. Final acceptance reporting.

These are implementation milestones, not separate future projects.

The required final result is an integrated, working Task 01 application.

## 132. Never Invent Financial Data

This system processes financial data.

Do not guess:

- Account mappings.
- Destination columns.
- Missing dates.
- Closing balances.
- Unverified fee meanings.
- Transfer bank routing.
- Unknown transaction colors.
- Formula-safe write locations.

When data is ambiguous, fail only the affected item with a clear Error Center explanation.

Continue other independent valid operations where partial-success rules permit.

## 133. Required Completion Report

At the end, provide:

1. Complete source-code structure.
2. Implemented application routes.
3. Backend API summary.
4. Database migration summary.
5. Google Sheets integration summary.
6. Implemented Task 01 modules.
7. Automated test results.
8. Real API integration-test results.
9. Actual read/write verification results.
10. Formula and Note protection results.
11. Deployment status.
12. Accessible domain status.
13. Remaining implementation blockers, if any.
14. Exact commands needed for installation or verification.
15. Explicit list of anything not yet tested.

Never label an implementation as production-ready if required acceptance tests have not passed.

## FINAL GOAL

**Deliver a premium, fully functioning Tutup Kas Lion Group Admin Panel and Task 01 Google Spreadsheet automation system that can be manually executed, can read real data, can calculate the required business values, can safely write results, can verify those writes, can handle partial failures, and can selectively retry failed source items.**

**Everything must be self-hosted on the user's VPS, accessible over HTTPS, and usable without GitHub or manual script editing by the administrator.**

**BUILD THE ACTUAL APPLICATION. IMPLEMENT THE ACTUAL CRAWLER. ENABLE REAL TEST WRITES. VERIFY THE RESULTS. PROVIDE A SAFE PRODUCTION ACTIVATION PATH.**

# END OF COMPLETE STANDALONE MASTER PROMPT
