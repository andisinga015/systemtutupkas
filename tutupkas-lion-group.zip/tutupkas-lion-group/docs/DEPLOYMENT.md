# Pemasangan di VPS Ubuntu 22.04

Panduan ini untuk VPS milik Anda, dijalankan oleh Anda melalui SSH. Lingkungan pembuat paket tidak memiliki SSH VPS; instalasi, domain, sertifikat, dan Google API VPS belum diuji di sini.

## 1. Transfer dan pemeriksaan ZIP

Dari komputer Anda, unggah ZIP beserta checksum melalui SFTP atau:

```bash
scp tutupkas-lion-group.zip tutupkas-lion-group.zip.sha256 aksesfinancebot@103.193.176.114:/home/aksesfinancebot/
ssh aksesfinancebot@103.193.176.114
cd /home/aksesfinancebot
sha256sum -c tutupkas-lion-group.zip.sha256
unzip tutupkas-lion-group.zip
cd tutupkas-lion-group
```

Jangan mengunggah `robot-key.json` ke GitHub atau aplikasi frontend. Paket memakai path yang sudah ada: `/home/aksesfinancebot/spreadsheet-robot/credentials/robot-key.json`.

## 2. Pasang aplikasi

```bash
sudo bash deploy/install.sh
sudo bash deploy/admin.sh create-admin namaadmin
```

Installer memasang Python venv terpisah, dependensi dengan checksum, rilis di `/opt/tutupkas/releases`, symlink `current`, migrasi SQLite, dan layanan API/worker. Database dan ledger tetap di `/var/lib/tutupkas`, terpisah dari rilis kode. Admin meminta password baru minimal 12 karakter melalui prompt tersembunyi. Tidak ada default password.

Installer menambahkan ACL baca khusus `tutupkas` pada kunci dan ACL traversal pada parent directory. Owner, isi kunci, dan project robot tidak diganti. Kredensial tidak dibuat world-readable. File environment adalah `/etc/tutupkas/app.env`, `root:tutupkas`, mode 0640. Periksa path file jika Service Account Anda berada di lokasi lain; jangan memasukkan private key ke environment template.

API bind IPv4 loopback `127.0.0.1:8000`. Worker hanya menjalankan job yang diantrikan oleh Start/Pratinjau/Crawl Ulang admin. Tidak ada cron transaksi. Hanya satu worker per database/lock path; jangan menjalankan dua deployment pada database sama dengan lock berbeda.

## 3. Hubungkan Nginx yang sudah memiliki HTTPS

**Installer sengaja tidak menimpa konfigurasi HTTPS yang belum bisa diinspeksi di lingkungan pembuat paket.** Inspeksi konfigurasi VPS Anda dahulu:

```bash
sudo nginx -T
sudo cp -a /etc/nginx /etc/nginx.backup-$(date +%Y%m%d-%H%M%S)
sudo install -m 0644 deploy/nginx-locations.conf /etc/nginx/snippets/tutupkas-locations.conf
```

Buka file site yang sudah menangani `server_name tutupkasliongroup.com` pada HTTPS. Pertahankan `listen 443 ssl` IPv4, `ssl_certificate`, `ssl_certificate_key`, include Let's Encrypt, dan redirect HTTP ke HTTPS yang sudah bekerja. Jangan menambahkan `[::]:80` atau `[::]:443`.

Di **dalam blok server HTTPS yang ada**, hapus/gantikan deklarasi lama `root`, `index`, dan `location /` milik welcome page, lalu tambahkan:

```nginx
include /etc/nginx/snippets/tutupkas-locations.conf;
```

Periksa juga konflik lokasi `/api/` dan `/assets/` bila sebelumnya sudah ada. Jangan mengganti lokasi ACME/certificate renewal yang masih diperlukan. Include yang disediakan mengatur root SPA, API proxy, cache aset, dan security headers; tidak mengatur listener atau sertifikat.

```bash
sudo nginx -t
# Jalankan hanya jika nginx -t berhasil:
sudo systemctl reload nginx
```

## 4. Pemeriksaan layanan

```bash
curl --fail http://127.0.0.1:8000/api/health
sudo systemctl status tutupkas-api tutupkas-worker --no-pager
sudo journalctl -u tutupkas-api -u tutupkas-worker -n 80 --no-pager
curl --fail https://tutupkasliongroup.com/api/health
curl --fail -I https://tutupkasliongroup.com/login
```

Masuk melalui HTTPS memakai admin yang Anda buat. Cookie produksi tidak akan bekerja melalui HTTP; jangan mematikan `TK_COOKIE_SECURE` pada VPS. Buka Dashboard dan pastikan layanan API terhubung. Jangan membuka port 8000 pada firewall.

## 5. Pengujian Google nyata melalui Admin

1. Tambah WEB dengan nama sesuai label blok di spreadsheet tujuan.
2. Pilih bulan/tahun. Simpan DOC DEPO dan/atau DOC QRIS. Validasi setiap URL. Pastikan judul nyata tampil.
3. Pastikan sumber dan salinan TEST sudah dibagikan kepada Service Account. Akses tujuan memerlukan Editor. Validasi metadata hanya membuktikan akses baca.
4. Buka Daftar Sheet; semua nama baru nonaktif. Aktifkan hanya sumber relevan.
5. Di Kas Kecil, simpan salinan tujuan bulan yang sama pada **TEST**, lalu validasi. Jangan memakai ID yang sama dengan produksi.
6. Pilih tanggal yang pemisah hari berikutnya tersedia. Jalankan **Pratinjau** dari Dashboard. Periksa setiap sel, nominal, Note, dan konflik di hasil serta Pusat Kesalahan.
7. Untuk warna kiriman, catatan kesalahan pratinjau menyertakan RGB aktual. Cocokkan dengan transaksi pada spreadsheet, lalu buat JSON palet di VPS, bukan dalam source:

   ```json
   {"approved_brown": [[1, 0.6, 0]], "excluded_blue": [[0, 1, 1]]}
   ```

   Nilai di atas **hanya contoh**, bukan bukti warna workbook Anda. Gunakan RGB aktual hasil inspeksi. Jalankan `sudo bash deploy/admin.sh approve-palette /path/palet-aktual.json`, tinjau dan ketik `SETUJUI`. Crawl Ulang memperbarui palet/alias yang disetujui sambil mempertahankan URL sumber, periode, tanggal, dan tujuan run asal.
8. Perbaiki konflik pemetaan. Sel manual, Note manual, angka nol yang bukan milik crawler, serta formula sengaja tidak ditimpa. Gunakan area output kosong dalam salinan TEST.
9. Jalankan **Mulai Penarikan** TEST. Ini adalah penulisan nyata. Tinjau hasil `verified`, angka di Google, Note Shift+F2, dan formula TOTAL. Robot melakukan pembacaan ulang API.
10. Uji kegagalan terisolasi pada salinan TEST, perbaiki sumber, gunakan Crawl Ulang per dokumen, dan pastikan output berhasil tidak diduplikasi.
11. Setelah TEST lengkap, simpan/validasi tujuan PRODUCTION, lalu otorisasi melalui panel. Otorisasi mensyaratkan run TEST berhasil yang memuat Note QRIS terverifikasi dan persetujuan admin atas formula/Note/retry. Setiap tanggal produksi juga memerlukan TEST pada website, tanggal, serta konfigurasi sumber yang sama.

Kesesuaian struktur `KET PENGIRIMAN` harus diverifikasi dari workbook asli. Resolver mendukung header nomor hari dengan kolom TOTAL samping seperti referensi, serta bagian tanggal lengkap dengan batas merged. Nomor hari harus mempunyai urutan dan hubungan struktural yang jelas dengan header website/bank/TOTAL; angka lepas tanpa bukti itu ditolak. Lihat [ENGINE.md](ENGINE.md).

Destinasi tidak boleh diedit bersamaan dengan proses menulis. API Sheets tidak menyediakan compare-and-swap terhadap isi sel: pemeriksaan terakhir sebelum menulis dan ledger membatasi risiko, tetapi tidak dapat mengunci pengguna lain di Google Sheets.

Tujuan HTTPS keluar: `sheets.googleapis.com` dan `oauth2.googleapis.com` (TLS diverifikasi). Installer Python memerlukan `pypi.org`, `files.pythonhosted.org`, serta mirror APT Ubuntu Anda. Tidak ada database eksternal.

## 6. Backup database

```bash
sudo bash deploy/admin.sh backup /var/lib/tutupkas/backups/tutupkas-$(date +%Y%m%d-%H%M%S).sqlite3
```

CLI memakai SQLite online backup API, mode file 0600, dan `integrity_check`; jangan menyalin file SQLite aktif dengan `cp` tanpa memperhitungkan WAL. Backup mencakup seluruh konfigurasi, akun, sesi, job, ledger, dan ownership. Simpan salinan terenkripsi di lokasi backup milik Anda. Service Account tetap dikelola terpisah.

## 7. Pemulihan

Lakukan pada jendela pemeliharaan. Pilih file backup milik Anda dan periksa dahulu:

```bash
sudo systemctl stop tutupkas-worker tutupkas-api
sudo bash deploy/admin.sh backup /var/lib/tutupkas/backups/before-restore-$(date +%Y%m%d-%H%M%S).sqlite3
sudo python3 - /path/backup.sqlite3 <<'PY'
import sqlite3, sys
with sqlite3.connect('file:' + sys.argv[1] + '?mode=ro', uri=True) as db:
    assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
    assert not db.execute('PRAGMA foreign_key_check').fetchall()
print('Backup valid')
PY
sudo install -m 0600 -o tutupkas -g tutupkas /path/backup.sqlite3 /var/lib/tutupkas/restore.sqlite3
sudo rm -f /var/lib/tutupkas/tutupkas.sqlite3-wal /var/lib/tutupkas/tutupkas.sqlite3-shm
sudo mv /var/lib/tutupkas/restore.sqlite3 /var/lib/tutupkas/tutupkas.sqlite3
sudo -u tutupkas bash -c 'set -a; source /etc/tutupkas/app.env; set +a; cd /opt/tutupkas/current/backend; /opt/tutupkas/current/.venv/bin/alembic upgrade head'
sudo systemctl start tutupkas-api tutupkas-worker
curl --fail http://127.0.0.1:8000/api/health
```

Restore database tidak membatalkan penulisan yang sudah terjadi di Google. Jangan memulihkan backup lama lalu menjalankan ulang secara buta: kepemilikan output yang belum ada di backup akan ditolak sebagai entri asing. Rekonsiliasi dengan audit/ledger backup terbaru terlebih dahulu.

## 8. Update dan rollback

Unggah ZIP baru ke direktori staging yang berbeda lalu jalankan installer baru. Ia tidak menghapus database, membuat backup sebelum migrasi, dan menyimpan path rilis sebelumnya di `/etc/tutupkas/previous-release`. Layanan dihentikan untuk migrasi setelah dependensi rilis baru siap.

Untuk rollback kode dengan skema kompatibel:

```bash
sudo systemctl stop tutupkas-worker tutupkas-api
sudo bash -c 'set -e; previous_release=$(cat /etc/tutupkas/previous-release); test -d "$previous_release"; ln -s "$previous_release" /opt/tutupkas/rollback.next; mv -Tf /opt/tutupkas/rollback.next /opt/tutupkas/current'
sudo systemctl start tutupkas-api tutupkas-worker
curl --fail http://127.0.0.1:8000/api/health
sudo nginx -t
```

Jika skema tidak kompatibel, pulihkan backup yang sesuai dengan versi kode melalui prosedur pemulihan. Jangan menjalankan `alembic downgrade base` pada produksi. Jika konfigurasi Nginx diubah manual, pulihkan file site dari backup lalu `nginx -t` sebelum reload. Rilis v1 belum diuji di VPS ini; uji rollback pada salinan sebelum mengandalkannya untuk produksi.

