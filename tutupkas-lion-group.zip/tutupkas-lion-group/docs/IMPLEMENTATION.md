# Implementasi dan API

## API

Seluruh endpoint di bawah berawalan `/api`. Semua endpoint administrasi memerlukan sesi admin. Mutasi juga memerlukan `X-CSRF-Token`. Hanya health, CSRF bootstrap, dan login tersedia sebelum autentikasi.

| Grup | Endpoint |
|---|---|
| Auth | GET `/auth/csrf`, POST `/auth/login`, GET `/auth/me`, POST `/auth/logout` |
| Dashboard | GET `/dashboard`, GET `/health` |
| WEB | GET/POST `/websites`, GET `/websites/{slug}`, PATCH `/websites/{id}` |
| Sumber | GET/PUT `/websites/{id}/sources`, POST `/sources/{id}/validate`, GET `/sources/{id}/history` |
| Sheet | GET/POST `/sources/{id}/tabs`, POST `/sources/{id}/tabs/refresh` |
| Alias | GET/PUT `/websites/{id}/aliases` |
| Tujuan | GET/PUT `/destinations`, POST `/destinations/{id}/validate`, GET `/destinations/{id}/history`, POST `/destinations/{id}/authorize` |
| Task 01 | POST/GET `/runs`, GET `/runs/{id}`, POST `/runs/{id}/retry`, POST `/runs/{id}/clear` |
| Clear | GET `/clearances`, POST `/clearances/{id}/reopen` |

POST `/runs`: website_id, selected_date (ISO), environment (`TEST`/`PRODUCTION`), preview (bool), idempotency_key. Pratinjau memakai `preview=true`, tanpa menulis Google. Status/result/error/detail plan diperoleh dari GET run. Retry menerima source_document_id dan mempertahankan snapshot run asal. Clear hanya untuk hasil tulis sukses terbaru tanpa error aktif tanggal sama. Reopen meminta reason minimal 10 karakter.

## Database dan migrasi

Migrasi awal Alembic membuat `users`, `auth_sessions`, `login_attempts`, `websites`, `source_documents`, `source_document_revisions`, `source_sheet_states`, `destination_documents`, `destination_document_revisions`, `validation_events`, `task_runs`, `task_run_items`, `task_errors`, `date_clearances`, `output_write_ledger`, `transfer_slot_ownership`, `account_aliases`, `audit_logs`.

Foreign keys diaktifkan pada koneksi SQLite; WAL, busy timeout, indeks, dan uniqueness melindungi pasangan website/periode/jenis sumber, tujuan/periode/environment, status tab per revisi, idempotency key, item/modul, dan kepemilikan sel tujuan. Partial unique index mencegah dua run aktif website/tanggal/environment sama. File lock lintas proses memastikan satu worker per deployment. SQLAlchemy memisahkan model dari SQLite untuk migrasi PostgreSQL nanti; PostgreSQL belum diuji.

Migrasi selalu `alembic upgrade head`, bukan drop/create saat startup. Akun dibuat CLI, tanpa password default. Riwayat sumber/tujuan dan audit mutasi disimpan terpisah; penggantian URL mereset validasi dan tab revision. Periode lama tidak ditimpa.

## Keamanan

Password Argon2id; token sesi acak disimpan sebagai SHA-256; HttpOnly, Secure, SameSite Strict; session expiry; CSRF token dan pemeriksaan Origin; rate limit login database per username serta IP; no public registration; authorization role admin pada semua endpoint. Log JSON tidak berisi body login, private key, environment dump, atau isi exception Google. Error manusia disimpan dengan konteks finansial minimal yang diperlukan.

Google Service Account berada di backend saja. URL hanya menerima host HTTPS `docs.google.com` dan pola spreadsheet ID. Koneksi API memakai endpoint Google yang tetap, bukan URL arbitrary. TLS, artifact checksum, dan signature package manager tidak dimatikan. Service account file asli tidak disalin ke ZIP. Static frontend tidak berisi kredensial.

Catatan risiko: limiter login masih dapat menjadi sasaran denial-of-service terarah terhadap nama pengguna. Nginx dapat menambahkan limit_req sesuai trafik VPS setelah pengukuran. Aplikasi ini belum menjalani audit keamanan eksternal; status produksi bergantung pemeriksaan TEST nyata dan instalasi VPS.

