# Aturan dan batas engine Task 01

## Sumber

Sumber aktif diambil dari snapshot konfigurasi saat admin mengantrekan run. Website database adalah identitas utama. Tanggal, sumber, revisi, periode, dan tujuan disimpan di run; retry tidak mengganti dokumen dengan URL bulan terbaru. Tab baru/berganti nama selalu nonaktif. Tab yang hilang tidak ikut run baru.

Pemisah harian harus berupa sel tanggal dengan latar gelap atau merged horizontal sekurangnya tiga kolom. Parser mendukung tanggal berformat serial Sheets, tanggal ISO, serta bulan Inggris/Indonesia. Hidden/grouped rows tetap masuk data API. Kedua pemisah harus unik dan berurutan: tanggal terpilih dan hari berikutnya. Penutupan persis `baris_pemisah_berikutnya - 1`, tanpa mencari baris transaksi lain untuk hari biasa. Batas akhir yang belum memiliki pemisah berikutnya menghasilkan kesalahan.

Untuk bagian tanpa transaksi, DEPO/WD nol, saldo diambil dari saldo valid terakhir melalui baris penutupan/pemisah sebelumnya. Error formula atau nominal rusak tidak diperlakukan sebagai hari nol. Kolom metrik dicari dari header unik `Total`/`Total Depo`, `Total WD`, `SALDO`. Nominal harus rupiah integer aman; teks ambigu dan error formula ditolak.

## Tujuh modul

| Tujuan | Aturan |
|---|---|
| TOTAL DEPO | Closing header `Total` pada DEPO atau `Total Depo` pada QRIS |
| TOTAL WD | Closing `Total WD` |
| SALDO BANK | Closing `SALDO`, carry-forward untuk hari kosong |
| BIAYA | ABS setelah menjumlahkan seluruh nilai H bertanda dari DOC DEPO aktif; input disimpan per tab |
| BIAYA TARIK QRIS | ABS(sum G harian) pada QRIS QRIZZ; header DLL harus di G |
| BIAYA AUTO WD | ABS(sum G harian) pada QRIS E-POWER; terpisah dari fee H |
| Pengeluaran FEE QRIS DEPO | H hanya untuk deskripsi D berawalan FEE QRIS PERIODE; teks asli/newline dipertahankan |
| Pengeluaran FEE QRIS WD | H hanya untuk FEE WD AUTO; deskripsi tujuan sekali |
| KET PENGIRIMAN | Warna D disetujui **dan** deskripsi transfer dikenali; DEPO lebih dahulu, lalu QRIS |

Aturan G pada QRIS QRIZZ adalah interpretasi awal dari spesifikasi. Header DLL diverifikasi, tetapi makna bisnis angka tetap harus dibandingkan terhadap sumber/tujuan TEST nyata sebelum produksi. Kolom H DEPO juga harus berheader DLL. Kiriman DEPO dicari dari header `Kiriman`; QRIS diharuskan H. Kolom deskripsi mengikuti layout D yang diberikan.

## Pemetaan aman

Sheet reguler memakai dua baris header, tanggal mulai baris 3, dan label WEB terdaftar sebagai anchor kolom tanggal. Website berikutnya membatasi kolom pencarian. Account matching memprioritaskan kecocokan normalisasi persis, nama kanan slash tanpa `( PP )`, atau pasangan QRIS/subheader. Tidak ada fuzzy matching. Gunakan alias nama sumber → header rekening dari Admin jika diperlukan. Lebih dari satu kandidat adalah error.

KET PENGIRIMAN mempunyai resolver berbeda. Ada dua struktur yang didukung:

1. Anchor tanggal lengkap merged melintasi kelompok bank, kemudian label WEB, header bank BCA/MANDIRI/BRI/BNI dua kolom, baris slot, dan batas TOTAL.
2. Header bulanan berupa nomor hari pada kolom TOTAL samping, sebagaimana screenshot. Pasangan hari sebelumnya/hari terpilih membatasi bagian horizontal. Header WEB merged harus mencakup empat bank di antara batas tersebut, dan kolom hari terpilih harus mempunyai label TOTAL dalam blok WEB yang sama. Hari pertama dibuktikan sebagai anchor pertama. Baris header nomor hari harus berurutan dan unik. Periode mengikuti tujuan bulanan yang dikonfigurasi. Posisi kolom/baris tidak di-hardcode, termasuk spacer dan kolom yang disembunyikan.

Satu tanggal harus memiliki bagian yang unik. Sumber DEPO mengikuti bank pada nama tab; QRIS mengisi slot tersedia BCA → MANDIRI → BRI → BNI. Angka bertanda dipertahankan. Sel dengan angka nol, formula kosong, atau Note tidak dihitung kosong. Sel merged dekoratif di bawah header bank juga dilindungi, sehingga tidak menjadi slot transaksi. Slot penuh tidak membuat baris baru.

**Struktur nomor hari/TOTAL samping telah diuji menggunakan grid yang mengikuti bentuk screenshot, bukan melalui akses workbook asli.** Jika struktur API workbook berbeda dari kedua kontrak di atas, modul kiriman akan gagal dengan pesan batas tanggal ambigu; modul independen tetap diproses. Periksa grid/merge asli pada salinan TEST sebelum memperluas resolver, tanpa memasukkan kolom tebakan atau mengubah data produksi.

Warna transfer tidak ditebak dari screenshot. Palet disetujui setelah melihat RGB aktual; warna biru yang disetujui dikecualikan. Warna lain pada deskripsi transfer menghasilkan masalah tinjauan. Deskripsi dikenali: KIRIM KE, PENGIRIMAN DARI, DARI KAS, DARI NL KAS. Penambahan frasa bisnis lain membutuhkan verifikasi terlebih dahulu.

## Tulis, retry, dan kepemilikan

Rencana semua item dibuat sebelum tulis, untuk menemukan tabrakan mapping. Tulis memakai batchUpdate updateCells dengan field mask `userEnteredValue,note`; tidak menyentuh format. Numeric ditulis numberValue, deskripsi stringValue (termasuk teks berawalan `=` tidak berubah menjadi formula). Formula dan Note seluruh tab dibaca; formula dibandingkan sebelum/sesudah operasi. QRIS mendapat cell Note nyata pada keterangan.

Ledger `PREPARED` disimpan sebelum API. Read-back memverifikasi nilai, deskripsi, dan Note; baru menjadi `VERIFIED`. Jika koneksi terputus setelah API menulis, retry mengenali nilai sebelum atau sesudah intent yang tercatat. Tidak ada append. Output asing/manual tidak diambil alih hanya karena nilainya sama dengan hasil robot.

Satu item mencakup satu tab/modul. Expense input disimpan bertanda; aggregate BIAYA menunggu semua dependensi berhasil dan menghitung ulang dari kontribusi tersimpan. Retry per dokumen hanya menandai item gagal menjadi pending. Hasil sukses tidak dibaca ulang dari sumber. Alias/palet yang baru disetujui dapat memperbaiki item gagal; perubahan itu dicatat dan produksi memerlukan TEST lagi.

Identitas kiriman mencakup sumber, tanggal, revisi, baris fisik, deskripsi, dan nominal. Kiriman sama menggunakan slot lama. Jika kiriman lama berubah/hilang/pindah baris, engine tidak dapat membuktikan identitas transaksi tanpa ID stabil; ia melaporkan konflik rekonsiliasi. Koreksi otomatis untuk kasus tersebut **belum didukung**. Jangan menghapus ledger agar konflik tampak hilang. Perlu tinjauan data dan rekonsiliasi yang disetujui.

Pemeriksaan lokal dan API Google tidak membentuk transaksi atomik lintas database dan spreadsheet. Intent ledger mengatasi crash/retry, tetapi tidak mengunci editor Google secara bersamaan. Hindari edit manual saat run berjalan. Worker tunggal membatasi concurrency; retry API hanya untuk timeout/429/5xx dengan backoff dan batas percobaan.

## Batas sumber daya

Satu tab sumber ditahan di memori pada satu waktu; tujuh tab tujuan di-cache untuk mapping. API mengambil grid tab yang relevan, bukan seluruh dokumen atau sumber nonaktif. Batas default adalah 2 juta sel grid per tab (termasuk area preformatted), dikonfigurasi melalui `TK_MAX_SHEET_CELLS`. Kebutuhan memori tetap bergantung format workbook. VPS 2 GB memakai satu API worker dan satu job worker dengan batas systemd 400/700 MB. Tab sangat besar perlu pengurangan area kosong atau pembaca streaming di pengembangan berikutnya; error ukuran tidak dianggap hasil nol.

