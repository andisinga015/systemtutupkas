"""Read-only verification of an administrator-authorized real TEST execution.

Run from backend with its environment loaded:
  python ../scripts/verify-real-run.py RUN_ID
No credentials or financial amounts are printed. No writes are issued here.
"""
import sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))

from sqlalchemy import select
from app.db import SessionLocal
from app.engine.types import Issue
from app.models import Run, RunItem, TaskError, WriteLedger
from app.sheets import SheetsClient


def main():
    if len(sys.argv)!=2:
        raise SystemExit('Penggunaan: python ../scripts/verify-real-run.py RUN_ID')
    with SessionLocal() as db:
        run=db.get(Run,int(sys.argv[1]))
        if not run or run.preview or run.environment!='TEST' or run.status!='SUCCESS':
            raise SystemExit('Diperlukan run TEST tulis yang benar-benar selesai SUCCESS.')
        if db.scalar(select(TaskError.id).where(TaskError.run_id==run.id,TaskError.is_resolved==False)):
            raise SystemExit('Masih ada kesalahan aktif.')
        rows=list(db.scalars(select(WriteLedger).join(RunItem,WriteLedger.run_item_id==RunItem.id).where(RunItem.run_id==run.id)))
        if not rows or any(r.verification_status!='VERIFIED' for r in rows):
            raise SystemExit('Ledger penulisan belum lengkap atau belum diverifikasi.')
        client=SheetsClient()
        grids={}
        notes=0
        for row in rows:
            if row.destination_tab not in grids:
                grids[row.destination_tab]=client.grid(run.config_snapshot['destination']['spreadsheet_id'],row.destination_tab)
            import re
            m=re.fullmatch(r'([A-Z]+)(\d+)',row.target_range)
            col=0
            for char in m[1]:
                col=col*26+ord(char)-64
            actual=grids[row.destination_tab].cell(int(m[2])-1,col-1)
            if actual.snapshot!=row.written_value:
                raise SystemExit(f'Verifikasi gagal pada {row.destination_tab}!{row.target_range}')
            notes+=bool(row.written_value.get('note'))
        print(f'REAL GOOGLE READ-BACK PASSED: {len(rows)} sel, {notes} Note, {len(grids)} tab. Run #{run.id}.')
        print('Periksa formula, pemetaan, dan perilaku retry di salinan TEST sebelum otorisasi produksi.')


if __name__=='__main__':
    try:
        main()
    except Issue as e:
        raise SystemExit(e.message)

