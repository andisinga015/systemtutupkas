# TUTUP KAS · LION GROUP

Panel administrasi Bahasa Indonesia dan worker Task 01 untuk Google Sheets. FastAPI + React/TypeScript + SQLite, berjalan mandiri di VPS. GitHub tidak diperlukan untuk instalasi atau operasional.

**Status:** aplikasi dapat dibangun dan diuji lokal. Resolver KET PENGIRIMAN mendukung struktur nomor hari/TOTAL samping dari referensi serta bagian tanggal lengkap. Pengujian Google API nyata, kesesuaian grid workbook Anda, warna transaksi aktual, instalasi systemd/Nginx, dan domain HTTPS belum diverifikasi dari lingkungan ini. Jangan aktifkan produksi sebelum pemeriksaan TEST di VPS selesai. Tidak ada data finansial atau kata sandi bawaan yang ditanamkan.

## Instalasi dari ZIP di VPS

ZIP rilis berisi source dan frontend hasil build; **Node.js tidak diperlukan di VPS** untuk paket tersebut.

```bash
unzip tutupkas-lion-group.zip
cd tutupkas-lion-group
sudo bash deploy/install.sh
sudo bash deploy/admin.sh create-admin namaadmin
```

Pemasang mempertahankan direktori robot dan kunci Service Account yang sudah ada. Nginx/HTTPS tidak diubah otomatis: lanjutkan langkah include konfigurasi pada [panduan VPS](docs/DEPLOYMENT.md). Pembuatan admin meminta password secara tersembunyi; tidak ada registrasi publik.

## Pengembangan lokal

Python 3.10+ dan Node.js 22+. Gunakan checkout yang ada; setiap tugas cloud sudah terisolasi, sehingga tidak perlu membuat Git worktree.

```bash
bash scripts/dev-install.sh
cd backend
../.venv/bin/python -m app.cli create-admin namaadmin
TK_COOKIE_SECURE=false TK_APP_ORIGIN=http://127.0.0.1:5173 ../.venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Terminal terpisah dari root proyek:

```bash
cd backend
../.venv/bin/python -m app.worker
```

Terminal ketiga dari root proyek:

```bash
cd frontend
npm run dev
```

Default SQLite berada di `backend/data/`. Gunakan `TK_CREDENTIAL_FILE` untuk menunjuk file Service Account lokal, tanpa menyalin isinya ke source. Cookie non-Secure hanya untuk pengembangan lokal; produksi memakai HTTPS dan `TK_COOKIE_SECURE=true`.

## Pengujian dan paket rilis

```bash
.venv/bin/pytest backend/tests -q
cd backend && ../.venv/bin/alembic check && cd ..
cd frontend && npm run build && cd ..
# Jika Chromium tersedia pada sistem:
PLAYWRIGHT_CHROMIUM_EXECUTABLE=/usr/bin/chromium bash scripts/e2e.sh
# Atau instal Chromium Playwright: cd frontend && npx playwright install chromium
bash scripts/package.sh
```

Paket dibuat sebagai `../tutupkas-lion-group.zip` dan `../tutupkas-lion-group.zip.sha256`, tanpa database, sesi, `.env`, `.git`, virtualenv, atau kredensial. E2E memakai database temporer dan password acak, lalu menghapusnya. Sumber Google palsu hanya tersedia di kode test, bukan di aplikasi.

## Struktur proyek

```text
backend/app/
  main.py, api.py        FastAPI dan API admin
  auth.py, cli.py        sesi, CSRF, Argon2id, admin dan backup
  models.py, db.py       skema SQLAlchemy, SQLite WAL/FK
  sheets.py             Google API v4, service account, retry/backoff
  worker.py             antrean persisten; satu worker, tanpa cron
  engine/
    parser.py           tanggal, closing, biaya, fee, kiriman
    resolver.py         blok website, rekening, tanggal, slot bank
    writer.py           rencana, ledger, Notes, perlindungan, read-back
    runner.py           isolasi modul, dependensi, partial success
backend/migrations/     Alembic, tidak menghapus database saat update
backend/tests/          unit dan integrasi API/engine terisolasi
frontend/src/           React, Bahasa Indonesia, tema navy/biru
frontend/e2e/           uji browser dengan backend sebenarnya
deploy/                 systemd, template environment, include Nginx
scripts/                setup, browser tests, packaging
docs/                   panduan VPS, perilaku engine, laporan pengujian
```

## Rute aplikasi

`/login`, `/dashboard`, `/admin-setting`, `/admin-setting/:slug`, `/admin-setting/:slug/history-url`, `/admin-setting/:slug/sheet-aktif`, `/kas-kecil`, `/kas-kecil/history-url`, `/tasks/1`, `/tasks/1/runs/:id`, `/tasks/1/runs/:id/errors`, `/riwayat`, `/pusat-kesalahan`.

Pusat Kesalahan dibuka di tab baru dari hasil proses. Task 02/03 ditampilkan terkunci dan tidak memiliki executor. Ringkasan API dan skema tersedia di [catatan implementasi](docs/IMPLEMENTATION.md); batas pemetaan dan cara verifikasi TEST tersedia di [panduan engine](docs/ENGINE.md).

