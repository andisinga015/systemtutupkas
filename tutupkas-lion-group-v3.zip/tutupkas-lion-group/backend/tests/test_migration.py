"""Upgrade a populated v1 schema; compare every original table and column."""
import json
import os
import sqlite3
import subprocess
import sys
from pathlib import Path


def test_v1_upgrade_preserves_accounts_sources_history_and_financial_ownership(tmp_path):
    backend=Path(__file__).parents[1]
    path=tmp_path/'legacy.sqlite3'
    env={**os.environ,'TK_DATABASE_URL':'sqlite:///'+str(path)}
    def migrate(target):
        result=subprocess.run([sys.executable,'-m','alembic','upgrade',target],cwd=backend,env=env,capture_output=True,text=True)
        assert result.returncode==0,result.stderr
    migrate('226dae92145d')
    with sqlite3.connect(path) as conn:
        conn.execute('PRAGMA foreign_keys=ON')
        stamp={'created_at':'2026-10-01','updated_at':'2026-10-01'}
        rows={
          'users':[dict(id=1,username='existing-admin',password_hash='retained-hash',role='admin',is_active=1,**stamp)],
          'websites':[dict(id=1,display_name='VELBETT',slug='velbett',is_active=1,is_archived=0,**stamp)],
          'source_documents':[dict(id=1,website_id=1,document_type='DEPO',year=2026,month=10,spreadsheet_url='old-source',spreadsheet_id='source-id',validation_status='VALID',active_revision_id=1,**stamp)],
          'source_document_revisions':[dict(id=1,source_document_id=1,revision_number=1,spreadsheet_url='old-source',spreadsheet_id='source-id',changed_by=1,changed_at='2026-10-01')],
          'source_sheet_states':[dict(id=1,source_document_id=1,source_revision_id=1,tab_name='WD BCA / NAMA',is_active=1,is_available=1,discovered_at='2026-10-01',last_seen_at='2026-10-01',**stamp)],
          'destination_documents':[dict(id=i,year=2026,month=month,environment=mode,spreadsheet_url=f'old-{i}',spreadsheet_id=f'id-{i}',validation_status='VALID',revision=1,**stamp) for i,month,mode in [(1,10,'TEST'),(2,10,'PRODUCTION'),(3,11,'TEST')]],
          'destination_document_revisions':[dict(id=1,destination_document_id=1,revision_number=1,spreadsheet_url='old-1',changed_by=1,changed_at='2026-10-01')],
          'task_runs':[dict(id=1,task_number=1,website_id=1,selected_date='2026-10-15',year=2026,month=10,environment='TEST',preview=0,status='SUCCESS',started_by=1,started_at='2026-10-15',idempotency_key='old-run',config_snapshot=json.dumps({'website':'VELBETT','destination':{'id':1,'revision':1}}))],
          'task_run_items':[dict(id=1,run_id=1,source_document_id=1,source_tab_name='WD BCA / NAMA',metric_type='transfers',status='SUCCESS',source_date='2026-10-15',result=json.dumps({'verified':True}))],
          'task_errors':[dict(id=1,run_id=1,run_item_id=1,source_tab_name='WD BCA / NAMA',error_code='OLD_ERROR',human_message='riwayat',technical_details='{}',suggested_fix='riwayat',is_resolved=1,retry_count=1)],
          'output_write_ledger':[dict(id=1,run_item_id=1,destination_document_id=1,destination_revision=1,destination_tab='KET PENGIRIMAN',target_range='B7',output_type='transfers',owner_key='owner',source_fingerprint='source',previous_managed_value='{}',written_value=json.dumps({'value':123,'note':'Note QRIS lama'}),note_fingerprint='note',last_written_at='2026-10-15',verification_status='VERIFIED')],
          'transfer_slot_ownership':[dict(id=1,run_item_id=1,source_transaction_fingerprint='tx',destination_document_id=1,destination_revision=1,destination_tab='KET PENGIRIMAN',destination_bank='BCA',description_cell='A7',amount_cell='B7',note_cell='A7',last_written_at='2026-10-15')],
          'date_clearances':[dict(id=1,website_id=1,selected_date='2026-10-15',year=2026,month=10,environment='TEST',task_number=1,is_clear=1,confirmed_by=1,confirmed_at='2026-10-15')],
          'account_aliases':[dict(id=1,website_id=1,source_name='alias lama',destination_header='nama lama')],
          'validation_events':[dict(id=1,document_id=1,document_type='SOURCE',result='VALID',human_message='valid',checked_at='2026-10-01')],
          'auth_sessions':[dict(token_hash='old-token',user_id=1,csrf_token='csrf',expires_at='2027-01-01')],
          'audit_logs':[dict(id=1,actor_id=1,action='old-audit',entity_type='task_runs',entity_id='1',metadata='{}',created_at='2026-10-15')]
        }
        for table,records in rows.items():
            for row in records:
                cols=','.join('"'+k+'"' for k in row)
                conn.execute(f'INSERT INTO "{table}" ({cols}) VALUES ({",".join("?" for _ in row)})',list(row.values()))
        snapshot={table:([r[1] for r in conn.execute(f'PRAGMA table_info("{table}")')],conn.execute(f'SELECT * FROM "{table}"').fetchall()) for table in rows}
    migrate('head')
    with sqlite3.connect(path) as conn:
        assert conn.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        assert not conn.execute('PRAGMA foreign_key_check').fetchall()
        for table,(columns,values) in snapshot.items():
            selected=','.join('"'+c+'"' for c in columns)
            assert conn.execute(f'SELECT {selected} FROM "{table}"').fetchall()==values,table
        assert conn.execute('SELECT year,month,destination_document_id FROM monthly_destinations').fetchall()==[(2026,11,3)]
        assert conn.execute('SELECT COUNT(*) FROM final_date_clearances').fetchone()[0]==0
        assert conn.execute('SELECT batch_id FROM task_runs').fetchone()[0] is None


def test_v2_upgrade_and_offline_queue_preparation_preserve_history(tmp_path):
    backend=Path(__file__).parents[1];path=tmp_path/'v2.sqlite3'
    env={**os.environ,'TK_DATABASE_URL':'sqlite:///'+str(path),'TK_WORKER_LOCK':str(tmp_path/'worker.lock')}
    def run(*args):
        result=subprocess.run([sys.executable,*args],cwd=backend,env=env,capture_output=True,text=True)
        assert result.returncode==0,result.stderr
    run('-m','alembic','upgrade','daf814b2a736')
    with sqlite3.connect(path) as db:
        stamp='2026-10-15'
        db.execute("INSERT INTO users(id,username,password_hash,role,is_active,created_at,updated_at) VALUES (1,'old-admin','unchanged-hash','admin',1,?,?)",(stamp,stamp))
        db.execute("INSERT INTO websites(id,display_name,slug,is_active,is_archived,created_at,updated_at) VALUES (1,'VELBETT','velbett',1,0,?,?)",(stamp,stamp))
        for i,status in enumerate(['SUCCESS','CANCELED','RUNNING','QUEUED'],1):
            db.execute('INSERT INTO task_runs(id,task_number,website_id,selected_date,year,month,environment,preview,status,started_by,started_at,idempotency_key,config_snapshot) VALUES (?,1,1,?,2026,10,?,0,?,1,?,?,?)',
                (i,f'2026-10-{14+i}','WORKING',status,stamp,'v2-run-'+str(i),json.dumps({'website':'VELBETT','sources':[],'destination':{'id':1,'revision':1}})))
            db.execute('INSERT INTO task_run_items(id,run_id,source_tab_name,metric_type,status,source_date,result) VALUES (?,?,?,?,?,?,?)',
                (i,i,'WD BCA / NAMA','deposit','SUCCESS' if i==1 else 'PENDING',f'2026-10-{14+i}',json.dumps({'verified':True})))
        before=db.execute('SELECT id,status,config_snapshot FROM task_runs ORDER BY id').fetchall()
    legacy_snapshot=tmp_path/'rollback-v2.sqlite3'
    with sqlite3.connect(path) as source,sqlite3.connect(legacy_snapshot) as target:source.backup(target)
    run('-m','alembic','upgrade','head')
    with sqlite3.connect(path) as db:
        assert db.execute('SELECT id,status,config_snapshot FROM task_runs ORDER BY id').fetchall()==before
        assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        assert not db.execute('PRAGMA foreign_key_check').fetchall()
    run('-m','app.cli','prepare-v3-upgrade','--services-stopped')
    with sqlite3.connect(path) as db:
        assert db.execute('SELECT status FROM task_runs ORDER BY id').fetchall()==[('SUCCESS',),('CANCELED',),('CANCELED',),('CANCELED',)]
        assert db.execute('SELECT password_hash FROM users').fetchone()[0]=='unchanged-hash'
        assert db.execute('SELECT result FROM task_run_items WHERE id=1').fetchone()[0]==json.dumps({'verified':True})
        assert db.execute('SELECT COUNT(*) FROM audit_logs WHERE action=?',('prepare_v3_upgrade',)).fetchone()[0]==1
    # The standalone rollback helper also runs against a V2 schema, without
    # importing the V3 ORM or starting old queued work.
    run(str(backend.parent/'scripts/cancel-legacy-queue.py'),str(legacy_snapshot),'--services-stopped','--lock',str(tmp_path/'worker.lock'))
