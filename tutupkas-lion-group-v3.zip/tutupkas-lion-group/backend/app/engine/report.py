"""Pemetaan baca-saja Laporan deposit harian; tanpa koordinat per website."""
import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

from .parser import parse_date
from .types import Cell, Grid, Issue, column, norm

REPORT = 'Laporan deposit harian'
FINANCIAL = {'TANGGAL', 'DEPOSIT', 'WITHDRAW', 'HASIL', 'ADMIN BCA', 'ADMIN MANDIRI',
             'ADMIN BRI', 'ADMIN BNI', 'TOTAL SALDO BANK', 'BALANCE'}
CONSOLIDATED = FINANCIAL | {'STATUS', 'KETERANGAN'}


def compact(value):
    return re.sub(r'\s+', '', norm(value))


def decimal_balance(value):
    if value is None or isinstance(value, bool) or str(value).strip() == '':
        raise Issue('INVALID_REPORT_BALANCE', 'BALANCE kosong atau tidak berupa angka; tidak dianggap nol.')
    text = str(value).strip()
    if ',' in text and '.' not in text and re.fullmatch(r'[+-]?\d+,\d{1,2}', text):
        text = text.replace(',', '.')
    try:
        result = Decimal(text)
    except InvalidOperation:
        raise Issue('REPORT_FORMULA_ERROR', 'Hasil formula BALANCE bukan angka yang dapat diverifikasi.',
                    'Periksa error formula dan referensi spreadsheet, lalu Periksa Ulang Rekonsiliasi.')
    if not result.is_finite():
        raise Issue('INVALID_REPORT_BALANCE', 'BALANCE tidak berupa angka finansial yang valid.')
    return result


def report_date(cell):
    parsed = parse_date(cell)
    if parsed:
        return parsed
    from datetime import date
    match = re.fullmatch(r'(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})', str(cell.value or '').strip())
    if match:
        try:
            return date(int(match[3]), int(match[2]), int(match[1]))
        except ValueError:
            pass
    return None


@dataclass
class Table:
    row: int
    date_col: int
    right: int
    headers: dict
    end: int


def markers(grid, registered):
    names = {}
    for name in registered:
        names.setdefault(compact(name), []).append(name)
    result = set()
    for r, row in enumerate(grid.rows):
        for c, cell in enumerate(row):
            key = compact(cell.value)
            if key in names:
                for name in names[key]:
                    result.add((r, c, name))
            # Separate one-letter cells, read strictly in a contiguous column.
            if re.fullmatch(r'[A-Z0-9]', norm(cell.value)):
                text = ''
                for rr in range(r, min(len(grid.rows), r + max(map(len, names), default=0))):
                    letter = norm(grid.cell(rr, c).value)
                    if not re.fullmatch(r'[A-Z0-9]', letter):
                        break
                    text += letter
                    if text in names:
                        for name in names[text]:
                            result.add((r, c, name))
    return sorted(result)


def tables(grid):
    dates = [(r, c) for r, row in enumerate(grid.rows) for c, cell in enumerate(row) if norm(cell.value) == 'TANGGAL']
    result = []
    for r, c in dates:
        right = min([cc for rr, cc in dates if cc > c and abs(rr-r) <= 2] or [grid.width])
        headers = {}
        for rr in range(r, min(r+3, len(grid.rows))):
            for cc in range(c, right):
                label = norm(grid.cell(rr, cc).value)
                if label in CONSOLIDATED:
                    headers.setdefault(label, set()).add(cc)
        end = min([rr for rr, cc in dates if cc == c and rr > r] or [len(grid.rows)])
        result.append(Table(r, c, right, headers, end))
    return result


def associations(grid, registered, discovered):
    found = markers(grid, registered)
    by_table = {}
    by_table = {id(t): set() for t in discovered}
    for r, c, name in found:
        compatible = []
        for table in discovered:
            previous = [t for t in discovered if t.date_col < table.date_col and abs(t.row-table.row) <= 2]
            left = max([max((max(cols) for cols in t.headers.values()), default=t.date_col)+1 for t in previous] or [0])
            extent = max((max(cols) for cols in table.headers.values()), default=table.date_col)
            if left <= c <= extent:
                compatible.append(table)
        if compatible:
            distance = min(abs(t.row-r) for t in compatible)
            for table in compatible:
                if abs(table.row-r) == distance:
                    by_table[id(table)].add(name)
    return found, by_table


def resolve_balance(grid: Grid, selected, website=None, registered=None):
    discovered = tables(grid)
    found, associated = associations(grid, registered or [], discovered)
    if website:
        if not any(name == website for _, _, name in found):
            raise Issue('WEBSITE_BLOCK_MISSING', f'Blok website {website} tidak ditemukan pada {REPORT}.')
        candidates = [t for t in discovered if website in associated[id(t)]]
        # A table associated with more than one website is not a safe fallback.
        if any(len(associated[id(t)]) > 1 for t in candidates):
            raise Issue('AMBIGUOUS_REPORT_BLOCK', f'Blok website {website} terdeteksi lebih dari satu. Periksa struktur laporan.')
    else:
        candidates = [t for t in discovered if not associated[id(t)] and CONSOLIDATED.issubset(t.headers)]
    if len(candidates) > 1:
        raise Issue('AMBIGUOUS_REPORT_BLOCK', f'Blok website {website} terdeteksi lebih dari satu. Periksa struktur laporan.'
                    if website else 'Tabel konsolidasi terdeteksi lebih dari satu. Periksa struktur laporan.')
    matching = []
    for table in candidates:
        rows = [r for r in range(table.row+1, table.end) if report_date(grid.cell(r, table.date_col)) == selected]
        if len(rows) > 1:
            raise Issue('DUPLICATE_REPORT_DATE', f'Tanggal {selected} ditemukan lebih dari satu dalam tabel laporan.')
        if rows:
            matching.append((table, rows[0]))
    if not matching:
        if not candidates:
            raise Issue('CONSOLIDATED_BLOCK_MISSING' if not website else 'REPORT_HEADERS_MISSING',
                        'Tabel konsolidasi dengan header lengkap tidak ditemukan secara unik.' if not website
                        else f'Header Tanggal dan BALANCE untuk {website} tidak ditemukan pada {REPORT}.')
        raise Issue('REPORT_DATE_MISSING', f'Tanggal {selected} tidak ditemukan dalam bagian laporan yang dipilih.')
    if len(matching) != 1:
        raise Issue('AMBIGUOUS_REPORT_BLOCK', f'Blok website {website} terdeteksi lebih dari satu. Periksa struktur laporan.'
                    if website else 'Tabel konsolidasi terdeteksi lebih dari satu. Periksa struktur laporan.')
    table, row = matching[0]
    cols = table.headers.get('BALANCE', set())
    if len(cols) != 1:
        raise Issue('REPORT_BALANCE_HEADER_MISSING', 'Header BALANCE tidak ditemukan secara unik dalam bagian laporan ini.')
    col = next(iter(cols))
    value = decimal_balance(grid.cell(row, col).value)
    return {'balance': str(value), 'cell': f'{column(col)}{row+1}', 'date_cell': f'{column(table.date_col)}{row+1}',
            'row': row, 'column': col, 'table_header_row': table.row+1}

