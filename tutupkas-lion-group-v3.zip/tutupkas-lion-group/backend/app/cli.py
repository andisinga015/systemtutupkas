import argparse
import getpass
import json
import os
import sqlite3
from pathlib import Path

from sqlalchemy import select

from .auth import hasher
from .config import settings
from .db import SessionLocal, utcnow
from .models import User, AuditLog


def main():
    parser = argparse.ArgumentParser(description="Administrasi Tutup Kas Lion Group")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("create-admin")
    p.add_argument("username")
    p = sub.add_parser("backup")
    p.add_argument("destination")
    p = sub.add_parser("approve-palette")
    p.add_argument("file", help="JSON: approved_brown dan excluded_blue, tiap warna array RGB 0..1")
    p = sub.add_parser('prepare-v3-upgrade', help='Batalkan pekerjaan lama setelah kedua layanan dihentikan')
    p.add_argument('--services-stopped',action='store_true',required=True)
    args = parser.parse_args()
    if args.command == 'prepare-v3-upgrade':
        import fcntl
        from .job_control import finalize_batch_cancel,finalize_cancel
        from .models import Run,CrawlBatch
        lock_path=Path(settings().worker_lock)
        lock_path.parent.mkdir(parents=True,exist_ok=True)
        with lock_path.open('a') as lock:
            try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:parser.error('Worker masih aktif. Hentikan API dan worker sebelum menyiapkan upgrade.')
            with SessionLocal() as db:
                batches=list(db.scalars(select(CrawlBatch).where(CrawlBatch.status.in_(['QUEUED','RUNNING','CANCEL_REQUESTED']))))
                for batch in batches:
                    batch.cancel_requested_at=batch.cancel_requested_at or utcnow()
                    db.flush();finalize_batch_cancel(db,batch)
                runs=list(db.scalars(select(Run).where(Run.status.in_(['QUEUED','RUNNING','CANCEL_REQUESTED']))))
                for run in runs:
                    run.cancel_requested_at=run.cancel_requested_at or utcnow()
                    db.flush();finalize_cancel(db,run)
                db.add(AuditLog(action='prepare_v3_upgrade',entity_type='maintenance',entity_id='queue',details={'batches':len(batches),'runs':len(runs)}))
                db.commit()
                print(f'Antrean lama difinalkan sebagai Dibatalkan: {len(batches)} kelompok, {len(runs)} proses terpisah. Hasil dan intent tulis tetap tersimpan.')
    elif args.command == "create-admin":
        password = getpass.getpass("Kata sandi admin (minimal 12 karakter): ")
        if len(password) < 12 or password != getpass.getpass("Ulangi kata sandi: "):
            parser.error("Kata sandi tidak cocok atau terlalu pendek.")
        with SessionLocal() as db:
            if db.scalar(select(User).where(User.username == args.username)):
                parser.error("Nama pengguna sudah ada.")
            db.add(User(username=args.username, password_hash=hasher.hash(password)))
            db.commit()
        print("Administrator dibuat.")
    elif args.command == "backup":
        url = settings().database_url
        if not url.startswith("sqlite:///"):
            parser.error("Perintah ini hanya untuk SQLite.")
        target = Path(args.destination)
        target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        if target.exists():
            parser.error("Tujuan backup sudah ada; pilih nama baru.")
        fd = os.open(target, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.close(fd)
        with sqlite3.connect(url[10:]) as source, sqlite3.connect(target) as dest:
            source.backup(dest)
            if dest.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise RuntimeError("Pemeriksaan backup gagal")
        print("Backup selesai dan integritas terverifikasi.")
    elif args.command == "approve-palette":
        palette = json.loads(Path(args.file).read_text())
        for key in ("approved_brown", "excluded_blue"):
            if key not in palette or not isinstance(palette[key], list):
                parser.error("Palet tidak valid.")
            for rgb in palette[key]:
                if not isinstance(rgb, list) or len(rgb) != 3 or not all(isinstance(v, (int, float)) and 0 <= v <= 1 for v in rgb):
                    parser.error("Gunakan warna RGB aktual 0..1.")
                rgb[:] = [round(v, 4) for v in rgb]
        if not palette['approved_brown']:
            parser.error("Palet cokelat tidak boleh kosong.")
        print(json.dumps(palette, indent=2))
        if input("Sudah dicocokkan dengan transaksi aktual? Ketik SETUJUI: ") != "SETUJUI":
            parser.error("Dibatalkan.")
        path = Path(settings().transfer_palette_file)
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        path.write_text(json.dumps(palette))
        path.chmod(0o600)
        with SessionLocal() as db:
            db.add(AuditLog(action="approve_transfer_palette", entity_type="palette", entity_id="current", details=palette))
            db.commit()


if __name__ == "__main__":
    main()

