import fcntl
import json
import logging
import signal
import time
from pathlib import Path

from sqlalchemy import select

from .config import settings
from .db import SessionLocal
from .engine.runner import process_run
from .batches import process_batch, fail_batch
from .models import Run, CrawlBatch, BatchEntry
from .job_control import finalize_cancel,finalize_batch_cancel,fail_run

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger('tutupkas.worker')
stopping = False


def stop(*_):
    global stopping
    stopping = True


def recover_jobs(db):
    for run in list(db.scalars(select(Run).where(Run.status.in_(['RUNNING','CANCEL_REQUESTED'])))):
        db.refresh(run)
        if run.cancel_requested_at or run.status=='CANCEL_REQUESTED':
            finalize_cancel(db,run)
        else:
            run.status='QUEUED'
    for batch in list(db.scalars(select(CrawlBatch).where(CrawlBatch.status.in_(['RUNNING','CANCEL_REQUESTED'])))):
        db.refresh(batch)
        if batch.cancel_requested_at or batch.status=='CANCEL_REQUESTED':
            finalize_batch_cancel(db,batch)
            continue
        batch.status = 'QUEUED'
        for entry in db.scalars(select(BatchEntry).where(BatchEntry.batch_id == batch.id, BatchEntry.status == 'RUNNING')):
            entry.status = 'WAITING'
    db.commit()


def main():
    lockpath = Path(settings().worker_lock)
    lockpath.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with lockpath.open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise SystemExit('Worker lain sudah berjalan.')
        signal.signal(signal.SIGTERM, stop)
        signal.signal(signal.SIGINT, stop)
        # Running jobs were already manually authorized. Resume only unfinished
        # items using their immutable config and persisted write intents.
        with SessionLocal() as db:
            recover_jobs(db)
        logger.info(json.dumps({"event": "worker_ready"}))
        while not stopping:
            with SessionLocal() as db:
                batch = db.scalar(select(CrawlBatch).where(CrawlBatch.status == 'QUEUED').order_by(CrawlBatch.id).limit(1))
                run = None if batch else db.scalar(select(Run).where(Run.status == 'QUEUED', Run.batch_id == None).order_by(Run.id).limit(1))
                if run or batch:
                    try:
                        if batch:
                            process_batch(db, batch, should_stop=lambda: stopping)
                        else:
                            process_run(db, run)
                    except Exception as e:
                        db.rollback()
                        logger.error(json.dumps({"event": "worker_error", "run_id": run.id if run else None,
                                                 "batch_id": batch.id if batch else None, "type": type(e).__name__}))
                        if batch:
                            fail_batch(db,batch)
                        else:
                            fail_run(db,run)
            if not run and not batch:
                time.sleep(settings().worker_poll_seconds)
        logger.info(json.dumps({"event": "worker_stopped"}))


if __name__ == '__main__':
    main()

