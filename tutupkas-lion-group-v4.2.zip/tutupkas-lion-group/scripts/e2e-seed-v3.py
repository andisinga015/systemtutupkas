"""Only browser-test configuration; never usable against an operational database."""
import os
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from sqlalchemy import select
from app.db import SessionLocal
from app.models import Website,SourceDocument,SourceRevision,SourceSheet,Destination,MonthlyDestination,DestinationMapping

url=os.environ.get('TK_DATABASE_URL','')
assert os.environ.get('TK_E2E_PASSWORD') and url.startswith('sqlite:////tmp/tutupkas-e2e.'), 'Only isolated E2E database permitted'
with SessionLocal() as db:
    # No worker runs in this suite: real enqueue/cancel routes are exercised;
    # these declared-valid source URLs do not prove Google access.
    for name,slug in [('VELBETT E2E','velbett-e2e'),('FANTASI E2E','fantasi-e2e')]:
        site=Website(display_name=name,slug=slug);db.add(site);db.flush()
        doc=SourceDocument(website_id=site.id,document_type='DEPO',year=2026,month=10,
            spreadsheet_url='https://docs.google.com/spreadsheets/d/e2e-source-123456/edit',spreadsheet_id='e2e-source-123456',
            spreadsheet_title='Sumber pengujian antrean',validation_status='VALID')
        db.add(doc);db.flush()
        rev=SourceRevision(source_document_id=doc.id,revision_number=1,spreadsheet_url=doc.spreadsheet_url,spreadsheet_id=doc.spreadsheet_id,changed_by=1)
        db.add(rev);db.flush();doc.active_revision_id=rev.id
        db.add(SourceSheet(source_document_id=doc.id,source_revision_id=rev.id,tab_name='WD BCA / NAMA',is_active=True))
        db.flush()
        from app.lineage import refresh_bindings
        refresh_bindings(db,doc,{'sheets':[{'properties':{'sheetId':1,'title':'WD BCA / NAMA'}}]})
    dest=Destination(year=2026,month=10,environment='WORKING',spreadsheet_url='https://docs.google.com/spreadsheets/d/e2e-destination-123456/edit',spreadsheet_id='e2e-destination-123456',validation_status='VALID',spreadsheet_title='Tujuan pengujian antrean')
    db.add(dest);db.flush();db.add(MonthlyDestination(year=2026,month=10,destination_document_id=dest.id))
    db.add(DestinationMapping(destination_document_id=dest.id,destination_revision=dest.revision,spreadsheet_id=dest.spreadsheet_id,year=2026,month=10,state='READY',registered=['VELBETT E2E','FANTASI E2E'],requested_by=1,evidence={'fixture_only':'enqueue/cancel; never starts worker'}))
    # Exclude the earlier invalid source WEB from this mass-date fixture.
    for site in db.scalars(select(Website).where(Website.slug=='web-uji-e2e')):site.is_active=False
    db.commit()
