import uuid

import pytest
from sqlalchemy import select

from app.engine import resolver
from app.engine.runner import process_run
from app.engine.types import Issue
from app.models import Run, RunItem, SourceDocument, SourceSheet, TaskError, WriteLedger
from helpers import DAY, PALETTE, DEPO_NAME, FakeSheets, put, regular_destination


def configured(logged, db, monkeypatch, tmp_path):
    from app.config import settings
    import json
    palette=tmp_path/'palette.json'
    palette.write_text(json.dumps(PALETTE))
    monkeypatch.setattr(settings(),'transfer_palette_file',str(palette))
    fake=FakeSheets()
    monkeypatch.setattr('app.api.SheetsClient',lambda:fake)
    w=logged.post('/api/websites',json={'display_name':'VELBETT','slug':'velbett'}).json()
    for kind,id in [('DEPO','depo-document-12345'),('QRIS','qris-document-12345')]:
        d=logged.put(f"/api/websites/{w['id']}/sources",json={'year':2026,'month':10,'document_type':kind,
                     'spreadsheet_url':f'https://docs.google.com/spreadsheets/d/{id}/edit'}).json()
        assert logged.post(f"/api/sources/{d['id']}/validate").json()['document']['validation_status']=='VALID'
        tabs=logged.get(f"/api/sources/{d['id']}/tabs").json()
        logged.post(f"/api/sources/{d['id']}/tabs",json={'ids':[t['id'] for t in tabs],'is_active':True})
    d=logged.put('/api/destinations',json={'year':2026,'month':10,'environment':'TEST',
                      'spreadsheet_url':'https://docs.google.com/spreadsheets/d/destination-copy-12345/edit'}).json()
    logged.post(f"/api/destinations/{d['id']}/validate")
    def rebuild_mapping():
        from app.destination_registry import build_mapping,queue_mapping
        from app.models import Destination
        mapping=queue_mapping(db,db.get(Destination,d['id']),1)
        db.commit();build_mapping(db,mapping,fake)
        assert mapping.state=='READY',mapping.error
    fake.rebuild_mapping=rebuild_mapping
    fake.mapping_reads=list(fake.reads)
    fake.reads.clear()  # Measure the authorized Run, separately from URL mapping.
    return w,fake


def start(logged, w, **kwargs):
    result=logged.post('/api/runs',json={'website_id':w['id'],'selected_date':str(DAY),'environment':'TEST',
                              'idempotency_key':str(uuid.uuid4()),**kwargs})
    assert result.status_code==202,result.text
    return result.json()


def test_all_modules_and_safe_readback(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    run=start(logged,w)
    process_run(db,db.get(Run,run['id']),fake)
    detail=logged.get(f"/api/runs/{run['id']}").json()
    assert detail['status']=='SUCCESS',detail['errors']
    assert len([i for i in detail['items'] if i['metric_type']!='reconciliation'])==18
    assert detail['reconciliation']['status']=='BALANCED'
    dest=fake.documents['destination-copy-12345']
    assert dest['SALDO BANK'].cell(2,1).value==2355000
    assert dest['TOTAL WD'].cell(2,1).value==9399000
    assert [dest['BIAYA'].cell(2,c).value for c in (1,2,3)]==[5500,5000,492000]
    assert dest['Pengeluaran FEE QRIS DEPO'].cell(2,2).value==621134
    assert dest['Pengeluaran FEE QRIS WD'].cell(2,2).value==732340
    assert dest['KET PENGIRIMAN'].cell(3,0).value=='PENGIRIMAN DARI KAS BESAR BCA'
    assert dest['KET PENGIRIMAN'].cell(4,1).value==-1741000
    assert dest['KET PENGIRIMAN'].cell(5,0).note=='QRIS E-POWER ( KIRIM KE KAS BESAR BRI ) -1.000.000'
    assert dest['TOTAL WD'].cell(2,4).formula=='=SUM(B3:C3)'
    assert dest['TOTAL WD'].cell(2,6).value==777
    ledgers=list(db.scalars(select(WriteLedger)))
    assert all(l.verification_status=='VERIFIED' for l in ledgers)
    assert logged.post(f"/api/runs/{run['id']}/clear").status_code==200
    assert logged.post('/api/runs',json={'website_id':w['id'],'selected_date':str(DAY),'environment':'TEST','idempotency_key':str(uuid.uuid4())}).status_code==409


def test_preview_no_writes_and_not_clearable(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    run=start(logged,w,preview=True)
    process_run(db,db.get(Run,run['id']),fake)
    assert db.get(Run,run['id']).status=='PREVIEWED'
    assert not fake.writes
    assert not list(db.scalars(select(WriteLedger)))
    assert logged.post(f"/api/runs/{run['id']}/clear").status_code==409


def test_selective_retry_preserves_verified_items_and_aggregate(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    fake.fail_tabs.add(DEPO_NAME)
    run=start(logged,w)
    process_run(db,db.get(Run,run['id']),fake)
    detail=logged.get(f"/api/runs/{run['id']}").json()
    assert detail['status']=='PARTIAL'
    assert any(e['error_code']=='AGGREGATE_INCOMPLETE' for e in detail['errors'])
    assert fake.documents['destination-copy-12345']['BIAYA'].cell(2,1).empty
    qris_reads=len([r for r in fake.reads if r[0]=='qris-document-12345'])
    docid=next(i['source_document_id'] for i in detail['items'] if i['source_tab_name']==DEPO_NAME)
    fake.fail_tabs.clear()
    assert logged.post(f"/api/runs/{run['id']}/retry",json={'source_document_id':docid}).status_code==202
    process_run(db,db.get(Run,run['id']),fake)
    detail=logged.get(f"/api/runs/{run['id']}").json()
    assert detail['status']=='SUCCESS',detail['errors']
    assert len([r for r in fake.reads if r[0]=='qris-document-12345'])==qris_reads
    assert fake.documents['destination-copy-12345']['BIAYA'].cell(2,1).value==5500


def test_module_failure_isolation_formula_and_manual_note(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    put(fake.documents['destination-copy-12345']['TOTAL DEPO'],2,1,'',formula='=""')
    put(fake.documents['destination-copy-12345']['TOTAL WD'],2,1,None,note='Manual note')
    run=start(logged,w)
    process_run(db,db.get(Run,run['id']),fake)
    detail=logged.get(f"/api/runs/{run['id']}").json()
    assert detail['status']=='PARTIAL'
    assert {e['error_code'] for e in detail['errors']}=={'FORMULA_CONFLICT','EXISTING_VALUE_CONFLICT'}
    assert fake.documents['destination-copy-12345']['SALDO BANK'].cell(2,1).value==2355000
    assert fake.documents['destination-copy-12345']['TOTAL WD'].cell(2,1).note=='Manual note'


def test_duplicate_start_and_repeated_run_do_not_append(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    key=str(uuid.uuid4())
    first=start(logged,w,idempotency_key=key)
    assert start(logged,w,idempotency_key=key)['id']==first['id']
    process_run(db,db.get(Run,first['id']),fake)
    second=start(logged,w)
    process_run(db,db.get(Run,second['id']),fake)
    assert db.get(Run,second['id']).status=='SUCCESS'
    grid=fake.documents['destination-copy-12345']['KET PENGIRIMAN']
    assert not grid.cell(3,2).value
    assert len(list(db.scalars(select(WriteLedger))))==len({(w.tab,w.address) for w in fake.writes})


def test_crash_after_google_write_reconciles_intent(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    original=fake.write
    crashed=[False]
    def crash(id,grid,writes):
        original(id,grid,writes)
        if not crashed[0]:
            crashed[0]=True
            raise ConnectionError('simulated uncertain transport')
    fake.write=crash
    run=start(logged,w)
    process_run(db,db.get(Run,run['id']),fake)
    assert db.get(Run,run['id']).status=='SUCCESS'
    assert all(l.verification_status=='VERIFIED' for l in db.scalars(select(WriteLedger)))
    assert len({(w.tab,w.address) for w in fake.writes})==len(fake.writes)


def test_no_active_tabs_and_mismatched_month_blocked(logged,db,monkeypatch,tmp_path):
    w,_=configured(logged,db,monkeypatch,tmp_path)
    for tab in db.scalars(select(SourceSheet)):
        tab.is_active=False
    db.commit()
    req={'website_id':w['id'],'selected_date':str(DAY),'environment':'TEST','idempotency_key':str(uuid.uuid4())}
    response=logged.post('/api/runs',json=req)
    assert response.status_code==409 and 'Tidak ada sheet aktif' in response.text
    assert logged.post('/api/runs',json={**req,'selected_date':'2026-11-15'}).status_code==409


def test_automatic_account_matching_and_no_cross_website():
    grid=regular_destination('SALDO BANK',['IVAN RAKHMANDA','E-POWER'])
    write=resolver.regular(grid,'VELBETT',['VELBETT','FANTASI'],DAY,DEPO_NAME,2355000)
    assert write.address=='B3'
    assert resolver.regular(grid,'VELBETT',['VELBETT','FANTASI'],DAY,'QRIS E-POWER',1).address=='C3'
    with pytest.raises(Issue):
        resolver.regular(grid,'FANTASI',['VELBETT','FANTASI'],DAY,DEPO_NAME,1)
    put(grid,1,2,'IVAN RAKHMANDA')
    with pytest.raises(Issue):
        resolver.regular(grid,'VELBETT',['VELBETT','FANTASI'],DAY,DEPO_NAME,1)


def test_qris_overflow_uses_mandiri_after_depo_priority(logged,db,monkeypatch,tmp_path):
    from helpers import BROWN
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    grid=fake.documents['qris-document-12345']['QRIS E-POWER']
    put(grid,84,3,'DARI KAS BNI',color=BROWN)
    put(grid,84,7,125000)
    run=start(logged,w)
    process_run(db,db.get(Run,run['id']),fake)
    assert db.get(Run,run['id']).status=='SUCCESS'
    target=fake.documents['destination-copy-12345']['KET PENGIRIMAN']
    assert target.cell(5,0).value=='DARI KAS BNI' # last BCA slot, despite description bank BNI
    assert target.cell(3,2).value=='KIRIM KE KAS BESAR BRI' # MANDIRI overflow, not BRI routing
    assert target.cell(3,2).note.endswith('-1.000.000')


def test_transfer_slots_full_does_not_overwrite_manual_content(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    grid=fake.documents['destination-copy-12345']['KET PENGIRIMAN']
    for r in range(3,6):
        for c in range(0,8,2):
            put(grid,r,c,'Manual')
            put(grid,r,c+1,0)
    run=start(logged,w)
    process_run(db,db.get(Run,run['id']),fake)
    errors=logged.get(f"/api/runs/{run['id']}").json()['errors']
    assert any(e['error_code']=='TRANSFER_SLOTS_FULL' for e in errors)
    assert grid.cell(3,0).value=='Manual' and grid.cell(3,1).value==0


def test_removed_owned_transfer_is_conflict(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    first=start(logged,w)
    process_run(db,db.get(Run,first['id']),fake)
    put(fake.documents['qris-document-12345']['QRIS E-POWER'],85,3,'BIAYA')
    second=start(logged,w)
    process_run(db,db.get(Run,second['id']),fake)
    detail=logged.get(f"/api/runs/{second['id']}").json()
    assert detail['status']=='PARTIAL'
    assert any(e['error_code']=='TRANSFER_IDENTITY_CHANGED' for e in detail['errors'])
    assert fake.documents['destination-copy-12345']['KET PENGIRIMAN'].cell(5,0).note


def test_readback_mismatch_is_not_success(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    fake.corrupt_readback=True
    run=start(logged,w)
    process_run(db,db.get(Run,run['id']),fake)
    detail=logged.get(f"/api/runs/{run['id']}").json()
    assert detail['status']!='SUCCESS'
    assert any(e['error_code']=='READBACK_FAILED' for e in detail['errors'])
    assert logged.post(f"/api/runs/{run['id']}/clear").status_code==409


def test_approved_palette_can_repair_failed_items_without_new_sources(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    run=start(logged,w)
    row=db.get(Run,run['id'])
    row.config_snapshot={**row.config_snapshot,'palette':{}}
    db.commit()
    process_run(db,row,fake)
    detail=logged.get(f"/api/runs/{row.id}").json()
    assert detail['status']=='PARTIAL'
    for doc in detail['config_snapshot']['sources']:
        if any(e['source_document_id']==doc['id'] for e in detail['errors']):
            assert logged.post(f'/api/runs/{row.id}/retry',json={'source_document_id':doc['id']}).status_code==202
            process_run(db,row,fake)
    assert row.status=='SUCCESS'


def test_clear_reopen_single_working_copy(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    run=start(logged,w)
    process_run(db,db.get(Run,run['id']),fake)
    result=logged.post(f"/api/runs/{run['id']}/clear")
    assert result.status_code==200,result.text
    clearance=result.json()
    assert logged.post(f"/api/clearances/{clearance['id']}/reopen",json={'reason':'Perbaikan data setelah tinjauan'}).status_code==200
    assert not logged.get('/api/clearances').json()[0]['is_clear']
    assert start(logged,w)['environment']=='WORKING'
