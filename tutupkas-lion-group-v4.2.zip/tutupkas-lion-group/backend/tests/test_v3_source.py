from copy import deepcopy
from datetime import date

import pytest
from sqlalchemy import select

from app.engine.parser import Day, transfer_rows
from app.engine.runner import process_run
from app.engine.types import Cell, Issue
from app.models import Run, RunItem
from helpers import DAY, PALETTE, DEPO_NAME, FakeSheets, depo, qris, marker, put
from test_engine import configured,start


def no_headers(g):
    for c in range(g.width): put(g,1,c,None)
    # Misleading duplicates elsewhere must never move confirmed source columns.
    put(g,0,0,'Total');put(g,0,1,'Total');put(g,0,2,'SALDO');put(g,0,3,'Kiriman')
    return g


@pytest.mark.parametrize('kind,factory,expected',[('DEPO',depo,[0,9399000,2355000]),('QRIS',qris,[75342988,59804000,449057834])])
def test_fixed_columns_ignore_missing_duplicate_and_wrong_source_headers(kind,factory,expected,monkeypatch):
    monkeypatch.setattr('app.engine.parser.header',lambda *args:pytest.fail('Source header lookup is forbidden'))
    g=no_headers(factory());day=Day.resolve(g,DAY,kind)
    assert [day.metric(label) for label in ['Total','Total WD','SALDO']]==expected
    assert day.signed_sum(7 if kind=='DEPO' else 6)==(-5500 if kind=='DEPO' else -492000)
    tx=transfer_rows(day,kind,PALETTE)
    assert [v['amount'] for v in tx]==([10000000,-1741000] if kind=='DEPO' else [-1000000])
    if kind=='QRIS': assert tx[0]['note'].endswith('-1.000.000')


def empty_october18(kind='DEPO'):
    g=no_headers(depo() if kind=='DEPO' else qris())
    if kind=='DEPO':
        g.rows.extend([[Cell() for _ in range(g.width)] for _ in range(4)])
        for r,day in [(308,18),(309,19),(310,20),(311,21)]:marker(g,r,date(2026,10,day))
    else:
        g.rows.extend([[Cell() for _ in range(g.width)] for _ in range(2)])
        marker(g,90,date(2026,10,18));marker(g,91,date(2026,10,19))
    return g


def test_real_october18_separator_only_example():
    g=empty_october18();day=Day.resolve(g,date(2026,10,18),'DEPO')
    assert day.start+1==309 and day.end+1==309 and day.transaction_rows==[]
    assert [day.metric(v) for v in ['Total','Total WD','SALDO']]==[0,0,2355000]
    assert day.last_metric_row+1==306
    assert day.signed_sum(7)==0 and transfer_rows(day,'DEPO',PALETTE)==[]


@pytest.mark.parametrize('kind,factory,column',[('DEPO',depo,11),('QRIS',qris,10)])
def test_populated_closing_uses_confirmed_columns_not_nearby_balance(kind,factory,column):
    g=no_headers(factory());put(g,305 if kind=='DEPO' else 87,column,888)
    if kind=='DEPO':put(g,305,12,999999999)
    assert Day.resolve(g,DAY,kind).metric('SALDO')==888


def test_empty_formulas_and_cumulative_values_do_not_invent_activity():
    g=depo();g.rows.insert(307,[Cell() for _ in range(g.width)])
    # Adjust the following separator from old row 307 to row 308.
    for m in g.merges:
        if m['startRowIndex']>=307:m['startRowIndex']+=1;m['endRowIndex']+=1
    for c in [4,5,7,8]:put(g,307,c,0,formula='=SUM(A1:A2)')
    put(g,307,9,123);put(g,307,10,456);put(g,307,11,2355000)
    d=Day.resolve(g,date(2026,10,16),'DEPO')
    assert not d.transaction_rows and d.metric('Total')==0 and d.metric('Total WD')==0


@pytest.mark.parametrize('problem',['missing_date','duplicate_date','invalid_balance','error_total','narrow_grid'])
def test_empty_day_errors_are_not_silently_zero(problem):
    g=empty_october18();selected=date(2026,10,18)
    if problem=='missing_date':put(g,309,0,None)
    if problem=='duplicate_date':marker(g,310,date(2026,10,19))
    if problem=='invalid_balance':put(g,308,11,'#REF!')
    if problem=='error_total':put(g,308,9,'#VALUE!')
    if problem=='narrow_grid':g.rows=[row[:5] for row in g.rows]
    with pytest.raises(Issue):
        day=Day.resolve(g,selected,'DEPO');day.metric('Total');day.metric('SALDO')


def test_fixed_fee_columns_and_business_rules_are_unchanged():
    z=no_headers(qris('QRIS QRIZZ'))
    put(z,86,3,'FEE QRIS PERIODE 15-16 october 2026');put(z,86,7,-100)
    d=Day.resolve(z,DAY,'QRIS')
    assert d.fees('FEE QRIS PERIODE')==('FEE QRIS PERIODE 14 - 15 october 2026\nFEE QRIS PERIODE 15-16 october 2026',621234)
    assert abs(d.signed_sum(6))==5000
    e=no_headers(qris());put(e,85,3,'FEE WD AUTO');put(e,85,7,-100)
    d=Day.resolve(e,DAY,'QRIS')
    assert d.fees('FEE WD AUTO')==('FEE WD AUTO',732440)
    assert abs(d.signed_sum(6))==492000


def test_all_modules_work_with_fixed_columns_and_one_source_snapshot(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    for sid in ['depo-document-12345','qris-document-12345']:
        for g in fake.documents[sid].values():no_headers(g)
    monkeypatch.setattr('app.engine.parser.header',lambda *args:pytest.fail('header() must not be used'))
    r=start(logged,w);process_run(db,db.get(Run,r['id']),fake)
    detail=logged.get(f"/api/runs/{r['id']}").json()
    assert detail['status']=='SUCCESS',detail['errors']
    counts={sid:len([1 for read_id,_ in fake.reads if read_id==sid]) for sid in ['depo-document-12345','qris-document-12345']}
    assert counts=={'depo-document-12345':1,'qris-document-12345':2}
    assert len([i for i in detail['items'] if i['source_document_id']])==17
    target=fake.documents['destination-copy-12345']
    assert [target['BIAYA'].cell(2,c).value for c in [1,2,3]]==[5500,5000,492000]
    assert target['Pengeluaran FEE QRIS DEPO'].cell(2,2).value==621134
    assert target['Pengeluaran FEE QRIS WD'].cell(2,2).value==732340
    assert target['KET PENGIRIMAN'].cell(5,0).note.endswith('-1.000.000')


def test_full_empty_day_run_preserves_saldo_and_writes_zero_only_when_proved(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    fake.documents['depo-document-12345'][DEPO_NAME]=empty_october18()
    for name in fake.documents['qris-document-12345']:
        old_id=fake.documents['qris-document-12345'][name].sheet_id
        fake.documents['qris-document-12345'][name]=empty_october18('QRIS')
        fake.documents['qris-document-12345'][name].sheet_id=old_id
    for title,g in fake.documents['destination-copy-12345'].items():
        if title=='KET PENGIRIMAN':put(g,0,0,'18-Oct-2026')
        elif title=='Laporan deposit harian':
            for offset in [0,13,26,39]:put(g,2,offset+1,'18-Oct-2026')
        else:
            put(g,2,0,'18-Oct-2026');put(g,2,g.width-2,'18-Oct-2026')
    fake.rebuild_mapping()  # Authorize the deliberately changed monthly layout.
    r=start(logged,w,selected_date='2026-10-18');process_run(db,db.get(Run,r['id']),fake)
    detail=logged.get(f"/api/runs/{r['id']}").json()
    assert detail['status']=='SUCCESS',detail['errors']
    target=fake.documents['destination-copy-12345']
    assert target['TOTAL DEPO'].cell(2,1).value==0 and target['TOTAL WD'].cell(2,1).value==0
    assert target['SALDO BANK'].cell(2,1).value==2355000
    assert not any(write.tab=='KET PENGIRIMAN' for write in fake.writes)
    assert [target['BIAYA'].cell(2,c).value for c in [1,2,3]]==[0,0,0]


def test_structural_source_failure_is_read_once_not_retried_per_metric(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    fake.fail_tabs.add(DEPO_NAME)
    r=start(logged,w);process_run(db,db.get(Run,r['id']),fake)
    assert len([read for read in fake.reads if read[0]=='depo-document-12345'])==1
    assert db.get(Run,r['id']).status=='PARTIAL'


def test_date_status_uses_each_selected_date_and_its_own_balance(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    for title,g in fake.documents['destination-copy-12345'].items():
        if title=='Laporan deposit harian':
            for offset in [0,13,26,39]:put(g,3,offset+1,'16-Oct-2026');put(g,3,offset+10,-30278535 if offset==13 else 0)
        elif title=='KET PENGIRIMAN':
            old=deepcopy(g);g.rows.extend(deepcopy(old.rows))
            for merge in old.merges:g.merges.append({**merge,'startRowIndex':merge['startRowIndex']+8,'endRowIndex':merge['endRowIndex']+8})
            put(g,8,0,'16-Oct-2026')
        else:put(g,3,0,'16-Oct-2026')
    fake.rebuild_mapping()
    first=start(logged,w);process_run(db,db.get(Run,first['id']),fake)
    second=start(logged,w,selected_date='2026-10-16');process_run(db,db.get(Run,second['id']),fake)
    a=logged.get('/api/reconciliations/date',params={'selected_date':str(DAY)}).json()['websites'][0]
    b=logged.get('/api/reconciliations/date',params={'selected_date':'2026-10-16'}).json()['websites'][0]
    assert a['run_id']==first['id'] and a['reconciliation_status']=='BALANCED' and a['balance']=='0'
    assert b['run_id']==second['id'] and b['reconciliation_status']=='NOT_BALANCED' and b['balance']=='-30278535'
