"""Measured isolated full website / one-item retry; no network or credentials.

Uses production snapshot, index, registry, parser, writer and SQL state. Wire
fixtures build only requested ranges. Optional Drive versions are simulated;
measured call counts include their reads. Runtime pacing remains 1.2s in app.
"""
import argparse,json,logging,resource,sys,tempfile,time
from copy import deepcopy
from datetime import date
from pathlib import Path
sys.path[:0]=[str(Path(__file__).resolve().parents[2]),str(Path(__file__).resolve().parents[1])]
p=argparse.ArgumentParser();p.add_argument('--history',type=int,default=40000);p.add_argument('--without-revision',action='store_true');args=p.parse_args()
resource.setrlimit(resource.RLIMIT_AS,(1536*1048576,)*2)
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine,select
from sqlalchemy.orm import Session
from app.auth import hasher
from app.db import Base,get_db
from app.config import settings
from app.main import app
from app.models import User,Run,RunItem,Destination,DestinationMapping,WriteLedger
from app.engine.runner import process_run
from app.destination_registry import build_mapping,queue_mapping
from app.source_index import indexed_source_day
from app.telemetry import Capture,api_attempt,response_bytes
from app.engine.types import column
from benchmark_memory import memory
from range_api import RangeAPI
from test_engine import configured,start
from test_v41_destination import shifted
from wide_api import WideAPI
from helpers import put,DEPO_NAME,marker
logging.disable(logging.CRITICAL)
with tempfile.TemporaryDirectory(prefix='tutupkas-v42-perf-') as folder,pytest.MonkeyPatch.context() as patch:
 path=Path(folder);engine=create_engine('sqlite:///'+str(path/'fixture.sqlite3'),connect_args={'check_same_thread':False});Base.metadata.create_all(engine)
 patch.setattr(settings(),'worker_lock',str(path/'worker.lock'));patch.setattr(settings(),'cookie_secure',False);patch.setattr(settings(),'app_origin','http://testserver');patch.setattr(settings(),'reconciliation_delay',0)
 with Session(engine,expire_on_commit=False) as db:
  db.add(User(username='finance',password_hash=hasher.hash('fixture-only-password-123')));db.commit();app.dependency_overrides[get_db]=lambda:db
  with TestClient(app) as client:
   csrf=client.get('/api/auth/csrf').json()['csrf_token'];login=client.post('/api/auth/login',json={'username':'finance','password':'fixture-only-password-123'},headers={'x-csrf-token':csrf});client.headers['x-csrf-token']=login.json()['csrf_token']
   w,fake=configured(client,db,patch,path)
   # October 18 has real selected and following separators and equivalent
   # populated financial rows; old labels and all 22 golden outputs are retained.
   for sheets in [fake.documents['depo-document-12345'],fake.documents['qris-document-12345']]:
    for g in sheets.values():
     for r,day in ([(290,18),(306,19),(307,20)] if g.width==13 else [(83,18),(88,19),(89,20)]):marker(g,r,date(2026,10,day))
   for title,g in fake.documents['destination-copy-12345'].items():
    for row in g.rows:
     for cell in row:
      if cell.value=='15-Oct-2026':cell.value='18-Oct-2026'
   apis={title:WideAPI(shifted(g),retain_calls=False) for title,g in fake.documents['destination-copy-12345'].items()}
   sources={(doc,title):RangeAPI(g,history=args.history,retain_calls=False) for doc,sheets in fake.documents.items() if doc!='destination-copy-12345' for title,g in sheets.items()}
   versions={doc:1 for doc in fake.documents};versions['destination-copy-12345']=1
   def tracked(api):
    raw=api.request
    def request(method,*pos,**kw):
     api_attempt(method);before=api.total_bytes
     try:return raw(method,*pos,**kw)
     finally:response_bytes(api.total_bytes-before)
    api.request=request
   for api in [*apis.values(),*sources.values()]:tracked(api)
   def token(doc):api_attempt('GET');return str(versions[doc]) if not args.without_revision else None
   fake.content_revision=token
   fake.indexed_source_day=lambda session,doc,title,selected,identity:indexed_source_day(session,sources[doc['spreadsheet_id'],title],doc,title,selected,identity)
   for (doc,title),api in sources.items():api.content_revision=lambda document,doc=doc:token(doc)
   fake.destination_grid=lambda doc,title,registered=():apis[title].destination_grid(doc,title,registered)
   def request(method,doc,**kw):
    import re
    title=re.match(r"'((?:[^']|'')*)'!",kw['params']['ranges'][0])[1].replace("''", "'")
    return apis[title].request(method,doc,**kw)
   fake.request=request
   def write(doc,grid,writes):
    fake.writes.extend(deepcopy(writes));apis[grid.title].write(doc,grid,writes);versions[doc]+=1
    fake._verified_revisions={}
   fake.write=write
   mapping=queue_mapping(db,db.scalar(select(Destination)),1);db.commit()
   with Capture() as cold:build_mapping(db,mapping,fake)
   assert mapping.state=='READY',mapping.error
   run=db.get(Run,start(client,w,selected_date='2026-10-18')['id']);process_run(db,run,fake)
   assert run.status=='SUCCESS',client.get(f'/api/runs/{run.id}').json()['errors']
   initial=run.config_snapshot['performance_attempts'][-1]
   golden=json.loads((Path(__file__).parents[1]/'fixtures/v3_financial_outputs.json').read_text())['writes']
   actual=[[x.tab,f'{column(x.col-420)}{x.row-73+1}',x.value,x.note,x.bank] for x in fake.writes]
   assert actual==[x[:5] for x in golden]
   fake.writes.clear();warm_run=db.get(Run,start(client,w,selected_date='2026-10-18',preview=True)['id']);process_run(db,warm_run,fake);assert warm_run.status=='PREVIEWED'
   warm=warm_run.config_snapshot['performance_attempts'][-1];assert not fake.writes
   steady_run=db.get(Run,start(client,w,selected_date='2026-10-18',preview=True)['id']);process_run(db,steady_run,fake);assert steady_run.status=='PREVIEWED'
   steady=steady_run.config_snapshot['performance_attempts'][-1];assert not fake.writes
   item=db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type=='deposit',RunItem.source_tab_name==DEPO_NAME));item.status='FAILED';run.status='PARTIAL';db.commit()
   before={i.id:deepcopy(i.result) for i in db.scalars(select(RunItem).where(RunItem.run_id==run.id,RunItem.status=='SUCCESS'))}
   result=client.post(f'/api/runs/{run.id}/retry',json={'item_ids':[item.id]});assert result.status_code==202,result.text
   process_run(db,run,fake);assert run.status=='SUCCESS';assert not fake.writes
   assert all(db.get(RunItem,i).result==v for i,v in before.items())
   retry=run.config_snapshot['performance_attempts'][-1]
   print(json.dumps({'selected_date':'2026-10-18','history_rows_per_source':args.history,'source_tabs':len(sources),'allocated_destination':[1000,1500],'address_space_limit_mib':1536,'version_tokens':not args.without_revision,'cold_mapping':mapping.evidence['performance'],'initial_processing':initial,'first_preview_after_writes':warm,'warm_preview':steady,'one_item_retry':retry,'snapshot_source_calls':{title:api.count for (doc,title),api in sources.items()},'golden_values_coordinates_notes_banks_match':True,'other_successful_items_unchanged':True,'retained_snapshots':db.query(__import__('app.models',fromlist=['SourceSnapshot']).SourceSnapshot).count(),'oom':False,**memory(),'network':'safely isolated lazy wire fixture; no Google latency/pacing; live acceptance pending'}))
  app.dependency_overrides.clear()
 engine.dispose()
