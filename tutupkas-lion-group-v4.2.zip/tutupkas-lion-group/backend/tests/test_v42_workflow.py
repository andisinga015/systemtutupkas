"""Durable active retry, fixed mapping, no-fee and evolving transfer groups."""
from copy import deepcopy
from uuid import uuid4

import pytest
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.engine.runner import process_run
from app.engine.types import Issue,Cell
from app.models import (Run,RunItem,RetryRequest,SourceSnapshot,DestinationConflict,DestinationMapping,
    MappingTarget,WriteLedger,TransferOwnership,TransferLineage,TaskError,SourceDocument,User,AuditLog)
from app.operations import queue_retry
from app.api import Retry
from helpers import DAY,DEPO_NAME,put
from test_engine import configured,start
from test_v42_conflicts import decision


def item_for(db,run,metric,tab=DEPO_NAME):
    return db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type==metric,RunItem.source_tab_name==tab))


def failed_source(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);fake.fail_tabs.add(DEPO_NAME)
    run=db.get(Run,start(logged,w)['id']);process_run(db,run,fake)
    assert run.status=='PARTIAL'
    return w,fake,run,item_for(db,run,'deposit')


@pytest.mark.parametrize('boundary',['reading','writing','last_item'])
def test_priority_retry_during_active_run_at_safe_boundaries(logged,db,monkeypatch,tmp_path,boundary):
    w,fake=configured(logged,db,monkeypatch,tmp_path);fake.fail_tabs.add(DEPO_NAME)
    run=db.get(Run,start(logged,w)['id']);requested=[];original_source=fake.source_day;original_write=fake.write
    def enqueue():
        if requested:return
        with Session(db.get_bind(),expire_on_commit=False) as other:
            selected=item_for(other,run,'deposit');assert selected.status=='FAILED'
            fake.fail_tabs.clear();put(fake.documents['depo-document-12345'][DEPO_NAME],305,9,12345)
            queue_retry(other,other.get(Run,run.id),Retry(item_ids=[selected.id],idempotency_key=str(uuid4())),other.get(User,1));other.commit()
            requested.append(selected.id)
    def source(id,title,*args):
        if boundary=='reading' and id=='qris-document-12345':enqueue()
        return original_source(id,title,*args)
    def write(id,grid,writes):
        original_write(id,grid,writes)
        if boundary=='writing' or boundary=='last_item' and grid.title=='Pengeluaran FEE QRIS DEPO':enqueue()
    fake.source_day=source;fake.write=write
    process_run(db,run,fake)
    assert requested
    req=db.scalar(select(RetryRequest));assert req.state=='SUCCEEDED'
    selected=db.get(RunItem,requested[0]);assert selected.status=='SUCCESS' and selected.result['plan'][0]['proposed']['value']==12345
    assert db.get(SourceSnapshot,selected.result['snapshot_id']).retry_request_id==req.id
    assert item_for(db,run,'balance').status=='FAILED'  # The previous failed shared snapshot is not replayed.
    assert len(list(db.scalars(select(DestinationMapping))))==2  # URL save + explicit validation, no retry remap.


def test_single_failed_item_among_42_successes_uses_fresh_source_only(logged,db,monkeypatch,tmp_path):
    w,fake,run,item=failed_source(logged,db,monkeypatch,tmp_path)
    for n in range(42):db.add(RunItem(run_id=run.id,source_document_id=item.source_document_id,source_tab_name=f'historical-{n}',metric_type='expense_input',status='SUCCESS',source_date=DAY,result={'signed_value':0,'preserved':n}))
    db.commit()
    preserved={i.id:deepcopy(i.result) for i in db.scalars(select(RunItem).where(RunItem.run_id==run.id,RunItem.status=='SUCCESS'))}
    fake.fail_tabs.clear();fake.reads.clear();fake.writes.clear()
    put(fake.documents['depo-document-12345'][DEPO_NAME],305,9,4321)
    assert logged.post(f'/api/runs/{run.id}/retry',json={'item_ids':[item.id]}).status_code==202
    process_run(db,run,fake)
    assert item.status=='SUCCESS' and fake.documents['destination-copy-12345']['TOTAL DEPO'].cell(2,1).value==4321
    assert all(db.get(RunItem,i).result==v for i,v in preserved.items())
    assert {t for d,t in fake.reads if d in ('depo-document-12345','qris-document-12345')}=={DEPO_NAME}
    assert {w.tab for w in fake.writes}=={'TOTAL DEPO'}


@pytest.mark.parametrize('action',['double_click','restart','cancel','atomic_claim'])
def test_durable_retry_queue_lifecycle(logged,db,monkeypatch,tmp_path,action):
    w,fake,run,item=failed_source(logged,db,monkeypatch,tmp_path)
    body={'item_ids':[item.id],'idempotency_key':str(uuid4())}
    assert logged.post(f'/api/runs/{run.id}/retry',json=body).status_code==202
    request=db.scalar(select(RetryRequest))
    if action=='double_click':
        assert logged.post(f'/api/runs/{run.id}/retry',json=body).status_code==202
        assert logged.post(f'/api/runs/{run.id}/retry',json={**body,'idempotency_key':str(uuid4())}).status_code==202
        assert len(list(db.scalars(select(RetryRequest))))==1
    elif action=='restart':
        from app.worker import recover_jobs
        recover_jobs(db);db.expire_all()
        assert db.get(RetryRequest,request.id).state=='QUEUED' and db.get(Run,run.id).status=='QUEUED'
    elif action=='cancel':
        assert logged.post(f'/api/runs/{run.id}/cancel').status_code==200
        assert request.state=='CANCELED';before=len(fake.writes);process_run(db,run,fake);assert len(fake.writes)==before;return
    else:
        from app.retry_queue import claim_next
        first=claim_next(db,run)
        with Session(db.get_bind()) as other:assert claim_next(other,other.get(Run,run.id)) is None
        assert first.id==request.id
        return
    fake.fail_tabs.clear();process_run(db,run,fake)
    assert request.state=='SUCCEEDED'


@pytest.mark.parametrize('mode',['url','rename_unproven','alias'])
def test_explicit_item_retry_uses_current_source_without_redirecting_other_items(logged,db,monkeypatch,tmp_path,mode):
    w,fake,run,item=failed_source(logged,db,monkeypatch,tmp_path)
    source=db.get(SourceDocument,item.source_document_id);old=deepcopy(run.config_snapshot['sources']);pinned=deepcopy(run.config_snapshot['destination'])
    original=fake.documents[source.spreadsheet_id];new_name='REKENING PENGGANTI'
    if mode in ('url','rename_unproven'):
        fake.documents['new-source-document-12345']=deepcopy(original)
        if mode=='rename_unproven':
            grid=fake.documents['new-source-document-12345'].pop(DEPO_NAME);grid.title=new_name;fake.documents['new-source-document-12345'][new_name]=grid
        response=logged.put(f"/api/websites/{w['id']}/sources",json={'year':2026,'month':10,'document_type':'DEPO','spreadsheet_url':'https://docs.google.com/spreadsheets/d/new-source-document-12345/edit'})
        assert response.status_code==200
        logged.post(f'/api/sources/{source.id}/validate');tabs=logged.get(f'/api/sources/{source.id}/tabs').json()
        logged.post(f'/api/sources/{source.id}/tabs',json={'ids':[t['id'] for t in tabs],'is_active':True})
    options=logged.get(f'/api/runs/{run.id}/items/{item.id}/retry-options').json()
    body={'item_ids':[item.id]}
    if mode=='rename_unproven':
        assert options['requires_selection'] and options['suggested'] is None
        assert logged.post(f'/api/runs/{run.id}/retry',json=body).status_code==409
        body['source_tab_name']=new_name
        # Explicit account alias is needed; no account guessing from the new name.
        logged.put(f"/api/websites/{w['id']}/aliases",json={'source_name':new_name,'destination_header':'IVAN RAKHMANDA'})
    fake.fail_tabs.clear()
    assert logged.post(f'/api/runs/{run.id}/retry',json=body).status_code==202
    process_run(db,run,fake)
    assert run.config_snapshot['sources']==old and run.config_snapshot['destination']==pinned
    assert item.status=='SUCCESS',logged.get(f'/api/runs/{run.id}').json()['errors']
    assert item_for(db,run,'balance').status=='FAILED'


@pytest.mark.parametrize('tab,source_name,row,fee_col',[
    ('Pengeluaran FEE QRIS DEPO','QRIS QRIZZ',85,7),('Pengeluaran FEE QRIS WD','QRIS E-POWER',86,7)])
@pytest.mark.parametrize('old',['blank','owned','manual','header_missing'])
def test_no_fee_is_noop_or_explicit_old_fee_conflict(logged,db,monkeypatch,tmp_path,tab,source_name,row,fee_col,old):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    if old=='owned':
        first=db.get(Run,start(logged,w)['id']);process_run(db,first,fake)
    source=fake.documents['qris-document-12345'][source_name];put(source,row,3,None);put(source,row,fee_col,None)
    dest=fake.documents['destination-copy-12345'][tab]
    if old=='manual':put(dest,2,1,'FEE LAMA');put(dest,2,2,1234)
    if old=='header_missing':put(dest,1,1,None);put(dest,1,2,None);fake.rebuild_mapping()
    fake.writes.clear();run=db.get(Run,start(logged,w)['id']);process_run(db,run,fake)
    selected=item_for(db,run,'qris_fee',source_name)
    if old in ('blank','header_missing'):
        assert selected.status=='SUCCESS' and not any(w.tab==tab for w in fake.writes)
    else:
        conflict=db.scalar(select(DestinationConflict).where(DestinationConflict.run_item_id==selected.id,DestinationConflict.state=='OPEN'))
        assert conflict and all(w['value'] is None for w in conflict.writes)
        assert decision(logged,conflict,'NEW').status_code==202
        process_run(db,run,fake)
        if old=='owned':assert conflict.state=='RESOLVED' and dest.cell(2,1).value is None and dest.cell(2,2).value is None
        else:assert conflict.state=='OPEN' and dest.cell(2,2).value==1234


@pytest.mark.parametrize('change',['amount','removed','description','row','note'])
@pytest.mark.parametrize('choice',['NEW','KEEP'])
def test_changed_transfers_correct_existing_group_without_appending(logged,db,monkeypatch,tmp_path,change,choice):
    w,fake=configured(logged,db,monkeypatch,tmp_path)
    original=db.get(Run,start(logged,w)['id']);process_run(db,original,fake)
    count=len(list(db.scalars(select(TransferOwnership))));target=fake.documents['destination-copy-12345']['KET PENGIRIMAN'];before=deepcopy(target)
    source=fake.documents['depo-document-12345'][DEPO_NAME]
    if change=='amount':put(source,291,8,999000)
    elif change=='removed':put(source,291,8,None);put(source,291,3,None)
    elif change=='description':source.rows[291][3].value='DARI KAS BCA BARU'
    elif change=='row':source.rows[294]=source.rows[291];source.rows[291]=[Cell() for _ in range(source.width)]
    else:
        source=fake.documents['qris-document-12345']['QRIS E-POWER'];source.rows[85][3].value='KIRIM KAS BRI BARU'
    fake.writes.clear();run=db.get(Run,start(logged,w)['id']);process_run(db,run,fake)
    conflict=db.scalar(select(DestinationConflict).where(DestinationConflict.run_id==run.id,DestinationConflict.reason=='TRANSFER_IDENTITY_CHANGED'))
    assert conflict and len(conflict.writes)>=2 and not any(w.tab=='KET PENGIRIMAN' for w in fake.writes)
    assert decision(logged,conflict,choice).status_code==202
    process_run(db,run,fake)
    assert conflict.state=='RESOLVED',logged.get(f'/api/runs/{run.id}').json()['errors']
    assert len(list(db.scalars(select(TransferOwnership))))==count
    if choice=='KEEP':assert target==before
    elif change=='removed':assert target.cell(3,0).value is None and target.cell(3,1).value is None
    elif change=='amount':assert target.cell(3,1).value==999000
    # Repeated same logical intent must not re-append or re-open a kept conflict.
    fake.writes.clear();again=db.get(Run,start(logged,w)['id']);process_run(db,again,fake)
    assert not list(db.scalars(select(DestinationConflict).where(DestinationConflict.run_id==again.id,DestinationConflict.state=='OPEN')))
    assert not any(w.tab=='KET PENGIRIMAN' for w in fake.writes)


@pytest.mark.parametrize('change',['header','date','fee_header','sheet_id','merge'])
def test_stale_destination_registry_blocks_and_never_remaps(logged,db,monkeypatch,tmp_path,change):
    w,fake=configured(logged,db,monkeypatch,tmp_path);run=db.get(Run,start(logged,w)['id'])
    count=len(list(db.scalars(select(DestinationMapping))));grid=fake.documents['destination-copy-12345']['TOTAL DEPO']
    if change=='header':put(grid,1,1,'PENGGANTI')
    elif change=='date':put(grid,2,0,'16-Oct-2026')
    elif change=='fee_header':grid=fake.documents['destination-copy-12345']['Pengeluaran FEE QRIS DEPO'];put(grid,1,1,'PENGGANTI')
    elif change=='sheet_id':grid.sheet_id+=100
    else:grid.merges.append({'startRowIndex':2,'endRowIndex':3,'startColumnIndex':1,'endColumnIndex':2})
    process_run(db,run,fake)
    assert run.status=='PARTIAL'
    assert any(e.error_code in ('DESTINATION_CHANGED','DESTINATION_READ_FAILED') for e in db.scalars(select(TaskError).where(TaskError.run_id==run.id)))
    assert len(list(db.scalars(select(DestinationMapping))))==count
    assert not any(w.tab==grid.title for w in fake.writes)


def test_mapping_revalidation_preserves_all_historical_ledgers(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);run=db.get(Run,start(logged,w)['id']);process_run(db,run,fake)
    old=[(l.id,l.owner_key,l.written_value) for l in db.scalars(select(WriteLedger))];map_id=run.config_snapshot['mapping_id'];fake.rebuild_mapping()
    assert [(l.id,l.owner_key,l.written_value) for l in db.scalars(select(WriteLedger))]==old
    assert db.get(DestinationMapping,map_id).state=='READY'
    assert logged.post(f'/api/runs/{run.id}/retry',json={}).status_code==409


def test_attempt_telemetry_is_bounded_and_separates_stages(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);run=db.get(Run,start(logged,w)['id']);process_run(db,run,fake)
    metrics=run.config_snapshot['performance_attempts'][-1]
    assert metrics['duration_ms']>0 and metrics['peak_rss_mb']>0
    assert all(metrics['stages_ms'][k]>=0 for k in ('source_reading','warm_mapping_lookup','destination_validation','actual_write','readback_verification','reconciliation'))
    assert metrics['api_reads']==0  # Fake high-level API is not misreported as real Google calls.
    assert db.scalar(select(AuditLog.id).where(AuditLog.action=='run_performance_measured'))


@pytest.mark.parametrize('kind',['DEPO','WD'])
@pytest.mark.parametrize('layout',['below_first_rows','merged','neighbor','ambiguous'])
def test_fee_headers_are_scoped_and_merged_origin_is_unique(kind,layout):
    from helpers import blank
    from app.engine.resolver import fees
    grid=blank('Pengeluaran FEE QRIS '+kind,10,10)
    put(grid,0,0,'VELBETT');put(grid,0,6,'FANTASI');put(grid,7,0,'15-Oct-2026');put(grid,7,6,'15-Oct-2026')
    put(grid,4,1,'KETERANGAN');put(grid,4,3,'FEE QRIS '+kind);put(grid,4,4,'TOTAL')
    put(grid,4,7,'KETERANGAN');put(grid,4,8,'FEE QRIS '+kind)
    if layout=='merged':grid.merges.append({'startRowIndex':4,'endRowIndex':5,'startColumnIndex':1,'endColumnIndex':3})
    if layout=='neighbor':put(grid,4,1,None)
    if layout=='ambiguous':put(grid,5,2,'KETERANGAN')
    if layout in ('neighbor','ambiguous'):
        with pytest.raises(Issue):fees(grid,'VELBETT',['VELBETT','FANTASI'],DAY,'FEE QRIS '+kind,'fee',123)
    else:
        writes=fees(grid,'VELBETT',['VELBETT','FANTASI'],DAY,'FEE QRIS '+kind,'fee',123)
        assert [(w.address,w.value) for w in writes]==[('B8','fee'),('D8',123)]


def test_successful_expense_total_requires_explicit_dependency_retry(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);run=db.get(Run,start(logged,w)['id']);process_run(db,run,fake)
    selected=item_for(db,run,'expense_input');total=db.scalar(select(RunItem).where(RunItem.run_id==run.id,RunItem.metric_type=='expense_total'))
    old=deepcopy(total.result);selected.status='FAILED';run.status='PARTIAL';db.commit()
    put(fake.documents['depo-document-12345'][DEPO_NAME],305,7,-8500);fake.writes.clear()
    assert logged.post(f'/api/runs/{run.id}/retry',json={'item_ids':[selected.id]}).status_code==202
    process_run(db,run,fake)
    assert total.status=='SUCCESS' and total.result==old and not fake.writes
    assert db.scalar(select(TaskError.id).where(TaskError.run_item_id==total.id,TaskError.error_code=='DEPENDENCY_STALE',TaskError.is_resolved==False))
    assert not logged.get(f'/api/runs/{run.id}').json()['date_status']['eligible']
    assert logged.post(f'/api/runs/{run.id}/retry',json={'item_ids':[total.id]}).status_code==202
    process_run(db,run,fake)
    conflict=db.scalar(select(DestinationConflict).where(DestinationConflict.run_item_id==total.id,DestinationConflict.state=='OPEN'))
    assert conflict and conflict.writes[0]['value']==7500 and not fake.writes
    assert decision(logged,conflict,'NEW').status_code==202;process_run(db,run,fake)
    assert fake.documents['destination-copy-12345']['BIAYA'].cell(2,1).value==7500


@pytest.mark.parametrize('tab',['TOTAL DEPO','Pengeluaran FEE QRIS DEPO','KET PENGIRIMAN'])
def test_worker_death_after_accepted_write_recovers_exact_intent_without_repost(logged,db,monkeypatch,tmp_path,tab):
    from app.worker import recover_jobs
    w,fake=configured(logged,db,monkeypatch,tmp_path);run=db.get(Run,start(logged,w)['id']);original=fake.write
    def crash(id,grid,writes):
        original(id,grid,writes)
        if grid.title==tab:raise SystemExit('worker terminated after accepted POST')
    fake.write=crash
    with pytest.raises(SystemExit):process_run(db,run,fake)
    pending=list(db.scalars(select(WriteLedger).where(WriteLedger.verification_status=='PREPARED')))
    assert pending and {l.destination_tab for l in pending}=={tab}
    recover_jobs(db);db.refresh(run);assert run.status in ('FAILED','PARTIAL')
    fake.write=original;fake.writes.clear()
    assert logged.post(f'/api/runs/{run.id}/retry',json={}).status_code==202
    process_run(db,run,fake)
    assert run.status=='SUCCESS',logged.get(f'/api/runs/{run.id}').json()['errors']
    assert not any((w.tab,w.address) in {(l.destination_tab,l.target_range) for l in pending} for w in fake.writes)
    assert all(l.verification_status=='VERIFIED' for l in pending)


def test_restored_transfer_reuses_retired_slot_and_requires_decision(logged,db,monkeypatch,tmp_path):
    w,fake=configured(logged,db,monkeypatch,tmp_path);first=db.get(Run,start(logged,w)['id']);process_run(db,first,fake)
    src=fake.documents['depo-document-12345'][DEPO_NAME];original=deepcopy(src.rows[291]);src.rows[291]=[Cell() for _ in original]
    removed=db.get(Run,start(logged,w)['id']);process_run(db,removed,fake)
    conflict=db.scalar(select(DestinationConflict).where(DestinationConflict.run_id==removed.id,DestinationConflict.state=='OPEN'))
    assert decision(logged,conflict,'NEW').status_code==202;process_run(db,removed,fake)
    assert db.scalar(select(TransferLineage).where(TransferLineage.state=='RETIRED'))
    src.rows[291]=original;fake.writes.clear();restored=db.get(Run,start(logged,w)['id']);process_run(db,restored,fake)
    conflict=db.scalar(select(DestinationConflict).where(DestinationConflict.run_id==restored.id,DestinationConflict.state=='OPEN'))
    assert conflict and conflict.writes[0]['row']==3
    assert decision(logged,conflict,'NEW').status_code==202;process_run(db,restored,fake)
    assert restored.status=='SUCCESS' and len(list(db.scalars(select(TransferOwnership))))==3


def test_prepared_recovery_never_accepts_changed_global_formula(logged,db,monkeypatch,tmp_path):
    from app.worker import recover_jobs
    w,fake=configured(logged,db,monkeypatch,tmp_path);run=db.get(Run,start(logged,w)['id']);original=fake.write
    def crash(id,grid,writes):original(id,grid,writes);raise SystemExit('accepted before readback')
    fake.write=crash
    with pytest.raises(SystemExit):process_run(db,run,fake)
    ledger=db.scalar(select(WriteLedger).where(WriteLedger.verification_status=='PREPARED'));recover_jobs(db)
    put(fake.documents['destination-copy-12345'][ledger.destination_tab],2,4,99,formula='=99')
    fake.write=original;fake.writes.clear()
    assert logged.post(f'/api/runs/{run.id}/retry',json={'item_ids':[ledger.run_item_id]}).status_code==202
    process_run(db,run,fake)
    assert ledger.verification_status=='PREPARED' and not fake.writes
    assert db.scalar(select(TaskError.id).where(TaskError.run_item_id==ledger.run_item_id,TaskError.error_code=='FORMULA_CHANGED',TaskError.is_resolved==False))


def test_unknown_legacy_transfer_identity_requires_explicit_proof_without_duplicate(logged,db,monkeypatch,tmp_path):
    from sqlalchemy import delete
    from app.models import LegacySourceLink
    w,fake=configured(logged,db,monkeypatch,tmp_path);first=db.get(Run,start(logged,w)['id']);process_run(db,first,fake)
    old_item=item_for(db,first,'transfers');doc=next(d for d in first.config_snapshot['sources'] if d['type']=='DEPO');identity=doc['identities'][DEPO_NAME]
    snapshot=deepcopy(first.config_snapshot)
    next(d for d in snapshot['sources'] if d['type']=='DEPO').pop('identities')
    first.config_snapshot=snapshot
    for owned in db.scalars(select(TransferOwnership).where(TransferOwnership.run_item_id==old_item.id)):
        db.execute(delete(TransferLineage).where(TransferLineage.ownership_id==owned.id))
    db.commit();fake.writes.clear()
    run=db.get(Run,start(logged,w)['id']);process_run(db,run,fake);item=item_for(db,run,'transfers')
    assert item.status=='FAILED' and db.scalar(select(TaskError.id).where(TaskError.run_item_id==item.id,TaskError.error_code=='LEGACY_LINEAGE_UNVERIFIED'))
    request=logged.post(f"/api/source-identities/{identity['id']}/confirm-legacy",json={'prior_run_item_id':old_item.id,'reviewed_history_and_google_identity':True})
    assert request.status_code==200,request.text
    assert db.get(LegacySourceLink,old_item.id).confirmed_by==1
    assert logged.post(f'/api/runs/{run.id}/retry',json={'item_ids':[item.id]}).status_code==202
    process_run(db,run,fake)
    assert item.status=='SUCCESS' and not any(w.tab=='KET PENGIRIMAN' for w in fake.writes)
    assert len(list(db.scalars(select(TransferOwnership))))==3


def test_api_process_restart_preserves_retry_queue_and_authenticated_session(logged,db,monkeypatch,tmp_path):
    import os,socket,subprocess,sys,time
    from pathlib import Path
    import requests
    w,fake,run,item=failed_source(logged,db,monkeypatch,tmp_path)
    assert logged.post(f'/api/runs/{run.id}/retry',json={'item_ids':[item.id]}).status_code==202
    retry_id=db.scalar(select(RetryRequest.id));db.commit()
    with socket.socket() as listener:listener.bind(('127.0.0.1',0));port=listener.getsockname()[1]
    base=f'http://127.0.0.1:{port}'
    env={**os.environ,'TK_DATABASE_URL':str(db.get_bind().url),'TK_COOKIE_SECURE':'false','TK_APP_ORIGIN':base,'TK_WORKER_LOCK':str(tmp_path/'worker.lock'),'TK_CREDENTIAL_FILE':str(tmp_path/'no-key.json')}
    session=requests.Session()
    for generation in range(2):
        proc=subprocess.Popen([sys.executable,'-m','uvicorn','app.main:app','--host','127.0.0.1','--port',str(port)],cwd=Path(__file__).parents[1],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        try:
            deadline=time.monotonic()+8
            while True:
                try:
                    response=session.get(base+'/api/auth/csrf',timeout=1)
                    if response.status_code==200:break
                except requests.RequestException:pass
                assert proc.poll() is None and time.monotonic()<deadline
                time.sleep(.05)
            if generation==0:
                response=session.post(base+'/api/auth/login',json={'username':'finance','password':'test-only-password-123'},headers={'x-csrf-token':response.json()['csrf_token']},timeout=3)
                assert response.status_code==200
            detail=session.get(base+f'/api/runs/{run.id}',timeout=3)
            assert detail.status_code==200,detail.text
            assert detail.json()['status']=='QUEUED'
            assert detail.json()['retry_requests'][0]['id']==retry_id and detail.json()['retry_requests'][0]['state']=='QUEUED'
        finally:
            proc.terminate();proc.wait(timeout=5)
