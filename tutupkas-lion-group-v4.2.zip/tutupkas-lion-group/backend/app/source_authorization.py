"""An explicit item retry authorizes current raw source, never unrelated items."""
from copy import deepcopy

from fastapi import HTTPException
from sqlalchemy import select

from .models import RunItem


def document_for(run,item):
    authorization=run.config_snapshot.get('item_source_authorizations',{}).get(str(item.id))
    if authorization:
        doc=deepcopy(authorization['document'])
        chosen=authorization['tab']
        if chosen in doc.get('identities',{}):doc['identities'][item.source_tab_name]=doc['identities'][chosen]
        doc['actual_tab_override']=chosen
        return doc
    return next((d for d in run.config_snapshot.get('sources',[]) if d['id']==item.source_document_id),None)


def alias_for(run,item,doc):
    authorization=run.config_snapshot.get('item_source_authorizations',{}).get(str(item.id))
    if authorization:return authorization.get('alias','')
    canonical=doc.get('identities',{}).get(item.source_tab_name,{}).get('names',[item.source_tab_name])[0]
    return run.config_snapshot['aliases'].get(item.source_tab_name,run.config_snapshot['aliases'].get(canonical,''))


def authorize_retry_source(db,run,item,requested_tab=None):
    if item.source_document_id is None:return None
    from .workflow import source_configuration
    docs,aliases=source_configuration(db,run.website_id,run.selected_date)
    doc=next((d for d in docs if d['id']==item.source_document_id),None)
    if not doc or doc['validation_status']!='VALID':
        raise HTTPException(409,'Dokumen sumber item belum divalidasi pada konfigurasi saat ini.')
    prior=document_for(run,item)
    old_identity=prior.get('identities',{}).get(item.source_tab_name,{}) if prior else {}
    if requested_tab is not None:
        if requested_tab not in doc['tabs']:raise HTTPException(409,'Sheet pilihan tidak aktif atau tidak tersedia.')
        chosen=requested_tab
    elif item.source_tab_name in doc['tabs']:
        chosen=item.source_tab_name
    else:
        proven=[tab for tab in doc['tabs'] if doc.get('identities',{}).get(tab,{}).get('lineage')==old_identity.get('lineage') and old_identity.get('lineage')]
        if len(proven)!=1:
            raise HTTPException(409,'Nama/identitas sheet berubah tanpa bukti kontinuitas. Pilih sheet sumber aktif secara eksplisit pada retry item.')
        chosen=proven[0]
    identity=doc.get('identities',{}).get(chosen)
    if not identity:raise HTTPException(409,'Identitas sheet sumber belum diverifikasi. Refresh dan validasi sumber.')
    canonical=identity.get('names',[chosen])[0]
    return {'document':{**doc,'tabs':[chosen]},'tab':chosen,'alias':aliases.get(chosen,aliases.get(canonical,'')),
            'prior_revision':prior.get('revision') if prior else None,'explicit_item_authorization':True}


def refresh_context_signature(db,run):
    """Only a wholly consistent authorized source context can prove currentness."""
    from .workflow import source_signature
    snapshot=dict(run.config_snapshot)
    effective=[];aliases=dict(snapshot['aliases'])
    all_items=list(db.scalars(select(RunItem).where(RunItem.run_id==run.id,RunItem.source_document_id!=None)))
    consistent=True
    for prior in snapshot['sources']:
        groups={tab:[i for i in all_items if i.source_document_id==prior['id'] and i.source_tab_name==tab] for tab in prior['tabs']}
        doc_context=None;tabs=[]
        for old_tab,items in groups.items():
            contexts=[]
            for item in items:
                doc=document_for(run,item)
                chosen=doc.get('actual_tab_override',old_tab)
                contexts.append((doc['revision'],doc['spreadsheet_id'],chosen,alias_for(run,item,doc)))
            if not contexts or len(set(contexts))!=1:consistent=False;break
            if doc_context is not None and (doc_context['revision'],doc_context['spreadsheet_id'])!=contexts[0][:2]:
                consistent=False;break
            item=items[0];doc_context=document_for(run,item);chosen=contexts[0][2];tabs.append(chosen)
            if contexts[0][3]:aliases[chosen]=contexts[0][3]
            elif old_tab in aliases:aliases.pop(old_tab)
        if not consistent:break
        effective.append({**(doc_context or prior),'tabs':tabs})
    if consistent:snapshot['effective_source_context_signature']=source_signature(effective,aliases)
    else:snapshot.pop('effective_source_context_signature',None)
    run.config_snapshot=snapshot


def authorized_source_is_current(db,run,item):
    from .workflow import source_configuration
    docs,_=source_configuration(db,run.website_id,run.selected_date)
    expected=document_for(run,item)
    current=next((d for d in docs if expected and d['id']==expected['id']),None)
    if not current or (current['revision'],current['spreadsheet_id'])!=(expected['revision'],expected['spreadsheet_id']):return False
    chosen=expected.get('actual_tab_override',item.source_tab_name)
    return chosen in current['tabs'] and current.get('identities',{}).get(chosen,{}).get('lineage')==expected.get('identities',{}).get(chosen,{}).get('lineage')
