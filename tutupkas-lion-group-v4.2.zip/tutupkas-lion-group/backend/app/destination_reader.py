"""Bounded destination snapshots: structural index on private temporary disk.

Only mapping predicates are indexed, never the complete cell payload. Ordinary
target values/Notes are read explicitly. Global V4 structure and formula checks
still visit the entire sheet in bounded bands, without keeping those bands.
"""
from collections import OrderedDict
from dataclasses import dataclass
import hashlib
import json
import logging
import os
import re
import sqlite3
import tempfile
import time
import weakref

from .config import settings
from .diagnostics import memory
from .engine.parser import parse_date
from .engine.report import CONSOLIDATED, compact, report_date
from .engine.types import Cell, Issue, norm
from .sheets import google_cell

logger = logging.getLogger('tutupkas.worker')
FIELDS = 'userEnteredValue,effectiveValue,note,effectiveFormat(backgroundColor,backgroundColorStyle,numberFormat(type)),formattedValue'


def encode(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=False,default=str)


@dataclass(frozen=True)
class FormulaSignature:
    digest: str
    count: int

    def __len__(self):
        return self.count


def formula_signature(cells):
    """Row/column ordered stream; equivalent to equality of V4 formula maps."""
    digest,count = hashlib.sha256(),0
    for r,c,cell in cells:
        if cell.formula is not None:
            digest.update(encode([r,c,cell.formula]).encode());digest.update(b'\n')
            count += 1
    return FormulaSignature(digest.hexdigest(),count)


def read_destination(client, document, title, registered=()):
    # Legacy in-memory test transports expose grid(); production always exposes
    # destination_grid(), whose grid implementation is the bounded reader.
    method = getattr(client,'destination_grid',None)
    return method(document,title,registered) if method else client.grid(document,title)


def close_view(view):
    method = getattr(view,'close',None)
    if method:
        method()


class MergeIndex:
    def __init__(self,db):
        self.db = db

    def __iter__(self):
        for (raw,) in self.db.execute('SELECT payload FROM merges ORDER BY seq'):
            yield json.loads(raw)

    def __len__(self):
        return self.db.execute('SELECT count(*) FROM merges').fetchone()[0]

    def __eq__(self,other):
        return len(self)==len(other) and all(a==b for a,b in zip(self,other))

    def at(self,row,col):
        record = self.db.execute('SELECT payload FROM merges WHERE top<=? AND bottom>? AND left_col<=? AND right_col>? ORDER BY seq LIMIT 1',
                                 (row,row,col,col)).fetchone()
        return json.loads(record[0]) if record else None


def _dispose(db, folder):
    db.close()
    folder.cleanup()


class DestinationReader:
    def __init__(self,client,document,title,registered=()):
        self.client,self.document,self.title = client,document,title
        self.registered = tuple(registered)
        self.names = {norm(v) for v in registered}
        self.compact_names = {compact(v) for v in registered}
        self.cache = OrderedDict()
        self.cache_bytes = 0
        self.height,self.width = 0,0
        folder = tempfile.TemporaryDirectory(prefix='tutupkas-destination-')
        index_path = folder.name+'/structure.sqlite3'
        self.db = sqlite3.connect(index_path,check_same_thread=False)
        os.chmod(index_path,0o600)
        self._cleanup = weakref.finalize(self,_dispose,self.db,folder)
        self.db.executescript('''
            PRAGMA cache_size=-512; PRAGMA temp_store=FILE; PRAGMA mmap_size=0;
            PRAGMA journal_mode=OFF; PRAGMA synchronous=OFF;
            CREATE TABLE cells(r INTEGER,c INTEGER,payload TEXT,structural INTEGER,PRIMARY KEY(r,c));
            CREATE INDEX cells_columns ON cells(c,r);
            CREATE TABLE extents(r INTEGER PRIMARY KEY,n INTEGER);
            CREATE TABLE formulas(r INTEGER,c INTEGER,value TEXT,PRIMARY KEY(r,c));
            CREATE TABLE merges(seq INTEGER PRIMARY KEY,top INTEGER,bottom INTEGER,left_col INTEGER,right_col INTEGER,payload TEXT);
            CREATE INDEX merge_positions ON merges(top,left_col);
        ''')
        try:
            p = client.sheet_properties(document,title)
            self.sheet_id = p['sheetId']
            self.allocated_height = p.get('gridProperties',{}).get('rowCount',0)
            self.allocated_width = p.get('gridProperties',{}).get('columnCount',0)
            self._merges()
            self.merges = MergeIndex(self.db)
            self._scan()
        except BaseException:
            self.close()
            raise

    def close(self):
        self.cache.clear()
        self.cache_bytes = 0
        self._cleanup()

    def refresh(self):
        return self.client.destination_grid(self.document,self.title,self.registered)

    def _sheets(self,raw):
        matches = [s for s in raw.get('sheets',[]) if s.get('properties',{}).get('sheetId')==self.sheet_id]
        if len(matches)!=1:
            raise Issue('DESTINATION_READ_FAILED','Identitas sheet pada respons tujuan tidak sesuai metadata.')
        return matches

    def _merges(self):
        # Sheets cannot paginate merges; range filters are NOT assumed to scope
        # merges. Request only merge coordinates, bound the decoded HTTP bytes,
        # select the exact current sheet ID and spill the result to the index.
        a1 = self.client.a1(self.title,0,0,0,0)
        try:
            raw = self.client.request('GET',self.document,params={'ranges':[a1],
                'fields':'sheets(properties(sheetId),merges(sheetId,startRowIndex,endRowIndex,startColumnIndex,endColumnIndex))'})
        except Issue as error:
            if error.code=='RESPONSE_TOO_LARGE':
                raise Issue('MERGE_METADATA_LIMIT','Metadata merge melampaui batas respons aman; penulisan dihentikan.',
                            'Simpan diagnostik untuk pemeriksaan; tidak ada asumsi merge kosong atau perubahan spreadsheet.')
            raise
        for sheet in self._sheets(raw):
            for seq,m in enumerate(sheet.get('merges',[])):
                if not all(k in m for k in ('startRowIndex','endRowIndex','startColumnIndex','endColumnIndex')):
                    raise Issue('MERGE_METADATA_INVALID','Koordinat merged range tidak lengkap.')
                top,bottom,left,right = (m[k] for k in ('startRowIndex','endRowIndex','startColumnIndex','endColumnIndex'))
                if (any(not isinstance(v,int) or isinstance(v,bool) for v in (top,bottom,left,right)) or
                    not 0<=top<bottom<=self.allocated_height or not 0<=left<right<=self.allocated_width or
                    'sheetId' in m and m['sheetId']!=self.sheet_id):
                    raise Issue('MERGE_METADATA_INVALID','Koordinat merge tidak sesuai sheet aktual.')
                self.db.execute('INSERT INTO merges VALUES(?,?,?,?,?,?)',(seq,top,bottom,left,right,encode(m)))
        del raw

    def _ranges(self,ranges):
        raw = self.client.request('GET',self.document,params={'ranges':ranges,'includeGridData':'true',
            'fields':'sheets(properties(sheetId),data(startRow,startColumn,rowData(values('+FIELDS+'))))'})
        try:
            for sheet in self._sheets(raw):
                yield from sheet.get('data',[])
        finally:
            del raw

    @staticmethod
    def _payload(cell):
        return encode([cell.value,cell.formula,cell.note,cell.color,cell.date_format])

    @staticmethod
    def _cell(raw):
        value,formula,note,color,formatted = json.loads(raw)
        return Cell(value,formula,note,tuple(color) if color is not None else None,formatted)

    def _index_limit(self):
        size = self.db.execute('PRAGMA page_count').fetchone()[0]*self.db.execute('PRAGMA page_size').fetchone()[0]
        if size > settings().destination_index_bytes:
            raise Issue('DESTINATION_STRUCTURE_LIMIT','Struktur aktual tujuan melebihi batas indeks sementara aman.',
                        'Simpan diagnostik untuk pemeriksaan struktur; transaksi dan proteksi tidak dilewati.')

    def _header_entry(self,r,c,value):
        # Discovery checks only predicates used by website/header matching;
        # unrelated financial values in rows 2..11 are not a new global guard.
        if value in (None,'') or not (r<2 or norm(value) in self.names):
            return None
        # Values and CellData APIs may serialize the same double as 1 or 1.0.
        if isinstance(value,(int,float)) and not isinstance(value,bool):
            value = float(value)
        return encode([c,value]).encode()+b'\n'

    def _groups(self,tiles):
        group,total = [],0
        for tile in tiles:
            top,bottom,left,right,_ = tile
            size = (bottom-top+1)*(right-left+1)
            if group and (total+size>settings().destination_batch_cells or len(group)>=32):
                yield group
                group,total = [],0
            group.append(tile);total += size
        if group:
            yield group

    def _responses(self,group,values=False):
        # Keep original V4 tile boundaries. Grouping ranges reduces HTTP calls
        # without changing per-range extents or assuming that merges are scoped.
        pending = [group]
        while pending:
            batch = pending.pop()
            try:
                if values:
                    bands = self.client.values(self.document,[t[4] for t in batch])
                    if len(bands)!=len(batch):
                        raise Issue('DESTINATION_READ_FAILED','Rentang discovery header tidak lengkap.')
                    pairs = list(zip(batch,bands))
                else:
                    bands = list(self._ranges([t[4] for t in batch]))
                    pairs = []
                    for band in bands:
                        r,c = band.get('startRow',0),band.get('startColumn',0)
                        matches = [(i,t) for i,t in enumerate(batch) if t[0]<=r<=t[1] and t[2]<=c<=t[3]]
                        if len(matches)!=1:
                            raise Issue('DESTINATION_READ_FAILED','GridData tidak sesuai rentang tujuan yang diminta.')
                        i,tile = matches[0]
                        pairs.append((i,tile,band))
                    pairs = [(tile,band) for _,tile,band in sorted(pairs,key=lambda p:p[0])]
            except Issue as error:
                if error.code!='RESPONSE_TOO_LARGE' or len(batch)==1:
                    raise
                middle = len(batch)//2
                pending.extend([batch[middle:],batch[:middle]])
                continue
            yield from pairs
            pairs.clear();bands.clear()
            band = None

    def _header_values(self):
        digests = [hashlib.sha256() for _ in range(min(12,self.allocated_height))]
        budget = min(settings().grid_chunk_cells,settings().destination_batch_cells)
        row_step = min(12,max(1,budget))
        col_step = min(64,max(1,budget//row_step))
        def tiles():
            for c in range(0,self.allocated_width,col_step):
                last = min(self.allocated_width,c+col_step)-1
                for first in range(0,len(digests),row_step):
                    stop = min(len(digests),first+row_step)
                    yield first,stop-1,c,last,self.client.a1(self.title,first,stop-1,c,last)
        for group in self._groups(tiles()):
            for (first,last_row,c,last,_),band in self._responses(group,values=True):
                for offset,row in enumerate(band.get('values',[])):
                    r = first+offset
                    if r>last_row or len(row)>last-c+1:
                        raise Issue('DESTINATION_READ_FAILED','Rentang discovery header melampaui permintaan.')
                    for dc,value in enumerate(row):
                        entry = self._header_entry(r,c+dc,value)
                        if entry is not None:
                            digests[r].update(entry)
        return [d.hexdigest() for d in digests]

    def _scan(self):
        started = time.monotonic()
        header_before = self._header_values()
        header_after = [hashlib.sha256() for _ in header_before]
        cfg = settings()
        band_width = min(64,max(1,cfg.grid_chunk_cells))
        # Preserve V4 band and row extents, including formatted blank headers.
        def tiles():
            for c in range(0,self.allocated_width,band_width):
                last_col = min(self.allocated_width,c+band_width)-1
                step = max(1,min(cfg.source_chunk_rows,cfg.grid_chunk_cells//(last_col-c+1)))
                for r in range(0,self.allocated_height,step):
                    last_row = min(self.allocated_height,r+step)-1
                    yield r,last_row,c,last_col,self.client.a1(self.title,r,last_row,c,last_col)
        for group in self._groups(tiles()):
            for (r,last_row,c,last_col,_),band in self._responses(group):
                top,left = band.get('startRow',0),band.get('startColumn',0)
                for dr,row in enumerate(band.get('rowData',[])):
                    rr = top+dr
                    values = row.get('values',[])
                    if not r<=rr<=last_row or not c<=left<=last_col or left+len(values)>last_col+1:
                        raise Issue('DESTINATION_READ_FAILED','Data tujuan melampaui rentang yang diminta.')
                    self.height = max(self.height,rr+1)
                    self.width = max(self.width,left+len(values))
                    self.db.execute('INSERT INTO extents VALUES(?,?) ON CONFLICT(r) DO UPDATE SET n=max(n,excluded.n)',(rr,left+len(values)))
                    for dc,value in enumerate(values):
                        # Formatting-only allocated blanks affect V4 row
                        # extents, already recorded above, but no predicate.
                        if not value.get('effectiveValue') and not value.get('userEnteredValue') and not value.get('note'):
                            continue
                        cc,cell = left+dc,google_cell(value)
                        label = norm(cell.value)
                        normal_date = parse_date(cell)
                        structural = rr<2 or normal_date is not None or label in ('BCA','MANDIRI','BRI','BNI','TOTAL')
                        day_candidate = rr<4 and (isinstance(cell.value,(int,float)) and not isinstance(cell.value,bool)
                            and 1<=cell.value<=31 and cell.value==int(cell.value) or
                            isinstance(cell.value,str) and re.fullmatch(r'(?:[1-9]|[12][0-9]|3[01])',cell.value.strip()) is not None)
                        keep = (rr<2 and (cell.value is not None or cell.formula is not None or bool(cell.note)) or day_candidate or
                                normal_date is not None or report_date(cell) is not None or
                                label in self.names or compact(cell.value) in self.compact_names or
                                label in CONSOLIDATED or label in ('BCA','MANDIRI','BRI','BNI','TOTAL') or
                                self.title in ('Pengeluaran FEE QRIS DEPO','Pengeluaran FEE QRIS WD') and label in ('FEE QRIS DEPO','FEE QRIS WD') or
                                self.title.casefold()=='laporan deposit harian' and re.fullmatch(r'[A-Z0-9]',label) is not None)
                        if keep:
                            self.db.execute('INSERT INTO cells VALUES(?,?,?,?)',(rr,cc,self._payload(cell),int(structural)))
                        if cell.formula is not None:
                            self.db.execute('INSERT INTO formulas VALUES(?,?,?)',(rr,cc,cell.formula))
                        if rr<len(header_after):
                            entry = self._header_entry(rr,cc,cell.value)
                            if entry is not None:
                                header_after[rr].update(entry)
                # Neither the raw band nor ordinary values/Notes are kept.
                self._index_limit()
        if header_before != [d.hexdigest() for d in header_after]:
            raise Issue('DESTINATION_CHANGED','Header tujuan berubah selama discovery. Ulangi pratinjau.')
        self.db.commit()
        self.structural_signature = self._structural()
        self.formula_signature = formula_signature((r,c,Cell(formula=f)) for r,c,f in self.db.execute('SELECT r,c,value FROM formulas ORDER BY r,c'))
        # Formula text is no longer needed after the signature; do not retain a
        # whole formula map across items. Index page cache stays 512 KiB.
        self.db.execute('DROP TABLE formulas');self.db.commit()
        logger.info(json.dumps({'event':'destination_scan','destination_tab':self.title,
            **getattr(self.client,'diagnostic_context',{}),'duration_ms':round((time.monotonic()-started)*1000),
            'indexed_cells':self.db.execute('SELECT count(*) FROM cells').fetchone()[0],**memory()}))

    def iter_cells(self,top=0,bottom=None,left=0,right=None):
        # Explicit structural iteration: consumers filter only predicates that
        # are indexed above. Ordinary financial payload is never inferred blank.
        bottom = self.height if bottom is None else bottom
        right = self.width if right is None else right
        for r,c,raw in self.db.execute('SELECT r,c,payload FROM cells WHERE r>=? AND r<? AND c>=? AND c<? ORDER BY r,c',
                                     (top,bottom,left,right)):
            yield r,c,self._cell(raw)

    def _structural(self):
        # Byte-identical to V4 fingerprint([labels,merges]), generated as a JSON
        # stream instead of building the complete labels list in RAM.
        digest,first = hashlib.sha256(b'[['),True
        def emit(label):
            nonlocal first
            if not first:digest.update(b', ')
            digest.update(encode(label).encode());first=False
        for r in range(min(2,self.height)):
            record = self.db.execute('SELECT n FROM extents WHERE r=?',(r,)).fetchone()
            n = record[0] if record else 0
            cells = iter(self.iter_cells(r,r+1))
            current = next(cells,None)
            for c in range(n):
                cell = current[2] if current is not None and current[1]==c else Cell()
                emit([r,c,cell.value,cell.formula])
                if current is not None and current[1]==c:current=next(cells,None)
        for r,c,raw in self.db.execute('SELECT r,c,payload FROM cells WHERE r>=2 AND structural=1 ORDER BY r,c'):
            cell = self._cell(raw);emit([r,c,cell.value,cell.formula])
        digest.update(b'], [')
        for i,merge in enumerate(self.merges):
            if i:digest.update(b', ')
            digest.update(encode(merge).encode())
        digest.update(b']]')
        return digest.hexdigest()

    def read_cells(self,positions):
        result = {}
        step = min(32,settings().grid_chunk_cells)
        for first in range(0,len(positions),step):
            chunk = positions[first:first+step]
            allowed = set(chunk)
            if any(not 0<=r<self.allocated_height or not 0<=c<self.allocated_width for r,c in chunk):
                raise Issue('DESTINATION_RANGE_INVALID','Koordinat sel tujuan berada di luar sheet aktual.')
            # Defaults are justified by explicit single-cell GETs, including
            # omitted empty CellData, never by absence from the structure index.
            found = {pos:Cell() for pos in chunk}
            ranges = [self.client.a1(self.title,r,r,c,c) for r,c in chunk]
            tiles=[(r,r,c,c,a1) for (r,c),a1 in zip(chunk,ranges)]
            for _,band in self._responses(tiles):
                r,c = band.get('startRow',0),band.get('startColumn',0)
                for dr,row in enumerate(band.get('rowData',[])):
                    for dc,value in enumerate(row.get('values',[])):
                        if (r+dr,c+dc) not in allowed:
                            raise Issue('DESTINATION_READ_FAILED','Pembacaan sel tujuan melampaui permintaan.')
                        found[r+dr,c+dc] = google_cell(value)
            result.update(found)
        return result

    def prefetch(self,positions):
        positions = list(dict.fromkeys(positions))
        for first in range(0,len(positions),32):
            for pos,cell in self.read_cells(positions[first:first+32]).items():
                self._remember(pos,cell)

    @staticmethod
    def _size(cell):
        return 512+4*sum(len(v) for v in (cell.value,cell.formula,cell.note) if isinstance(v,str))

    def _remember(self,pos,cell):
        if pos in self.cache:
            self.cache_bytes -= self._size(self.cache.pop(pos))
        size = self._size(cell)
        if size>4*1048576:
            return  # A large actual cell can be checked without retaining it.
        self.cache[pos] = cell
        self.cache_bytes += size
        while len(self.cache)>128 or self.cache_bytes>4*1048576:
            _,old = self.cache.popitem(last=False)
            self.cache_bytes -= self._size(old)

    def cell(self,row,col):
        pos = row,col
        if row<0 or col<0:
            return Cell()
        if pos not in self.cache:
            cell = self.read_cells([pos])[pos]
            self._remember(pos,cell)
            return cell
        self.cache.move_to_end(pos)
        return self.cache[pos]

    def inherited(self,row,col):
        merge = self.merges.at(row,col)
        if merge:
            row,col = merge['startRowIndex'],merge['startColumnIndex']
        # The scan explicitly covered all header cells. Missing header entries
        # are known empty, not unrequested target cells.
        if row in (0,1):
            record = self.db.execute('SELECT payload FROM cells WHERE r=? AND c=?',(row,col)).fetchone()
            return self._cell(record[0]) if record else Cell()
        return self.cell(row,col)

    def marker_letter(self,row,col):
        # This predicate was exhaustively indexed for report discovery. Its
        # absence proves "not one letter", never that a financial cell is empty.
        record=self.db.execute('SELECT payload FROM cells WHERE r=? AND c=?',(row,col)).fetchone()
        value=norm(self._cell(record[0]).value) if record else ''
        return value if re.fullmatch(r'[A-Z0-9]',value) else ''
