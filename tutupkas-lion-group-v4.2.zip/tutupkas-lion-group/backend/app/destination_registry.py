from .telemetry import measured
"""Approved monthly absolute coordinates, independent of source tab names.

Mapping is explicit and versioned. Ordinary reads never invoke a resolver.
Without a trustworthy unchanged revision, safety validation falls back to the
V4.1 bounded global proof; it never silently rebuilds or moves coordinates.
"""
from calendar import monthrange
from collections import OrderedDict
from dataclasses import asdict
from datetime import date
import hashlib
import json
import fcntl
from pathlib import Path

from sqlalchemy import delete, select, update
from sqlalchemy.orm import Session

from .config import settings
from .db import utcnow
from .destination_reader import DestinationReader, FormulaSignature, close_view, read_destination
from .engine import resolver
from .engine.parser import parse_date
from .engine.report import REPORT, report_date, resolve_balance_cell
from .engine.types import Cell, Issue, Write, column, fingerprint, norm
from .engine.writer import formula_map, structural
from .models import AuditLog, Destination, DestinationMapping, MappingTab, MappingTarget, MappingStructure, MonthlyDestination, Website, WriteLedger
from .source_index import revision,verified_revision
from .telemetry import Capture

TABS=('TOTAL DEPO','TOTAL WD','SALDO BANK','BIAYA','Pengeluaran FEE QRIS DEPO','Pengeluaran FEE QRIS WD','KET PENGIRIMAN',REPORT)


def current_mapping(db,dest):
    return db.scalar(select(DestinationMapping).where(DestinationMapping.destination_document_id==dest.id,
        DestinationMapping.destination_revision==dest.revision).order_by(DestinationMapping.id.desc()))


def queue_mapping(db,dest,user_id):
    for old in db.scalars(select(DestinationMapping).where(DestinationMapping.destination_document_id==dest.id,
                                                         DestinationMapping.state.in_(['QUEUED','BUILDING']))):
        old.state='INVALIDATED'
    mapping=DestinationMapping(destination_document_id=dest.id,destination_revision=dest.revision,
        spreadsheet_id=dest.spreadsheet_id,year=dest.year,month=dest.month,requested_by=user_id,
        registered=list(db.scalars(select(Website.display_name).order_by(Website.id))))
    db.add(mapping);db.flush()
    return mapping


def status(db,dest):
    mapping=current_mapping(db,dest)
    return {'id':mapping.id,'state':mapping.state,'error':mapping.error,
            'issues':mapping.evidence.get('issues',[]),'revision':mapping.destination_revision} if mapping else {'state':'NOT_BUILT'}


def _issue(error):
    return {'code':error.code,'message':error.message,'fix':error.fix,'context':error.context}


def _anchors(grid,positions):
    # These are structural coordinates covered by the discovery scan, not
    # financial targets. No network request per mapped matrix entry.
    return [[r,c,next((cell for rr,cc,cell in grid.iter_cells(r,r+1,c,c+1)),Cell()).snapshot]
            for r,c in sorted(set(positions))]


def _coordinates(grid,row,col,left,right,anchors=()):
    return {'tab':grid.title,'sheet_id':grid.sheet_id,'row':row,'col':col,'a1':f'{column(col)}{row+1}',
            'boundary':[left,right],'anchors':_anchors(grid,[*anchors,(row,left),(0,left),(1,left),(0,col),(1,col)])}


def _is_structure(r,value,formula=None,formatted=False):
    return r<2 or parse_date(Cell(value,formula,date_format=formatted)) is not None or norm(value) in ('BCA','MANDIRI','BRI','BNI','TOTAL')


def structure_overlay(db,tab,changes,formats=None):
    """Exact V4 hash with only explicitly authorized financial cells overlaid."""
    overlay={(w.row,w.col):[w.value,None] for w in changes}
    stream=db.execute(select(MappingStructure.row_index,MappingStructure.column_index,MappingStructure.value).where(
        MappingStructure.mapping_tab_id==tab.id).order_by(MappingStructure.row_index,MappingStructure.column_index))
    digest,first=hashlib.sha256(b'[['),True
    def emit(r,c,value):
        nonlocal first
        if not first:digest.update(b', ')
        digest.update(json.dumps([r,c,*value],sort_keys=True,ensure_ascii=False,default=str).encode());first=False
    current=next(stream,None)
    for r,extent in enumerate(tab.evidence.get('header_extents',[])):
        for c in range(extent):
            payload=current[2] if current is not None and (current[0],current[1])==(r,c) else [None,None]
            if current is not None and (current[0],current[1])==(r,c):current=next(stream,None)
            emit(r,c,overlay.pop((r,c),payload))
    pending=iter(sorted((r,c,payload) for (r,c),payload in overlay.items()))
    change=next(pending,None)
    while current is not None or change is not None:
        changed=False
        if change is not None and (current is None or change[:2]<current[:2]):
            r,c,payload=change;change=next(pending,None);changed=True
        elif change is not None and change[:2]==current[:2]:
            r,c,payload=change;change=next(pending,None);current=next(stream,None);changed=True
        else:
            r,c,payload=current;current=next(stream,None)
        if not changed or _is_structure(r,payload[0],payload[1],(formats or {}).get((r,c),False)):emit(r,c,payload)
    digest.update(b'], [')
    for i,merge in enumerate(tab.evidence['merges']):
        if i:digest.update(b', ')
        digest.update(json.dumps(merge,sort_keys=True,ensure_ascii=False,default=str).encode())
    digest.update(b']]')
    return digest.hexdigest()


def accept_structure(db,tab,writes,signature,formats=None):
    for w in writes:
        key=(tab.id,w.row,w.col)
        existing=db.get(MappingStructure,key)
        if _is_structure(w.row,w.value,formatted=(formats or {}).get((w.row,w.col),False)):
            if existing:existing.value=[w.value,None]
            else:db.add(MappingStructure(mapping_tab_id=tab.id,row_index=w.row,column_index=w.col,value=[w.value,None]))
        elif existing:db.delete(existing)
    tab.structure_signature=signature


def build_mapping(db,mapping,client):
    path=Path(settings().worker_lock).parent/'mapping-build.lock'
    path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    with path.open('a') as lock:
        path.chmod(0o600)
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:return False
        with Capture() as metrics:
            _build_mapping(db,mapping,client)
        mapping.evidence={**mapping.evidence,'performance':metrics.result}
        db.add(AuditLog(actor_id=mapping.requested_by,action='mapping_performance_measured',
            entity_type='destination_mapping_versions',entity_id=str(mapping.id),details=metrics.result))
        db.commit()
        return True


def recover_mappings(db):
    path=Path(settings().worker_lock).parent/'mapping-build.lock'
    path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    with path.open('a') as lock:
        path.chmod(0o600)
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:return
        for mapping in db.scalars(select(DestinationMapping).where(DestinationMapping.state=='BUILDING')):
            mapping.state,mapping.error='FAILED',{'code':'MAPPING_INTERRUPTED','message':'Mapping terputus; validasi ulang URL untuk versi baru.'}


def _build_mapping(db,mapping,client):
    claimed=db.execute(update(DestinationMapping).where(DestinationMapping.id==mapping.id,DestinationMapping.state=='QUEUED')
                       .values(state='BUILDING'))
    db.commit()
    if not claimed.rowcount:return
    db.refresh(mapping)
    count,issues=0,[]
    try:
        metadata=client.metadata(mapping.spreadsheet_id)
        if metadata.get('spreadsheetId',mapping.spreadsheet_id)!=mapping.spreadsheet_id:
            raise Issue('DESTINATION_IDENTITY_CHANGED','Identitas workbook tujuan tidak sesuai URL.')
        available={s['properties']['title'] for s in metadata.get('sheets',[])}
        missing=set(TABS)-available
        if missing:raise Issue('TAB_MISSING','Tab tujuan yang diwajibkan tidak tersedia.',tabs=sorted(missing))
        before=revision(client,mapping.spreadsheet_id)
        def add(website,selected,module,category,coordinates):
            nonlocal count
            count+=1
            if count>settings().destination_mapping_targets:
                raise Issue('MAPPING_RESOURCE_LIMIT','Jumlah target absolut melebihi batas registry; tidak ada target dilewati.')
            db.add(MappingTarget(mapping_id=mapping.id,website=website,selected_date=selected,module=module,
                                 category=category,coordinates=coordinates))
            if count%500==0:db.flush()
        for title in TABS:
            view=read_destination(client,mapping.spreadsheet_id,title,mapping.registered)
            try:
                signature=formula_map(view)
                tab=MappingTab(mapping_id=mapping.id,title=title,google_sheet_id=view.sheet_id,
                    structure_signature=structural(view),formula_signature=asdict(signature),content_revision=before,
                    evidence={'height':view.height,'width':view.width,
                        'allocated_height':getattr(view,'allocated_height',view.height),
                        'allocated_width':getattr(view,'allocated_width',view.width),'merges':list(view.merges),
                        'header_extents':[(view.db.execute('SELECT n FROM extents WHERE r=?',(r,)).fetchone() or [0])[0]
                                          if hasattr(view,'db') else len(view.rows[r]) for r in range(min(2,view.height))]})
                db.add(tab);db.flush()
                structure_count=0
                for r,c,cell in view.iter_cells():
                    # Formatting/date predicates are evaluated exactly as V4;
                    # financial payload is retained only when it IS structure.
                    if (r<2 or parse_date(cell) is not None or norm(cell.value) in ('BCA','MANDIRI','BRI','BNI','TOTAL')):
                        db.add(MappingStructure(mapping_tab_id=tab.id,row_index=r,column_index=c,value=[cell.value,cell.formula]))
                        structure_count+=1
                        if structure_count%500==0:db.flush()
                db.flush()
                if structure_overlay(db,tab,[])!=tab.structure_signature:
                    raise Issue('MAPPING_STRUCTURE_INVALID','Bukti struktur registry tidak identik dengan pembacaan tujuan.')
                if title==REPORT:
                    dates=sorted({report_date(cell) for r,c,cell in view.iter_cells() if report_date(cell) is not None
                                  and (report_date(cell).year,report_date(cell).month)==(mapping.year,mapping.month)})
                    for selected in dates:
                        for website in [None,*mapping.registered]:
                            try:
                                found=resolve_balance_cell(view,selected,website,mapping.registered)
                                letters=''.join(c for c in found['date_cell'] if c.isalpha())
                                dc=0
                                for letter in letters:dc=dc*26+ord(letter)-64
                                anchors=[(found['row'],dc-1),(found['table_header_row']-1,found['column'])]
                                add(website or '',selected,title,'BALANCE',{**_coordinates(view,found['row'],found['column'],0,view.width,anchors),**found,
                                    'validation':{'kind':'REPORT','website':website,'date':str(selected)}})
                            except Issue as error:issues.append({'tab':title,'website':website,'date':str(selected),**_issue(error)})
                    db.commit();continue
                if title=='KET PENGIRIMAN':
                    for day in range(1,monthrange(mapping.year,mapping.month)[1]+1):
                        selected=date(mapping.year,mapping.month,day)
                        for website in mapping.registered:
                            try:
                                slots=resolver.transfer_slots(view,website,mapping.registered,selected)
                                add(website,selected,title,'SLOTS',{'tab':title,'sheet_id':view.sheet_id,'slots':slots,
                                    'validation':{'kind':'SLOTS','website':website,'date':str(selected)}})
                            except Issue as error:
                                if error.code!='DESTINATION_DATE_MISSING':
                                    issues.append({'tab':title,'website':website,'date':str(selected),**_issue(error)})
                    db.commit();continue
                for website in mapping.registered:
                    try:anchor,left,right=resolver.website_block(view,website,mapping.registered)
                    except Issue as error:
                        issues.append({'tab':title,'website':website,**_issue(error)});continue
                    dates={parse_date(cell) for r,c,cell in view.iter_cells(top=2,left=left,right=left+1) if parse_date(cell) is not None}
                    dates=sorted(d for d in dates if (d.year,d.month)==(mapping.year,mapping.month))
                    for selected in dates:
                        try:row=resolver.date_row(view,left,right,selected)
                        except Issue as error:
                            issues.append({'tab':title,'website':website,'date':str(selected),**_issue(error)});continue
                        if title.startswith('Pengeluaran FEE QRIS '):
                            label='FEE QRIS DEPO' if title.endswith('DEPO') else 'FEE QRIS WD'
                            inspection=_coordinates(view,row,min(left+1,right-1),left,right)
                            # TOTAL is a protected calculated column, outside
                            # the fee payload even if its write headers are absent.
                            totals=[c for c in range(left+1,right) if any(norm(view.inherited(r,c).value)=='TOTAL' for r in (0,1))]
                            inspection.update({'columns':[left+1,min(totals) if totals else right],
                                'validation':{'kind':'SCOPE','website':website,'date':str(selected)}})
                            add(website,selected,title,'__FEE_OCCUPANCY__',inspection)
                            try:
                                writes=resolver.fees(view,website,mapping.registered,selected,label,'',0)
                                header_anchors=[(r,c) for r,c,cell in view.iter_cells(anchor,min(row,anchor+12),left+1,right)
                                                if norm(cell.value) in ('KETERANGAN',label)]
                                add(website,selected,title,label,{'tab':title,'sheet_id':view.sheet_id,
                                    'cells':[_coordinates(view,w.row,w.col,left,right,header_anchors) for w in writes],
                                    'validation':{'kind':'FEE','website':website,'date':str(selected),'label':label}})
                            except Issue as error:issues.append({'tab':title,'website':website,'date':str(selected),**_issue(error)})
                        else:
                            categories={}
                            for c in range(left+1,right):
                                top,sub=norm(view.inherited(0,c).value),norm(view.inherited(1,c).value)
                                labels={top,sub} if title=='BIAYA' else {top,sub,f'{top} {sub}'.strip()}
                                for name in labels-{''}:
                                    categories.setdefault(name,set()).add(c)
                            for category,cols in categories.items():
                                if len(cols)!=1:
                                    coordinates={'error':{'code':'ACCOUNT_MISSING','message':f'Header {category} tidak unik dalam blok {website}.'}}
                                else:
                                    col=next(iter(cols))
                                    coordinates=_coordinates(view,row,col,left,right)
                                    coordinates['validation']={'kind':'LABEL' if title=='BIAYA' else 'REGULAR',
                                        'website':website,'date':str(selected),'label':category}
                                add(website,selected,title,category,coordinates)
            finally:close_view(view)
            # Partially built tables are durable but never usable as READY.
            db.commit()
        after=revision(client,mapping.spreadsheet_id)
        if before is not None and before!=after:
            raise Issue('DESTINATION_CHANGED','Workbook berubah selama mapping; validasi ulang tanpa memindahkan target secara otomatis.')
        db.refresh(mapping)
        dest=db.get(Destination,mapping.destination_document_id);db.refresh(dest)
        binding=db.scalar(select(MonthlyDestination).where(MonthlyDestination.year==mapping.year,MonthlyDestination.month==mapping.month))
        if mapping.state!='BUILDING' or (dest.revision,dest.spreadsheet_id)!=(mapping.destination_revision,mapping.spreadsheet_id) or not binding or binding.destination_document_id!=dest.id:
            mapping.state='INVALIDATED';db.commit();return
        mapping.state,mapping.evidence='READY',{'targets':count,'content_revision':after,'issues':issues,
            'title':metadata.get('properties',{}).get('title')}
        dest.spreadsheet_title=metadata.get('properties',{}).get('title')
        dest.validation_status,dest.validated_at='VALID',utcnow()
        db.commit()
    except Issue as error:
        db.rollback();db.refresh(mapping)
        if mapping.state=='BUILDING':mapping.state,mapping.error='FAILED',_issue(error)
        db.commit()
    except Exception:
        db.rollback();db.refresh(mapping)
        if mapping.state=='BUILDING':mapping.state,mapping.error='FAILED',{'code':'MAPPING_FAILED','message':'Mapping terhenti; validasi ulang dan periksa log.'}
        db.commit()
        raise


def background_mapping(bind,mapping_id,client_factory):
    with Session(bind,expire_on_commit=False) as db:
        mapping=db.get(DestinationMapping,mapping_id)
        if mapping and mapping.state=='QUEUED':
            try:build_mapping(db,mapping,client_factory())
            except Issue as error:
                mapping.state,mapping.error='FAILED',_issue(error);db.commit()


def assert_current(db,run):
    map_id=run.config_snapshot.get('mapping_id')
    mapping=db.get(DestinationMapping,map_id) if map_id else None
    pin=run.config_snapshot['destination']
    dest=db.get(Destination,pin['id'])
    if not mapping or mapping.state!='READY' or not dest:
        raise Issue('MAPPING_NOT_READY','Registry tujuan belum siap. Simpan/validasi URL bulanan dan tunggu mapping selesai.')
    db.refresh(dest);db.refresh(mapping)
    latest=current_mapping(db,dest)
    if ((dest.revision,dest.spreadsheet_id)!=(pin['revision'],pin['spreadsheet_id']) or
        mapping.destination_revision!=pin['revision'] or not latest or latest.id!=mapping.id):
        raise Issue('MAPPING_REVISION_CHANGED','URL atau mapping tujuan berubah. Run tetap dipin; buat otorisasi baru tanpa redirect otomatis.')
    return mapping


@measured('warm_mapping_lookup')
def target(db,run,title,category,regular=False,source='',alias=''):
    mapping=assert_current(db,run)
    names=({norm(alias)} if alias else resolver.account_names(source)) if regular else {norm(category)}
    entries=list(db.scalars(select(MappingTarget).where(MappingTarget.mapping_id==mapping.id,
        MappingTarget.website==run.config_snapshot['website'],MappingTarget.selected_date==run.selected_date,
        MappingTarget.module==title,MappingTarget.category.in_(names))))
    if not entries:
        relevant=[i for i in mapping.evidence.get('issues',[]) if i.get('tab')==title and i.get('website')==run.config_snapshot['website'] and i.get('date',str(run.selected_date))==str(run.selected_date)]
        if relevant:
            problem=relevant[0];raise Issue(problem['code'],problem['message'],problem.get('fix','Validasi ulang tujuan setelah perbaikan.'))
        raise Issue('ACCOUNT_MISSING' if regular else 'HEADER_MISSING','Target tidak tersedia pada registry tujuan yang disetujui.',
                    'Periksa account/alias dan tanggal; validasi ulang URL bila layout diubah.',destination_tab=title)
    found={}
    for entry in entries:
        data=entry.coordinates
        if 'error' in data:raise Issue(data['error']['code'],data['error']['message'])
        key=(data.get('row'),data.get('col')) if regular else entry.category
        found[key]=entry
    if len(found)!=1:raise Issue('ACCOUNT_MISSING','Rekening tujuan tidak ditemukan secara unik pada registry.')
    return next(iter(found.values()))


class RegistryView(DestinationReader):
    def __init__(self,db,client,run,title):
        self.owner_db,self.run,self.client=db,run,client
        mapping=assert_current(db,run)
        tab=db.scalar(select(MappingTab).where(MappingTab.mapping_id==mapping.id,MappingTab.title==title))
        if tab is None:raise Issue('TAB_MISSING','Tab tidak tersedia dalam registry yang disetujui.')
        self.record=tab
        self.document,self.title,self.sheet_id=mapping.spreadsheet_id,title,tab.google_sheet_id
        self.registered=tuple(mapping.registered)
        self.height,self.width=tab.evidence['height'],tab.evidence['width']
        self.allocated_height,self.allocated_width=tab.evidence['allocated_height'],tab.evidence['allocated_width']
        self.merges=tab.evidence['merges']
        self.structural_signature=tab.structure_signature
        self.formula_signature=FormulaSignature(**tab.formula_signature)
        self.cache,self.cache_bytes=OrderedDict(),0
        self.anchors=[]
        self.validations=[]

    def require_coordinates(self,coordinates):
        if coordinates.get('validation'):self.validations.append(coordinates)
        for data in coordinates.get('cells',[coordinates]):
            self.anchors.extend(data.get('anchors',[]))

    def check_validations(self,view):
        for coordinates in self.validations:
            rule=coordinates['validation'];selected=date.fromisoformat(rule['date']);website=rule['website']
            kind=rule['kind']
            if kind=='REPORT':
                actual=resolve_balance_cell(view,selected,website,self.registered)
                same=(actual['row'],actual['column'])==(coordinates['row'],coordinates['column'])
            elif kind=='SLOTS':same=fingerprint(resolver.transfer_slots(view,website,self.registered,selected))==fingerprint(coordinates['slots'])
            elif kind=='FEE':
                actual=resolver.fees(view,website,self.registered,selected,rule['label'],'',0)
                same=[(w.row,w.col) for w in actual]==[(p['row'],p['col']) for p in coordinates['cells']]
            elif kind=='SCOPE':
                _,left,right=resolver.website_block(view,website,self.registered)
                same=([left,right]==coordinates['boundary'] and resolver.date_row(view,left,right,selected)==coordinates['row'])
            else:
                if kind=='LABEL':actual=resolver.labeled(view,website,self.registered,selected,rule['label'],0)
                else:actual=resolver.regular(view,website,self.registered,selected,rule['label'],0,rule['label'])
                same=(actual.row,actual.col)==(coordinates['row'],coordinates['col'])
                _,left,right=resolver.website_block(view,website,self.registered)
                same= same and [left,right]==coordinates['boundary']
            if not same:raise Issue('DESTINATION_CHANGED','Validasi target tidak sesuai registry; koordinat tidak dipindahkan otomatis.')

    def check_anchors(self):
        expected={(r,c):value for r,c,value in self.anchors}
        actual={pos:self.cell(*pos) for pos in expected}
        if any(actual[pos].snapshot!=value for pos,value in expected.items()):
            raise Issue('DESTINATION_CHANGED','Anchor registry tujuan berubah; persetujuan mapping lama tidak dipindahkan.')

    def close(self):
        self.cache.clear();self.cache_bytes=0

    def recover_structure(self,view):
        """Prove a lost-reply write from durable intent without acknowledging it.

        A fee description containing a date is part of the global structural
        predicate. Only exact, non-formula, unmerged PREPARED cell snapshots may
        explain that difference. Other structure must still match byte for byte.
        Financial verification remains the writer's separate responsibility.
        """
        from .transfer_intents import coordinates
        dest=self.run.config_snapshot['destination']
        records=list(self.owner_db.scalars(select(WriteLedger).where(
            WriteLedger.destination_document_id==dest['id'],WriteLedger.destination_revision==dest['revision'],
            WriteLedger.destination_tab==self.title,WriteLedger.verification_status=='PREPARED')
            .limit(settings().grid_chunk_cells+1)))
        if len(records)>settings().grid_chunk_cells:return False
        writes=[];ids=[];formats={}
        for ledger in records:
            r,c=coordinates(ledger.target_range);cell=view.cell(r,c)
            if cell.snapshot!=ledger.written_value or cell.formula is not None:continue
            if any(m['startRowIndex']<=r<m['endRowIndex'] and m['startColumnIndex']<=c<m['endColumnIndex'] for m in self.merges):continue
            writes.append(Write(self.title,r,c,cell.value,cell.note));ids.append(ledger.id);formats[r,c]=cell.date_format
        if not writes or structural(view)!=structure_overlay(self.owner_db,self.record,writes,formats):return False
        if formula_map(view)!=FormulaSignature(**self.record.formula_signature):return False
        accept_structure(self.owner_db,self.record,writes,structural(view),formats)
        self.structural_signature=self.record.structure_signature
        self.owner_db.add(AuditLog(actor_id=self.run.started_by,action='prepared_structure_recovered',
            entity_type='destination_mapping_tabs',entity_id=str(self.record.id),details={'ledger_ids':ids,'run_id':self.run.id}))
        return True

    @measured('destination_validation')
    def refresh(self,force_global=False,allowed_changes=(),formats=None,positions=()):
        assert_current(self.owner_db,self.run)
        before=revision(self.client,self.document,use_previous=not force_global)
        if not force_global and before is not None and before==self.record.content_revision:
            # An unchanged file revision proves the global structure/formulas
            # unchanged. Actual financial target cells are still explicitly GET.
            view=RegistryView(self.owner_db,self.client,self.run,self.title)
            view.anchors=list(self.anchors)
            try:
                view.prefetch(list(dict.fromkeys([*(tuple(a[:2]) for a in view.anchors),*positions])))
                view.check_anchors()
                if revision(self.client,self.document)!=before:
                    raise Issue('DESTINATION_CHANGED','Workbook berubah selama pemeriksaan anchor tujuan.')
                verified_revision(self.client,self.document,before)
                return view
            except BaseException:
                view.close();raise
        view=read_destination(self.client,self.document,self.title,self.registered)
        try:
            pin=self.run.config_snapshot['destination']
            uncertain=self.owner_db.scalar(select(WriteLedger.id).where(
                WriteLedger.destination_document_id==pin['id'],WriteLedger.destination_revision==pin['revision'],
                WriteLedger.destination_tab==self.title,WriteLedger.verification_status=='PREPARED').limit(1))
            if uncertain and formula_map(view)!=FormulaSignature(**self.record.formula_signature):
                raise Issue('FORMULA_CHANGED','Formula global berubah saat masih ada intent PREPARED; histori tidak diakui atau ditimpa otomatis.')
            expected=structure_overlay(self.owner_db,self.record,allowed_changes,formats) if allowed_changes else self.record.structure_signature
            if view.sheet_id!=self.sheet_id or (structural(view)!=expected and
                    (allowed_changes or not self.recover_structure(view))):
                raise Issue('DESTINATION_CHANGED','Struktur tujuan berbeda dari registry absolut. Validasi ulang URL; koordinat tidak dipindahkan.')
            self.check_validations(view)
            expected_anchors={(r,c):value for r,c,value in self.anchors}
            if hasattr(view,'prefetch'):view.prefetch(list(dict.fromkeys([*expected_anchors,*positions])))
            if any(view.cell(*pos).snapshot!=value for pos,value in expected_anchors.items()):
                raise Issue('DESTINATION_CHANGED','Anchor target yang disetujui berubah; mapping lama tidak diubah.')
            after=revision(self.client,self.document)
            if before is not None and before!=after:
                raise Issue('DESTINATION_CHANGED','Workbook berubah selama validasi tujuan.')
            if not allowed_changes:
                self.record.content_revision=after
                self.record.formula_signature=asdict(formula_map(view))
                self.owner_db.commit()
            view.validated_content_revision=after
            verified_revision(self.client,self.document,after)
            return view
        except BaseException:
            close_view(view);raise

    def after_write(self,writes,fresh):
        formats={(w.row,w.col):fresh.cell(w.row,w.col).date_format for w in writes}
        return self.refresh(force_global=True,allowed_changes=writes,formats=formats)

    def accept_verified(self,writes,view):
        accept_structure(self.owner_db,self.record,writes,structural(view),{(w.row,w.col):view.cell(w.row,w.col).date_format for w in writes})
        self.record.content_revision=getattr(view,'validated_content_revision',None)
        self.record.formula_signature=asdict(formula_map(view))
        self.structural_signature=self.record.structure_signature
        self.formula_signature=formula_map(view)
        self.cache.clear();self.cache_bytes=0


def regular_write(db,run,title,source,value,alias=''):
    entry=target(db,run,title,'',regular=True,source=source,alias=alias)
    data=entry.coordinates
    return Write(title,data['row'],data['col'],value)


def labeled_write(db,run,title,label,value):
    entry=target(db,run,title,label)
    data=entry.coordinates
    return Write(title,data['row'],data['col'],value)


def fee_writes(db,run,title,label,description,value):
    entry=target(db,run,title,label)
    return [Write(title,pos['row'],pos['col'],val) for pos,val in zip(entry.coordinates['cells'],[description,value])]


def inspect_no_fee(db,run,item,grid,coordinates):
    """Inspect the mapped website/date even when a write header is unnecessary."""
    from .engine.writer import owner_key
    from .models import WriteLedger
    row=coordinates['row'];left,right=coordinates['columns'];writes=[]
    expected_owner=owner_key(run,item)
    ledgers=list(db.scalars(select(WriteLedger).where(WriteLedger.destination_document_id==run.config_snapshot['destination']['id'],
        WriteLedger.destination_revision==run.config_snapshot['destination']['revision'],WriteLedger.destination_tab==grid.title,
        WriteLedger.output_type=='qris_fee',WriteLedger.owner_key==expected_owner)))
    known={ledger.target_range for ledger in ledgers}
    for first in range(left,right,32):
        positions=[(row,c) for c in range(first,min(right,first+32))]
        cells=grid.read_cells(positions)
        for (r,c),cell in cells.items():
            address=f'{column(c)}{r+1}'
            if not cell.empty or address in known:writes.append(Write(grid.title,r,c,None))
    return writes
