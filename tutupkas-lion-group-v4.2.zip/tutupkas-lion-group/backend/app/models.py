from datetime import date, datetime
from typing import Optional

from sqlalchemy import JSON, Boolean, Date, DateTime, ForeignKey, Index, Integer, String, Text, UniqueConstraint, text
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base, utcnow


class Stamp:
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


class User(Stamp, Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(80), unique=True)
    password_hash: Mapped[str] = mapped_column(Text)
    role: Mapped[str] = mapped_column(String(30), default="admin")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    last_login_at: Mapped[Optional[datetime]] = mapped_column(DateTime)


class AuthSession(Base):
    __tablename__ = "auth_sessions"
    token_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    csrf_token: Mapped[str] = mapped_column(String(100))
    expires_at: Mapped[datetime] = mapped_column(DateTime, index=True)


class LoginAttempt(Base):
    __tablename__ = "login_attempts"
    id: Mapped[int] = mapped_column(primary_key=True)
    identity: Mapped[str] = mapped_column(String(64), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)


class Website(Stamp, Base):
    __tablename__ = "websites"
    id: Mapped[int] = mapped_column(primary_key=True)
    display_name: Mapped[str] = mapped_column(String(100))
    slug: Mapped[str] = mapped_column(String(100), unique=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_archived: Mapped[bool] = mapped_column(Boolean, default=False)


class SourceDocument(Stamp, Base):
    __tablename__ = "source_documents"
    __table_args__ = (UniqueConstraint("website_id", "document_type", "year", "month"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    website_id: Mapped[int] = mapped_column(ForeignKey("websites.id"), index=True)
    document_type: Mapped[str] = mapped_column(String(10))
    year: Mapped[int] = mapped_column(Integer)
    month: Mapped[int] = mapped_column(Integer)
    spreadsheet_url: Mapped[str] = mapped_column(Text)
    spreadsheet_id: Mapped[str] = mapped_column(String(150))
    spreadsheet_title: Mapped[Optional[str]] = mapped_column(Text)
    validation_status: Mapped[str] = mapped_column(String(30), default="UNVALIDATED")
    validated_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    active_revision_id: Mapped[Optional[int]] = mapped_column(Integer)


class SourceRevision(Base):
    __tablename__ = "source_document_revisions"
    __table_args__ = (UniqueConstraint("source_document_id", "revision_number"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    source_document_id: Mapped[int] = mapped_column(ForeignKey("source_documents.id"), index=True)
    revision_number: Mapped[int] = mapped_column(Integer)
    spreadsheet_url: Mapped[str] = mapped_column(Text)
    spreadsheet_id: Mapped[str] = mapped_column(String(150))
    changed_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    changed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class SourceSheet(Stamp, Base):
    __tablename__ = "source_sheet_states"
    __table_args__ = (UniqueConstraint("source_revision_id", "tab_name"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    source_document_id: Mapped[int] = mapped_column(ForeignKey("source_documents.id"), index=True)
    source_revision_id: Mapped[int] = mapped_column(ForeignKey("source_document_revisions.id"), index=True)
    tab_name: Mapped[str] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=False)
    is_available: Mapped[bool] = mapped_column(Boolean, default=True)
    discovered_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Destination(Stamp, Base):
    __tablename__ = "destination_documents"
    __table_args__ = (UniqueConstraint("year", "month", "environment"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    year: Mapped[int] = mapped_column(Integer)
    month: Mapped[int] = mapped_column(Integer)
    environment: Mapped[str] = mapped_column(String(12))
    spreadsheet_url: Mapped[str] = mapped_column(Text)
    spreadsheet_id: Mapped[str] = mapped_column(String(150))
    spreadsheet_title: Mapped[Optional[str]] = mapped_column(Text)
    validation_status: Mapped[str] = mapped_column(String(30), default="UNVALIDATED")
    validated_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    revision: Mapped[int] = mapped_column(Integer, default=1)
    test_verified_revision: Mapped[Optional[int]] = mapped_column(Integer)
    production_authorized_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))
    authorized_at: Mapped[Optional[datetime]] = mapped_column(DateTime)


class DestinationRevision(Base):
    __tablename__ = "destination_document_revisions"
    id: Mapped[int] = mapped_column(primary_key=True)
    destination_document_id: Mapped[int] = mapped_column(ForeignKey("destination_documents.id"), index=True)
    revision_number: Mapped[int] = mapped_column(Integer)
    spreadsheet_url: Mapped[str] = mapped_column(Text)
    changed_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    changed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class ValidationEvent(Base):
    __tablename__ = "validation_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    document_id: Mapped[int] = mapped_column(Integer, index=True)
    document_type: Mapped[str] = mapped_column(String(20))
    result: Mapped[str] = mapped_column(String(30))
    error_code: Mapped[Optional[str]] = mapped_column(String(60))
    human_message: Mapped[str] = mapped_column(Text)
    checked_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Run(Base):
    __tablename__ = "task_runs"
    __table_args__ = (Index("one_active_run", "website_id", "selected_date", "environment", unique=True,
                           sqlite_where=text("status IN ('QUEUED','RUNNING','CANCEL_REQUESTED')"),
                           postgresql_where=text("status IN ('QUEUED','RUNNING','CANCEL_REQUESTED')")),)
    id: Mapped[int] = mapped_column(primary_key=True)
    task_number: Mapped[int] = mapped_column(Integer, default=1)
    website_id: Mapped[int] = mapped_column(ForeignKey("websites.id"), index=True)
    selected_date: Mapped[date] = mapped_column(Date)
    year: Mapped[int] = mapped_column(Integer)
    month: Mapped[int] = mapped_column(Integer)
    environment: Mapped[str] = mapped_column(String(12))
    preview: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(30), default="QUEUED", index=True)
    started_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    finished_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    cancel_requested_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    cancel_requested_by: Mapped[Optional[int]] = mapped_column(ForeignKey('users.id'))
    current_phase: Mapped[Optional[str]] = mapped_column(String(40))
    idempotency_key: Mapped[str] = mapped_column(String(100), unique=True)
    config_snapshot: Mapped[dict] = mapped_column(JSON)
    batch_id: Mapped[Optional[int]] = mapped_column(ForeignKey("crawl_batches.id"), index=True)


class RunItem(Base):
    __tablename__ = "task_run_items"
    __table_args__ = (UniqueConstraint("run_id", "source_document_id", "source_tab_name", "metric_type"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("task_runs.id"), index=True)
    source_document_id: Mapped[Optional[int]] = mapped_column(ForeignKey("source_documents.id"))
    source_tab_name: Mapped[str] = mapped_column(Text)
    metric_type: Mapped[str] = mapped_column(String(50))
    status: Mapped[str] = mapped_column(String(30), default="PENDING")
    source_date: Mapped[date] = mapped_column(Date)
    result: Mapped[Optional[dict]] = mapped_column(JSON)
    processed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)


class TaskError(Base):
    __tablename__ = "task_errors"
    id: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("task_runs.id"), index=True)
    run_item_id: Mapped[int] = mapped_column(ForeignKey("task_run_items.id"), index=True)
    source_document_id: Mapped[Optional[int]] = mapped_column(ForeignKey("source_documents.id"))
    source_tab_name: Mapped[str] = mapped_column(Text)
    error_code: Mapped[str] = mapped_column(String(80))
    human_message: Mapped[str] = mapped_column(Text)
    technical_details: Mapped[dict] = mapped_column(JSON, default=dict)
    suggested_fix: Mapped[str] = mapped_column(Text)
    is_resolved: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    retry_count: Mapped[int] = mapped_column(Integer, default=0)


class Clearance(Base):
    __tablename__ = "date_clearances"
    __table_args__ = (UniqueConstraint("website_id", "selected_date", "environment", "task_number"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    website_id: Mapped[int] = mapped_column(ForeignKey("websites.id"))
    selected_date: Mapped[date] = mapped_column(Date)
    year: Mapped[int] = mapped_column(Integer)
    month: Mapped[int] = mapped_column(Integer)
    environment: Mapped[str] = mapped_column(String(12))
    task_number: Mapped[int] = mapped_column(Integer, default=1)
    is_clear: Mapped[bool] = mapped_column(Boolean, default=True)
    confirmed_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    confirmed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    reopened_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    reopen_reason: Mapped[Optional[str]] = mapped_column(Text)
    destination_document_id: Mapped[Optional[int]] = mapped_column(ForeignKey("destination_documents.id"))
    destination_revision: Mapped[Optional[int]] = mapped_column(Integer)
    context_signature: Mapped[Optional[str]] = mapped_column(String(64))


class MonthlyDestination(Stamp, Base):
    __tablename__ = 'monthly_destinations'
    __table_args__ = (UniqueConstraint('year', 'month'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    year: Mapped[int] = mapped_column(Integer)
    month: Mapped[int] = mapped_column(Integer)
    destination_document_id: Mapped[int] = mapped_column(ForeignKey('destination_documents.id'))


class DayGate(Base):
    __tablename__ = 'execution_date_gates'
    selected_date: Mapped[date] = mapped_column(Date, primary_key=True)
    version: Mapped[int] = mapped_column(Integer, default=1)


class CrawlBatch(Base):
    __tablename__ = 'crawl_batches'
    __table_args__ = (Index('one_active_batch_per_date', 'selected_date', unique=True,
                     sqlite_where=text("status IN ('QUEUED','RUNNING','CANCEL_REQUESTED')"),
                     postgresql_where=text("status IN ('QUEUED','RUNNING','CANCEL_REQUESTED')")),)
    id: Mapped[int] = mapped_column(primary_key=True)
    selected_date: Mapped[date] = mapped_column(Date, index=True)
    preview: Mapped[bool] = mapped_column(Boolean, default=False)
    recheck_only: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(30), default='QUEUED', index=True)
    idempotency_key: Mapped[str] = mapped_column(String(100), unique=True)
    required_websites: Mapped[list] = mapped_column(JSON)
    destination_snapshot: Mapped[dict] = mapped_column(JSON)
    started_by: Mapped[int] = mapped_column(ForeignKey('users.id'))
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    finished_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    cancel_requested_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    cancel_requested_by: Mapped[Optional[int]] = mapped_column(ForeignKey('users.id'))
    current_phase: Mapped[Optional[str]] = mapped_column(String(40))


class BatchEntry(Base):
    __tablename__ = 'crawl_batch_entries'
    __table_args__ = (UniqueConstraint('batch_id', 'website_id'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    batch_id: Mapped[int] = mapped_column(ForeignKey('crawl_batches.id'), index=True)
    website_id: Mapped[int] = mapped_column(ForeignKey('websites.id'))
    position: Mapped[int] = mapped_column(Integer)
    run_id: Mapped[int] = mapped_column(ForeignKey('task_runs.id'))
    status: Mapped[str] = mapped_column(String(30), default='WAITING')
    reused: Mapped[bool] = mapped_column(Boolean, default=False)


class Reconciliation(Base):
    __tablename__ = 'reconciliations'
    id: Mapped[int] = mapped_column(primary_key=True)
    selected_date: Mapped[date] = mapped_column(Date, index=True)
    website_id: Mapped[Optional[int]] = mapped_column(ForeignKey('websites.id'), index=True)
    run_id: Mapped[Optional[int]] = mapped_column(ForeignKey('task_runs.id'), index=True)
    batch_id: Mapped[Optional[int]] = mapped_column(ForeignKey('crawl_batches.id'), index=True)
    destination_document_id: Mapped[int] = mapped_column(ForeignKey('destination_documents.id'))
    destination_revision: Mapped[int] = mapped_column(Integer)
    context_signature: Mapped[str] = mapped_column(String(64), index=True)
    kind: Mapped[str] = mapped_column(String(20))
    status: Mapped[str] = mapped_column(String(30))
    balance: Mapped[Optional[str]] = mapped_column(String(150))
    cell: Mapped[Optional[str]] = mapped_column(String(100))
    error_code: Mapped[Optional[str]] = mapped_column(String(80))
    human_message: Mapped[str] = mapped_column(Text)
    details: Mapped[dict] = mapped_column(JSON, default=dict)
    checked_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)


class FinalClearance(Base):
    __tablename__ = 'final_date_clearances'
    __table_args__ = (UniqueConstraint('selected_date', 'destination_document_id', 'destination_revision', 'context_signature'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    selected_date: Mapped[date] = mapped_column(Date, index=True)
    destination_document_id: Mapped[int] = mapped_column(ForeignKey('destination_documents.id'))
    destination_revision: Mapped[int] = mapped_column(Integer)
    context_signature: Mapped[str] = mapped_column(String(64))
    is_clear: Mapped[bool] = mapped_column(Boolean, default=True)
    confirmed_by: Mapped[int] = mapped_column(ForeignKey('users.id'))
    confirmed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    reopened_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    reopen_reason: Mapped[Optional[str]] = mapped_column(Text)


class WriteLedger(Base):
    __tablename__ = "output_write_ledger"
    __table_args__ = (UniqueConstraint("destination_document_id", "destination_revision", "destination_tab", "target_range"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    run_item_id: Mapped[int] = mapped_column(ForeignKey("task_run_items.id"))
    destination_document_id: Mapped[int] = mapped_column(ForeignKey("destination_documents.id"))
    destination_revision: Mapped[int] = mapped_column(Integer)
    destination_tab: Mapped[str] = mapped_column(Text)
    target_range: Mapped[str] = mapped_column(String(50))
    output_type: Mapped[str] = mapped_column(String(50))
    owner_key: Mapped[str] = mapped_column(String(64))
    source_fingerprint: Mapped[str] = mapped_column(String(64))
    previous_managed_value: Mapped[dict] = mapped_column(JSON)
    written_value: Mapped[dict] = mapped_column(JSON)
    note_fingerprint: Mapped[str] = mapped_column(String(64))
    last_written_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    verification_status: Mapped[str] = mapped_column(String(30), default="PREPARED")


class TransferOwnership(Base):
    __tablename__ = "transfer_slot_ownership"
    __table_args__ = (UniqueConstraint("destination_document_id", "destination_revision", "source_transaction_fingerprint"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    run_item_id: Mapped[int] = mapped_column(ForeignKey("task_run_items.id"))
    source_transaction_fingerprint: Mapped[str] = mapped_column(String(64))
    destination_document_id: Mapped[int] = mapped_column(ForeignKey("destination_documents.id"))
    destination_revision: Mapped[int] = mapped_column(Integer)
    destination_tab: Mapped[str] = mapped_column(Text)
    destination_bank: Mapped[str] = mapped_column(String(20))
    description_cell: Mapped[str] = mapped_column(String(50))
    amount_cell: Mapped[str] = mapped_column(String(50))
    note_cell: Mapped[str] = mapped_column(String(50))
    last_written_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class AccountAlias(Base):
    __tablename__ = "account_aliases"
    __table_args__ = (UniqueConstraint("website_id", "source_name"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    website_id: Mapped[int] = mapped_column(ForeignKey("websites.id"))
    source_name: Mapped[str] = mapped_column(Text)
    destination_header: Mapped[str] = mapped_column(Text)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    actor_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))
    action: Mapped[str] = mapped_column(String(80), index=True)
    entity_type: Mapped[str] = mapped_column(String(50))
    entity_id: Mapped[str] = mapped_column(String(100))
    details: Mapped[dict] = mapped_column("metadata", JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


# V4.2 is additive: historical financial tables and their keys are unchanged.
class SourceIdentity(Stamp, Base):
    __tablename__ = 'source_tab_identities'
    __table_args__ = (UniqueConstraint('source_revision_id', 'google_sheet_id'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    source_document_id: Mapped[int] = mapped_column(ForeignKey('source_documents.id'))
    source_revision_id: Mapped[int] = mapped_column(ForeignKey('source_document_revisions.id'))
    spreadsheet_id: Mapped[str] = mapped_column(String(150))
    google_sheet_id: Mapped[int] = mapped_column(Integer)
    lineage: Mapped[str] = mapped_column(String(64), index=True)
    names: Mapped[list] = mapped_column(JSON)


class SourceBinding(Base):
    __tablename__ = 'source_tab_bindings'
    source_sheet_state_id: Mapped[int] = mapped_column(ForeignKey('source_sheet_states.id'), primary_key=True)
    identity_id: Mapped[int] = mapped_column(ForeignKey('source_tab_identities.id'))
    status: Mapped[str] = mapped_column(String(30), default='VERIFIED')
    verified_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class SourceDateIndex(Base):
    __tablename__ = 'source_date_index'
    __table_args__ = (UniqueConstraint('identity_id', 'content_revision', 'selected_date'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    identity_id: Mapped[int] = mapped_column(ForeignKey('source_tab_identities.id'), index=True)
    content_revision: Mapped[str] = mapped_column(String(100))
    selected_date: Mapped[date] = mapped_column(Date)
    separator_row: Mapped[int] = mapped_column(Integer)
    separator_col: Mapped[int] = mapped_column(Integer)
    following_row: Mapped[Optional[int]] = mapped_column(Integer)
    following_col: Mapped[Optional[int]] = mapped_column(Integer)
    evidence: Mapped[dict] = mapped_column(JSON)
    verified_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class DestinationMapping(Stamp, Base):
    __tablename__ = 'destination_mapping_versions'
    id: Mapped[int] = mapped_column(primary_key=True)
    destination_document_id: Mapped[int] = mapped_column(ForeignKey('destination_documents.id'), index=True)
    destination_revision: Mapped[int] = mapped_column(Integer)
    spreadsheet_id: Mapped[str] = mapped_column(String(150))
    year: Mapped[int] = mapped_column(Integer)
    month: Mapped[int] = mapped_column(Integer)
    state: Mapped[str] = mapped_column(String(30), default='QUEUED', index=True)
    registered: Mapped[list] = mapped_column(JSON)
    requested_by: Mapped[int] = mapped_column(ForeignKey('users.id'))
    evidence: Mapped[dict] = mapped_column(JSON, default=dict)
    error: Mapped[Optional[dict]] = mapped_column(JSON)


class MappingTab(Base):
    __tablename__ = 'destination_mapping_tabs'
    __table_args__ = (UniqueConstraint('mapping_id', 'title'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    mapping_id: Mapped[int] = mapped_column(ForeignKey('destination_mapping_versions.id'), index=True)
    title: Mapped[str] = mapped_column(Text)
    google_sheet_id: Mapped[int] = mapped_column(Integer)
    structure_signature: Mapped[str] = mapped_column(String(64))
    formula_signature: Mapped[dict] = mapped_column(JSON)
    content_revision: Mapped[Optional[str]] = mapped_column(String(100))
    evidence: Mapped[dict] = mapped_column(JSON)


class MappingTarget(Base):
    __tablename__ = 'destination_absolute_targets'
    __table_args__ = (UniqueConstraint('mapping_id', 'website', 'selected_date', 'module', 'category'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    mapping_id: Mapped[int] = mapped_column(ForeignKey('destination_mapping_versions.id'), index=True)
    website: Mapped[str] = mapped_column(String(100))
    selected_date: Mapped[date] = mapped_column(Date)
    module: Mapped[str] = mapped_column(String(100))
    category: Mapped[str] = mapped_column(Text)
    coordinates: Mapped[dict] = mapped_column(JSON)


class MappingStructure(Base):
    __tablename__ = 'destination_mapping_structure'
    mapping_tab_id: Mapped[int] = mapped_column(ForeignKey('destination_mapping_tabs.id'),primary_key=True)
    row_index: Mapped[int] = mapped_column(Integer,primary_key=True)
    column_index: Mapped[int] = mapped_column(Integer,primary_key=True)
    value: Mapped[list] = mapped_column(JSON)


class LegacySourceLink(Base):
    __tablename__ = 'source_legacy_lineage_links'
    prior_run_item_id: Mapped[int] = mapped_column(ForeignKey('task_run_items.id'),primary_key=True)
    identity_id: Mapped[int] = mapped_column(ForeignKey('source_tab_identities.id'))
    confirmed_by: Mapped[int] = mapped_column(ForeignKey('users.id'))
    evidence: Mapped[dict] = mapped_column(JSON)
    confirmed_at: Mapped[datetime] = mapped_column(DateTime,default=utcnow)


class TransferLineage(Base):
    __tablename__ = 'transfer_lineage_state'
    ownership_id: Mapped[int] = mapped_column(ForeignKey('transfer_slot_ownership.id'),primary_key=True)
    source_identity_id: Mapped[Optional[int]] = mapped_column(ForeignKey('source_tab_identities.id'))
    current_fingerprint: Mapped[Optional[str]] = mapped_column(String(64),index=True)
    pending_fingerprint: Mapped[Optional[str]] = mapped_column(String(64))
    state: Mapped[str] = mapped_column(String(30),default='ACTIVE')
    provenance: Mapped[dict] = mapped_column(JSON,default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime,default=utcnow,onupdate=utcnow)


class RetryRequest(Base):
    __tablename__ = 'item_retry_requests'
    __table_args__ = (Index('one_open_item_retry', 'run_item_id', unique=True,
        sqlite_where=text("state IN ('QUEUED','CLAIMED')"),
        postgresql_where=text("state IN ('QUEUED','CLAIMED')")),)
    id: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey('task_runs.id'), index=True)
    run_item_id: Mapped[int] = mapped_column(ForeignKey('task_run_items.id'))
    requested_by: Mapped[int] = mapped_column(ForeignKey('users.id'))
    idempotency_key: Mapped[str] = mapped_column(String(100), unique=True)
    state: Mapped[str] = mapped_column(String(30), default='QUEUED', index=True)
    kind: Mapped[str] = mapped_column(String(30), default='SOURCE_RETRY')
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    claimed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    finished_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    details: Mapped[dict] = mapped_column(JSON, default=dict)


class SourceSnapshot(Base):
    __tablename__ = 'source_date_snapshots'
    id: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey('task_runs.id'), index=True)
    source_document_id: Mapped[int] = mapped_column(ForeignKey('source_documents.id'))
    identity_id: Mapped[Optional[int]] = mapped_column(ForeignKey('source_tab_identities.id'))
    retry_request_id: Mapped[Optional[int]] = mapped_column(ForeignKey('item_retry_requests.id'), index=True)
    tab_name: Mapped[str] = mapped_column(Text)
    selected_date: Mapped[date] = mapped_column(Date)
    state: Mapped[str] = mapped_column(String(30), default='SCANNING')
    checksum: Mapped[Optional[str]] = mapped_column(String(64))
    payload: Mapped[Optional[dict]] = mapped_column(JSON)
    provenance: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class MappedResult(Base):
    __tablename__ = 'item_mapped_results'
    id: Mapped[int] = mapped_column(primary_key=True)
    run_item_id: Mapped[int] = mapped_column(ForeignKey('task_run_items.id'), index=True)
    snapshot_id: Mapped[Optional[int]] = mapped_column(ForeignKey('source_date_snapshots.id'))
    retry_request_id: Mapped[Optional[int]] = mapped_column(ForeignKey('item_retry_requests.id'))
    mapping_id: Mapped[Optional[int]] = mapped_column(ForeignKey('destination_mapping_versions.id'))
    state: Mapped[str] = mapped_column(String(30), default='MAPPED')
    writes: Mapped[list] = mapped_column(JSON)
    provenance: Mapped[dict] = mapped_column(JSON)
    checksum: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class DestinationConflict(Base):
    __tablename__ = 'destination_conflicts'
    __table_args__ = (Index('one_actionable_item_conflict', 'run_item_id', unique=True,
        sqlite_where=text("state IN ('OPEN','WRITE_PENDING','KEEP_PENDING')"),
        postgresql_where=text("state IN ('OPEN','WRITE_PENDING','KEEP_PENDING')")),)
    id: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey('task_runs.id'), index=True)
    run_item_id: Mapped[int] = mapped_column(ForeignKey('task_run_items.id'))
    mapping_id: Mapped[Optional[int]] = mapped_column(ForeignKey('destination_mapping_versions.id'))
    state: Mapped[str] = mapped_column(String(30), default='OPEN')
    reason: Mapped[str] = mapped_column(String(80))
    writes: Mapped[list] = mapped_column(JSON)
    observed: Mapped[list] = mapped_column(JSON)
    observation_hash: Mapped[str] = mapped_column(String(64))
    provenance: Mapped[dict] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime)


class ConflictDecision(Base):
    __tablename__ = 'conflict_decisions'
    id: Mapped[int] = mapped_column(primary_key=True)
    conflict_id: Mapped[int] = mapped_column(ForeignKey('destination_conflicts.id'), index=True)
    retry_request_id: Mapped[int] = mapped_column(ForeignKey('item_retry_requests.id'))
    actor_id: Mapped[int] = mapped_column(ForeignKey('users.id'))
    action: Mapped[str] = mapped_column(String(30))
    observation_hash: Mapped[str] = mapped_column(String(64))
    idempotency_key: Mapped[str] = mapped_column(String(100), unique=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class RetainedCell(Base):
    __tablename__ = 'retained_cell_decisions'
    ledger_id: Mapped[int] = mapped_column(ForeignKey('output_write_ledger.id'),primary_key=True)
    decision_id: Mapped[int] = mapped_column(ForeignKey('conflict_decisions.id'))
    conflict_id: Mapped[int] = mapped_column(ForeignKey('destination_conflicts.id'))
    snapshot: Mapped[dict] = mapped_column(JSON)
    checksum: Mapped[str] = mapped_column(String(64))
    recorded_at: Mapped[datetime] = mapped_column(DateTime,default=utcnow)

