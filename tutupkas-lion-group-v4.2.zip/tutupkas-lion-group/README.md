# TUTUP KAS · LION GROUP V4.2

Panel admin tutup kas dengan sumber DOC DEPO/QRIS, tujuan Kas Kecil bulanan, kiriman, fee dan rekonsiliasi seluruh WEB. V4.2 menambahkan snapshot sumber, indeks tanggal, registry koordinat absolut, retry satu item saat Run berjalan, serta keputusan konflik Data Lama/Data Baru. Perhitungan, kolom sumber, layout, formula, Notes dan aturan BALANCE tetap mengikuti V4.1.

## Upgrade VPS yang sudah ada

Unduh ZIP lengkap beserta SHA256, unggah ke staging lalu ikuti [UPGRADE_V42.md](docs/UPGRADE_V42.md). Script `deploy/upgrade.sh` membackup SQLite/aplikasi/frontend, menerapkan migrasi additive dan memulai **API saja**. Worker menunggu verifikasi manual. Akun, password, app.env, kredensial Google yang sama, Nginx/HTTPS dan MemoryMax dipertahankan. Jangan memakai install.sh untuk menimpa instalasi lama.

```bash
sha256sum -c tutupkas-lion-group-v4.2.zip.sha256
unzip tutupkas-lion-group-v4.2.zip -d /tmp/tutupkas-staging-v42
cd /tmp/tutupkas-staging-v42/tutupkas-lion-group
sudo bash deploy/upgrade.sh
```

Setelah upgrade, refresh/validasi sumber untuk membuktikan Google sheetId, validasi URL Kas Kecil bulanan hingga registry READY, lalu tinjau Preview pada salinan aman sebelum menjalankan worker untuk mode tulis. Sel lama yang berbeda memerlukan keputusan admin; source retry tidak mengulang sukses lainnya. Rollback harus memulihkan release dan database backup bersama. Detail terdapat dalam panduan upgrade.

## Operasi

- Tab baru/rename perlu ditinjau dan diaktifkan; identitas recreated tidak diadopsi berdasarkan nama.
- Registry dibangun saat URL disimpan/divalidasi. Crawl/retry memakai koordinat yang dipin, tanpa remapping otomatis.
- Retry item gagal membaca raw source terkini; perubahan BIAYA input dapat memerlukan retry total terpisah.
- Konflik menampilkan nilai Google aktual dan hasil sumber. Formula/merge/Note manual tetap dilindungi; KEEP tidak memaksa KLOP.
- Preview dan Laporan deposit harian hanya baca. Selesai & Clear memerlukan seluruh WEB dan BALANCE konsolidasi sesuai aturan lama.

## Pengembangan dan verifikasi

Python 3.10+, Node 20+ dan dependensi yang terkunci:

```bash
bash scripts/dev-install.sh
.venv/bin/python -m pytest backend/tests -q
cd frontend
npm ci
npm run build
cd ..
PLAYWRIGHT_CHROMIUM_EXECUTABLE=/usr/bin/chromium bash scripts/e2e.sh
python3 scripts/package.py
```

ZIP menyertakan source, migrasi, test, dokumentasi dan frontend prebuilt `public/`. Key nyata, password, database, `.env`, cache, virtualenv dan node_modules dikecualikan. `scripts/verify-real-run.py RUN_ID` memverifikasi tulisan nyata hanya dengan GET dan registry yang dipin.

## Laporan rilis

- [Arsitektur dan batas keselamatan](docs/ARCHITECTURE_V42.md)
- [Laporan pengujian](docs/TEST_REPORT.md) dan [cakupan 80 persyaratan](docs/COVERAGE_V42.md)
- [Benchmark dan batas validasi live](docs/PERFORMANCE_V42.md)
- [Perubahan per file](docs/CHANGED_FILES_V42.md)
- [Upgrade/migrasi/rollback](docs/UPGRADE_V42.md)
- [Catatan rilis](docs/RELEASE_NOTES_V42.md)

Validasi Google/VPS asli masih pending karena akses tidak tersedia di lingkungan pengembangan. Fast path memerlukan metadata versi Drive dengan Service Account yang sama; bila tidak tersedia, pembuktian bounded lebih lambat. Tidak ada janji waktu live <60 detik. Snapshot dibatasi 8 MiB per tab/tanggal dan 64 MiB per Run; ledger/audit tidak dihapus otomatis. Laporan V4.1/V4/V3 dipertahankan di folder docs.
